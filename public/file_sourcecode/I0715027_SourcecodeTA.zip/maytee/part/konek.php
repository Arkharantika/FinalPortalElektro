<?php
$konek=mysqli_connect([HOST],[USERNAME],[PASSWORD]);
mysqli_select_db($konek,[DB_NAME]);