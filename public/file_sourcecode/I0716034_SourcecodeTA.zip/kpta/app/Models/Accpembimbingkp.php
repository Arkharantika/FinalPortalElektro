<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Accpembimbingkp extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'kp_acc_pembimbing';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    //protected $fillable = ['sks','ipk'];
    protected $guarded = [];
}
