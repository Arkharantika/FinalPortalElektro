/*
 Navicat Premium Data Transfer

 Source Server         : portal
 Source Server Type    : MySQL
 Source Server Version : 100137
 Source Host           : si.ft.uns.ac.id:3306
 Source Schema         : dbportalelektro

 Target Server Type    : MySQL
 Target Server Version : 100137
 File Encoding         : 65001

 Date: 04/08/2020 22:25:38
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for bebas_lab
-- ----------------------------
DROP TABLE IF EXISTS `bebas_lab`;
CREATE TABLE `bebas_lab`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mahasiswa_id` int(15) NULL DEFAULT NULL,
  `kalab_sel` tinyint(6) NULL DEFAULT 0,
  `tgl_kalab_sel` date NULL DEFAULT NULL,
  `kalab_ik` tinyint(6) NULL DEFAULT 0,
  `tgl_kalab_ik` date NULL DEFAULT NULL,
  `kalab_elektronika` tinyint(6) NULL DEFAULT 0,
  `tgl_kalab_elektronika` date NULL DEFAULT NULL,
  `laboran_elektronika` tinyint(6) NULL DEFAULT 0,
  `tgl_laboran_elektronika` date NULL DEFAULT NULL,
  `kalab_tele` tinyint(6) NULL DEFAULT 0,
  `tgl_kalab_tele` date NULL DEFAULT NULL,
  `pembimbing_akademik` tinyint(6) NULL DEFAULT 0,
  `tgl_pembimbing_akademik` date NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of bebas_lab
-- ----------------------------
INSERT INTO `bebas_lab` VALUES (1, 102, 1, '2020-08-04', 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, '2020-08-04 21:52:43', '2020-08-04 21:52:43');
INSERT INTO `bebas_lab` VALUES (2, 100, 1, '2020-08-04', 0, NULL, 0, NULL, 0, NULL, 0, NULL, 0, NULL, '2020-08-04 21:53:36', '2020-08-04 21:53:36');

-- ----------------------------
-- Table structure for biodata_alumni
-- ----------------------------
DROP TABLE IF EXISTS `biodata_alumni`;
CREATE TABLE `biodata_alumni`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mahasiswa_id` int(15) NULL DEFAULT NULL,
  `nama` varchar(191) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `nim` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tempat_lahir` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `tgl_lahir` date NULL DEFAULT NULL,
  `agama` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `jenis_kelamin` tinyint(6) NULL DEFAULT NULL,
  `tgl_masuk` date NULL DEFAULT NULL,
  `tgl_lulus` date NULL DEFAULT NULL,
  `alamat` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `no_rumah` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `no_hp` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `nilai_ta` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ipk_terakhir` double(6, 2) NULL DEFAULT NULL,
  `capaian_sks` int(11) NULL DEFAULT NULL,
  `masa_studi` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `bidang_ilmu` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `judul_ind` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `judul_eng` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `acc_pembimbing` tinyint(6) NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of biodata_alumni
-- ----------------------------
INSERT INTO `biodata_alumni` VALUES (1, 88, 'Kevin Sebastian', 'I0716018', 'Karanganyar', '1998-04-21', 'Kristen', 1, '2016-08-01', '2020-07-24', 'Jl. Angsana no 13 perum jaten permai indah, Karanganyar', 'kscdh6@gmail.com', '-', '0895383293004', '93.2 (A)', 3.12, 144, '4 Tahun', 'Teknologi Informasi dan Komunikasi', 'Sistem Informasi Manajemen Energi berbasis Internet of Things (IoT) dengan metode Rapid Application Development (RAD)', 'Internet of Things (IoT) based Energy Management Information System with Rapid Application Development (RAD) Method', 0, '2020-08-01 23:01:06', '2020-08-01 23:01:06');
INSERT INTO `biodata_alumni` VALUES (2, 85, 'Ghufron Husnan', 'I0716015', 'Purworejo', '1998-06-19', 'Islam', 1, '2016-08-01', '2020-07-30', 'Bendo RT 01/02 buntalan Klaten Tengah Klaten Jawa Tengah', 'ghufronhusnan99@gmail.com', '-', '081249684939', '86.9 (A)', 3.01, 144, '4 Tahun', 'Sistem Energi Listrik', 'Analisa Efisiensi Penggunaan Water Cooling pada Photovoltaic Cell di Solar Tracker', 'Analysis of Efficient of the water cooling usage on photovoltaic cell in solar tracker', 1, '2020-08-03 11:07:57', '2020-08-04 09:42:06');
INSERT INTO `biodata_alumni` VALUES (3, 71, 'Adip Safiudin', 'I0716001', 'Jepara', '1999-04-24', 'Islam', 1, '2016-08-01', '2020-07-29', 'Desa Tritis 03/04 Nalumsari Jepara', 'adip240499@student.uns.ac.id', '-', '08224285509', '89.3 (A)', 3.53, 145, '4 Tahun', 'Teknologi Informasi dan Komunikasi', 'Pengembangan Sistem Informasi Outcome Based Education (OBE) Berbasis Website dengan Metode Rapid Application Development (RAD).', 'The Development Of Web-Based Outcome Based \r\nEducation (OBE) Information Systems With Rapid Application Development (RAD) Methods', 0, '2020-08-03 11:48:16', '2020-08-04 12:08:03');
INSERT INTO `biodata_alumni` VALUES (4, 104, 'Yudhi Prabowo Kusuma', 'I0716034', 'Wonogiri', '1997-11-02', 'Islam', 1, '2016-08-01', '2020-07-10', 'Krompakan RT 02/03, Pule, Selogiri, Wonogiri', 'yudhie123@gmail.com', '-', '085226666877', '90 (A)', 3.59, 144, '4 Tahun', 'Teknologi Informasi dan Komputer', 'Sistem Informasi Portal Elektro dengan Metode Rapid Application Development (RAD) Menggunakan Framework Laravel', 'Information System Portal Elektro Using Rapid Application Development (Rad) Method and Laravel Framework', 0, '2020-08-04 01:08:03', '2020-08-04 01:08:03');
INSERT INTO `biodata_alumni` VALUES (5, 102, 'Vernanda Sitorini Zul Hizmi', 'I0716032', 'Karanganyar', '1998-06-29', 'ISLAM', 2, '2016-08-22', '2020-07-20', 'Silamat RT 03/ RW 12, Ngringo, Jaten, Karanganyar, Jawa Tengah', 'vernandasitorinizulhizmi@gmail.com', '-', '085728525599', '88.9 (A)', 3.77, 145, '4 Tahun', 'Sistem Mekatronika', 'Sistem Kendali Posisi VTOL (Vertical Take Off Landing) dengan Metode ANFIS Menggunakan Interface Simulink', 'Position Control System VTOL (Vertical Take Off Landing) Using ANFIS Method with Simulink Interface', 0, '2020-08-04 13:14:25', '2020-08-04 13:45:42');

-- ----------------------------
-- Table structure for exit_survey
-- ----------------------------
DROP TABLE IF EXISTS `exit_survey`;
CREATE TABLE `exit_survey`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mahasiswa_id` int(15) NULL DEFAULT NULL,
  `nama` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `nim` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sosmed` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `linkedin` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `alamat` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `no_hp` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `PB1` tinyint(6) NULL DEFAULT NULL,
  `PB2` tinyint(6) NULL DEFAULT NULL,
  `PB3` tinyint(6) NULL DEFAULT NULL,
  `PB4` tinyint(6) NULL DEFAULT NULL,
  `PB5` tinyint(6) NULL DEFAULT NULL,
  `PB6` tinyint(6) NULL DEFAULT NULL,
  `PB7` tinyint(6) NULL DEFAULT NULL,
  `PB8` tinyint(6) NULL DEFAULT NULL,
  `PB9` tinyint(6) NULL DEFAULT NULL,
  `PB10` tinyint(6) NULL DEFAULT NULL,
  `PB11` tinyint(6) NULL DEFAULT NULL,
  `PB12` tinyint(6) NULL DEFAULT NULL,
  `PB13` tinyint(6) NULL DEFAULT NULL,
  `PB14` tinyint(6) NULL DEFAULT NULL,
  `PB15` tinyint(6) NULL DEFAULT NULL,
  `PB16` tinyint(6) NULL DEFAULT NULL,
  `PB17` tinyint(6) NULL DEFAULT NULL,
  `PB18` tinyint(6) NULL DEFAULT NULL,
  `PB19` tinyint(6) NULL DEFAULT NULL,
  `PB20` tinyint(6) NULL DEFAULT NULL,
  `PB21` tinyint(6) NULL DEFAULT NULL,
  `PB22` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `LP1` tinyint(6) NULL DEFAULT NULL,
  `LP2` tinyint(6) NULL DEFAULT NULL,
  `LP3` tinyint(6) NULL DEFAULT NULL,
  `LP4` tinyint(6) NULL DEFAULT NULL,
  `LP5` tinyint(6) NULL DEFAULT NULL,
  `LP6` tinyint(6) NULL DEFAULT NULL,
  `LP7` tinyint(6) NULL DEFAULT NULL,
  `LP8` tinyint(6) NULL DEFAULT NULL,
  `LP9` tinyint(6) NULL DEFAULT NULL,
  `LP10` tinyint(6) NULL DEFAULT NULL,
  `LP11` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `PGP1` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `PGP2` tinyint(6) NULL DEFAULT NULL,
  `PGP3` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `PGP4` tinyint(6) NULL DEFAULT NULL,
  `PGP5` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `PTA1` tinyint(6) NULL DEFAULT NULL,
  `PTA2` tinyint(6) NULL DEFAULT NULL,
  `PTA3` tinyint(6) NULL DEFAULT NULL,
  `PTA4` tinyint(6) NULL DEFAULT NULL,
  `PTA5` tinyint(6) NULL DEFAULT NULL,
  `PTA6` tinyint(6) NULL DEFAULT NULL,
  `PTA7` tinyint(6) NULL DEFAULT NULL,
  `PTA8` tinyint(6) NULL DEFAULT NULL,
  `PTA9` tinyint(6) NULL DEFAULT NULL,
  `PTA10` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `acc_koorta` tinyint(6) NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of exit_survey
-- ----------------------------
INSERT INTO `exit_survey` VALUES (1, 102, 'Vernanda Sitorini Zul Hizmi', 'I0716032', 'vernandasitorinizulhizmi@gmail.com', 'https://www.instagram.com/vnandaszh/', 'https://www.linkedin.com/in/vernanda-sitorini-zul-hizmi-916aab1a7/', 'Silamat RT 3/ RW 12, Ngringo, Jaten, Karanganyar, Jawa Tengah', '085728525599', 5, 3, 4, 5, 5, 4, 5, 5, 5, 5, 4, 4, 5, 5, 5, 5, 4, 5, 5, 4, 4, 'Diharapkan bisa lebih tertib perihal jam masuk dan selesai perkuliahan.', 5, 4, 5, 4, 4, 5, 4, 4, 5, 4, 'Diaharapkan setiap mahasiswa wajib minimal mengikuti penelitian dari Dosen', '1', 2, '-', 2, '-', 4, 5, 5, 5, 5, 4, 4, 4, 4, 'Tugas Akhir yang memiliki keluaran alat mungkin selanjutnya dapat ditaruh di lab yang sesuai.', 0, '2020-08-04 13:42:00', '2020-08-04 13:42:00');
INSERT INTO `exit_survey` VALUES (2, 104, 'Yudhi Prabowo Kusuma', 'I0716034', 'yudhie123@gmail.com', '-', '-', 'Krompakan RT 02/03, Pule, Selogiri, Wonogiri', '085226666877', 4, 4, 3, 4, 4, 4, 3, 4, 4, 3, 3, 4, 3, 4, 4, 4, 4, 4, 4, 3, 3, 'Sebaiknya untuk mahasiswa yang terlambat diberikan sanksi yang sama, terkadang ada mahasiswa yang karena sudah merasa dekat dengan dosen lalu menyepelekan datang terlambat dan tetap masuk dalam absensi.', 4, 4, 3, 3, 4, 3, 4, 4, 4, 4, 'Pembelajaran yang menanamkan kedisiplinan dalam ujian sehingga kemampuan individu dari mahasiswa tersebut dapat dipetakan dengan lebih jelas.', '1', 2, '-', 2, '-', 5, 4, 4, 4, 4, 5, 5, 5, 4, 'Kedepannya untuk Tugas Akhir dalam alur revisi mahasiswa diberikan kejelasan.', 0, '2020-08-04 14:29:08', '2020-08-04 14:29:08');

-- ----------------------------
-- Table structure for failed_jobs
-- ----------------------------
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for hal_pengesahan
-- ----------------------------
DROP TABLE IF EXISTS `hal_pengesahan`;
CREATE TABLE `hal_pengesahan`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mahasiswa_id` int(15) NULL DEFAULT NULL,
  `PB1` tinyint(6) NULL DEFAULT 0,
  `PB2` tinyint(6) NULL DEFAULT 0,
  `PJ1` tinyint(6) NULL DEFAULT 0,
  `PJ2` tinyint(6) NULL DEFAULT 0,
  `koor_ta` tinyint(6) NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of hal_pengesahan
-- ----------------------------
INSERT INTO `hal_pengesahan` VALUES (1, 102, 1, 1, 0, 1, 0, '2020-08-04 16:31:13', '2020-08-04 21:52:10');
INSERT INTO `hal_pengesahan` VALUES (2, 33, 0, 1, 0, 0, 0, '2020-08-04 16:35:46', '2020-08-04 16:35:46');
INSERT INTO `hal_pengesahan` VALUES (3, 100, 1, 0, 0, 0, 0, '2020-08-04 21:53:17', '2020-08-04 21:53:17');

-- ----------------------------
-- Table structure for koordinator_kbk
-- ----------------------------
DROP TABLE IF EXISTS `koordinator_kbk`;
CREATE TABLE `koordinator_kbk`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `ta_id` int(15) NOT NULL,
  `koordinator` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `peminatan` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `status_kbk` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `koordinator_kbk_ibfk_1`(`ta_id`) USING BTREE,
  CONSTRAINT `koordinator_kbk_ibfk_1` FOREIGN KEY (`ta_id`) REFERENCES `ta` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 41 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of koordinator_kbk
-- ----------------------------
INSERT INTO `koordinator_kbk` VALUES (8, 33, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2019-05-27 00:00:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (9, 34, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2019-05-29 00:00:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (10, 35, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2019-05-29 00:00:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (11, 36, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2019-07-04 00:00:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (12, 37, 'Hari Maghfiroh M.Eng.', 'Sistem Mekatronika (SM)', 'SETUJU', '2019-07-10 00:00:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (13, 38, 'Hari Maghfiroh M.Eng.', 'Sistem Mekatronika (SM)', 'SETUJU', '2019-07-10 00:00:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (14, 39, 'Hari Maghfiroh M.Eng.', 'Sistem Mekatronika (SM)', 'SETUJU', '2019-08-28 00:00:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (15, 40, 'Hari Maghfiroh M.Eng.', 'Sistem Mekatronika (SM)', 'SETUJU', '2020-01-27 00:01:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (16, 41, 'Sutrisno S.T., M.Sc, Ph.D.', 'Teknologi Informasi dan Komunikasi (ICT)', 'SETUJU', '2020-01-27 00:02:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (17, 42, 'Sutrisno S.T., M.Sc, Ph.D.', 'Teknologi Informasi dan Komunikasi (ICT)', 'SETUJU', '2020-01-27 00:03:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (18, 43, 'Hari Maghfiroh M.Eng.', 'Sistem Mekatronika (SM)', 'SETUJU', '2020-01-27 00:04:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (19, 44, 'Sutrisno S.T., M.Sc, Ph.D.', 'Teknologi Informasi dan Komunikasi (ICT)', 'SETUJU', '2020-01-27 00:05:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (20, 45, 'Hari Maghfiroh M.Eng.', 'Sistem Mekatronika (SM)', 'SETUJU', '2020-01-27 00:06:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (21, 46, 'Sutrisno S.T., M.Sc, Ph.D.', 'Teknologi Informasi dan Komunikasi (ICT)', 'SETUJU', '2020-01-27 00:07:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (22, 47, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2020-03-16 00:01:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (23, 48, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2020-03-16 00:02:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (24, 49, 'Hari Maghfiroh M.Eng.', 'Sistem Mekatronika (SM)', 'SETUJU', '2020-03-16 00:03:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (25, 50, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2020-03-16 00:04:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (26, 51, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2020-03-16 00:05:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (27, 52, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2020-03-16 00:06:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (28, 53, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2020-03-16 00:07:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (29, 54, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2020-03-16 00:08:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (30, 55, 'Hari Maghfiroh M.Eng.', 'Sistem Mekatronika (SM)', 'SETUJU', '2020-03-16 00:09:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (31, 56, 'Sutrisno S.T., M.Sc, Ph.D.', 'Teknologi Informasi dan Komunikasi (ICT)', 'SETUJU', '2020-03-16 00:10:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (32, 57, 'Sutrisno S.T., M.Sc, Ph.D.', 'Teknologi Informasi dan Komunikasi (ICT)', 'SETUJU', '2020-03-16 00:11:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (33, 58, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2020-03-16 00:12:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (34, 59, 'Hari Maghfiroh M.Eng.', 'Sistem Mekatronika (SM)', 'SETUJU', '2020-03-16 00:13:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (35, 60, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2020-03-16 00:14:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (36, 61, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2020-03-16 00:15:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (37, 62, 'Chico Hermanu Brillianto Apribowo S.T., M.Eng.', 'Sistem Energi Listrik (SEL)', 'SETUJU', '2020-03-16 00:16:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (38, 63, 'Hari Maghfiroh M.Eng.', 'Sistem Mekatronika (SM)', 'SETUJU', '2020-03-16 00:17:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (39, 64, 'Hari Maghfiroh M.Eng.', 'Sistem Mekatronika (SM)', 'SETUJU', '2020-03-16 00:18:00', NULL);
INSERT INTO `koordinator_kbk` VALUES (40, 65, 'Hari Maghfiroh M.Eng.', 'Sistem Mekatronika (SM)', 'SETUJU', '2020-03-16 00:19:00', NULL);

-- ----------------------------
-- Table structure for kp
-- ----------------------------
DROP TABLE IF EXISTS `kp`;
CREATE TABLE `kp`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `mahasiswa_id` int(15) NOT NULL,
  `ipk` float NULL DEFAULT NULL,
  `sks` int(10) NULL DEFAULT NULL,
  `tgl_ajuan` timestamp(0) NULL DEFAULT NULL,
  `perusahaan_nama` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `perusahaan_almt` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `perusahaan_jenis` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `pic` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `tgl_mulai_kp` date NULL DEFAULT NULL,
  `tgl_selesai_kp` date NULL DEFAULT NULL,
  `status_kp` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `kp`(`mahasiswa_id`) USING BTREE,
  CONSTRAINT `kp_ibfk_1` FOREIGN KEY (`mahasiswa_id`) REFERENCES `ref_mahasiswa` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 211 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of kp
-- ----------------------------
INSERT INTO `kp` VALUES (48, 17, 3.73, 108, '2017-02-13 13:04:00', 'PT GMF AeroAsia', 'Kompleks Bandara Internasional Soekarno Hatta, Cengkareng, Banten', 'Penerbangan', '', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (49, 34, 3.5, 105, '2017-06-20 10:26:00', 'PT Premier Oil', 'Jl. Jendral Sudirman kav. 52-53 Central Jakarta - 12190', 'Minyak dan Gas', 'Recruitment Specialist', '2017-07-17', '2017-09-16', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (50, 2, 3, 100, '2017-03-31 09:32:00', 'PT. ABC', 'Jl.Sudirman no 1 Jakarta', 'Elektro', 'Manager HRD', '2017-07-03', '2017-08-04', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (51, 31, 3.2, 97, '2017-02-28 17:41:00', 'PT. AIR MEDIA PERSADA', 'Ruko PERMAI No.8 Lt.2&3, Jl. Magelang Km. 4,6 YOGYAKARTA', 'Layanan Jasa Teknologi Informasi - Perancangan Software Sistem Informasi berbasis Web', 'Pimpinan PT. Air Media Persada', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (52, 6, 3.18, 102, '2017-06-19 12:50:00', 'PT. Pertamina Hulu Energi', 'Jalan TB. Simatupang Kav. 99, Jakarta Selatan 12520', 'Perusahaan minyak dan gas bumi', 'Direktur Pengembangan PT. PHE', '2017-07-17', '2017-08-16', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (53, 11, 3.17, 102, '2017-06-19 13:05:00', 'PT. Indonesia Power UBP Mrica', 'Jl. Raya Banyumas KM. 8. Kota, Banjarnegara, Jawa Tengah 53471', 'Pembangkit Listrik Tenaga Air', 'Pelaksana Administrasi Karir', '2017-07-17', '2017-08-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (54, 15, 2.69, 83, '2017-06-20 13:13:00', 'PT. GMF AeroAsia', 'Soekarno Hatta International Airport, Cengkareng - Indonesia PO. BOX 1303', 'Maintenance Facilities', 'HR Specialist', '2017-07-17', '2017-09-01', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (55, 20, 3.2, 104, '2017-06-22 10:27:00', 'PT GMF AeroAsia', 'Soekarno-Hatta International Airport PO. BOX 1303 Cengkareng - Indonesia', 'Maintenance Facility', 'HR Spesialist', '2017-07-17', '2017-09-01', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (56, 21, 2.76, 92, '2018-02-08 13:08:00', 'PT. GMF Aeroasia', 'Bandara Soekarno-Hatta cengkareng, Indonesia', 'Maintenance Pesawat Terbang', 'HRD Specialist', '2018-02-13', '2018-03-14', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (57, 32, 3.17, 98, '2017-03-22 14:41:00', 'PT. Indocement Tunggal Prakarsa Tbk.', 'Citeureup factory. Jln. Mayor Oking Jayaatmaja Citeureup - Cibinong', 'Produsen Semen', 'Corp. People Development Departement Head', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (58, 28, 2.99, 95, '2017-03-22 14:42:00', 'PT. Indocement Tunggal Prakarsa Tbk.', 'Citeureup Factory. Jl. Mayor Oking Jayaatmaja Citeureup-Cibinong', 'Produsen Semen', 'Corp.People Development Department Head', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (59, 4, 3.46, 107, '2017-03-22 14:42:00', 'PT. Indocement Tunggal Prakarsa Tbk.', 'Citeureup factory. Jln. Mayor Oking Jayaatmaja Citeureup - Cibinong', 'Produsen Semen', 'Corp. People Development Departement Head', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (60, 5, 3.16, 105, '2017-03-30 13:45:00', 'PT. Indocement Tunggal Prakarsa Tbk.', 'Citeureup Factory. Jl.Mayor Oking Jayaatmaja, Citeureup-Cibinong', 'Produsen Semen', 'Corp. People Development Department Head', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (61, 17, 3.73, 108, '2017-06-20 12:08:00', 'PT Dirgantara Indonesia', 'Jl. Padjajaran no.154 Bandung', 'Penerbangan', 'Kepala Divisi Sumber Daya Manusia', '2017-07-24', '2017-08-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (62, 1, 3.6, 105, '2017-06-06 11:10:00', 'PT Dirgantara Indonesia', 'Jalan Padjajaran No.154, Bandung 40174', 'Penerbangan', 'Kepala Divisi Sumber Daya Manusia', '2017-07-24', '2017-08-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (63, 29, 3.23, 105, '2017-06-19 12:42:00', 'PT. PLN TJBB', 'Jalan Ehave, Gandul, Cinere, Gandul, Cinere, Kota Depok, Jawa Barat 16514', 'Transmisi Jaringan Listrik', 'Manager KSA TJBB', '2017-07-24', '2017-08-25', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (64, 19, 3.44, 105, '2017-06-19 12:59:00', 'PT PLN TJBB', 'Jalan Ehave, Gandul, Cinere, Gandul, Cinere, Kota Depok, Jawa Barat 16514', 'Transmisi Jaringan Listrik', 'Manager KSA PT PLN TJBB', '2017-07-24', '2017-08-25', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (65, 13, 3.25, 109, '2017-04-12 11:05:00', 'INDONESIA POWER UNIT PEMBANGKITAN SEMARANG', 'Jl. Ronggowarsito Komplek Pelabuhan Tanjung Emas Semarang 50127, Indonesia', 'Pembangkit Listrik, Distrubusi Listrik', 'Kepala SDM', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (66, 3, 2.96, 99, '2017-06-21 12:39:00', 'Petrochina International Jabung Ltd.', 'Menara Kuningan, 25th Floor. Jl. H.R Rasuna Said, Block X7 Kav. 5 Jakarta Indonesia', 'Energy ( Oil & Gas ) ', 'HR Manager ', '2017-07-10', '2017-09-09', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (67, 13, 3.25, 109, '2017-07-17 13:33:00', 'PT INDONESlA POWER SUB UNIT PLTA WONOGIRI', 'Desa Donoharjo, Kec. Wonogiri Kab. Wonogiri, PO Box 5', 'Pembangkit Listrik, Distrubusi Listrik', 'Kepala SDM', '2017-07-20', '2017-08-20', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (68, 48, 3.45, 88, '2018-01-10 10:07:00', 'PT GS Battery', 'Kawasan Surya Cipta Swadaya, Jl. Surya Utama Kav. I3 - I4, Karawang Timur, Kutamekar, Ciampel, Kabupaten Karawang, Jawa Barat 41363', 'Baterai', 'HR IR Dept Head', '2018-01-15', '2018-03-15', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (69, 16, 3.74, 131, '2018-01-10 10:05:00', 'PT GS Battery', 'Kawasan Surya Cipta Swadaya, Jl. Surya Utama Kav. I3 - I4, Karawang Timur, Kutamekar, Ciampel, Kabupaten Karawang, Jawa Barat 41363', 'Baterai', 'HR IR Dept. Head', '2018-01-15', '2018-03-15', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (70, 68, 3.75, 88, '2017-12-06 15:10:00', 'PT XL Axiata Tbk.', 'Graha XL, Jl. Mega Kuningan Lot E4-7 No.1 Kawasan Mega Kuningan, Jakarta 12950, Indonesia', 'Operator telekomunikasi seluler', 'Presiden Direktur', '2018-01-11', '2018-02-11', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (71, 61, 3.31, 86, '2018-01-04 08:54:00', 'PLN APP KARAWANG', 'Jl. Raya Kosambi-Klari, Karawang, Jawa Barat', 'Kelistrikan', 'Manager APP', '2018-01-14', '2018-02-28', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (72, 59, 3.13, 88, '2017-12-06 15:15:00', 'PT. Pelayanan Listrik Nasional Batam', 'Jl. Engku Putri No. 03 Batam Centre', 'Kelistrikan', 'Finance Division', '2018-01-14', '2018-02-16', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (73, 64, 3.12, 86, '2017-12-27 12:16:00', 'PT. Yodya Karya', 'Jalan Mayjen DI Panjaitan Kav 8 Cipinang Besar Selatan Jatinegara RT/RW 5/11, Jakarta Timur.', 'Konsultansi Konstruksi', 'HRD Department', '2018-01-15', '2018-02-16', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (74, 63, 3.21, 86, '2018-01-08 10:41:00', 'PT PLN (Persero) TJBB', 'Jl. JCC Krukut Limo, Cinere 16514, Jakarta Selatan', 'Kelistrikan', 'Supervisor SDM', '2018-01-22', '2018-02-23', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (75, 43, 3.41, 88, '2017-12-27 12:17:00', 'PT. Yodya Karya', 'Jalan Mayjen DI Panjaitan Kav 8 Cipinang Besar Selatan Jatinegara RT/RW 5/11, Jakarta Timur', 'Konsultansi Konstruksi', 'HRD Department', '2018-01-15', '2018-02-16', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (76, 32, 3, 86, '2018-01-08 10:38:00', 'PT PLN (Persero) TJBB', 'Jl. JCC Krukut Limo, Cinere 16514, Jakarta Selatan', 'Kelistrikan', 'Supervisor SDM', '2018-01-22', '2018-02-23', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (77, 60, 2.7, 75, '2017-09-12 14:26:00', 'PT. PLN (Persero) TJBB', 'Jalan JCC Krukut Limo, Cinere 16514, Jakarta Selatan', 'Kelistrikan', 'Supervisor SDM', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (78, 35, 3.06, 86, '2017-12-06 15:21:00', 'PLN APP KARAWANG', 'Jl. Raya Kosambi-Klari, Karawang, Jawa Barat', 'Kelistrikan', 'Manager APP', '2018-01-14', '2018-02-28', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (79, 58, 3.06, 83, '2017-12-27 13:58:00', 'PT Telekomunikasi Selular', 'Jl. Jend. Gatot Subroto Kav. 52  Jakarta Selatan 12710', 'Telekomunikasi', 'GM HCM Management ', '2018-01-01', '2018-02-28', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (80, 50, 3.43, 88, '2017-12-27 13:59:00', 'PT Telekomunikasi Selular', 'Jl. Jend. Gatot Subroto Kav. 52  Jakarta Selatan 12710', 'Telekomunikasi', 'GM HCM Management ', '2018-01-01', '2018-02-28', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (81, 31, 3.27, 121, '2018-03-14 10:02:00', 'PT. INKA (Persero)', 'Jl Yos Sudarso No. 71 Madiun Jawa Timur Ã¢â‚¬â€œ Indonesia', 'Industri Pembuatan Kereta Api', 'Kabag Personalia', '2018-09-03', '2018-10-06', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (82, 4, 3.42, 128, '2017-10-16 13:27:00', 'PT. INKA (Persero)', 'Jl. Yos Sudarso No. 71 Madiun Jawa Timur - Indonesia', 'Industri Pembuatan Kereta Api', 'Kabag Personalia', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (83, 36, 3.05, 88, '2017-10-27 07:14:00', 'PT Surya Energi Indotama', 'Gedung C Lt.2, Jl. Soekarno Hatta No. 442, Pasirluyu, Bandung, Kota Bandung, Jawa Barat 40254', 'Penyedia manufaktur modul surya di Indonesia', 'Kepala Bagian SDM dan Umum', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (84, 47, 3.45, 88, '2017-10-27 07:14:00', 'PT. Surya Energi Indotama', 'Gedung C Lt.2, Jl. Soekarno Hatta No. 442, Pasirluyu, Bandung, Kota Bandung, Jawa Barat 40254, Indonesia', 'Penyedia Manufaktur Modul Surya Di Indonesia', 'Kepala Bagian SDM dan Umum', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (85, 56, 2.96, 83, '2017-10-25 22:55:00', 'PT Kone Indo Elevator', 'KEM Tower, 7th Floor Jl. LandasanPacu Barat Blok B10, Kav.2 GunungSahari Selatan,, RW.10, South Gunung Sahari, Kemayoran, Jakarta', 'Manufacture Elevator', 'National Tools and Equipment Manager', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (86, 67, 3.05, 88, '2017-10-26 09:12:00', 'PT.PLN (PERSERO) AREA MAGELANG', 'Jalan Jenderal Ahmad Yani No. 14, Magelang Utara, Panjang, Magelang, Kota Magelang, Jawa Tengah ', 'Perseroan Terbatas', 'Manager', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (87, 53, 2.93, 85, '2018-01-18 13:03:00', 'PT. PLN  Persero Area Jawa Tengah', 'Jl. Pemuda No.93, Semarang Tengah, Kota Semarang, Jawa Tengah', 'Kelistrikan', 'Manajer Area', '2018-01-22', '2018-03-02', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (88, 49, 3.39, 88, '2018-01-18 13:02:00', 'PT. PLN Persero Area Jawa Tengah', 'Jl. Pemuda No.93, Semarang Tengah, Kota Semarang, Jawa Tengah', 'Kelistrikan', 'Manajer Area', '2018-01-22', '2018-03-02', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (89, 33, 3.29, 88, '2018-01-18 09:50:00', 'PT. PLN Persero Area Jawa Tengah', 'Jl. Pemuda No.93, Semarang Tengah, Kota Semarang, Jawa Tengah', 'Kelistrikan', 'Manajer Area', '2018-01-22', '2018-03-02', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (90, 51, 3.03, 88, '2017-10-27 10:40:00', 'PT PLN Persero Transmisi Jawa Bagian Barat', 'Jalan Ehave, Gandul, Cinere, Kota Depok, Jawa Barat 16514', 'BUMN ', 'Supervisor bidang admnistrasi dan SDM ', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (91, 54, 3.15, 88, '2017-10-30 13:18:00', 'PT INDONESIA POWER Sub Unit PLTA Jelok', 'Desa Delik, Kec. Tuntang, Kab. Semarang', 'Pembangkitan Kelistrikan', 'Administrasi Umum', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (92, 55, 2.96, 84, '2017-10-30 13:22:00', 'PT INDONESIA POWER Sub Unit PLTA Jelok', 'Desa Delik, Kec. Tuntang, Kab. Semarang', 'Pembangkitan Kelistrikan', 'Administrasi Umum', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (93, 28, 3.09, 115, '2017-12-27 14:37:00', 'PT. INDONESlA POWER SUB UNIT PLTA WONOGIRI', 'Desa Donoharjo, Kec. Wonogiri Kab. Wonogiri, PO Box 5', 'Pembangkit Listrik, Distrubusi Listrik', 'Pelaksana Senior Umum', '2018-01-02', '2018-01-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (94, 44, 3.02, 104, '2018-07-20 14:24:00', 'PT ASKI', 'Jl. Raya Mayor Oking Jaya Atmaja, Karang Asem Bar., Citeureup, Bogor, Jawa Barat 16810', 'Manufaktur', 'Human Resource Departement', '2018-07-23', '2018-09-22', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (95, 7, 3.44, 125, '2018-03-02 14:06:00', 'PT. Purimet Metropolitan', 'Jl. Majapahit No. 18, 20, 22 Blok A / 116 Kel. Petojo Selatan, Kec. Gambir, Jakarta Pusat', 'Perdagangan besar mesin, peralatan dan perlengkapan lainnya', 'Direktur', '2018-03-05', '2018-04-06', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (96, 4, 3.42, 128, '2018-01-10 08:49:00', 'PT. Indonesia Power Sub Unit PLTA Wonogiri', 'Jalan Karang Talun, Pokohkidul, Kecamatan Wonogiri, Kec. Wonogiri, Jawa Tengah 57615', 'Pembangkit Listrik', 'Kepala HRD PLTA Mrica', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (97, 4, 3.42, 128, '2018-03-19 10:30:00', 'PT. Indonesia Power Sub Unit PLTA Mrica', 'Jl. Raya Banyumas KM 8 Banjarnegara 53471', 'Pembangkit Listrik', 'Kepala HRD PLTA Mrica', '2018-07-01', '2018-07-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (98, 55, 2.96, 84, '2018-07-03 14:26:00', '. Indonesia Power Unit Pembangkit Mrica ( UP MRC )', 'Jl. Raya Banyumas KM.8 Banjarnegara, Jawa Tengah', 'Pembangkitan Kelistrikan', 'General Manager', '2018-07-23', '2018-08-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (99, 67, 3.05, 88, '2018-07-03 09:27:00', 'PT. PLN (PERSERO) AREA MAGELANG', 'Jl. A. Yani No. 14, Magelang Utara , Magelang, Kota Magelang, Jawa Tengah', 'Perseroan Terbatas', 'Manager', '2018-07-23', '2018-08-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (100, 54, 3.15, 88, '2018-07-03 14:24:00', 'PT INDONESIA POWER Unit Pembagkitan Mrica', 'Jl. Raya Banyumas KM. 8 Banjarnegara, Jawa Tengah 53471 ', 'Pembangkitan Kelistrikan', 'General Manager ', '2018-07-23', '2018-08-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (101, 46, 2.82, 99, '2018-04-17 12:59:00', 'PT Garuda Maintenance Facility Aero Asia', 'Soekarno Hatta International Airport  Cengkareng - Indonesia,  PO. BOX 1303 BUSH 19100', 'Maintenance Facilities', 'HR Specialist', '2018-07-23', '2018-09-07', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (102, 63, 3.13, 107, '2018-03-02 14:36:00', 'PT PJB UP Muara Karang', 'Jl. Pluit Karang Ayu Barat No.1, RT.12/RW.3, Pluit, Penjaringan, Kota Jkt Utara, Daerah Khusus Ibukota Jakarta 14450', 'Listrik', 'Supervisor Bagian Umum dan CSR', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (103, 60, 2.8, 93, '2018-05-24 13:14:00', 'PT. PLN (Persero) Pusat Sertifikasi', 'Jalan Laboratorium, Duren Tiga, Pancoran, RT.6/RW.1, Duren Tiga, Pancoran, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12760', 'Kelistrikan', 'Manajer Keuangan SDM dan Adiministrasi', '2018-07-23', '2018-08-24', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (104, 45, 3.28, 109, '2018-03-02 14:37:00', 'PT PJB UP Muara Karang', 'Jl. Pluit Karang Ayu Barat No.1, RT.12/RW.3, Pluit, Penjaringan, Kota Jkt Utara, Daerah Khusus Ibukota Jakarta 14450', 'Listrik', 'Supervisor Bagian Umum dan CSR', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (105, 40, 2.83, 90, '2018-03-02 14:40:00', 'PT PJB UP Muara Karang', 'Jl. Pluit Karang Ayu Barat No.1, RT.12/RW.3, Pluit, Penjaringan, Kota Jkt Utara, Daerah Khusus Ibukota Jakarta 14450', 'Listrik', 'Supervisor Bagian Umum dan CSR', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (106, 39, 3.19, 107, '2018-07-20 14:20:00', 'PT ASKI', 'Jl. Raya Mayor Oking KM. 2.2 No. 1, Karang Asem Barat, Citeureup, Bogor, Jawa Barat 16810', 'Manufaktur', 'Human Resource Departement Head', '2018-07-23', '2018-09-22', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (107, 70, 3.28, 107, '2018-07-17 11:18:00', 'Badan Tenaga Nuklir Nasional (BATAN)', 'Jl. Babarsari - Kotak Pos 6101 YKBB, Yogyakarta 55281', 'Pusat Sains dan Teknologi Akselerator (PSTA)', 'Kepala Pusat Sains dan Teknologi Akselerator', '2018-07-23', '2018-08-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (108, 38, 3, 103, '2018-07-20 14:23:00', 'PT. ASKI', 'Jl. Raya Mayor Oking KM. 2.2 No. 1, Karang Asem Barat, Citeureup, Bogor, Jawa Barat 16810', 'Manufaktur', 'Human Resource Departement Head', '2018-07-23', '2018-09-22', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (109, 41, 2.87, 125, '2019-06-24 12:47:00', 'PT Rekaindo Global Jasa', 'Jl. Candi Sewu No.30, Madiun Lor, Mangu Harjo, Kota Madiun, Jawa Timur 63122', 'Manufacture', 'Bagian SDM', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (110, 47, 3.48, 111, '2018-07-03 14:02:00', 'PT. Holcim Indonesia Tbk. Plant Cilacap', 'Jalan Ir. H. Juanda Cilacap, Jawa Tengah', 'Perusahaan Produksi Semen Nasional', 'Bagian HRD', '2018-07-16', '2018-08-24', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (111, 32, 3.23, 134, '2018-05-21 09:29:00', 'PT. Tiga Serangkai Pustaka Mandiri', 'Jalan Dr. Supomo No. 23 Solo 57141, Surakarta, Jawa Tengah', 'Percetakan Buku', 'IT Manager', '2018-05-14', '2018-06-13', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (112, 8, 3.2, 145, '2018-06-29 13:54:00', 'PT. Indonesia Power', 'Jalan Laba Terusan Panimbang Desa Sukamaju Kecamatan Labuan, Kabupaten Pandeglang, Banten', 'Jasa Pembangkit Listrik', 'Manajer Administrasi Indonesia Power Labuan', '2018-07-02', '2018-07-30', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (113, 5, 3.28, 141, '2018-06-29 13:53:00', 'PT. Indonesia Power', 'Jalan Laba Terusan Panimbang Desa Sukamaju Kecamatan Labuan, Kabupaten Pandeglang, Banten', 'Jasa Pembangkit Listrik', 'Manajer Administrasi Indonesia Power Labuan', '2018-07-02', '2018-07-30', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (114, 36, 3.11, 111, '2018-05-09 22:17:00', 'PT Bhimasena Research and Development', 'Jalan Bandung-Sumedang, Cibeusi, Jatinangor, Kabupaten Sumedang, Jawa Barat 45363', 'Pengembang teknologi dalam bidang otomotif, aerospace, energi, dan industri', 'Kepala HRD Bagian Administrasi', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (115, 27, 3.11, 111, '2018-05-11 00:05:00', 'PT. Indonesia Power', 'Jl. Laba Terusan Panimbang Desa Sukamaju Kec Labuan, Kab Pandeglang, Banten', 'Jasa Pembangkit Listrik', 'Manajer Administrasi Indonesia Power Labuan', '0000-00-00', '0000-00-00', '', NULL);
INSERT INTO `kp` VALUES (116, 56, 3.02, 104, '2018-07-10 13:01:00', 'PT PLN (Persero) Transmisi - Jawa Bagian Tengah APP Karawang', 'Jl. Raya Kosambi-Klari,Pancawati, Karawang, Jawa Barat', 'Kelistrikan Negara', 'Supervisor Administrasi dan SDM', '2018-07-16', '2018-08-16', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (117, 65, 3.26, 108, '2018-07-10 13:04:00', 'PT. PLN APP Karawang', 'Jalan Raya Kosambi No.1, Rt.2/Rw.7, Pancawati, Karawang, Kabupaten Karawang, Jawa Barat 41371', 'Kelistrikan', 'Supervisor Administrasi dan SDM', '2018-07-16', '2018-08-16', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (118, 36, 3.11, 111, '2018-07-13 09:52:00', 'PT PLN (Persero) Transmisi - Jawa Bagian Tengah APP Karawang', 'Jl. Raya Kosambi-Klari,Pancawati, Karawang, Jawa Barat', 'Kelistrikan Negara', 'Supervisor Administrasi dan SDM', '2018-07-16', '2018-08-16', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (119, 51, 3.07, 109, '2018-07-03 12:35:00', 'PT PLN (PERSERO) APP Cawang', 'Jalan Cililitan Besar No 1, Cawang,  Cililitan,  Jakarta Timur 13640', 'BUMN ', 'Bagian SDM ', '2018-07-16', '2018-08-17', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (120, 40, 2.83, 90, '2018-07-13 10:32:00', 'PT Telkom Witel Yogyakarta', 'Jl. Yos Sudarso No.9, 001, Kotabaru, Gondokusuman, Kota Yogyakarta, Daerah Istimewa Yogyakarta 55224', 'Telekomunikasi', 'GM Witel Yogyakarta', '2018-07-16', '2018-08-30', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (121, 62, 3.13, 107, '2018-07-13 08:55:00', 'PT Telkom Witel Yogyakarta', 'Jl. Yos Sudarso no 9, 001, Kotabaru, Gondokusuman, Yogyakarta 55224', 'Telekomunikasi', 'GM Witel Yogyakarta', '2018-07-16', '2018-08-30', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (122, 45, 3.28, 109, '2018-07-13 09:17:00', 'PT Telkom Witel Yogyakarta', 'Jl. Yos Sudarso no 9, Kotabaru, Gondokusuman, Yogyakarta 55224', 'Telekomunikasi', 'GM Witel Yogyakarta', '2018-07-16', '2018-08-30', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (123, 81, 3.59, 64, '2018-10-24 09:17:00', 'PT. Pembangkitan Jawa Bali', 'Jl. PLTGU Muara Tawar No. 1, Segarajaya, Tarumajaya, Bekasi, Jawa Barat', 'Unit Pembangkitan PLTGU Muara Tawar', 'Supervisor SDM', '2019-01-18', '2019-02-17', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (124, 103, 3.22, 64, '2018-10-24 09:23:00', 'PT Pembangkitan Jawa Bali ', 'Jl. PLTGU Muara Tawar No.1, Segaraja, Tarumajaya, Bekasi, Jawa Barat. 17212', 'Unit Pembangkit PLTGU Muara Tawar', 'Supervisor SDM', '2019-01-18', '2019-02-17', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (125, 30, 3.3, 137, '2018-09-03 12:46:00', 'PT Praja Ghupta Utama', 'Jalan Sultan Iskandar Muda 7 BC Kebayoran Lama, Jakarta Selatan', 'General Trading, Construction', 'Project Manager', '2018-09-03', '2018-10-07', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (126, 90, 3.02, 86, '2018-08-30 10:13:00', 'Pasifik Satelit Nusantara', 'Kantor Taman A9 Unit C3-C4 Lot. 8/9 Jl. DR. Ide Anak Agung Gde Agung No. 9 Mega Kuningan, Jakarta Selatan 12950 Indonesia', 'Telekomunikasi', 'Kepala Bagian Recruitment', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (127, 73, 3.22, 88, '2018-08-21 10:11:00', 'PT Bukit Asam Tbk', 'JL. PARIGI NO.1 TANJUNG ENIM 31716 SUMATERA SELATAN', 'Pertambangan', 'SM. SDM Stratejik PT. Bukit Asam, Tbk. Cq. Manager', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (128, 84, 3.08, 86, '2018-12-20 11:04:00', 'UPT Balai Yasa Yogyakarta PT KAI', 'Jl. Kusbini No.01, Klitren, Gondokusuman, Kota Yogyakarta, Daerah Istimewa Yogyakarta', 'Perusahaan Transportasi', 'Assistant Manager Sumber Daya Manusia(SDM)', '2019-01-21', '2019-03-01', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (129, 76, 3.4, 88, '2018-08-30 10:13:00', 'Pasifik Satelit Nusantara', 'Kantor Taman A9 Unit C3-C4 Lot. 8/9 Jl. Ide Anak Agung Gde Agung No.9 Mega Kuningan, Jakarta Selatan 12950 Indonesia', 'Telekomunikasi', 'Kepala Bagian Recruitment', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (130, 97, 3.21, 88, '2018-09-09 11:31:00', 'PT. PLN Persero - Distribusi Jawa Timur', 'Jl. Embong Trengguli No.19-21, Embong Kaliasin, Genteng, Kota Surabaya, Jawa Timur', 'Distribusi dan Manajemen Listrik', 'Manajer SDM', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (131, 96, 3.58, 88, '2018-10-24 09:48:00', 'PT Star Energy Geothermal Powerplant', 'Desa Margamukti, Kecamatan Pangalengan, Kabupaten Bandung, Jawa Barat 40379', 'Powerplant', 'Operations Superintendent', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (132, 91, 3.1, 86, '2019-06-25 13:15:00', 'PT Indonesia Power Unit Pembangkitan Semarang', 'Jl. Ronggowarsito, Tj. Mas, Semarang Utara, Kota Semarang, Jawa Tengah 50174', 'BUMN', 'General Manager', '2019-08-01', '2019-08-30', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (133, 86, 3.27, 107, '2019-05-15 11:48:00', 'PT. Formulatrix Indonesia', 'Jl. Soekarno - Hatta No.121, Cebongan, Argomulyo, Kota Salatiga, Jawa Tengah 50731', 'Manufaktur', 'HRD Manager', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (134, 102, 3.72, 88, '2019-01-04 10:24:00', 'PT. DIRGANTARA INDONESIA', 'Jl. Pajajaran No. 154 Bandung 40174', 'Bergerak di sektor industri pesawat terbang', 'Kepala Manager HRD', '2019-01-15', '2019-02-14', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (135, 98, 3.37, 86, '2019-06-11 13:57:00', 'PT Angkasa Pura II', 'Bandara Internasional Halim Perdana Kusumah Jl. Protokol Halim Perdanakusuma Jakarta 13610', 'Pelayanan jasa kebandarudaraan', 'General Manager', '2019-07-01', '2019-08-30', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (136, 74, 3.62, 88, '2018-12-04 15:05:00', 'PT. PERTAMINA (Persero) Refinery Unit IV Cilacap', 'Jl. Mt. Haryono No.77, Rawakeong, Lomanis, Cilacap Tengah, Kabupaten Cilacap, Jawa Tengah', 'Pengolahan Minyak', 'Humas Capital Manager RU IV Cilacap', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (137, 85, 2.55, 74, '2019-06-28 12:24:00', 'PJB Academy Kampus Cirata', 'Jl. PLTA Cirata, Cadassari, Tegal Waru, Purwakarta Regency, West Java 41165', 'Pembangkit Listrik Tenaga Surya', 'Supervisor PJB Academy', '2019-07-22', '2019-08-23', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (138, 87, 3, 103, '2019-07-18 10:21:00', 'Airnav Indonesia', 'Perum LPPNPI Kantor Cabang Surabaya Administration & Operational Building Lantai 2 Bandara Juanda', 'Perusahaan yang menyediakan layanan lalu lintas penerbangan yang mengutamakan keselamatan, nyaman da', 'Staff Administrasi', '2019-07-29', '2019-09-06', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (139, 82, 3.59, 88, '2019-05-20 13:29:00', 'PT. PERTAMINA (Persero) Refinery Unit IV', 'Jl. Mt. Haryono No.77, Rawakeong, Lomanis, Cilacap Tengah, Kabupaten Cilacap, Jawa Tengah 53221', 'Pengolahan Minyak', 'Human Capital Manager RU IV Cilacap', '2019-07-01', '2019-08-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (140, 79, 3.17, 86, '2018-11-01 15:28:00', 'PLTU PACITAN 1 JAWA TIMUR-PACITAN', 'Jl.Pacitan Trenggalek Km.55 Desa Sukorejo, Kecamatan Sudimoro,Kabupaten Pacitan,Jawa Timur,Indonesia', 'PLTU', 'Supervisor SDM', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (141, 93, 3.2, 86, '2018-09-18 22:35:00', 'Star Energy', 'Jl. Jayanegara, Kabandungan, Sukabumi, Jawa Barat 43368', 'Geothermal Power Plant', 'Human Resources Department', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (142, 97, 3.21, 88, '2019-06-25 13:11:00', 'PT. Indonesia Power UP Semarang', 'Jl. Ronggowarsito, Tj. Mas, Semarang Utara, Kota Semarang, Jawa Tengah 50174', 'Pembangkit Tenaga Listrik', 'General Manager', '2019-08-01', '2019-08-30', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (143, 104, 3.45, 86, '2019-01-08 13:37:00', 'PT Telkomsel', 'Jl. Gatot Subroto No.Kav. 52, RT.6/RW.1, Kuningan Bar., Mampang Prpt., Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12710', 'Operator Seluler', 'Human Capital Management (HCM) Up. Bpk Eko Prasety', '2019-01-18', '2019-02-22', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (144, 71, 3.4, 86, '2019-01-08 14:07:00', 'PT.Telkomsel', 'Jl. Gatot Subroto No.Kav. 52, RT.6/RW.1, Kuningan Bar., Mampang Prpt., Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12710', 'Operator Seluler', 'Human Capital Management (HCM) Up. Bpk Eko Prasety', '2019-01-18', '2019-02-22', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (145, 89, 3.31, 86, '2018-11-01 15:29:00', 'PLTU Pacitan 1 Jawa Timur - Pacitan', 'Jl. Pacitan Trenggalek Km. 55 Desa Sukorejo,  Kecamatan Sudimoro, Kabupaten Pacitan, Jawa Timur, Indonesia', 'PLTU', 'Supervisor SDM', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (146, 73, 3.22, 88, '2018-11-26 15:22:00', 'PT. PERTAMINA (Persero) Refinery Unit IV', 'Jl. Mt. Haryono No.77, Rawakeong, Lomanis, Cilacap Tengah, Kabupaten Cilacap, Jawa Tengah 53221', 'Pengolahan Minyak', 'Human Capital Manager RU IV Cilacap', '0000-00-00', '0000-00-00', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (147, 88, 2.87, 82, '2019-01-15 09:30:00', 'PT. Telkomsel', 'Jl. Gatot Subroto No.Kav 52, RT.6/RW.1, Kuningan Bar., Mampang Prpt., Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12710', 'Operator Seluler', 'Human Capital Management Up. Bapak Eko Prasetyo', '2019-01-18', '2019-02-22', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (148, 76, 3.4, 88, '2019-01-04 10:38:00', 'PT. TELKOM AKSES SEMARANG', 'Jl. Singotoro No.20, Semarang, Jawa Tengah, 50256', 'Telekomunikasi', 'Operation Senior Manager', '2019-01-14', '2019-02-22', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (149, 90, 3.02, 86, '2019-01-04 10:40:00', 'PT. TELKOM AKSES SEMARANG', 'Jl. Singotoro No.20, Semarang, Jawa Tengah, 50256', 'Telekomunikasi', 'Operation Senior Manager', '2019-01-14', '2019-02-22', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (150, 89, 3.31, 86, '2019-06-27 10:07:00', 'PT. Pembangkitan Jawa-Bali Unit Pembangkitan Cirata', 'Desa Cadas Sari, Kecamatan Tegal Waru, Plered Purwakarta 41162', 'PLTA', 'General Manager', '2019-07-22', '2019-08-23', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (151, 79, 3.17, 86, '2019-06-26 13:41:00', 'PT. Pembangkitan Jawa Bali Unit Pembangkitan Cirata', 'Desa Cadas Sari, Kecamatan Tegal Waru, Plered, Kabupaten Purwakarta, Jawa Barat 41162', 'PLTA', 'General Manager', '2019-07-23', '2019-08-23', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (152, 100, 3.07, 86, '2019-01-03 14:23:00', 'PT Star Energy Geothermal Powerplant', 'Perkebunan Kertamanah, Desa Margamukti, Pangalengan, Margamukti, Pangalengan, Bandung, Jawa Barat 40378', 'Pembangkit Listrik', 'Human Resource Department', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (153, 96, 3.58, 88, '2019-06-26 13:51:00', 'PJB Academy Kampus Cirata', 'Desa Cerdas Sari, Kecamatan Tegal Waru, Plered Purwakarta 41165', 'PLTS', 'PJB Academy Kampus Cirata u.p. Bapak Aditya Cahya ', '2019-07-22', '2019-08-23', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (154, 93, 3.25, 107, '2019-02-11 10:51:00', 'PT. Sorik Marapi', 'Recapital Building, Jalan Adityawarman No.55 Jakarta Selatan, DKI Jakarta 12160', 'Geothermal Power', 'Human Resources Department', '2019-02-15', '2019-03-15', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (155, 74, 3.63, 109, '2019-05-22 13:46:00', 'PT Pertamina (Persero) RU IV Cilacap', 'Jl. Mt. Haryono No.77, Rawakeong, Lomanis, Cilacap Tengah, Kabupaten Cilacap, Jawa Tengah', 'Pengolahan Minyak', 'Humas Capital Manager RU IV Cilacap', '2019-07-01', '2019-08-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (157, 100, 3.08, 107, '2019-05-23 12:53:00', 'PT PERTAMINA (PERSERO) REFINERY UNIT IV', 'Jl. MT. Haryono No.77, Rawakeong, Lomanis, Cilacap Tengah, Kabupaten Cilacap, Jawa Tengah 53221', 'Kilang Minyak', 'Human Resource Department', '2019-07-01', '2019-08-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (158, 122, 3.07, 80, '2019-10-07 15:01:00', 'PT.Toyota Motor Manufacturing Indonesia', 'Jl. Yos Sudarso Sunter II Jakarta Utara 14330', 'Motor Manufacturing', 'HRD', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (159, 72, 3.2, 105, '2019-05-27 12:29:00', 'Airnav Indonesia', 'Perum LPPNPI Kantor Cabang Surabaya Administration & Operational Building Lantai 2 Bandara Juanda', 'Perusahaan yang menyediakan layanan lalu lintas penerbangan yang mengutamakan keselamatan, nyaman da', 'Staff Administrasi', '2019-07-29', '2019-09-06', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (160, 86, 3.27, 107, '2019-07-01 14:01:00', 'PT UMG Idealab', 'Jl. Tangkas Baru No.2, RT.8/RW.2, Karet Semanggi, Setiabudi, Jakarta Selatan, Jakarta 12930', 'Tech Startup Incubator', 'CEO UMG Idealab', '2019-07-22', '2019-08-22', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (161, 42, 2.91, 134, '2019-06-21 15:22:00', 'PT. Rekaindo Global Jasa', 'Jl. Candi Sewu No.30, Madiun Lor, Mangu Harjo, Kota Madiun, Jawa Timur', 'Manufacture', 'Bagian SDM', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (162, 37, 3.43, 148, '2019-06-21 15:25:00', 'PT. Rekaindo Global Jasa', 'Jl. Candi Sewu No.30, Madiun Lor, Mangu Harjo, Kota Madiun, Jawa Timur', 'Manufacture', 'Bagian SDM', '0000-00-00', '0000-00-00', 'TOLAK', NULL);
INSERT INTO `kp` VALUES (164, 121, 3.68, 84, '2019-12-05 15:14:00', 'PT Indonesia Power Unit Jasa Pemeliharaan', 'jl. Aipda KS Tubun no 8, Jakarta Barat', 'Unit Pembangkit', 'Manajer Administrasi', '2020-01-27', '2020-02-29', 'SETUJU', '2020-07-29 19:21:43');
INSERT INTO `kp` VALUES (165, 99, 3.29, 109, '2019-07-15 12:08:00', 'PT. Astra Komponen Indonesia', 'Jl. Raya Mayor Oking KM. 2.2 No. 1, Karang Asem Barat, Citeureup. Bogor, Jawa Barat 16810', 'Perancangan dan Pembuatan Komponen', 'HR Sect. Head', '0000-00-00', '0000-00-00', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (166, 37, 3.43, 148, '2019-08-01 12:52:00', 'P.T. Rekaindo Global Jasa', 'Jl. Candi Sewu No.30, Madiun Lor, Mangu Harjo, Kota Madiun, Jawa Timur', 'Manufacture', 'Bagian SDM', '2019-08-13', '2019-09-27', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (167, 41, 2.87, 125, '2019-07-31 13:08:00', 'P.T. Rekaindo Global Jasa', 'Jl. Candi Sewu No.30, Madiun Lor, Mangu Harjo, Kota Madiun, Jawa Timur 63122', 'Manufacture', 'Bagian SDM', '2019-08-13', '2019-09-27', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (168, 42, 2.91, 134, '2019-07-31 13:23:00', 'P.T. Rekaindo Global Jasa', 'Jl. Candi Sewu No.30, Madiun Lor, Mangu Harjo, Kota Madiun, Jawa Timur', 'Manufacture', 'Bagian SDM', '2019-08-13', '2019-09-27', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (169, 110, 3.42, 82, '2019-12-30 09:34:00', 'PT Indonesia Power UP Semarang', 'Jl. Coaster, Jl. Ronggowarsito Komplek Pelabuhan, Tj. Mas, Kecamatan Semarang Utara, Kota Semarang, Jawa Tengah 50174', 'Pembangkit', 'General Manajer', '2020-01-02', '2020-01-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (170, 112, 3.15, 84, '2019-12-30 09:32:00', 'PT Indonesia Power UP Semarang', 'Jl. Coaster, Jl.Ronggowarsito Komplek Pelabuhan, Tj.Mas, Kec.Semarang Utara, Kota Semarang, Jawa Tengah 50174', 'Pembangkit Listrik', 'General Manager', '2020-01-02', '2020-01-31', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (171, 105, 3.58, 86, '2019-12-23 14:30:00', 'Lentera Bumi Nusantara', 'Jl. Raya Ciheras, Kp. Sindang Asih RT. 02/RW. 02 Dusun Lembur Tengah, Desa Ciheras Kec. Cipatujah, Tasikmalaya', 'Lembaga Riset Energi Baru Terbarukan', 'Chief Executive Officer', '2020-01-20', '2020-02-24', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (172, 130, 3.06, 104, '2019-10-24 10:48:00', 'PT. Dirgantara Indonesia \r\n', 'Jalan Pajajaran No. 154 Bandung 40174 Jawa Barat - Indonesia\r\n', 'Industri Pesawat Terbang \r\n', 'HRD\r\n', '2020-02-11', '2020-05-14', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (173, 111, 3.38, 84, '2020-01-10 13:10:00', 'PT.BAKTI NUGRAHA YUDA ENERGY', 'Jalan Desa Terusan, Tanjung Kemala, Bati Raja Oku, Sumatera Selatan  ', 'PLTU (10 x 2 MW) ', 'Manager HRD and GA', '2020-01-20', '2020-02-20', 'SETUJU', '2020-07-29 19:56:19');
INSERT INTO `kp` VALUES (174, 143, 3.68, 82, '2020-01-10 13:55:00', 'PT. Bakti Nugraha Yuda Energy', 'Jalan Desa Terusan, Tanjung Kemala, Batu Raja Oku, Sumatera Selatan', 'PLTU (2 x 10MW)', 'Manager HRD and GA', '2020-01-20', '2020-02-20', 'SETUJU', '2020-07-29 07:42:20');
INSERT INTO `kp` VALUES (175, 139, 3.48, 84, '2019-09-02 12:23:00', 'PT. Pertamina (Persero) RU IV Cilacap', 'Jl. Letjen Haryono MT. 77 Lomanis,  Cilacap Jawa Tengah', 'Pertambangan', 'Manager Human Capital', '2020-01-20', '2020-02-29', 'TOLAK', '2020-07-10 13:43:49');
INSERT INTO `kp` VALUES (176, 116, 3.49, 84, '2020-01-13 10:32:00', 'PT Hino Motors Manufacturing Indonesia', 'Kawasan Industri Kota Bukit Indah. Jl. Damar Blok D1 No.1. Purwakarta. 41181. Jawa Barat - Indonesia', 'Industri pembuatan motor diesel, Industri perakitan kendaraan', 'Kepala Bagian HRD', '2020-01-21', '2020-02-28', 'SETUJU', '2020-07-28 13:08:58');
INSERT INTO `kp` VALUES (177, 129, 2.84, 82, '2019-09-04 15:17:00', 'PT PERTAMINA (PERSERO) Unit Pengolahan IV Cilacap', 'Jl. Letjen Haryono MT. 77 Lomanis,  Cilacap Jawa Tengah 53221 ', 'Pertambangan', 'Manager Human Capital', '2020-01-20', '2020-02-29', 'TOLAK', '2020-08-03 09:41:19');
INSERT INTO `kp` VALUES (178, 114, 3.19, 84, '2019-12-31 13:03:00', 'PT. DIRGANTARA INDONESIA', 'Jalan Pajajaran No. 154  Bandung 40174  West Java - Indonesia', 'Penerbangan', 'HRD PT. DI', '2020-02-05', '2020-03-05', 'SETUJU', '2020-07-30 14:21:11');
INSERT INTO `kp` VALUES (179, 145, 3.58, 84, '2020-01-03 13:12:00', 'B2TKE BPPT', 'Gd 620 Kawasan PUSPIPTEK, Setu, Tangerang Selatan 15314', 'Balai Besar Teknologi Konversi Energi', 'Kepala B2TKE', '2020-01-20', '2020-02-29', 'SETUJU', '2020-07-30 15:01:30');
INSERT INTO `kp` VALUES (180, 127, 3.32, 84, '2019-12-31 12:48:00', 'B2TKE BPPT', 'Gd 620 Kawasan PUSPIPTEK, Setu, Tangerang Selatan 15314', 'Balai Besar Teknologi Konversi Energi', 'Kepala B2TKE', '2020-01-20', '2020-02-29', 'SETUJU', '2020-07-28 10:57:29');
INSERT INTO `kp` VALUES (181, 115, 3.38, 84, '2019-12-31 12:45:00', 'Lentera Bumi Nusantara', 'Jalan Raya Ciheras, Kampung Sindang Asih, RT 02/RW 02, Dusun Lembur Tengah, Desa Ciheras, Cipatujuh, Jawa Barat, Indonesia 46189', 'Lembaga Riset Energi Baru Terbarukan', 'Chief Executive Officer Lentera Bumi Nusantara', '2020-01-20', '2020-02-24', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (183, 132, 3.23, 84, '2020-01-03 13:47:00', 'PT Dirgantara Indonesia', 'Jalan Pajajaran No. 154  Bandung 40174 ', 'Pesawat Terbang', 'Kadiv SDM PT. Dirgantara Indonesia', '2020-01-28', '2020-02-27', 'SETUJU', '2020-07-29 20:53:58');
INSERT INTO `kp` VALUES (184, 108, 2.95, 84, '2019-12-23 15:24:00', 'PT PLN Persero UIW Unit Pelaksana Pengatur Distribusi Kalimantan Barat', 'Jl. Ismail Marzuki No. 15, Pontianak 78243', 'BUMN (Kelistrikan)', 'Manager UP2D', '2020-01-27', '2020-02-27', 'SETUJU', '2020-07-30 12:30:43');
INSERT INTO `kp` VALUES (185, 141, 3.18, 82, '2020-01-27 13:09:00', 'PT. Sarihusada Generasi Mahardika Plant Yogyakarta', 'Jl. Kusumanegara No.173, Muja Muju, Kec. Umbulharjo, Kota Yogyakarta, Daerah Istimewa Yogyakarta 55165', 'Produksi Nutrisi Ibu Hamil dan Anak', 'Manager Engineering & HRD', '2020-02-01', '2020-03-31', 'SETUJU', '2020-07-14 16:55:13');
INSERT INTO `kp` VALUES (186, 122, 3.12, 80, '2020-01-15 10:46:00', 'PT TRIMITRA CHITRAHASTA', 'Delta Silicon 2 Industrial Estate Jl. Damar Blok F1 - 06 Lippo Cikarang, Bekasi 17550 Jawa Barat - Indonesia', 'Metal Stamping', 'Manager HRD', '2020-01-20', '2020-03-20', 'SETUJU', '2020-07-20 13:34:04');
INSERT INTO `kp` VALUES (187, 118, 3.34, 84, '2020-01-22 14:02:00', 'PT. INDONESIA POWER- Maintenance Service Unit Semarang', 'Jl. Ronggowarsito Komplek Pelabuhan Tanjung Emas Semarang 50127, Indonesia', 'Pembangkitan Tenaga Listrik', 'Manager Human Resource', '2020-01-27', '2020-02-29', 'SETUJU', NULL);
INSERT INTO `kp` VALUES (197, 133, 3.62, 126, '2020-03-16 11:02:00', 'Lab. Instrumentasi dan Kendali, FT UNS', 'Jl. Ir. Sutami 36A, Surakarta, Jawa Tengah', 'Laboratorium Pemerintah', 'Kepala Lab. Instrumentasi dan Kendali', '2020-07-27', '2020-08-30', 'SETUJU', '2020-07-27 09:46:36');
INSERT INTO `kp` VALUES (199, 106, 3.23, 126, '2020-07-14 12:06:20', 'Lab. Instrumentasi dan Kendali, FT UNS', 'Jalan Ir. Sutami 36 Kentingan, Jebres, Surakarta, Jawa Tengah, Indonesia 57126', 'Lab. Instrumentasi dan Kendali, FT UNS', 'Kepala Lab. Instrumentasi dan Kendali, FT UNS', '2020-07-27', '2020-08-30', 'SETUJU', '2020-07-27 09:45:25');
INSERT INTO `kp` VALUES (200, 109, 3.14, 126, '2020-07-14 13:35:51', 'Lab. Instrumentasi dan Kendali, FT UNS', 'Jl. Ir. Sutami 36A, Surakarta, Jawa Tengah', 'Laboratorium Pemerintah', 'Kepala Lab. Instrumentasi dan Kendali', '2020-07-27', '2020-08-30', 'SETUJU', '2020-07-24 15:00:13');
INSERT INTO `kp` VALUES (201, 120, 3.59, 124, '2020-07-15 17:19:24', 'Laboratorium Telekomunikasi FT UNS', 'Jalan Ir. Sutami 36 Kentingan, Jebres, Surakarta, Jawa Tengah, Indonesia 57126', 'Laboratorium Telekomunikasi FT UNS', 'Kepala Laboratorium Telekomunikasi', '2020-07-27', '2020-09-05', 'SETUJU', '2020-07-27 09:42:24');
INSERT INTO `kp` VALUES (202, 128, 3.66, 126, '2020-07-15 17:31:18', 'Lab. Instrumentasi dan Kendali, FT UNS', 'Jl. Ir. Sutami No. 36, Surakarta, Jawa Tengah', 'Laboratorium Pemerintah', 'Kepala Lab. Instrumentasi dan Kendali', '2020-07-27', '2020-08-30', 'SETUJU', '2020-07-24 14:58:55');
INSERT INTO `kp` VALUES (203, 119, 3.43, 126, '2020-07-15 19:05:24', 'Laboratorium Telekomunikasi FT UNS', 'Jalan Ir. Sutami 36 Kentingan, Jebres, Surakarta, Jawa Tengah, Indonesia 57126', 'Laboratorium Telekomunikasi FT UNS', 'Kepala Laboratorium Telekomunikasi FT UNS', '2020-07-27', '2020-09-05', 'SETUJU', '2020-07-27 09:41:28');
INSERT INTO `kp` VALUES (204, 125, 3.42, 126, '2020-07-15 21:08:42', 'Laboratorium Telekomunikasi dan Pengolahan Sinyal Program Studi Teknik Elektro Universitas Sebelas Maret', 'Jl. Ir. Sutami No.36 A, Jebres, Kec. Jebres, Kota Surakarta, Jawa Tengah 57126', 'Laboratorium', 'Kepala Laboratorium', '2020-07-27', '2020-09-05', 'SETUJU', '2020-07-27 09:40:26');
INSERT INTO `kp` VALUES (205, 139, 3.55, 125, '2020-07-16 13:05:42', 'Laboratorium Telekomunikasi FT UNS', 'Jalan Ir.Sutami 36 Kentingan, Jebres, Surakarta, Jawa Tengah, Indonesia 57126', 'Laboratorium Telekomunikasi FT UNS', 'Kepala Laboratorium Telekomunikasi FT UNS', '2020-07-27', '2020-09-05', 'SETUJU', '2020-07-27 09:37:28');
INSERT INTO `kp` VALUES (206, 117, 3.02, 121, '2020-07-17 13:59:06', 'Laboratorium Telekomunikasi dan Pengolahan Sinyal Program Studi Teknik Elektro, Fakultas Teknik, Universitas Sebelas Maret', 'Gedung 3 lt. 2 Fakultas Teknik Universitas Sebelas Maret, Jl. Ir.Sutami No.36A, Jebres, Kec. Jebres, Kota Surakarta, Jawa Tengah 57126', 'Laboratorium', 'Kepala Laboratorium Telekomunikasi dan Pengolahan Sinyal', '2020-07-27', '2020-09-05', 'SETUJU', '2020-07-27 09:36:49');
INSERT INTO `kp` VALUES (207, 137, 3.37, 127, '2020-07-17 20:16:18', 'Laboratorium Komputer dan Jaringan, Fakultas Teknik UNS', 'Jalan Ir. Sutami 36 Kentingan, Jebres, Surakarta, Jawa Tengah, Indonesia', 'Laboratorium Pemerintah', 'Kepala Laboratorium Komputer dan Jaringan, Fakultas Teknik UNS', '2020-07-27', '2020-08-31', 'SETUJU', '2020-07-27 09:36:10');
INSERT INTO `kp` VALUES (208, 134, 3.43, 125, '2020-07-17 20:57:46', 'Laboratorium Komputer dan Jaringan, Fakultas Teknik UNS', 'Jalan Ir. Sutami 36 Kentingan, Jebres, Surakarta, Jawa Tengah, Indonesia', 'Laboratorium Pemerintah', 'Kepala Laboratorium Komputer dan Jaringan, Fakultas Teknik UNS', '2020-07-27', '2020-08-31', 'SETUJU', '2020-07-27 09:35:18');
INSERT INTO `kp` VALUES (209, 57, 2.68, 128, '2020-07-20 09:32:36', 'Glolingo And Vridom Education Digital Startup', 'Jl. Candi 2C, No. 555, Karangbesuki, Malang, Jawa Timur', 'Startup Pendidikan', 'Chief Production Officer', '2020-05-14', '2020-06-26', 'SETUJU', '2020-07-23 09:05:03');
INSERT INTO `kp` VALUES (210, 126, 3.28, 128, '2020-08-03 14:42:54', 'Laboratorium Elektronika Teknik Elektro UNS', 'Jalan Ir. Sutami 36 Kentingan, Jebres, Surakarta, Jawa Tengah, Indonesia 57126', 'Laboratorium Universitas', 'Kepala Laboratorium Elektronika Teknik Elektro UNS', NULL, NULL, 'WAITING', '2020-08-03 15:50:27');

-- ----------------------------
-- Table structure for kp_acc
-- ----------------------------
DROP TABLE IF EXISTS `kp_acc`;
CREATE TABLE `kp_acc`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `kp_id` int(15) NULL DEFAULT NULL,
  `pengajuan` date NULL DEFAULT NULL,
  `permohonan` date NULL DEFAULT NULL,
  `penugasan` date NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `ibfk_kp4`(`kp_id`) USING BTREE,
  CONSTRAINT `ibfk_kp4` FOREIGN KEY (`kp_id`) REFERENCES `kp` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 183 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of kp_acc
-- ----------------------------
INSERT INTO `kp_acc` VALUES (20, 48, '2017-03-07', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (21, 49, '2017-02-28', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (22, 50, '2017-02-28', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (23, 51, '2017-08-30', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (24, 52, '2017-03-21', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (25, 53, '2017-03-15', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (26, 54, '2017-03-20', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (27, 55, '2017-03-20', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (28, 56, '2017-03-20', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (29, 57, '2018-04-02', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (30, 58, '2017-11-14', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (31, 59, '2017-10-16', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (32, 60, '2018-04-24', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (33, 61, '2017-04-03', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (34, 62, '2017-04-03', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (35, 63, '2017-04-07', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (36, 64, '2017-04-10', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (37, 65, '2017-06-12', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (38, 66, '2017-04-17', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (39, 67, '2017-06-13', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (40, 68, '2017-08-24', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (41, 69, '2017-08-24', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (42, 70, '2017-08-28', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (43, 71, '2017-08-31', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (44, 72, '2017-08-31', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (45, 73, '2017-09-13', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (46, 74, '2017-09-05', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (47, 75, '2017-09-13', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (48, 76, '2017-09-19', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (49, 77, '2018-02-28', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (50, 78, '2017-09-28', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (51, 79, '2017-10-02', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (52, 80, '2017-10-02', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (53, 81, '2017-10-13', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (54, 82, '2018-01-09', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (55, 83, '2018-05-09', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (56, 84, '2018-03-23', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (57, 85, '2018-05-21', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (58, 86, '2018-01-18', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (59, 87, '2017-10-27', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (60, 88, '2017-10-27', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (61, 89, '2017-10-27', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (62, 90, '2018-05-30', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (63, 91, '2018-01-08', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (64, 92, '2018-01-08', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (65, 93, '2017-12-06', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (66, 94, '2018-04-04', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (67, 95, '2018-01-11', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (68, 96, '2018-01-10', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (69, 97, '2018-01-10', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (70, 98, '2018-01-22', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (71, 99, '2018-01-22', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (72, 100, '2018-01-22', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (73, 101, '2018-02-28', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (74, 102, '2018-05-31', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (75, 103, '2018-03-01', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (76, 104, '2018-05-31', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (77, 105, '2018-05-31', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (78, 106, '2018-05-03', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (79, 107, '2018-03-28', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (80, 108, '2018-05-03', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (81, 109, '2019-07-23', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (82, 110, '2018-03-23', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (83, 111, '2018-04-11', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (84, 112, '2018-04-20', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (85, 113, '2018-05-18', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (86, 114, '2018-05-25', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (87, 115, '0000-00-00', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (88, 116, '2018-05-25', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (89, 117, '2018-05-28', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (90, 118, '2018-05-28', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (91, 119, '2018-05-31', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (92, 120, '2018-05-31', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (93, 121, '2018-05-31', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (94, 122, '2018-05-31', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (95, 123, '2018-07-03', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (96, 124, '2018-07-03', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (97, 125, '2018-07-19', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (98, 126, '2018-12-11', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (99, 127, '2018-11-26', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (100, 128, '2018-09-06', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (101, 129, '2018-12-11', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (102, 130, '2018-10-16', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (103, 131, '2019-01-07', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (104, 132, '2018-10-19', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (105, 133, '2019-05-29', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (106, 134, '2018-10-26', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (107, 135, '2018-09-26', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (108, 136, '2019-02-18', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (109, 137, '2019-01-03', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (110, 138, '2019-05-07', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (111, 139, '2018-11-26', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (112, 140, '2018-12-05', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (113, 141, '2019-02-06', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (114, 142, '2018-10-19', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (115, 143, '2018-10-24', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (116, 144, '2018-10-24', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (117, 145, '2018-12-13', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (118, 146, '2018-11-26', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (119, 147, '2018-12-12', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (120, 148, '2018-12-11', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (121, 149, '2018-12-11', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (122, 150, '2018-12-18', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (123, 151, '2018-12-20', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (124, 152, '2019-02-26', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (125, 153, '2019-01-10', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (126, 154, '2019-02-07', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (127, 155, '2019-02-20', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (129, 157, '2019-03-05', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (130, 158, '2020-01-03', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (131, 159, '2019-04-15', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (132, 160, '2019-06-12', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (133, 161, '2019-07-23', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (134, 162, '2019-07-23', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (136, 164, '2019-07-16', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (137, 165, '2019-07-15', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (138, 166, '2019-07-23', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (139, 167, '2019-07-23', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (140, 168, '2019-07-23', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (141, 169, '2019-07-31', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (142, 170, '2019-08-06', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (143, 171, '2019-08-08', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (144, 172, '2020-01-21', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (145, 173, '2019-12-02', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (146, 174, '0000-00-00', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (147, 175, '2019-09-10', '2020-07-10', NULL, NULL, '2020-07-10 13:36:07');
INSERT INTO `kp_acc` VALUES (148, 176, '2019-10-04', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (149, 177, '2019-09-12', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (150, 178, '2019-09-10', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (151, 179, '2019-09-11', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (152, 180, '2019-09-10', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (153, 181, '2019-09-12', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (155, 183, '2019-09-10', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (156, 184, '2019-09-19', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (157, 185, '2019-10-23', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (158, 186, '2020-01-14', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (159, 187, '2020-01-14', NULL, NULL, NULL, NULL);
INSERT INTO `kp_acc` VALUES (169, 197, '2020-07-20', '2020-07-23', '2020-07-27', NULL, '2020-07-27 09:46:36');
INSERT INTO `kp_acc` VALUES (171, 200, '2020-07-14', '2020-07-21', '2020-07-24', '2020-07-14 20:30:00', '2020-07-24 15:00:13');
INSERT INTO `kp_acc` VALUES (172, 199, '2020-07-14', '2020-07-21', '2020-07-27', '2020-07-14 20:30:25', '2020-07-27 09:45:26');
INSERT INTO `kp_acc` VALUES (173, 204, '2020-07-16', '2020-07-27', '2020-07-27', '2020-07-16 09:03:06', '2020-07-27 09:40:26');
INSERT INTO `kp_acc` VALUES (174, 203, '2020-07-16', '2020-07-20', '2020-07-27', '2020-07-16 09:03:16', '2020-07-27 09:41:28');
INSERT INTO `kp_acc` VALUES (175, 202, '2020-07-16', '2020-07-21', '2020-07-24', '2020-07-16 09:03:36', '2020-07-24 14:58:55');
INSERT INTO `kp_acc` VALUES (176, 201, '2020-07-16', '2020-07-20', '2020-07-27', '2020-07-16 09:05:02', '2020-07-27 09:42:24');
INSERT INTO `kp_acc` VALUES (177, 208, '2020-07-20', '2020-07-21', '2020-07-27', '2020-07-20 09:31:55', '2020-07-27 09:35:18');
INSERT INTO `kp_acc` VALUES (178, 207, '2020-07-20', '2020-07-21', '2020-07-27', '2020-07-20 09:32:14', '2020-07-27 09:36:10');
INSERT INTO `kp_acc` VALUES (179, 206, '2020-07-20', '2020-07-20', '2020-07-27', '2020-07-20 09:32:26', '2020-07-27 09:36:49');
INSERT INTO `kp_acc` VALUES (180, 205, '2020-07-20', '2020-07-20', '2020-07-27', '2020-07-20 09:32:34', '2020-07-27 09:37:28');
INSERT INTO `kp_acc` VALUES (181, 209, '2020-07-20', '2020-05-06', '2020-05-12', '2020-07-20 09:33:48', '2020-07-23 07:48:55');
INSERT INTO `kp_acc` VALUES (182, 210, '2020-08-03', NULL, NULL, '2020-08-03 15:50:27', '2020-08-03 15:50:27');

-- ----------------------------
-- Table structure for kp_acc_pembimbing
-- ----------------------------
DROP TABLE IF EXISTS `kp_acc_pembimbing`;
CREATE TABLE `kp_acc_pembimbing`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `mahasiswa_id` int(15) NULL DEFAULT NULL,
  `tempat_kp` tinyint(6) NULL DEFAULT 0,
  `proposal_kp` tinyint(6) NULL DEFAULT 0,
  `penugasan_kp` tinyint(6) NULL DEFAULT 0,
  `seminar_kp` tinyint(6) NULL DEFAULT 0,
  `laporan_kp` tinyint(6) NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `ibfk_mhs_id`(`mahasiswa_id`) USING BTREE,
  CONSTRAINT `ibfk_mhs_id` FOREIGN KEY (`mahasiswa_id`) REFERENCES `ref_mahasiswa` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 155 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of kp_acc_pembimbing
-- ----------------------------
INSERT INTO `kp_acc_pembimbing` VALUES (2, 139, 1, 1, 1, 0, 0, NULL, '2020-07-20 11:13:18');
INSERT INTO `kp_acc_pembimbing` VALUES (3, 17, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (4, 34, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (5, 2, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (6, 31, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (7, 6, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (8, 11, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (9, 15, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (10, 20, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (11, 21, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (12, 32, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (13, 28, 1, 1, 1, 1, 1, NULL, '2020-07-27 11:38:12');
INSERT INTO `kp_acc_pembimbing` VALUES (14, 4, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (15, 5, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (16, 17, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (17, 1, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (18, 29, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (19, 19, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (20, 13, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (21, 3, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (22, 13, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (23, 48, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (24, 16, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (25, 68, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (26, 61, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (27, 59, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (28, 64, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (29, 63, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (30, 43, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (31, 32, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (32, 60, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (33, 35, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (34, 58, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (35, 50, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (36, 31, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (37, 4, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (38, 36, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (39, 47, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (40, 56, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (41, 67, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (42, 53, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (43, 49, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (44, 33, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (45, 51, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (46, 54, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (47, 55, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (48, 28, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (49, 44, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (50, 7, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (51, 4, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (52, 4, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (53, 55, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (54, 67, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (55, 54, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (56, 46, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (57, 63, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (58, 60, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (59, 45, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (60, 40, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (61, 39, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (62, 70, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (63, 38, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (64, 41, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (65, 47, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (66, 32, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (67, 8, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (68, 5, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (69, 36, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (70, 27, 1, 1, 1, 1, 1, NULL, '2020-07-13 18:39:39');
INSERT INTO `kp_acc_pembimbing` VALUES (71, 56, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (72, 65, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (73, 36, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (74, 51, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (75, 40, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (76, 62, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (77, 45, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (78, 81, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (79, 103, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (80, 30, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (81, 90, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (82, 73, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (83, 84, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (84, 76, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (85, 97, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (86, 96, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (87, 91, 1, 1, 1, 1, 1, NULL, '2020-07-27 11:37:24');
INSERT INTO `kp_acc_pembimbing` VALUES (88, 86, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (89, 102, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (90, 98, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (91, 74, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (92, 85, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (93, 87, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (94, 82, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (95, 79, 1, 1, 1, 1, 1, NULL, '2020-07-27 11:37:39');
INSERT INTO `kp_acc_pembimbing` VALUES (96, 93, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (97, 97, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (98, 104, 1, 1, 1, 1, 1, NULL, '2020-07-27 11:36:56');
INSERT INTO `kp_acc_pembimbing` VALUES (99, 71, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (100, 89, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (101, 73, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (102, 88, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (103, 76, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (104, 90, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (105, 89, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (106, 79, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (107, 100, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (108, 96, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (109, 93, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (110, 74, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (112, 100, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (113, 122, 1, 1, 1, 1, 1, NULL, '2020-07-31 10:44:54');
INSERT INTO `kp_acc_pembimbing` VALUES (114, 72, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (115, 86, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (116, 42, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (117, 37, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (118, 125, 1, 1, 1, 0, 0, NULL, '2020-07-24 16:34:41');
INSERT INTO `kp_acc_pembimbing` VALUES (119, 121, 1, 1, 1, 1, 1, NULL, '2020-07-29 20:18:42');
INSERT INTO `kp_acc_pembimbing` VALUES (120, 99, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (121, 37, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (122, 41, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (123, 42, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (124, 110, 1, 1, 1, 1, 1, NULL, '2020-07-29 20:19:02');
INSERT INTO `kp_acc_pembimbing` VALUES (125, 112, 1, 1, 1, 1, 1, NULL, '2020-07-29 09:57:07');
INSERT INTO `kp_acc_pembimbing` VALUES (126, 105, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (127, 130, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (128, 111, 1, 1, 1, 1, 1, NULL, '2020-07-29 20:18:26');
INSERT INTO `kp_acc_pembimbing` VALUES (129, 143, 1, 1, 1, 1, 1, NULL, '2020-07-29 12:45:08');
INSERT INTO `kp_acc_pembimbing` VALUES (130, 116, 1, 1, 1, 1, 0, NULL, '2020-07-28 15:25:57');
INSERT INTO `kp_acc_pembimbing` VALUES (131, 129, 0, 0, 0, 0, 0, NULL, '2020-08-03 09:41:19');
INSERT INTO `kp_acc_pembimbing` VALUES (132, 114, 1, 1, 1, 1, 0, NULL, '2020-07-31 11:35:59');
INSERT INTO `kp_acc_pembimbing` VALUES (133, 145, 1, 1, 1, 1, 1, NULL, '2020-07-27 08:03:23');
INSERT INTO `kp_acc_pembimbing` VALUES (134, 127, 1, 1, 1, 1, 0, NULL, '2020-07-31 11:34:39');
INSERT INTO `kp_acc_pembimbing` VALUES (135, 115, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (136, 113, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (137, 132, 1, 1, 1, 1, 1, NULL, '2020-07-27 11:36:05');
INSERT INTO `kp_acc_pembimbing` VALUES (138, 108, 1, 1, 1, 1, 0, NULL, '2020-07-31 16:08:17');
INSERT INTO `kp_acc_pembimbing` VALUES (139, 141, 1, 1, 1, 1, 1, NULL, '2020-07-15 18:44:46');
INSERT INTO `kp_acc_pembimbing` VALUES (140, 122, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (141, 118, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (142, 164, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (143, 117, 1, 1, 1, 0, 0, NULL, '2020-07-24 16:35:00');
INSERT INTO `kp_acc_pembimbing` VALUES (144, 128, 1, 1, 1, 0, 0, NULL, '2020-07-24 14:37:55');
INSERT INTO `kp_acc_pembimbing` VALUES (145, 137, 1, 1, 1, 0, 0, NULL, '2020-07-27 08:27:51');
INSERT INTO `kp_acc_pembimbing` VALUES (146, 134, 1, 1, 1, 0, 0, NULL, '2020-07-27 08:28:03');
INSERT INTO `kp_acc_pembimbing` VALUES (147, 120, 1, 1, 1, 0, 0, NULL, '2020-07-27 08:11:29');
INSERT INTO `kp_acc_pembimbing` VALUES (148, 131, 0, 0, 0, 0, 0, NULL, NULL);
INSERT INTO `kp_acc_pembimbing` VALUES (149, 109, 1, 1, 1, 0, 0, NULL, '2020-07-24 14:43:33');
INSERT INTO `kp_acc_pembimbing` VALUES (150, 119, 1, 1, 1, 0, 0, NULL, '2020-07-27 08:11:50');
INSERT INTO `kp_acc_pembimbing` VALUES (151, 133, 1, 1, 1, 0, 0, NULL, '2020-07-24 15:57:43');
INSERT INTO `kp_acc_pembimbing` VALUES (152, 106, 1, 1, 1, 0, 0, '2020-07-14 11:25:24', '2020-07-24 14:38:19');
INSERT INTO `kp_acc_pembimbing` VALUES (153, 57, 1, 1, 1, 1, 1, '2020-07-16 10:48:06', '2020-08-04 14:46:37');
INSERT INTO `kp_acc_pembimbing` VALUES (154, 126, 1, 0, 0, 0, 0, '2020-08-03 14:21:37', '2020-08-03 14:21:37');

-- ----------------------------
-- Table structure for kp_dokumen
-- ----------------------------
DROP TABLE IF EXISTS `kp_dokumen`;
CREATE TABLE `kp_dokumen`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `kp_id` int(15) NULL DEFAULT NULL,
  `file_proposal` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `file_permohonan` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `file_balasan` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `file_penugasan` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `file_surattugas` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `file_selesaikp` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `file_presensi` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `file_laporan` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `file_nilai` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `ibfk_kp2`(`kp_id`) USING BTREE,
  CONSTRAINT `ibfk_kp2` FOREIGN KEY (`kp_id`) REFERENCES `kp` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 186 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of kp_dokumen
-- ----------------------------
INSERT INTO `kp_dokumen` VALUES (23, 48, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (24, 49, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714034_Berkas_PresensiKP.pdf\r\n', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (25, 50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (26, 51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (27, 52, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714006_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (28, 53, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714011_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (29, 54, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714015_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (30, 55, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714020_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (31, 56, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714021_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (32, 57, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (33, 58, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (34, 59, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (35, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (36, 61, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714017_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (37, 62, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714001_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (38, 63, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (39, 64, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714019_Berkas_PresensiKP.pdf\r\n', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (40, 65, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (41, 66, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714003_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (42, 67, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714013_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (43, 68, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715017_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (44, 69, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714016_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (45, 70, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715038_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (46, 71, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715031_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (47, 72, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715029_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (48, 73, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715034_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (49, 74, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715033_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (50, 75, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715012_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (51, 76, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715001_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (52, 77, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (53, 78, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715004_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (54, 79, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715028_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (55, 80, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715019_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (56, 81, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (57, 82, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (58, 83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (59, 84, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (60, 85, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (61, 86, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (62, 87, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715022_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (63, 88, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715018_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (64, 89, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715002_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (65, 90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (66, 91, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (67, 92, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (68, 93, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714028_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (69, 94, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715013_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (70, 95, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714007_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (71, 96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (72, 97, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714004_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (73, 98, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715025_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (74, 99, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715037_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (75, 100, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715024_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (76, 101, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715015_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (77, 102, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (78, 103, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715030_Berkas_PresensiKP.pdf\r\n', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (79, 104, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (80, 105, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (81, 106, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715008_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (82, 107, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715040_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (83, 108, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715007_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (84, 109, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (85, 110, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715016_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (86, 111, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714032_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (87, 112, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714008_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (88, 113, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714005_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (89, 114, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (90, 115, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (91, 116, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715026_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (92, 117, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715035_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (93, 118, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715005_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (94, 119, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715020_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (95, 120, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715009_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (96, 121, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715032_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (97, 122, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715014_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (98, 123, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716011_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (99, 124, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716033_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (100, 125, NULL, NULL, NULL, NULL, NULL, NULL, 'I0714030_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (101, 126, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (102, 127, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (103, 128, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716014_Berkas_PresensiKP.pdf\r\n', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (104, 129, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (105, 130, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (106, 131, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (107, 132, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716021_Berkas_PresensiKP.pdf\r\n', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (108, 133, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (109, 134, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716032_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (110, 135, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716028_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (111, 136, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (112, 137, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716015_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (113, 138, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716017_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (114, 139, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716012_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (115, 140, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (116, 141, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (117, 142, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716027_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (118, 143, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716034_PresensiKP.pdf', NULL, NULL, NULL, '2020-07-27 15:25:34');
INSERT INTO `kp_dokumen` VALUES (119, 144, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716001_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (120, 145, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (121, 146, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716003_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (122, 147, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716018_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (123, 148, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716006_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (124, 149, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716020_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (125, 150, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716019_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (126, 151, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716009_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (127, 152, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (128, 153, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716026_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (129, 154, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716023_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (130, 155, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716004_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (132, 157, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716030_Berkas_PresensiKP.pdf\r\n', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (133, 158, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (134, 159, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716002_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (135, 160, NULL, NULL, NULL, NULL, NULL, NULL, 'I0716016_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (136, 161, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (137, 162, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (139, 164, NULL, NULL, NULL, NULL, 'I0717017_Berkas_SurattugasKP.pdf', 'I0717017_Berkas_SelesaiKP.pdf', 'I0717017_PresensiKP.pdf', 'I0717017_Berkas_LaporanKP.pdf', 'I0717017_Berkas_NilaiKP.pdf', NULL, '2020-07-29 20:45:27');
INSERT INTO `kp_dokumen` VALUES (140, 165, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (141, 166, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715006_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (142, 167, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715010_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (143, 168, NULL, NULL, NULL, NULL, NULL, NULL, 'I0715011_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (144, 169, NULL, NULL, NULL, NULL, NULL, NULL, 'I0717006_Berkas_PresensiKP.pdf', NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (145, 170, NULL, NULL, NULL, NULL, NULL, NULL, 'I0717008_Berkas_PresensiKP.pdf', 'I0717008_Berkas_LaporanKP.pdf', 'I0717008_Berkas_NilaiKP.pdf', NULL, '2020-07-30 11:00:21');
INSERT INTO `kp_dokumen` VALUES (146, 171, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (147, 172, NULL, NULL, NULL, NULL, 'I0717026_Berkas_SurattugasKP.pdf', NULL, NULL, NULL, NULL, NULL, '2020-07-21 07:33:23');
INSERT INTO `kp_dokumen` VALUES (148, 173, NULL, NULL, NULL, NULL, 'I0717007_Berkas_SurattugasKP.pdf', 'I0717007_Berkas_SelesaiKP.pdf', 'I0717007_PresensiKP.pdf', 'I0717007_Berkas_LaporanKP.pdf', 'I0717007_Berkas_NilaiKP.pdf', NULL, '2020-07-29 21:23:39');
INSERT INTO `kp_dokumen` VALUES (149, 174, NULL, NULL, NULL, NULL, 'I0717039_Berkas_SurattugasKP.pdf', 'I0717039_Berkas_SelesaiKP.pdf', 'I0717039_PresensiKP.pdf', 'I0717039_Berkas_LaporanKP.pdf', 'I0717039_Berkas_NilaiKP.pdf', NULL, '2020-07-29 21:17:56');
INSERT INTO `kp_dokumen` VALUES (150, 175, NULL, 'I0717035_Berkas_PermohonanKP_175.pdf', 'I0717035_Berkas_BalasanKP_175.pdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-07-10 13:39:49');
INSERT INTO `kp_dokumen` VALUES (151, 176, NULL, NULL, NULL, NULL, 'I0717012_Berkas_SurattugasKP.pdf', 'I0717012_Berkas_SelesaiKP.pdf', NULL, NULL, NULL, NULL, '2020-07-28 15:08:29');
INSERT INTO `kp_dokumen` VALUES (152, 177, 'I0717025_Berkas_ProposalKP_177.pdf', 'I0717025_Berkas_PermohonanKP_177.pdf', 'I0717025_Berkas_BalasanKP_177.pdf', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-03 09:06:41');
INSERT INTO `kp_dokumen` VALUES (153, 178, NULL, NULL, NULL, NULL, 'I0717010_Berkas_SurattugasKP.pdf', 'I0717010_Berkas_SelesaiKP.pdf', NULL, NULL, NULL, NULL, '2020-07-30 14:21:11');
INSERT INTO `kp_dokumen` VALUES (154, 179, NULL, NULL, NULL, NULL, 'I0717041_Berkas_SurattugasKP.pdf', 'I0717041_Berkas_SelesaiKP.pdf', 'I0717041_PresensiKP.pdf', 'I0717041_Berkas_LaporanKP.pdf', 'I0717041_Berkas_NilaiKP.pdf', NULL, '2020-07-30 15:01:30');
INSERT INTO `kp_dokumen` VALUES (155, 180, NULL, NULL, NULL, NULL, 'I0717023_Berkas_SurattugasKP.pdf', 'I0717023_Berkas_SelesaiKP.pdf', NULL, NULL, NULL, NULL, '2020-07-28 11:31:19');
INSERT INTO `kp_dokumen` VALUES (156, 181, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (158, 183, NULL, NULL, NULL, NULL, 'I0717028_Berkas_SurattugasKP.pdf', 'I0717028_Berkas_SelesaiKP.pdf', 'I0717028_PresensiKP.pdf', NULL, NULL, NULL, '2020-07-29 20:56:06');
INSERT INTO `kp_dokumen` VALUES (159, 184, NULL, NULL, NULL, NULL, 'I0717004_Berkas_SurattugasKP.pdf', 'I0717004_Berkas_SelesaiKP.pdf', NULL, NULL, NULL, NULL, '2020-07-30 12:30:43');
INSERT INTO `kp_dokumen` VALUES (160, 185, NULL, NULL, NULL, NULL, NULL, 'I0717037_Berkas_SelesaiKP.pdf', NULL, 'I0717037_Berkas_LaporanKP.pdf', 'I0717037_Berkas_NilaiKP.pdf', NULL, '2020-07-29 07:52:31');
INSERT INTO `kp_dokumen` VALUES (161, 186, 'I0717018_Berkas_ProposalKP_186.pdf', NULL, NULL, 'I0717018_Berkas_PenugasanKP.pdf', 'I0717018_Berkas_SurattugasKP.pdf', 'I0717018_Berkas_SelesaiKP.pdf', 'I0717018_PresensiKP.pdf', 'I0717018_Berkas_LaporanKP.pdf', 'I0717018_Berkas_NilaiKP.pdf', NULL, '2020-08-04 11:51:22');
INSERT INTO `kp_dokumen` VALUES (162, 187, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_dokumen` VALUES (172, 197, 'I0717029_Berkas_ProposalKP_197.pdf', 'I0717029_Berkas_PermohonanKP_197.pdf', 'I0717029_Berkas_BalasanKP_197.pdf', 'I0717029_Berkas_PenugasanKP.pdf', 'I0717029_Berkas_SurattugasKP.pdf', NULL, NULL, NULL, NULL, NULL, '2020-07-27 15:11:21');
INSERT INTO `kp_dokumen` VALUES (174, 199, 'I0717002_Berkas_ProposalKP_199.pdf', 'I0717002_Berkas_PermohonanKP_199.pdf', 'I0717002_Berkas_BalasanKP_199.pdf', 'I0717002_Berkas_PenugasanKP.pdf', 'I0717002_Berkas_SurattugasKP.pdf', NULL, NULL, NULL, NULL, '2020-07-14 12:06:20', '2020-07-27 15:15:06');
INSERT INTO `kp_dokumen` VALUES (175, 200, 'I0717005_Berkas_ProposalKP_200.pdf', 'I0717005_Berkas_PermohonanKP_200.pdf', 'I0717005_Berkas_BalasanKP_200.pdf', 'I0717005_Berkas_PenugasanKP.pdf', NULL, NULL, NULL, NULL, NULL, '2020-07-14 13:35:51', '2020-07-24 14:46:42');
INSERT INTO `kp_dokumen` VALUES (176, 201, 'I0717016_Berkas_ProposalKP_201.pdf', 'I0717016_Berkas_PermohonanKP_201.pdf', 'I0717016_Berkas_BalasanKP_201.pdf', 'I0717016_Berkas_PenugasanKP.pdf', 'I0717016_Berkas_SurattugasKP.pdf', NULL, NULL, NULL, NULL, '2020-07-15 17:19:25', '2020-07-27 15:47:46');
INSERT INTO `kp_dokumen` VALUES (177, 202, 'I0717024_Berkas_ProposalKP_202.pdf', 'I0717024_Berkas_PermohonanKP_202.pdf', 'I0717024_Berkas_BalasanKP_202.pdf', 'I0717024_Berkas_PenugasanKP.pdf', 'I0717024_Berkas_SurattugasKP.pdf', NULL, NULL, NULL, NULL, '2020-07-15 17:31:18', '2020-07-27 15:11:02');
INSERT INTO `kp_dokumen` VALUES (178, 203, 'I0717015_Berkas_ProposalKP_203.pdf', 'I0717015_Berkas_PermohonanKP_203.pdf', 'I0717015_Berkas_BalasanKP_203.pdf', NULL, 'I0717015_Berkas_SurattugasKP.pdf', NULL, NULL, NULL, NULL, '2020-07-15 19:05:25', '2020-07-27 15:33:25');
INSERT INTO `kp_dokumen` VALUES (179, 204, 'I0717021_Berkas_ProposalKP_204.pdf', 'I0717021_Berkas_PermohonanKP_204.pdf', 'I0717021_Berkas_BalasanKP_204.pdf', 'I0717021_Berkas_PenugasanKP.pdf', 'I0717021_Berkas_SurattugasKP.pdf', NULL, NULL, NULL, NULL, '2020-07-15 21:08:42', '2020-07-27 15:08:17');
INSERT INTO `kp_dokumen` VALUES (180, 205, 'I0717035_Berkas_ProposalKP_205.pdf', 'I0717035_Berkas_PermohonanKP_205.pdf', 'I0717035_Berkas_BalasanKP_205.pdf', 'I0717035_Berkas_PenugasanKP.pdf', 'I0717035_Berkas_SurattugasKP.pdf', NULL, NULL, NULL, NULL, '2020-07-16 13:05:42', '2020-07-27 15:07:59');
INSERT INTO `kp_dokumen` VALUES (181, 206, 'I0717013_Berkas_ProposalKP_206.pdf', 'I0717013_Berkas_PermohonanKP_206.pdf', 'I0717013_Berkas_BalasanKP_206.pdf', 'I0717013_Berkas_PenugasanKP.pdf', 'I0717013_Berkas_SurattugasKP.pdf', NULL, NULL, NULL, NULL, '2020-07-17 13:59:06', '2020-07-27 17:29:43');
INSERT INTO `kp_dokumen` VALUES (182, 207, 'I0717033_Berkas_ProposalKP_207.pdf', 'I0717033_Berkas_PermohonanKP_207.pdf', 'I0717033_Berkas_BalasanKP_207.pdf', 'I0717033_Berkas_PenugasanKP.pdf', 'I0717033_Berkas_SurattugasKP.pdf', NULL, NULL, NULL, NULL, '2020-07-17 20:16:18', '2020-07-27 18:18:16');
INSERT INTO `kp_dokumen` VALUES (183, 208, 'I0717030_Berkas_ProposalKP_208.pdf', 'I0717030_Berkas_PermohonanKP_208.pdf', 'I0717030_Berkas_BalasanKP_208.pdf', 'I0717030_Berkas_PenugasanKP.pdf', NULL, NULL, NULL, NULL, NULL, '2020-07-17 20:57:46', '2020-07-27 09:52:36');
INSERT INTO `kp_dokumen` VALUES (184, 209, 'I0715027_Berkas_ProposalKP_209.pdf', 'I0715027_Berkas_PermohonanKP_209.pdf', 'I0715027_Berkas_BalasanKP_209.pdf', 'I0715027_Berkas_PenugasanKP.pdf', 'I0715027_Berkas_SurattugasKP.pdf', 'I0715027_Berkas_SelesaiKP.pdf', NULL, NULL, NULL, '2020-07-20 09:32:36', '2020-08-03 12:23:04');
INSERT INTO `kp_dokumen` VALUES (185, 210, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2020-08-03 14:42:54', '2020-08-03 14:42:54');

-- ----------------------------
-- Table structure for kp_klaim
-- ----------------------------
DROP TABLE IF EXISTS `kp_klaim`;
CREATE TABLE `kp_klaim`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kp_id` int(11) NULL DEFAULT NULL,
  `klaim_nama` varchar(191) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `klaim_nim` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `klaim_status` tinyint(3) NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `ibfk_kp_1`(`kp_id`) USING BTREE,
  CONSTRAINT `ibfk_kp_1` FOREIGN KEY (`kp_id`) REFERENCES `kp` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 68 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of kp_klaim
-- ----------------------------
INSERT INTO `kp_klaim` VALUES (26, 185, 'Miftahuddin Irfani', 'i0716020', 1, NULL, '2020-07-16 13:21:22');
INSERT INTO `kp_klaim` VALUES (27, 185, 'Annisa Hanifa', 'i0716006', 1, NULL, '2020-07-16 13:21:33');
INSERT INTO `kp_klaim` VALUES (28, 185, 'Adip Safiudin', 'i0716001', 1, NULL, '2020-07-16 13:21:56');
INSERT INTO `kp_klaim` VALUES (29, 185, 'Mohamad Nisman Falich', 'i0716021', 1, NULL, '2020-07-16 13:22:12');
INSERT INTO `kp_klaim` VALUES (30, 185, 'Kevin Sebastian Arief', 'I0716018', 1, NULL, '2020-07-16 13:22:26');
INSERT INTO `kp_klaim` VALUES (31, 186, 'Vernanda Sitorini Zul Hizmi', 'I0716032', 1, NULL, '2020-07-20 14:52:57');
INSERT INTO `kp_klaim` VALUES (32, 186, 'Rilo Pambudi Aditya Wardani', 'I0716028', 1, NULL, '2020-07-20 14:53:25');
INSERT INTO `kp_klaim` VALUES (33, 186, 'Kevin Sebastian', 'I0716018', 1, NULL, '2020-07-20 14:54:04');
INSERT INTO `kp_klaim` VALUES (34, 186, 'Henry Probo Santoso', 'I0716016', 1, NULL, '2020-07-20 14:55:17');
INSERT INTO `kp_klaim` VALUES (35, 186, 'Afif Yuhendrasmiko', 'I0716003', 1, NULL, '2020-07-20 14:56:03');
INSERT INTO `kp_klaim` VALUES (36, 186, 'DANIEL AQUINO PURBA', 'I0716012', 1, NULL, '2020-07-20 14:56:32');
INSERT INTO `kp_klaim` VALUES (37, 209, 'Banu Maheswara', 'I0717010', 1, NULL, '2020-08-03 09:58:22');
INSERT INTO `kp_klaim` VALUES (38, 209, 'Alvin Ichwanur Ridho', 'I0717004', 1, NULL, '2020-08-03 09:58:25');
INSERT INTO `kp_klaim` VALUES (39, 209, 'Kevin Dwiyanto Saputra', 'I0717023', 1, NULL, '2020-08-03 09:58:26');
INSERT INTO `kp_klaim` VALUES (40, 209, 'Berlianne Shanaza Andriany', 'I0717012', 1, NULL, '2020-08-03 09:58:27');
INSERT INTO `kp_klaim` VALUES (41, 209, 'Hanifah Yulia', 'I0717018', 1, NULL, '2020-08-03 09:58:28');
INSERT INTO `kp_klaim` VALUES (42, 176, 'Mochammad Nisman Falich', 'I0716021', 1, NULL, '2020-07-29 11:27:24');
INSERT INTO `kp_klaim` VALUES (43, 176, 'Afif Yuhendrasmiko', 'I0716003', 1, NULL, '2020-07-29 11:27:24');
INSERT INTO `kp_klaim` VALUES (44, 176, 'Aulia Vici Yunitasari', 'I0717008', 1, NULL, '2020-07-29 11:27:24');
INSERT INTO `kp_klaim` VALUES (45, 176, 'Athaya Cantia Putri', 'I0717006', 1, NULL, '2020-07-29 11:27:24');
INSERT INTO `kp_klaim` VALUES (46, 176, 'Gilang Satria Aji', 'I0717017', 1, NULL, '2020-07-29 11:27:24');
INSERT INTO `kp_klaim` VALUES (47, 180, 'Krisna Hakim', 'I0716018', 0, NULL, '2020-07-31 12:39:00');
INSERT INTO `kp_klaim` VALUES (48, 180, 'Musyaffa\' Ahmad', 'I0716026', 1, NULL, '2020-07-31 20:50:35');
INSERT INTO `kp_klaim` VALUES (49, 180, 'Afif Yuhendrasmiko', 'I0716003', 1, NULL, '2020-07-31 20:51:53');
INSERT INTO `kp_klaim` VALUES (50, 180, 'Athaya Cantia Putri', 'I0717006', 1, NULL, '2020-07-31 20:52:26');
INSERT INTO `kp_klaim` VALUES (51, 180, 'Gilang Satria Ajie', 'I0717017', 1, NULL, '2020-07-31 20:52:53');
INSERT INTO `kp_klaim` VALUES (52, 180, 'Aulia Vici Yunitasari', 'I0717008', 1, NULL, '2020-07-31 20:53:07');
INSERT INTO `kp_klaim` VALUES (53, 180, 'Attar Al Mufashal Rasyid', 'I0717007', 1, NULL, '2020-07-31 20:53:18');
INSERT INTO `kp_klaim` VALUES (54, 180, 'Weldino Panji Kurniadi', 'I0717041', 1, NULL, '2020-07-31 20:53:46');
INSERT INTO `kp_klaim` VALUES (55, 180, 'M. Ikyu Arqie Ramadhan', 'I0717028', 1, NULL, '2020-07-31 20:54:08');
INSERT INTO `kp_klaim` VALUES (56, 184, 'Krisna Hakim', 'I0716018', 1, NULL, '2020-07-31 22:10:17');
INSERT INTO `kp_klaim` VALUES (57, 184, 'Aulia Vici Yunitasari', 'I0717008', 1, NULL, '2020-07-31 22:10:17');
INSERT INTO `kp_klaim` VALUES (58, 184, 'Berlianne Shanaza Andriany', 'I0717012', 1, NULL, '2020-07-31 22:10:17');
INSERT INTO `kp_klaim` VALUES (59, 184, 'Weldino Panji Kurniadi', 'I0717041', 1, NULL, '2020-07-31 22:18:02');
INSERT INTO `kp_klaim` VALUES (60, 184, 'Afif Yuhendrasmiko', 'I0716003', 1, NULL, '2020-07-31 22:18:18');
INSERT INTO `kp_klaim` VALUES (61, 178, 'Aulia Vici Yunitasari', 'I0717008', 1, NULL, '2020-07-31 20:46:31');
INSERT INTO `kp_klaim` VALUES (62, 178, 'Berlianne Shanaza Andriany', 'I0717012', 0, NULL, NULL);
INSERT INTO `kp_klaim` VALUES (63, 178, 'Bintang Sujatmiko', 'I0716011', 1, NULL, '2020-07-31 20:46:57');
INSERT INTO `kp_klaim` VALUES (64, 178, 'Miftahudin Irfani', 'I0716020', 1, NULL, '2020-07-31 20:47:13');
INSERT INTO `kp_klaim` VALUES (65, 178, 'Annisa Hanifa', 'I0716006', 1, NULL, '2020-07-31 20:47:31');
INSERT INTO `kp_klaim` VALUES (66, 178, 'Yudhi Prabowo Kusuma', 'I0716034', 1, NULL, '2020-07-31 20:47:52');
INSERT INTO `kp_klaim` VALUES (67, 178, 'Rilo Pambudi Aditya Wardani', 'I0716028', 1, NULL, '2020-07-31 20:48:15');

-- ----------------------------
-- Table structure for kp_nilai
-- ----------------------------
DROP TABLE IF EXISTS `kp_nilai`;
CREATE TABLE `kp_nilai`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `kp_id` int(15) NULL DEFAULT NULL,
  `huruf` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `angka` double(5, 2) NULL DEFAULT NULL,
  `skala` double(5, 2) NULL DEFAULT NULL,
  `angka_pembimbing` double(5, 2) NULL DEFAULT NULL,
  `angka_perusahaan` double(5, 2) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `ibfk_kp5`(`kp_id`) USING BTREE,
  CONSTRAINT `ibfk_kp5` FOREIGN KEY (`kp_id`) REFERENCES `kp` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 101 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of kp_nilai
-- ----------------------------
INSERT INTO `kp_nilai` VALUES (15, 50, '', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (16, 67, 'A-', 84.08, 3.70, 80.00, 86.80, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (17, 52, 'A', 85.00, 4.00, 89.50, 82.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (18, 66, 'A', 85.20, 4.00, 81.00, 88.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (19, 64, 'A', 91.40, 4.00, 95.00, 89.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (20, 61, 'A', 90.80, 4.00, 95.00, 88.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (21, 54, 'A-', 83.76, 3.70, 84.00, 83.60, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (22, 62, 'A', 86.64, 4.00, 87.00, 86.40, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (23, 49, 'A', 88.80, 4.00, 90.00, 88.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (24, 55, 'A', 85.04, 4.00, 80.00, 88.40, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (25, 63, 'A', 91.40, 4.00, 95.00, 89.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (26, 53, 'A', 91.20, 4.00, 90.00, 92.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (27, 56, 'A', 88.68, 4.00, 90.00, 87.80, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (28, 93, 'A', 91.28, 4.00, 95.00, 88.80, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (29, 70, 'A', 88.56, 4.00, 88.80, 88.40, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (30, 72, 'A', 85.16, 4.00, 87.80, 83.40, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (31, 73, 'A-', 84.64, 3.70, 88.00, 82.40, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (32, 87, 'A-', 84.00, 3.70, 78.00, 88.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (33, 71, 'A-', 83.36, 3.70, 80.00, 85.60, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (34, 75, 'A', 86.60, 4.00, 93.80, 81.80, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (35, 74, 'A', 91.08, 4.00, 90.00, 91.80, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (36, 95, 'A', 85.24, 4.00, 100.00, 75.40, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (37, 78, 'A', 86.04, 4.00, 87.00, 85.40, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (38, 76, 'A', 89.48, 4.00, 86.00, 91.80, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (39, 79, 'A', 92.00, 4.00, 92.00, 92.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (40, 80, 'A', 92.00, 4.00, 92.00, 92.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (41, 89, 'A', 88.00, 4.00, 88.00, 88.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (42, 88, 'A', 88.00, 4.00, 88.00, 88.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (43, 69, 'A', 91.40, 4.00, 92.00, 91.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (44, 68, 'B+', 79.40, 3.30, 80.00, 79.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (45, 111, 'A-', 84.80, 3.70, 86.00, 84.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (46, 97, 'A', 89.00, 4.00, 84.50, 92.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (47, 113, 'A-', 81.40, 3.70, 85.00, 79.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (48, 125, 'A', 88.00, 4.00, 88.00, 88.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (49, 112, 'A', 85.00, 4.00, 85.00, 85.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (50, 101, 'A-', 82.40, 3.70, 86.00, 80.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (51, 122, 'A', 85.56, 4.00, 84.00, 86.60, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (52, 118, 'A', 92.48, 4.00, 95.00, 90.80, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (53, 119, 'A', 88.67, 4.00, 86.98, 89.80, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (54, 116, 'A', 90.36, 4.00, 90.00, 90.60, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (55, 121, 'A', 89.04, 4.00, 85.50, 91.40, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (56, 100, 'A', 85.36, 4.00, 85.00, 85.60, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (57, 110, 'A', 92.40, 4.00, 90.00, 94.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (58, 98, 'A', 86.56, 4.00, 88.00, 85.60, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (59, 107, 'A', 91.20, 4.00, 87.00, 94.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (60, 120, 'A', 90.60, 4.00, 87.00, 93.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (61, 117, 'A', 89.36, 4.00, 80.00, 95.60, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (62, 103, 'A-', 82.88, 3.70, 83.00, 82.80, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (63, 94, 'A', 93.00, 4.00, 90.00, 95.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (64, 99, 'A', 86.36, 4.00, 86.00, 86.60, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (65, 106, 'A', 90.40, 4.00, 85.00, 94.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (66, 108, 'A', 85.52, 4.00, 86.00, 85.20, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (67, 134, 'A', 95.00, 4.00, 95.00, 95.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (68, 148, 'A', 93.00, 4.00, 90.00, 95.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (69, 149, 'A', 93.00, 4.00, 90.00, 95.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (70, 128, 'A-', 84.96, 3.70, 87.00, 83.60, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (71, 143, 'A', 85.64, 4.00, 86.00, 85.40, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (72, 124, 'A', 89.45, 4.00, 98.00, 83.75, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (73, 123, 'A', 87.50, 4.00, 95.00, 82.50, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (74, 154, 'A', 88.00, 4.00, 85.00, 90.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (75, 144, 'A-', 83.44, 3.70, 85.00, 82.40, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (76, 147, 'A', 86.04, 4.00, 91.80, 82.20, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (77, 132, 'A', 89.44, 4.00, 88.00, 90.40, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (78, 135, 'A', 95.00, 4.00, 95.00, 95.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (79, 150, 'A', 90.36, 4.00, 90.00, 90.60, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (80, 139, 'A', 90.00, 4.00, 90.00, 90.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (81, 153, 'A', 90.24, 4.00, 90.00, 90.40, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (82, 160, 'A', 92.36, 4.00, 92.00, 92.60, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (83, 151, 'A', 89.16, 4.00, 87.00, 90.60, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (84, 137, 'A', 89.88, 4.00, 90.00, 89.80, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (85, 159, 'A', 86.20, 4.00, 85.00, 87.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (86, 138, 'A', 86.08, 4.00, 85.00, 86.80, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (87, 157, 'A', 88.80, 4.00, 90.00, 88.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (88, 155, 'A', 90.00, 4.00, 90.00, 90.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (89, 142, 'A', 85.68, 4.00, 84.00, 86.80, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (90, 146, 'A', 88.20, 4.00, 90.00, 87.00, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (91, 168, 'A', 85.92, 4.00, 90.00, 83.20, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (92, 166, 'A-', 83.12, 3.70, 83.00, 83.20, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (93, 167, 'A-', 84.52, 3.70, 85.00, 84.20, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (94, 174, '', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (95, 169, '', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (96, 164, '', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (97, 170, '', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (98, 173, '', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (99, 183, '', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `kp_nilai` VALUES (100, 179, '', NULL, NULL, NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for kp_rencana
-- ----------------------------
DROP TABLE IF EXISTS `kp_rencana`;
CREATE TABLE `kp_rencana`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `kp_id` int(15) NULL DEFAULT NULL,
  `rencana_mulai_kp` date NULL DEFAULT NULL,
  `rencana_selesai_kp` date NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `ibfk_kp`(`kp_id`) USING BTREE,
  CONSTRAINT `ibfk_kp` FOREIGN KEY (`kp_id`) REFERENCES `kp` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 184 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of kp_rencana
-- ----------------------------
INSERT INTO `kp_rencana` VALUES (21, 48, '2017-07-31', '2017-08-31', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (22, 49, '2017-07-17', '2017-09-17', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (23, 50, '2017-07-10', '2017-08-11', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (24, 51, '2017-07-03', '2017-08-05', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (25, 52, '2017-07-17', '2017-09-17', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (26, 53, '2017-07-17', '2017-08-31', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (27, 54, '2017-07-17', '2017-09-01', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (28, 55, '2017-07-17', '2017-09-01', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (29, 56, '2017-07-17', '2017-09-01', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (30, 57, '2017-07-17', '2017-08-17', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (31, 58, '2017-07-17', '2017-08-17', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (32, 59, '2017-07-17', '2017-08-17', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (33, 60, '2017-07-17', '2017-08-17', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (34, 61, '2017-07-17', '2017-08-17', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (35, 62, '2017-07-17', '2017-08-17', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (36, 63, '2017-07-24', '2017-08-25', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (37, 64, '2017-07-24', '2017-08-25', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (38, 65, '2017-07-20', '2017-08-20', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (39, 66, '2017-07-10', '2017-09-08', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (40, 67, '2017-07-17', '2017-08-31', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (41, 68, '2018-01-15', '2018-03-15', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (42, 69, '2018-01-15', '2018-03-15', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (43, 70, '2018-01-11', '2018-02-11', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (44, 71, '2018-01-14', '2018-02-28', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (45, 72, '2018-01-14', '2018-02-16', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (46, 73, '2018-01-15', '2018-02-16', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (47, 74, '2018-01-22', '2018-02-23', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (48, 75, '2018-01-15', '2018-02-16', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (49, 76, '2018-01-22', '2018-02-23', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (50, 77, '2018-01-22', '2018-02-23', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (51, 78, '2018-01-14', '2018-02-28', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (52, 79, '2018-01-15', '2018-02-16', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (53, 80, '2018-01-15', '2018-02-16', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (54, 81, '2018-03-11', '2018-05-05', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (55, 82, '2018-03-11', '2018-04-14', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (56, 83, '2018-07-09', '2018-08-24', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (57, 84, '2018-07-09', '2018-08-24', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (58, 85, '2018-01-15', '2018-02-16', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (59, 86, '2018-01-20', '2018-02-24', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (60, 87, '2018-01-22', '2018-03-02', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (61, 88, '2018-01-22', '2018-03-02', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (62, 89, '2018-01-22', '2018-03-02', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (63, 90, '2018-01-20', '2018-02-24', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (64, 91, '2018-01-22', '2018-03-02', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (65, 92, '2018-01-22', '2018-02-02', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (66, 93, '2018-01-15', '2018-02-15', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (67, 94, '2018-07-16', '2018-09-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (68, 95, '2018-03-05', '2018-04-05', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (69, 96, '2018-07-01', '2018-07-31', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (70, 97, '2018-07-01', '2018-07-31', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (71, 98, '2018-07-23', '2018-08-31', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (72, 99, '2018-07-23', '2018-08-31', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (73, 100, '2018-07-23', '2018-08-31', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (74, 101, '2018-07-23', '2018-08-31', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (75, 102, '2018-07-16', '2018-08-16', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (76, 103, '2018-07-23', '2018-08-24', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (77, 104, '2018-07-16', '2018-08-16', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (78, 105, '2018-07-16', '2018-08-16', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (79, 106, '2018-07-16', '2018-09-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (80, 107, '2018-07-23', '2018-08-31', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (81, 108, '2018-07-16', '2018-09-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (82, 109, '2019-07-22', '2019-09-07', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (83, 110, '2018-07-16', '2018-08-24', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (84, 111, '2018-04-23', '2018-05-25', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (85, 112, '2018-05-10', '2018-06-09', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (86, 113, '2018-06-04', '2018-07-04', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (87, 114, '2018-07-16', '2018-08-24', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (88, 115, '2018-07-02', '2018-08-04', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (89, 116, '2018-07-16', '2018-08-16', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (90, 117, '2018-07-16', '2018-08-16', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (91, 118, '2018-07-16', '2018-08-16', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (92, 119, '2018-07-16', '2018-08-17', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (93, 120, '2018-07-16', '2018-08-30', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (94, 121, '2018-07-16', '2018-08-30', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (95, 122, '2018-07-16', '2018-08-30', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (96, 123, '2019-01-18', '2019-02-17', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (97, 124, '2019-01-18', '2019-02-17', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (98, 125, '2018-09-03', '2018-10-07', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (99, 126, '2019-01-14', '2019-02-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (100, 127, '2019-01-15', '2019-02-15', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (101, 128, '2019-01-21', '2019-03-01', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (102, 129, '2019-01-14', '2019-02-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (103, 130, '2019-01-21', '2019-03-01', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (104, 131, '2019-01-21', '2019-03-01', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (105, 132, '2019-07-22', '2019-08-23', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (106, 133, '2019-07-22', '2019-08-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (107, 134, '2019-01-14', '2019-02-16', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (108, 135, '2019-07-22', '2019-08-30', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (109, 136, '2019-07-15', '2019-09-27', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (110, 137, '2019-07-23', '2019-08-23', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (111, 138, '2019-07-29', '2019-09-06', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (112, 139, '2019-07-15', '2019-09-27', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (113, 140, '2019-07-23', '2019-08-23', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (114, 141, '2019-01-21', '2019-03-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (115, 142, '2019-07-22', '2019-08-23', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (116, 143, '2019-01-18', '2019-02-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (117, 144, '2019-01-18', '2019-02-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (118, 145, '2019-07-23', '2019-08-23', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (119, 146, '2019-07-15', '2019-09-27', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (120, 147, '2019-01-18', '2019-02-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (121, 148, '2019-01-14', '2019-02-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (122, 149, '2019-01-14', '2019-02-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (123, 150, '2019-07-22', '2019-08-23', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (124, 151, '2019-07-23', '2019-08-23', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (125, 152, '2019-01-21', '2019-02-28', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (126, 153, '2019-07-22', '2019-08-23', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (127, 154, '2019-02-15', '2019-03-15', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (128, 155, '2019-07-15', '2019-09-27', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (130, 157, '2019-07-15', '2019-09-13', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (131, 158, '2020-01-20', '2020-03-20', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (132, 159, '2019-07-29', '2019-09-06', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (133, 160, '2019-07-22', '2019-08-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (134, 161, '2019-07-21', '2019-09-06', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (135, 162, '2019-07-21', '2019-09-06', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (137, 164, '2020-01-27', '2020-02-29', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (138, 165, '2019-07-22', '2019-10-22', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (139, 166, '2019-08-13', '2019-09-27', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (140, 167, '2019-08-13', '2019-09-27', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (141, 168, '2019-08-13', '2019-09-27', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (142, 169, '2020-02-01', '2020-02-29', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (143, 170, '2020-02-01', '2020-02-29', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (144, 171, '2020-01-20', '2020-02-24', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (145, 172, '2020-02-01', '2019-07-31', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (146, 173, '2020-01-20', '2020-02-19', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (147, 174, '2020-01-20', '2020-02-19', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (148, 175, '2020-01-20', '2020-02-29', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (149, 176, '2020-01-20', '2020-02-29', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (150, 177, '2020-01-20', '2020-02-29', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (151, 178, '2020-02-01', '2020-02-29', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (152, 179, '2020-01-20', '2020-02-29', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (153, 180, '2020-01-20', '2020-02-29', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (154, 181, '2020-01-20', '2020-02-24', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (156, 183, '2020-01-28', '2020-02-29', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (157, 184, '2020-01-27', '2020-02-27', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (158, 185, '2020-01-20', '2020-02-17', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (159, 186, '2020-01-20', '2020-03-20', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (160, 187, '2020-01-27', '2020-02-29', NULL, NULL);
INSERT INTO `kp_rencana` VALUES (170, 197, '2020-07-27', '2020-08-30', NULL, '2020-07-15 09:21:50');
INSERT INTO `kp_rencana` VALUES (172, 199, '2020-07-27', '2020-08-30', '2020-07-14 12:06:20', '2020-07-14 12:06:20');
INSERT INTO `kp_rencana` VALUES (173, 200, '2020-07-27', '2020-08-30', '2020-07-14 13:35:51', '2020-07-14 13:37:34');
INSERT INTO `kp_rencana` VALUES (174, 201, '2020-07-20', '2020-08-31', '2020-07-15 17:19:24', '2020-07-15 17:19:24');
INSERT INTO `kp_rencana` VALUES (175, 202, '2020-07-27', '2020-08-30', '2020-07-15 17:31:18', '2020-07-15 17:31:18');
INSERT INTO `kp_rencana` VALUES (176, 203, '2020-07-20', '2020-08-31', '2020-07-15 19:05:25', '2020-07-15 19:05:25');
INSERT INTO `kp_rencana` VALUES (177, 204, '2020-07-20', '2020-08-29', '2020-07-15 21:08:42', '2020-07-15 21:08:42');
INSERT INTO `kp_rencana` VALUES (178, 205, '2020-07-20', '2020-08-31', '2020-07-16 13:05:42', '2020-07-16 13:11:43');
INSERT INTO `kp_rencana` VALUES (179, 206, '2020-07-20', '2020-08-29', '2020-07-17 13:59:06', '2020-07-18 19:45:34');
INSERT INTO `kp_rencana` VALUES (180, 207, '2020-07-27', '2020-08-31', '2020-07-17 20:16:18', '2020-07-17 21:00:28');
INSERT INTO `kp_rencana` VALUES (181, 208, '2020-07-27', '2020-08-31', '2020-07-17 20:57:46', '2020-07-17 20:57:46');
INSERT INTO `kp_rencana` VALUES (182, 209, '2020-05-14', '2020-06-19', '2020-07-20 09:32:36', '2020-07-20 09:32:36');
INSERT INTO `kp_rencana` VALUES (183, 210, '2020-08-10', '2020-09-30', '2020-08-03 14:42:54', '2020-08-03 14:42:54');

-- ----------------------------
-- Table structure for kp_seminar
-- ----------------------------
DROP TABLE IF EXISTS `kp_seminar`;
CREATE TABLE `kp_seminar`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `kp_id` int(15) NOT NULL,
  `judul_seminar` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `tanggal_seminar` date NULL DEFAULT NULL,
  `jam_mulai` time(0) NULL DEFAULT NULL,
  `jam_selesai` time(0) NULL DEFAULT NULL,
  `ruang_id` int(10) NULL DEFAULT NULL,
  `status_seminarkp` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `KPID`(`kp_id`) USING BTREE,
  INDEX `ruang`(`ruang_id`) USING BTREE,
  CONSTRAINT `kp_seminar_ibfk_1` FOREIGN KEY (`kp_id`) REFERENCES `kp` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `kp_seminar_ibfk_2` FOREIGN KEY (`ruang_id`) REFERENCES `ref_ruang` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 110 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of kp_seminar
-- ----------------------------
INSERT INTO `kp_seminar` VALUES (16, 50, '', '2017-10-02', '09:00:00', '00:00:00', 4, 'SETUJU', '2017-09-29 16:02:00', NULL);
INSERT INTO `kp_seminar` VALUES (17, 67, '', NULL, NULL, NULL, 1, 'SETUJU', '2018-01-11 12:50:00', NULL);
INSERT INTO `kp_seminar` VALUES (18, 52, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-01-04 15:25:00', NULL);
INSERT INTO `kp_seminar` VALUES (19, 66, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-01-10 13:23:00', NULL);
INSERT INTO `kp_seminar` VALUES (20, 64, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-01-05 10:51:00', NULL);
INSERT INTO `kp_seminar` VALUES (21, 61, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-01-10 08:40:00', NULL);
INSERT INTO `kp_seminar` VALUES (22, 54, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-01-05 15:43:00', NULL);
INSERT INTO `kp_seminar` VALUES (23, 62, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-01-08 14:04:00', NULL);
INSERT INTO `kp_seminar` VALUES (24, 49, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-01-10 07:52:00', NULL);
INSERT INTO `kp_seminar` VALUES (25, 55, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-01-23 13:16:00', NULL);
INSERT INTO `kp_seminar` VALUES (26, 63, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-01-04 15:31:00', NULL);
INSERT INTO `kp_seminar` VALUES (27, 53, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-01-05 10:37:00', NULL);
INSERT INTO `kp_seminar` VALUES (28, 56, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-07-31 09:35:00', NULL);
INSERT INTO `kp_seminar` VALUES (29, 93, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-05-03 11:20:00', NULL);
INSERT INTO `kp_seminar` VALUES (30, 70, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-05-25 09:59:00', NULL);
INSERT INTO `kp_seminar` VALUES (31, 72, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-05-25 10:01:00', NULL);
INSERT INTO `kp_seminar` VALUES (32, 73, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-07-02 09:32:00', NULL);
INSERT INTO `kp_seminar` VALUES (33, 87, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-06-29 14:24:00', NULL);
INSERT INTO `kp_seminar` VALUES (34, 71, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-07-06 10:05:00', NULL);
INSERT INTO `kp_seminar` VALUES (35, 75, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-06-28 14:22:00', NULL);
INSERT INTO `kp_seminar` VALUES (36, 74, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-06-28 13:54:00', NULL);
INSERT INTO `kp_seminar` VALUES (37, 95, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-06-07 15:10:00', NULL);
INSERT INTO `kp_seminar` VALUES (38, 78, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-07-06 13:39:00', NULL);
INSERT INTO `kp_seminar` VALUES (39, 76, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-06-26 10:05:00', NULL);
INSERT INTO `kp_seminar` VALUES (40, 79, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-07-10 14:34:00', NULL);
INSERT INTO `kp_seminar` VALUES (41, 80, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-07-10 14:38:00', NULL);
INSERT INTO `kp_seminar` VALUES (42, 89, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-07-06 13:38:00', NULL);
INSERT INTO `kp_seminar` VALUES (43, 88, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-07-13 14:36:00', NULL);
INSERT INTO `kp_seminar` VALUES (44, 69, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-07-10 14:43:00', NULL);
INSERT INTO `kp_seminar` VALUES (45, 68, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-07-10 14:41:00', NULL);
INSERT INTO `kp_seminar` VALUES (46, 111, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-07-13 10:06:00', NULL);
INSERT INTO `kp_seminar` VALUES (47, 97, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-08-30 12:49:00', NULL);
INSERT INTO `kp_seminar` VALUES (48, 113, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-10-16 13:05:00', NULL);
INSERT INTO `kp_seminar` VALUES (49, 125, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-12-05 12:56:00', NULL);
INSERT INTO `kp_seminar` VALUES (50, 112, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-10-30 09:30:00', NULL);
INSERT INTO `kp_seminar` VALUES (51, 101, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-12-13 12:46:00', NULL);
INSERT INTO `kp_seminar` VALUES (52, 122, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-12-12 12:36:00', NULL);
INSERT INTO `kp_seminar` VALUES (53, 118, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-11 14:06:00', NULL);
INSERT INTO `kp_seminar` VALUES (54, 119, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-10 09:55:00', NULL);
INSERT INTO `kp_seminar` VALUES (55, 116, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-04 16:40:00', NULL);
INSERT INTO `kp_seminar` VALUES (56, 121, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2018-12-13 10:23:00', NULL);
INSERT INTO `kp_seminar` VALUES (57, 100, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-07 14:27:00', NULL);
INSERT INTO `kp_seminar` VALUES (58, 110, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-07 13:50:00', NULL);
INSERT INTO `kp_seminar` VALUES (59, 98, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-07 14:26:00', NULL);
INSERT INTO `kp_seminar` VALUES (60, 107, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-10 10:45:00', NULL);
INSERT INTO `kp_seminar` VALUES (61, 120, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-04 16:39:00', NULL);
INSERT INTO `kp_seminar` VALUES (62, 117, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-10 10:16:00', NULL);
INSERT INTO `kp_seminar` VALUES (63, 103, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-10 10:46:00', NULL);
INSERT INTO `kp_seminar` VALUES (64, 94, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-14 09:09:00', NULL);
INSERT INTO `kp_seminar` VALUES (65, 99, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-11 13:21:00', NULL);
INSERT INTO `kp_seminar` VALUES (66, 106, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-11 13:52:00', NULL);
INSERT INTO `kp_seminar` VALUES (67, 108, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-01-11 15:39:00', NULL);
INSERT INTO `kp_seminar` VALUES (68, 134, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-04-02 09:07:00', NULL);
INSERT INTO `kp_seminar` VALUES (69, 148, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-05-22 10:06:00', NULL);
INSERT INTO `kp_seminar` VALUES (70, 149, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-05-22 10:44:00', NULL);
INSERT INTO `kp_seminar` VALUES (71, 128, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-05-10 10:09:00', NULL);
INSERT INTO `kp_seminar` VALUES (72, 143, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-05-17 14:38:00', NULL);
INSERT INTO `kp_seminar` VALUES (73, 124, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-05-14 15:16:00', NULL);
INSERT INTO `kp_seminar` VALUES (74, 123, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-05-16 14:22:00', NULL);
INSERT INTO `kp_seminar` VALUES (75, 154, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-05-29 15:08:00', NULL);
INSERT INTO `kp_seminar` VALUES (76, 144, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-05-22 14:24:00', NULL);
INSERT INTO `kp_seminar` VALUES (77, 147, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-05-22 15:19:00', NULL);
INSERT INTO `kp_seminar` VALUES (78, 132, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-10-09 14:00:00', NULL);
INSERT INTO `kp_seminar` VALUES (79, 135, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-10-10 13:19:00', NULL);
INSERT INTO `kp_seminar` VALUES (80, 150, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-11-15 13:51:00', NULL);
INSERT INTO `kp_seminar` VALUES (81, 139, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-10-25 13:06:00', NULL);
INSERT INTO `kp_seminar` VALUES (82, 153, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-11-21 13:07:00', NULL);
INSERT INTO `kp_seminar` VALUES (83, 160, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-10-29 09:37:00', NULL);
INSERT INTO `kp_seminar` VALUES (84, 151, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-11-20 13:37:00', NULL);
INSERT INTO `kp_seminar` VALUES (85, 137, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-11-25 13:27:00', NULL);
INSERT INTO `kp_seminar` VALUES (86, 159, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-11-18 13:24:00', NULL);
INSERT INTO `kp_seminar` VALUES (87, 138, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-11-25 15:09:00', NULL);
INSERT INTO `kp_seminar` VALUES (88, 157, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-11-19 16:01:00', NULL);
INSERT INTO `kp_seminar` VALUES (89, 155, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-11-20 15:40:00', NULL);
INSERT INTO `kp_seminar` VALUES (90, 142, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-11-25 13:27:00', NULL);
INSERT INTO `kp_seminar` VALUES (91, 146, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2019-12-23 14:49:00', NULL);
INSERT INTO `kp_seminar` VALUES (92, 168, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2020-01-02 12:59:00', NULL);
INSERT INTO `kp_seminar` VALUES (93, 166, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2020-01-02 13:13:00', NULL);
INSERT INTO `kp_seminar` VALUES (94, 167, '', '0000-00-00', '00:00:00', '00:00:00', 1, 'SETUJU', '2020-01-23 15:43:00', NULL);
INSERT INTO `kp_seminar` VALUES (95, 174, 'ANALISA SISTEM PROTEKSI TURBO GENERATOR 12MW DENGAN WANLIDA MGPR 620Hb (BACKUP PROTECTION) PLTU BATURAJA PT. BAKTI NUGRAHA YUDA ENERGY', '2020-02-28', '09:00:00', '00:00:00', 5, 'SETUJU', '2020-07-01 11:57:00', NULL);
INSERT INTO `kp_seminar` VALUES (96, 169, 'Sistem Pernapasan Pada Generator Transformer (GT) Menggunakan Dehydrating Breather PLTU UNIT 3 PT Indonesia Power Semarang PGU', '2020-03-06', '08:00:00', '00:00:00', 6, 'SETUJU', '2020-07-01 07:36:00', NULL);
INSERT INTO `kp_seminar` VALUES (97, 164, 'PENGUJIAN KUALITAS ISOLASI BELITAN DARI KUMPARAN STATOR GENERATOR SINKRON BERDASARKAN NILAI TAHANAN ISOLASI, TAN DELTA, DAN PARTIAL DISCHARGE PADA PLTU JATENG 2 ADIPALA ', '2020-03-06', '09:20:00', '00:00:00', 6, 'SETUJU', '2020-07-03 13:59:00', NULL);
INSERT INTO `kp_seminar` VALUES (98, 170, 'SISTEM PROTEKSI OVER CURRENT RELAY (CO-5) PADA MOTOR FDFAN 3A PLTU UNIT 3 PT INDONESIA POWER SEMARANG\r\n', '2020-03-10', '13:00:00', '00:00:00', 1, 'SETUJU', '2020-07-01 08:50:00', NULL);
INSERT INTO `kp_seminar` VALUES (99, 173, 'ANALISA SISTEM PROTEKSI PENYULANG GAMBUS 20kV DENGAN SEPAM SERI 40 PADA PLTU BATURAJA PT. BAKTI NUGRAHA YUDA ENERGY', '2020-03-10', '14:00:00', '00:00:00', 1, 'SETUJU', '2020-07-01 14:24:00', NULL);
INSERT INTO `kp_seminar` VALUES (100, 183, 'ANALISIS KARAKTERISTIK AERODINAMIKA DAN KESTABILAN PESAWAT PADA TAILAP PLERIMENARY DESIGN DENGAN MENGGUNAKAN SOFTWARE OPENVSP, 2020', '2020-03-13', '13:00:00', '00:00:00', 1, 'SETUJU', '2020-03-11 07:24:00', NULL);
INSERT INTO `kp_seminar` VALUES (101, 179, 'ANALISIS SISTEM KERJA DAN PERFORMA PV ROOFTOP 10 KWP BERBASIS SMART GRID PADA GEDUNG B2TKE BPPT PUSPIPTEK SERPON', '2020-03-13', '13:00:00', '00:00:00', 1, 'SETUJU', '2020-03-11 07:51:00', NULL);
INSERT INTO `kp_seminar` VALUES (103, 185, 'IMPROVISASI AKSES TERHADAP MAIN SERVER PLC MENGGUNAKAN MEDIA WIRELESS NETWORK PT SARIHUSADA GENERASI MAHARDIKA PLANT YOGYAKARTA', '2020-07-17', '09:00:00', '11:00:00', 9, 'SETUJU', '2020-07-16 11:35:37', '2020-07-16 13:55:05');
INSERT INTO `kp_seminar` VALUES (104, 186, 'SISTEM INFORMASI PEMELIHARAAN PREVENTIF DIES PT TRIMITRA CHITRAHASTA', '2020-07-23', '10:00:00', '12:00:00', 9, 'SETUJU', '2020-07-20 14:29:29', '2020-07-20 14:56:45');
INSERT INTO `kp_seminar` VALUES (105, 209, 'SISTEM MANAJEMEN TES TOEFL GLOLINGO AND VRIDOM EDUCATION  DIGITAL STARTUP', '2020-08-04', '14:00:00', '15:00:00', 9, 'SETUJU', '2020-07-27 11:49:55', '2020-08-03 09:58:31');
INSERT INTO `kp_seminar` VALUES (106, 176, 'ANALISIS SISTEM KONTROL TIRE TIGHTEN MACHINE PADA PROSES PEMASANGAN RODA TRUK MEDIUM DI PT HINO MOTORS MANUFACTURING INDONESIA', '2020-07-30', '19:00:00', '20:00:00', 9, 'SETUJU', '2020-07-28 16:59:44', '2020-07-29 11:28:45');
INSERT INTO `kp_seminar` VALUES (107, 180, 'ANALISA PERFORMA PV ROOFTOP 10 kWp BERBASIS SMART GRID DI GEDUNG ENERGI B2TKE-BPPT', '2020-08-03', '10:00:00', '11:00:00', 9, 'SETUJU', '2020-07-31 11:44:07', '2020-07-31 20:55:03');
INSERT INTO `kp_seminar` VALUES (108, 184, 'PEMELIHARAAN PREVENTIF LOAD BREAK SWITCH MOTORIZED PADA SISTEM DISTRIBUSI 20 KV DI PT. PLN (Persero) UNIT PELAKSANA PENGATUR DISTRIBUSI (UP2D) KALIMANTAN BARAT', '2020-08-03', '13:00:00', '14:00:00', 9, 'SETUJU', '2020-07-31 19:23:57', '2020-07-31 22:18:26');
INSERT INTO `kp_seminar` VALUES (109, 178, 'PERANCANGAN SISTEM KENDALI OTOMATIK ALTITUDE HOLDER UNMANNED AERIAL VEHICLE (UAV) MEDIUM ALTITUDE LONG ENDURANCE (MALE) DENGAN CONTROLLER PID', '2020-08-03', '11:00:00', '12:00:00', 9, 'SETUJU', '2020-07-31 19:46:57', '2020-07-31 20:48:17');

-- ----------------------------
-- Table structure for kp_surat
-- ----------------------------
DROP TABLE IF EXISTS `kp_surat`;
CREATE TABLE `kp_surat`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `kp_id` int(15) NULL DEFAULT NULL,
  `no_surat` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `tanggal_surat` date NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `ibfk_kp3`(`kp_id`) USING BTREE,
  CONSTRAINT `ibfk_kp3` FOREIGN KEY (`kp_id`) REFERENCES `kp` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 179 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of kp_surat
-- ----------------------------
INSERT INTO `kp_surat` VALUES (18, 48, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (19, 49, '-', '2017-04-26', NULL, NULL);
INSERT INTO `kp_surat` VALUES (20, 50, '001/KP/3/2017', '2017-03-31', NULL, NULL);
INSERT INTO `kp_surat` VALUES (21, 51, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (22, 52, '0543/PHE430/2017-S8', '2017-06-08', NULL, NULL);
INSERT INTO `kp_surat` VALUES (23, 53, '060/32/UPMRC/2017', '2017-04-04', NULL, NULL);
INSERT INTO `kp_surat` VALUES (24, 54, 'GMF/TWL-2228/17', '2017-06-07', NULL, NULL);
INSERT INTO `kp_surat` VALUES (25, 55, 'GMF/TWL-2229/17', '2017-06-07', NULL, NULL);
INSERT INTO `kp_surat` VALUES (26, 56, 'GMF/TWL - 2058/18', '2018-02-05', NULL, NULL);
INSERT INTO `kp_surat` VALUES (27, 57, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (28, 58, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (29, 59, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (30, 60, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (31, 61, '1061/037.11a/HD3000/04/2017', '2017-04-13', NULL, NULL);
INSERT INTO `kp_surat` VALUES (32, 62, '1061/037.11a/HD3000/04/2017', '2017-04-13', NULL, NULL);
INSERT INTO `kp_surat` VALUES (33, 63, '0297/SDM.04.09/TJBB/2017', '2017-04-21', NULL, NULL);
INSERT INTO `kp_surat` VALUES (34, 64, '0314/SDM.04.09/TJBB/2017', '2017-05-02', NULL, NULL);
INSERT INTO `kp_surat` VALUES (35, 65, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (36, 66, '-', '2017-06-08', NULL, NULL);
INSERT INTO `kp_surat` VALUES (37, 67, '106/32/UPMRC/2017', '2017-07-10', NULL, NULL);
INSERT INTO `kp_surat` VALUES (38, 68, 'RW/HRD/40/X11/2017', '2017-12-13', NULL, NULL);
INSERT INTO `kp_surat` VALUES (39, 69, 'RW/HRD/40/X11/2017', '2017-12-13', NULL, NULL);
INSERT INTO `kp_surat` VALUES (40, 70, '467/KP/XL/ November/17', '2017-11-27', NULL, NULL);
INSERT INTO `kp_surat` VALUES (41, 71, '0197/SDM04.09/APP-KRWG/2017', '2017-11-13', NULL, NULL);
INSERT INTO `kp_surat` VALUES (42, 72, '03918/SDM.04.06/HoDORG/20179', '2017-11-10', NULL, NULL);
INSERT INTO `kp_surat` VALUES (43, 73, '253/YK-WIL.III/XII/2017', '2017-12-18', NULL, NULL);
INSERT INTO `kp_surat` VALUES (44, 74, '0952/SDM.04.09/TJBB/2017', '2017-12-11', NULL, NULL);
INSERT INTO `kp_surat` VALUES (45, 75, '254/YK-WIL.III/XII/2017', '2017-12-18', NULL, NULL);
INSERT INTO `kp_surat` VALUES (46, 76, '0955/SDM.04.09/TJBB/2017', '2017-12-11', NULL, NULL);
INSERT INTO `kp_surat` VALUES (47, 77, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (48, 78, '0198/SDM04.09/APP-KRWG/2017', '2017-11-13', NULL, NULL);
INSERT INTO `kp_surat` VALUES (49, 79, '252/HR.09/HD-32/XII/2017', '2017-12-06', NULL, NULL);
INSERT INTO `kp_surat` VALUES (50, 80, '252/HR.09/HD-32/XII/2017', '2017-12-06', NULL, NULL);
INSERT INTO `kp_surat` VALUES (51, 81, '52/233.BS/INKA/2018', '2018-03-01', NULL, NULL);
INSERT INTO `kp_surat` VALUES (52, 82, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (53, 83, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (54, 84, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (55, 85, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (56, 86, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (57, 87, '0008/SDM.04.09/A.SMG/2018', '2018-01-15', NULL, NULL);
INSERT INTO `kp_surat` VALUES (58, 88, '0009/SDM.04.09/A.SMG/2018', '2018-01-15', NULL, NULL);
INSERT INTO `kp_surat` VALUES (59, 89, '0010/SDM.04.09/A.SMG/2018', '2018-01-15', NULL, NULL);
INSERT INTO `kp_surat` VALUES (60, 90, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (61, 91, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (62, 92, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (63, 93, '183/32/UPMRC/2017', '2017-12-20', NULL, NULL);
INSERT INTO `kp_surat` VALUES (64, 94, 'SKT/ASKI/HRGA/001/VII/2018', '2018-07-18', NULL, NULL);
INSERT INTO `kp_surat` VALUES (65, 95, '013/SP/III/PM/18', '2018-03-01', NULL, NULL);
INSERT INTO `kp_surat` VALUES (66, 96, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (67, 97, '9/32/UPMRC/2018', '2018-01-18', NULL, NULL);
INSERT INTO `kp_surat` VALUES (68, 98, '12/32/UPMRC/2018', '2018-02-05', NULL, NULL);
INSERT INTO `kp_surat` VALUES (69, 99, '0080/SDM.04.06/A.MGL/2018', '2018-03-21', NULL, NULL);
INSERT INTO `kp_surat` VALUES (70, 100, '13/32/UPMRC/2018', '2018-02-05', NULL, NULL);
INSERT INTO `kp_surat` VALUES (71, 101, 'GMF/TWL-2177/18', '2018-04-16', NULL, NULL);
INSERT INTO `kp_surat` VALUES (72, 102, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (73, 103, '0034/STH.00.01/PS/2018', '2018-03-28', NULL, NULL);
INSERT INTO `kp_surat` VALUES (74, 104, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (75, 105, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (76, 106, 'SKT/ASKI/HRGA/001/VII/2018', '2018-07-18', NULL, NULL);
INSERT INTO `kp_surat` VALUES (77, 107, 'B-2460/BATAN/STA/DL02 01/07/2018', '2018-07-06', NULL, NULL);
INSERT INTO `kp_surat` VALUES (78, 108, 'SKT/ASKI/HRGA/001/VII/2018', '2018-07-18', NULL, NULL);
INSERT INTO `kp_surat` VALUES (79, 109, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (80, 110, '-', '2018-05-31', NULL, NULL);
INSERT INTO `kp_surat` VALUES (81, 111, '01/HRDAM/TSIC/V/2018', '2018-05-07', NULL, NULL);
INSERT INTO `kp_surat` VALUES (82, 112, '259/07/UJPBLB/2018', '2018-06-28', NULL, NULL);
INSERT INTO `kp_surat` VALUES (83, 113, '259/07/UJPBLB/2018', '2018-06-28', NULL, NULL);
INSERT INTO `kp_surat` VALUES (84, 114, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (85, 115, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (86, 116, '0099/SDM.04.09/APP-KRWG/2018', '2018-07-03', NULL, NULL);
INSERT INTO `kp_surat` VALUES (87, 117, '0098/SDM.04.09/APP-KRWG/2018', '2018-07-03', NULL, NULL);
INSERT INTO `kp_surat` VALUES (88, 118, '0095/SDM.04.09/APP-KRWG/2018', '2018-07-03', NULL, NULL);
INSERT INTO `kp_surat` VALUES (89, 119, '0082/SDM.04.09/APP CWNG/2018', '2018-07-03', NULL, NULL);
INSERT INTO `kp_surat` VALUES (90, 120, 'Tel.47/PS 000/R4W-4H522000/2018', '2018-06-26', NULL, NULL);
INSERT INTO `kp_surat` VALUES (91, 121, 'Tel.46/PS 000/R4W-4H522000/2018', '2018-06-26', NULL, NULL);
INSERT INTO `kp_surat` VALUES (92, 122, 'Tel.45/PS 000/R4W-4H522000/2018', '2018-06-26', NULL, NULL);
INSERT INTO `kp_surat` VALUES (93, 123, '078.PP/335/UPMT/IX/2018', '2018-09-26', NULL, NULL);
INSERT INTO `kp_surat` VALUES (94, 124, '079.PP/335/UPMT/IX/2018', '2018-09-26', NULL, NULL);
INSERT INTO `kp_surat` VALUES (95, 125, '192/PGU/Adm/VII/2018', '2018-08-10', NULL, NULL);
INSERT INTO `kp_surat` VALUES (96, 126, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (97, 127, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (98, 128, 'KE.105/XII/4/BYYK-2018', '2018-12-07', NULL, NULL);
INSERT INTO `kp_surat` VALUES (99, 129, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (100, 130, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (101, 131, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (102, 132, '113/32/UPSMG/2018', '2018-10-30', NULL, NULL);
INSERT INTO `kp_surat` VALUES (103, 133, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (104, 134, '862/037.11a/HD3000/12/2018', '2018-12-26', NULL, NULL);
INSERT INTO `kp_surat` VALUES (105, 135, '10.10/02/02/2019/', '2019-02-02', NULL, NULL);
INSERT INTO `kp_surat` VALUES (106, 136, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (107, 137, 'EA138335', '2019-02-06', NULL, NULL);
INSERT INTO `kp_surat` VALUES (108, 138, 'HMS.02.03/06/LPPNPI/07/2019/731', '2019-07-10', NULL, NULL);
INSERT INTO `kp_surat` VALUES (109, 139, 'KP-109/K22310/2019-S8', '2019-04-15', NULL, NULL);
INSERT INTO `kp_surat` VALUES (110, 140, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (111, 141, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (112, 142, '113/32/UPSMG/2018', '2018-10-30', NULL, NULL);
INSERT INTO `kp_surat` VALUES (113, 143, '305/HR.09/HD-032/XII/2018', '2018-12-30', NULL, NULL);
INSERT INTO `kp_surat` VALUES (114, 144, '305/HR.09/HD-032/XII/2018', '2018-12-30', NULL, NULL);
INSERT INTO `kp_surat` VALUES (115, 145, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (116, 146, 'NULL', '0000-00-00', NULL, NULL);
INSERT INTO `kp_surat` VALUES (117, 147, '011/HR.09/HD-32/I/2019', '2019-01-15', NULL, NULL);
INSERT INTO `kp_surat` VALUES (118, 148, '0401/TK.000/TA-0204/12-2018', '2018-12-20', NULL, NULL);
INSERT INTO `kp_surat` VALUES (119, 149, '0402/TK.000/TA-0204/12-2018', '2018-12-20', NULL, NULL);
INSERT INTO `kp_surat` VALUES (120, 150, 'O003335', '2019-01-16', NULL, NULL);
INSERT INTO `kp_surat` VALUES (121, 151, 'O003335', '2019-01-16', NULL, NULL);
INSERT INTO `kp_surat` VALUES (122, 152, NULL, NULL, NULL, NULL);
INSERT INTO `kp_surat` VALUES (123, 153, 'EA138335', '2019-02-06', NULL, NULL);
INSERT INTO `kp_surat` VALUES (124, 154, 'SM2093/190208/GEN', '2019-02-08', NULL, NULL);
INSERT INTO `kp_surat` VALUES (125, 155, 'KP-111/K22310/2019-S8', '2019-04-15', NULL, NULL);
INSERT INTO `kp_surat` VALUES (127, 157, 'KP-110/K22310/2019-S8', '2019-04-15', NULL, NULL);
INSERT INTO `kp_surat` VALUES (128, 158, NULL, NULL, NULL, NULL);
INSERT INTO `kp_surat` VALUES (129, 159, 'PDL.03.02/06/LPPNPI/05/2019/590', '2019-05-24', NULL, NULL);
INSERT INTO `kp_surat` VALUES (130, 160, '01/UMGI/SR/VI/2019', '2019-06-18', NULL, NULL);
INSERT INTO `kp_surat` VALUES (131, 161, NULL, NULL, NULL, NULL);
INSERT INTO `kp_surat` VALUES (132, 162, NULL, NULL, NULL, NULL);
INSERT INTO `kp_surat` VALUES (134, 164, '036.SKt/070/UJH/2019', '2019-11-26', NULL, NULL);
INSERT INTO `kp_surat` VALUES (135, 165, NULL, NULL, NULL, NULL);
INSERT INTO `kp_surat` VALUES (136, 166, '343.35/REKA/GEN/VII/2019', '2019-07-26', NULL, NULL);
INSERT INTO `kp_surat` VALUES (137, 167, '343.35/REKA/GEN/VII/2019', '2019-07-26', NULL, NULL);
INSERT INTO `kp_surat` VALUES (138, 168, '343.35/REKA/GEN/VII/2019', '2019-07-26', NULL, NULL);
INSERT INTO `kp_surat` VALUES (139, 169, '0105/32/UPSMG/2019', '2019-08-14', NULL, NULL);
INSERT INTO `kp_surat` VALUES (140, 170, '0105/32/UPSMG/2019', '2019-08-14', NULL, NULL);
INSERT INTO `kp_surat` VALUES (141, 171, '01102/VIII/HR/SK.KP/2019', '2019-08-30', NULL, NULL);
INSERT INTO `kp_surat` VALUES (142, 172, '111/037.11a/HD3000/02/2020\r\n', '2020-02-04', NULL, NULL);
INSERT INTO `kp_surat` VALUES (143, 173, '141/SPM/HRD/SITE/XII.19', '2019-12-27', NULL, NULL);
INSERT INTO `kp_surat` VALUES (144, 174, '142/SPM/HRD/SITE/XII.19', '2019-12-27', NULL, NULL);
INSERT INTO `kp_surat` VALUES (145, 175, 'KP-121/K22310/2020-S8', '2020-01-08', NULL, '2020-07-10 13:43:49');
INSERT INTO `kp_surat` VALUES (146, 176, '0001/PKL/HMMI-HRD/I/2020', '2020-01-10', NULL, NULL);
INSERT INTO `kp_surat` VALUES (147, 177, 'KP-121/K22310/2020-S8', '2020-01-08', NULL, '2020-08-03 09:41:19');
INSERT INTO `kp_surat` VALUES (148, 178, '2009/037.11a/HD3000/11/2019', '2019-11-25', NULL, NULL);
INSERT INTO `kp_surat` VALUES (149, 179, 'B-323/BPPT/B2TKE/SD/DL.03.01/09/2019', '2019-09-04', NULL, NULL);
INSERT INTO `kp_surat` VALUES (150, 180, 'B-323/BPPT/B2TKE/SD/DL.03.01/09/2019', '2019-09-04', NULL, NULL);
INSERT INTO `kp_surat` VALUES (151, 181, '01138/XI/HR/SK.KP/2019', '2019-11-15', NULL, NULL);
INSERT INTO `kp_surat` VALUES (153, 183, '1927/037.11a/HD3000/10/2019', '2019-10-15', NULL, NULL);
INSERT INTO `kp_surat` VALUES (154, 184, '0112/MUM.00.01/120500/2019', '2019-12-04', NULL, NULL);
INSERT INTO `kp_surat` VALUES (155, 185, '003655/SH-PKL/I/2020', '2020-01-24', NULL, NULL);
INSERT INTO `kp_surat` VALUES (156, 186, 'HRD/01/TCH/I/2020', '2020-01-13', NULL, NULL);
INSERT INTO `kp_surat` VALUES (157, 187, '008.SKt/070/MSU/2020', '2020-01-17', NULL, NULL);
INSERT INTO `kp_surat` VALUES (167, 197, '03 /UNS/FT/IK/2020', '2020-07-24', NULL, '2020-07-27 09:46:36');
INSERT INTO `kp_surat` VALUES (168, 209, '-', '2020-05-12', '2020-07-23 07:45:43', '2020-07-23 07:48:55');
INSERT INTO `kp_surat` VALUES (169, 202, '01 /UNS/FT/IK/2020', '2020-07-24', '2020-07-24 14:58:55', '2020-07-24 14:58:55');
INSERT INTO `kp_surat` VALUES (170, 200, '02 /UNS/FT/IK/2020', '2020-07-24', '2020-07-24 15:00:13', '2020-07-24 15:00:13');
INSERT INTO `kp_surat` VALUES (171, 208, '01 /UNS/FT/LabKomJar/2020', '2020-07-24', '2020-07-27 09:35:18', '2020-07-27 09:35:18');
INSERT INTO `kp_surat` VALUES (172, 207, '02 /UNS/FT/LabKomJar/2020', '2020-07-24', '2020-07-27 09:36:10', '2020-07-27 09:36:10');
INSERT INTO `kp_surat` VALUES (173, 206, '001/TELKO/UN27.8/2020', '2020-07-24', '2020-07-27 09:36:49', '2020-07-27 09:36:49');
INSERT INTO `kp_surat` VALUES (174, 205, '001/TELKO/UN27.8/2020', '2020-07-24', '2020-07-27 09:37:28', '2020-07-27 09:37:28');
INSERT INTO `kp_surat` VALUES (175, 204, '003/TELKO/UN27.8/2020', '2020-07-24', '2020-07-27 09:38:06', '2020-07-27 09:40:26');
INSERT INTO `kp_surat` VALUES (176, 203, '005/TELKO/UN27.8/2020', '2020-07-24', '2020-07-27 09:41:28', '2020-07-27 09:41:28');
INSERT INTO `kp_surat` VALUES (177, 201, '004/TELKO/UN27.8/2020', '2020-07-24', '2020-07-27 09:42:24', '2020-07-27 09:42:24');
INSERT INTO `kp_surat` VALUES (178, 199, '04 /UNS/FT/IK/2020', '2020-07-24', '2020-07-27 09:45:26', '2020-07-27 09:45:26');

-- ----------------------------
-- Table structure for log_judul_ta
-- ----------------------------
DROP TABLE IF EXISTS `log_judul_ta`;
CREATE TABLE `log_judul_ta`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ta_id` int(11) NULL DEFAULT NULL,
  `judul_lama` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `judul_baru` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `judul_alasan` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `status_judul` smallint(6) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of log_judul_ta
-- ----------------------------
INSERT INTO `log_judul_ta` VALUES (1, 49, 'Rancang Bangun Sistem Adaptive Cruise Control Pada Sepeda Motor Listrik', 'Perancangan dan Analisis Sistem Adaptive Cruise Control Pada Sepeda Motor Listrik', 'Mendapatkan masukan dari Penguji I ( Dr. Miftahul Anwar S.Si., M.Eng. ) supaya mengganti kalimat Rancang Bangun yang identik dengan Tugas Akhir D3 dan sudah mendapat persetujuan pembimbing untuk penggantian judul ketika sesi diskusi pada saat pelaksanaan sidang pendadaran', 1, '2020-07-09 09:39:17', '2020-07-10 06:52:30');
INSERT INTO `log_judul_ta` VALUES (2, 59, 'Pengunaan Rangkaian Boost Converter pada Kontroler Panel Surya dengna Menggunakan Metode Rapid Prototyping.', 'Kendali Kecepatan Motor AC pada Kendaraan Listrik Menggunakan Metode Logika Fuzzy', 'Mengalami beberapa kendala yang selalu menghambat proses pengerjaan skripsi.', 2, '2020-07-14 12:04:15', '2020-07-14 12:04:15');
INSERT INTO `log_judul_ta` VALUES (3, 64, 'Rancang Bangun Sistem Kendali Posisi dengan Metode LQG pada PVTOL (Plannar Vertical Take Off Landing)', 'Sistem Kendali Posisi dengan Metode Linear Quadratic Gaussian pada VTOL (Vertical Take Off Landing)', 'Penyederhanaan kalimat serta menitikberatkan pada metode yang diajukan', 1, '2020-07-14 13:49:40', '2020-07-15 16:53:31');
INSERT INTO `log_judul_ta` VALUES (4, 64, 'Rancang Bangun Sistem Kendali Posisi dengan Metode LQG pada PVTOL (Plannar Vertical Take Off Landing)', 'Sistem Kendali Posisi dengan Metode Linear Quadratic Gaussian pada VTOL (Vertical Take-Off Landing)', 'Penghapusan kata Rancang Bangun', 2, '2020-07-14 16:29:01', '2020-07-14 16:29:01');
INSERT INTO `log_judul_ta` VALUES (5, 63, 'Rancang Bangun Autonomous Mobile Robot Menggunakan Sistem Navigasi Local Mapping.', 'Navigasi Autonomous Robot Balancing Beroda Dua Berbasis ROS', 'Menyesuaikan dengan apa yang dibuat agar lebih detail dan spesifik', 1, '2020-07-21 13:56:42', '2020-08-01 08:23:46');
INSERT INTO `log_judul_ta` VALUES (6, 63, 'Rancang Bangun Autonomous Mobile Robot Menggunakan Sistem Navigasi Local Mapping.', 'Navigasi otonom pada robot Keseimbangan beroda dua berbasis ROS', 'Penyempurnaan, perbaikan kata dalam bahasa indonesia', 2, '2020-07-21 15:36:33', '2020-07-21 15:36:33');
INSERT INTO `log_judul_ta` VALUES (7, 53, 'Rancang Bangun Kendali Motor DC Tanpa Sikat (BLDC) pada Sepeda Listrik.', 'Rancang Bangun Kendali Kecepatan Motor DC Tanpa Sikat (BLDC) pada Sepeda Listrik', 'Permintaan dari Pembimbing 1 karena alat yang saya buat cenderung lebih pengendalian kecepatan motor BLDC', 1, '2020-07-21 19:10:42', '2020-08-01 05:42:43');
INSERT INTO `log_judul_ta` VALUES (8, 35, 'Analisis Kualitas Daya Listrik Tiga Fasa Menggunakan USB DAQ Berbasis PC', 'Rancang Bangun Instrumen Power Quality Analyzer Tiga Fasa Menggunakan Low Cost USB DAQ Berbasis PC', 'Agar lebih sesuai dengan penelitian yang dilakukan', 1, '2020-07-21 20:07:01', '2020-07-21 20:08:25');
INSERT INTO `log_judul_ta` VALUES (9, 62, 'Sistem Managemen Energi Gedung Berbasis Internet of Things menggunakan Modulasi LoRa', 'Sistem Manajemen Energi Berbasis Internet of Things Menggunakan Modulasi LoRa (Long Range)', 'Penyesuaian dengan isi TA.', 1, '2020-07-23 19:10:50', '2020-07-23 19:48:50');
INSERT INTO `log_judul_ta` VALUES (10, 47, 'Rancang Bangun Sistem Manajemen Baterai (BMS) dengan Active Balancing Menggunakan Topologi Flyback Converter untuk Baterai Lithium Ion.', 'Sistem Manajemen Baterai (BMS) dengan Active Balancing Menggunakan Topologi Flyback Converter untuk Baterai Lithium Ion', 'Revisi dari pak Anwar', 1, '2020-07-26 14:04:28', '2020-07-31 18:09:17');
INSERT INTO `log_judul_ta` VALUES (11, 38, 'Kendali Kecepatan Motor Induksi Menggunakan Fuzzy Logic dan PID Berbasis Mikrokontroler C2000', 'Kendali Kecepatan Motor Induksi Menggunakan Fuzzy Logic Berbasis Mikrokontroler Arduino', 'Mendapat saran dari Dosen Pembimbing untuk mengganti ke mikrokontroler Arduino karena lebih familiar. Mengganti Fuzzy-PID dengan Fuzzy saja dikarenakan untuk menyederhanakan proses kontrol dan pengambilan data.', 1, '2020-07-27 10:40:47', '2020-07-31 18:06:52');
INSERT INTO `log_judul_ta` VALUES (12, 63, 'Navigasi Autonomous Robot Balancing Beroda Dua Berbasis ROS', 'Navigasi Robot Keseimbangan dengan Virtual Map dan Virtual Sensor', 'Penyesuaian dengan hasil revisi dari seminar hasil', 1, '2020-07-27 14:14:56', '2020-08-01 08:38:44');
INSERT INTO `log_judul_ta` VALUES (13, 53, 'Rancang Bangun Kendali Kecepatan Motor DC Tanpa Sikat (BLDC) pada Sepeda Listrik', 'Pengembangan Kendali PI dan Monitoring pada Kecepatan Motor BLDC dengan Sensor Hall', 'Terdapat Perubahan Metode Kendali yang digunakan', 1, '2020-07-31 00:33:08', '2020-08-01 08:38:40');
INSERT INTO `log_judul_ta` VALUES (14, 53, 'Pengembangan Kendali PI dan Monitoring pada Kecepatan Motor BLDC dengan Sensor Hall', 'Rancang Bangun Kendali dan Monitoring pada Kecepatan Motor BLDC dengan Sensor Hall', 'Perubahan algoritma kendali yang digunakan', 1, '2020-08-03 20:32:04', '2020-08-04 13:20:45');

-- ----------------------------
-- Table structure for log_pembatalan_ta
-- ----------------------------
DROP TABLE IF EXISTS `log_pembatalan_ta`;
CREATE TABLE `log_pembatalan_ta`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ta_id` int(15) NULL DEFAULT NULL,
  `pembatalan_alasan` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `status_pembatalan` smallint(6) NULL DEFAULT 2,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for log_pembimbing2_ta
-- ----------------------------
DROP TABLE IF EXISTS `log_pembimbing2_ta`;
CREATE TABLE `log_pembimbing2_ta`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log_pembimbing_ta_id` int(15) NULL DEFAULT NULL,
  `pembimbing_lama` int(15) NULL DEFAULT NULL,
  `pembimbing_baru` int(15) NULL DEFAULT NULL,
  `pembimbing_ke` smallint(6) NULL DEFAULT NULL,
  `status_pembimbing_lama` smallint(6) NULL DEFAULT 2,
  `status_pembimbing_baru` smallint(6) NULL DEFAULT 2,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for log_pembimbing_ta
-- ----------------------------
DROP TABLE IF EXISTS `log_pembimbing_ta`;
CREATE TABLE `log_pembimbing_ta`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ta_id` int(15) NULL DEFAULT NULL,
  `pembimbing_alasan` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `status_pembimbing` smallint(6) NULL DEFAULT 2,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for log_perpanjangan_ta
-- ----------------------------
DROP TABLE IF EXISTS `log_perpanjangan_ta`;
CREATE TABLE `log_perpanjangan_ta`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ta_id` int(15) NULL DEFAULT NULL,
  `perpanjangan_ke` int(15) NULL DEFAULT NULL,
  `perpanjangan_alasan` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `rencana_deadline` date NULL DEFAULT NULL,
  `status_perpanjangan` smallint(6) NULL DEFAULT 2,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES (1, '2014_10_12_000000_create_users_table', 1);
INSERT INTO `migrations` VALUES (2, '2014_10_12_100000_create_password_resets_table', 1);
INSERT INTO `migrations` VALUES (3, '2019_08_19_000000_create_failed_jobs_table', 1);
INSERT INTO `migrations` VALUES (6, '2020_02_27_063732_create_roles_table', 2);
INSERT INTO `migrations` VALUES (7, '2020_02_27_063958_create_role_user_table', 2);
INSERT INTO `migrations` VALUES (8, '2020_02_27_163839_create_foreign_keys_for_role_user_table', 3);

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets`  (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  INDEX `password_resets_email_index`(`email`(191)) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of password_resets
-- ----------------------------
INSERT INTO `password_resets` VALUES ('ggfrozz@gmail.com', '$2y$10$6fc7zAFnIbBfiAUV2GNEOukLNgp4jErrbkJeH0wcpYBmL9VrWiyv2', '2020-02-27 05:19:13');

-- ----------------------------
-- Table structure for ref_dosen
-- ----------------------------
DROP TABLE IF EXISTS `ref_dosen`;
CREATE TABLE `ref_dosen`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `kode_dosen` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `nip` bigint(30) NULL DEFAULT NULL,
  `nama_dosen` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `status_dosen` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `signature_dosen` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 22 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ref_dosen
-- ----------------------------
INSERT INTO `ref_dosen` VALUES (1, 'AUG001', 1951100120161001, 'Dr.Ir. Augustinus Sujono M.T.', 'AKTIF', '1951100120161001.png', '2020-03-01 16:20:22', '2020-07-22 12:52:43');
INSERT INTO `ref_dosen` VALUES (2, 'CHI001', 198804162015041002, 'Chico Hermanu BA, S.T., M.Eng.', 'AKTIF', '198804162015041002.png', '2020-03-01 16:20:22', '2020-07-20 11:20:36');
INSERT INTO `ref_dosen` VALUES (3, 'DRM001', 1983032420130201, 'Dr. Miftahul Anwar S.Si., M.Eng.', 'AKTIF', '1983032420130201.png', '2020-03-01 16:20:22', '2020-07-21 20:40:45');
INSERT INTO `ref_dosen` VALUES (4, 'FER001', 196801161999031001, 'Feri Adriyanto, Ph.D.', 'AKTIF', '196801161999031001.png', '2020-03-01 16:20:22', '2020-07-16 12:12:24');
INSERT INTO `ref_dosen` VALUES (5, 'HAR050', 199104132018031001, 'Hari Maghfiroh M.Eng.', 'AKTIF', '199104132018031001.png', '2020-03-01 16:20:22', '2020-07-16 13:06:04');
INSERT INTO `ref_dosen` VALUES (6, 'IRW001', 197004041996031002, 'Irwan Iftadi S.T., M.Eng.', 'AKTIF', '197004041996031002.png', '2020-03-01 16:20:22', '2020-07-16 11:47:45');
INSERT INTO `ref_dosen` VALUES (7, 'MEI002', 197705132009121004, 'Meiyanto Eko Sulistyo S.T., M.Eng.', 'AKTIF', '197705132009121004.png', '2020-03-01 16:20:22', '2020-07-23 09:36:49');
INSERT INTO `ref_dosen` VALUES (8, 'MUH015', 197007201999031001, 'Prof. Muhammad Nizam S.T,M.T,Ph.D.', 'AKTIF', '197007201999031001.png', '2020-03-01 16:20:22', NULL);
INSERT INTO `ref_dosen` VALUES (9, 'MUH043', 198812292019031011, 'Muhammad Hamka I, S.T., M.Eng.', 'AKTIF', '198812292019031011.png', '2020-03-01 16:20:22', '2020-07-16 11:06:20');
INSERT INTO `ref_dosen` VALUES (10, 'SUB012', 198106092003121002, 'Subuh Pramono S.T., M.T.', 'AKTIF', '198106092003121002.png', '2020-03-01 16:20:22', '2020-07-21 15:57:45');
INSERT INTO `ref_dosen` VALUES (11, 'SUT034', 198705062019031009, 'Sutrisno S.T., M.Sc, Ph.D.', 'AKTIF', '198705062019031009.png', '2020-03-01 16:20:22', '2020-07-21 20:32:34');
INSERT INTO `ref_dosen` VALUES (14, NULL, 196710191999031001, 'Jaka Sulistya Budi, S.T.', 'AKTIF', '196710191999031001.png', '2020-03-01 16:20:22', '2020-08-03 15:57:49');
INSERT INTO `ref_dosen` VALUES (15, NULL, 1987072320150401, 'Widodo', 'AKTIF', NULL, '2020-03-01 16:20:22', NULL);
INSERT INTO `ref_dosen` VALUES (16, NULL, 196710011997021001, 'Dr.Techn.Ir. Sholihin As\'ad, M.T.', 'AKTIF', NULL, '2020-03-01 16:20:22', NULL);
INSERT INTO `ref_dosen` VALUES (17, 'AGU060', 199203152019031017, 'Agus Ramelan, S.Pd., M.T.', 'AKTIF', '199203152019031017.png', '2020-03-01 16:20:22', '2020-07-16 11:37:50');
INSERT INTO `ref_dosen` VALUES (18, 'JOK018', 198904242019031013, 'Joko Slamet Saputro, S.Pd., M.T.', 'AKTIF', '198904242019031013.png', '2020-03-01 16:20:22', '2020-07-16 13:12:56');
INSERT INTO `ref_dosen` VALUES (19, 'NANANG', 197605302002121002, 'Nanang Wiyono, dr., M.Kes', 'AKTIF', '197605302002121002.png', '2020-04-04 22:54:20', '2020-06-26 13:15:07');
INSERT INTO `ref_dosen` VALUES (20, 'Dummy1', 100000000000001, 'Dosen1', 'AKTIF', NULL, '2020-07-04 22:51:22', '2020-07-04 22:51:22');
INSERT INTO `ref_dosen` VALUES (21, 'FAI010', 197711162005011008, 'Dr. Eng. Faisal Rahutomo, S.T., M.Kom.', 'AKTIF', '197711162005011008.png', '2020-07-21 20:40:26', '2020-07-22 10:57:00');

-- ----------------------------
-- Table structure for ref_jabatan
-- ----------------------------
DROP TABLE IF EXISTS `ref_jabatan`;
CREATE TABLE `ref_jabatan`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `nama_jabatan` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `dosen_id` int(15) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ref_jabatan
-- ----------------------------
INSERT INTO `ref_jabatan` VALUES (1, 'Kepala Program Studi', 4, NULL, NULL);
INSERT INTO `ref_jabatan` VALUES (2, 'Dekan', 16, NULL, NULL);
INSERT INTO `ref_jabatan` VALUES (3, 'Koordinator Kerja Praktek', 14, NULL, '2020-03-01 21:44:26');
INSERT INTO `ref_jabatan` VALUES (4, 'Koordinator Tugas Akhir', 9, NULL, NULL);
INSERT INTO `ref_jabatan` VALUES (5, 'KBK Teknologi Informasi dan Komunikasi (ICT)', 11, NULL, NULL);
INSERT INTO `ref_jabatan` VALUES (6, 'KBK Sistem Mekatronika (SM)', 5, NULL, '2020-03-01 17:42:11');
INSERT INTO `ref_jabatan` VALUES (7, 'KBK Sistem Energi Listrik (SEL)', 2, NULL, '2020-03-01 17:49:07');
INSERT INTO `ref_jabatan` VALUES (8, 'Staff Prodi', 15, '2020-03-01 16:59:44', '2020-03-01 21:36:34');
INSERT INTO `ref_jabatan` VALUES (9, 'Test', 8, '2020-03-01 21:36:43', '2020-03-01 21:36:43');
INSERT INTO `ref_jabatan` VALUES (10, 'Kalab Konversi Energi dan Sistem Tenaga Listrik', 2, NULL, NULL);
INSERT INTO `ref_jabatan` VALUES (11, 'Kalab Elektronika', 3, NULL, NULL);
INSERT INTO `ref_jabatan` VALUES (12, 'Laboran Elektronika', 14, NULL, NULL);
INSERT INTO `ref_jabatan` VALUES (13, 'Kalab Telekomunikasi dan Pengolahan Sinyal', 9, NULL, NULL);
INSERT INTO `ref_jabatan` VALUES (14, 'Kalab Instrumentasi Kendali', 5, NULL, NULL);

-- ----------------------------
-- Table structure for ref_mahasiswa
-- ----------------------------
DROP TABLE IF EXISTS `ref_mahasiswa`;
CREATE TABLE `ref_mahasiswa`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `nim` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `nama_mhs` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `angkatan` int(10) NULL DEFAULT NULL,
  `sks` int(10) NULL DEFAULT NULL,
  `ipk` float NULL DEFAULT NULL,
  `pem_akademik` int(15) NULL DEFAULT NULL,
  `pem_kp` int(15) NULL DEFAULT NULL,
  `signature_mhs` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `status_mhs` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `pemkp`(`pem_kp`) USING BTREE,
  INDEX `pemakademik`(`pem_akademik`) USING BTREE,
  CONSTRAINT `ref_mahasiswa_ibfk_1` FOREIGN KEY (`pem_akademik`) REFERENCES `ref_dosen` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `ref_mahasiswa_ibfk_2` FOREIGN KEY (`pem_kp`) REFERENCES `ref_dosen` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 261 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ref_mahasiswa
-- ----------------------------
INSERT INTO `ref_mahasiswa` VALUES (1, 'I0714001', 'Abid Alim Mustaqim', 2014, 150, 3.65, 1, 8, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (2, 'I0714002', 'Aditya Meita Nugraha', 2014, 32, 2.57, 1, 1, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (3, 'I0714003', 'Aji Fauzan Hidayat', 2014, 148, 3.26, 1, 7, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (4, 'I0714004', 'Andryawan Jaya Purnama', 2014, 149, 3.47, 1, 4, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (5, 'I0714005', 'Anrico Gideon Alfano', 2014, 149, 3.31, 1, 3, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (6, 'I0714006', 'Aulia Ardan Sultani', 2014, 148, 3.32, 1, 4, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (7, 'I0714007', 'Bima Tri Prasetya', 2014, 151, 3.55, 1, 2, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (8, 'I0714008', 'Bina Pangestu Nugroho', 2014, 153, 3.24, 3, 8, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (9, 'I0714009', 'Boni Vasius Rosen', 2014, 4, 1.05, 1, 20, NULL, 'UNDUR DIRI');
INSERT INTO `ref_mahasiswa` VALUES (10, 'I0714010', 'Dwiyan Bagas Dewanto', 2014, 2, 0.38, 1, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (11, 'I0714011', 'Edi Nugroho', 2014, 153, 3.34, 6, 1, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (12, 'I0714012', 'Fadhila Amalia', 2014, 7, 1.33, 8, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (13, 'I0714013', 'Fasda Ilhaq Robbani', 2014, 152, 3.28, 8, 3, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (14, 'I0714014', 'Febriano Ekky R P Y', 2014, 2, 0.38, 8, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (15, 'I0714015', 'Ferdiansyah Ashil Farisi', 2014, 145, 3.24, 8, 8, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (16, 'I0714016', 'Fransiskus Xaverius Rian Wicaksono', 2014, 158, 3.78, 8, 4, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (17, 'I0714017', 'Igor M. Farhan', 2014, 148, 3.82, 8, 6, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (18, 'I0714018', 'Irfan Maulana M', 2014, 70, 1.93, 8, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (19, 'I0714019', 'Luthfy Makhmudy', 2014, 148, 3.47, 9, 9, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (20, 'I0714020', 'M Hakim Adhiguna', 2014, 145, 3.25, 2, 6, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (21, 'I0714021', 'Muhamad Dzaky Ashidqi', 2014, 145, 3.09, 4, 9, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (22, 'I0714022', 'Muhammad Iqbal', 2014, 4, 1.05, 8, NULL, NULL, 'UNDUR DIRI');
INSERT INTO `ref_mahasiswa` VALUES (23, 'I0714026', 'Renaldy Purwanto', 2014, 80, 3.5, 1, 11, NULL, 'UNDUR DIRI');
INSERT INTO `ref_mahasiswa` VALUES (24, 'I0714027', 'Reynaldo Hutauruk', 2014, 111, 2.7, 7, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (25, 'I0714028', 'Reza Yusadika Putra', 2014, 146, 3.38, 7, 3, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (26, 'I0714029', 'Rio Yuan Pallafine', 2014, 148, 3.36, 4, 6, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (27, 'I0714030', 'Rizal Abdulrozaq Rosadi', 2014, 146, 3.34, 2, 9, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (28, 'I0714031', 'Rizal Nurhidayat', 2014, 142, 3.5, 9, 7, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (29, 'I0714032', 'Stephanus Hanurjaya', 2014, 146, 3.37, 3, 7, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (30, 'I0714033', 'Zulhendra Hanif', 2014, 41, 3.38, 1, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (31, 'I0714034', 'Dion Putra Anugrah', 2014, 141, 3.52, 4, 2, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (32, 'I0715001', 'Abyan Habibie', 2015, 145, 3.15, 4, 1, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (33, 'I0715002', 'Aditya Nur Fauzi G', 2015, 146, 3.42, 4, 8, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (34, 'I0715003', 'Ahmad Syah Aljabar', 2015, 43, 1.99, 1, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (35, 'I0715004', 'Arif Nuruddin', 2015, 145, 3.12, 1, 4, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (36, 'I0715005', 'Arifian Trilaksita', 2015, 145, 3.25, 1, 3, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (37, 'I0715006', 'Aris Maulana Fauzan', 2015, 153, 3.45, 1, 10, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (38, 'I0715007', 'Arthur Joshua Titus', 2015, 148, 3.2, 1, 10, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (39, 'I0715008', 'Cesarius Adi A K', 2015, 148, 3.35, 1, 10, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (40, 'I0715009', 'Dwiki Dimas Shidiq', 2015, 141, 3.09, 1, 10, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (41, 'I0715010', 'Faris Izzaturrahman', 2015, 127, 2.65, 7, 5, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (42, 'I0715011', 'Febri Abdul Rohman', 2015, 147, 2.9, 4, 11, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (43, 'I0715012', 'Ghea Faradiba', 2015, 148, 3.52, 4, 4, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (44, 'I0715013', 'Hillga Richman Radhita', 2015, 146, 3.21, 8, 3, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (45, 'I0715014', 'Johan Try Affandy', 2015, 150, 3.41, 8, 6, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (46, 'I0715015', 'Jusuf Abimas Pratama', 2015, 144, 3.15, 8, 7, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (47, 'I0715016', 'Kharis Akbar Baharizky', 2015, 151, 3.57, 8, 2, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (48, 'I0715017', 'Kirana Dyah Utari Kusumaputri', 2015, 145, 3.55, 8, 9, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (49, 'I0715018', 'Latif Nur Fauzi', 2015, 141, 3.53, 8, 1, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (50, 'I0715019', 'Lia Alvionita', 2015, 145, 3.55, 7, 8, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (51, 'I0715020', 'Lia Anjarwati', 2015, 144, 3.23, 7, 4, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (52, 'I0715021', 'Mohammad Izzul Mukhtar', 2015, 101, 2.16, 3, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (53, 'I0715022', 'Muhammad Akmal', 2015, 146, 3.19, 3, 6, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (54, 'I0715024', 'Muhammad Fajar Prakasa', 2015, 150, 3.32, 3, 7, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (55, 'I0715025', 'Muhammad Gunawan', 2015, 148, 3.12, 3, 2, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (56, 'I0715026', 'Muhammad Ramadhan Bagas Purnomo', 2015, 147, 3.22, 9, 9, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (57, 'I0715027', 'Muhammad Wahid Hasyim', 2015, 128, 2.68, 9, 10, 'I0715027.png', 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (58, 'I0715028', 'Mustofa Danang Ariyanto', 2015, 147, 3.32, 9, 8, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (59, 'I0715029', 'Oktavian Listiyanto', 2015, 145, 3.32, 9, 4, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (60, 'I0715030', 'Ramanda Fadhillah', 2015, 141, 3.14, 7, 3, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (61, 'I0715031', 'Ratih Rachmatika', 2015, 145, 3.51, 2, 6, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (62, 'I0715032', 'Ryoki Martfuadi', 2015, 148, 3.32, 6, 7, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (63, 'I0715033', 'Sifa`Us Wulaning Arsri', 2015, 145, 3.41, 6, 2, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (64, 'I0715034', 'Tony Febrianto', 2015, 145, 3.34, 6, 9, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (65, 'I0715035', 'Wahyu Kurniawan', 2015, 154, 3.44, 6, 1, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (66, 'I0715036', 'Wahyu Rahmat Hidayat', 2015, 13, 1.1, 8, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (67, 'I0715037', 'Yan Mahardhika Putra Perdana', 2015, 144, 3.22, 2, 8, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (68, 'I0715038', 'Yasmine Afifah', 2015, 145, 3.79, 2, 4, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (69, 'I0715039', 'Zaniar Rickiansyah', 2015, 2, 0.19, 8, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (70, 'I0715040', 'Yuana Ayub Sunarya', 2015, 151, 3.46, 2, 10, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (71, 'I0716001', 'Adip Safiudin', 2016, 141, 3.52, 1, 5, 'I0716001.png', 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (72, 'I0716002', 'Adrian Seta Ekananda', 2016, 137, 3.21, 1, 8, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (73, 'I0716003', 'Afif Yuhendrasmiko', 2016, 129, 3.19, 1, 4, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (74, 'I0716004', 'Ahmad Imam Rauyani', 2016, 141, 3.65, 1, 3, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (75, 'I0716005', 'Ammar Galih Gumilang', 2016, 36, 2.56, 10, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (76, 'I0716006', 'Annisa Hanifa', 2016, 143, 3.48, 10, 6, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (77, 'I0716007', 'Aulia Ramadhani', 2016, 31, 2.29, 4, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (78, 'I0716008', 'Axel Adam Mahendra', 2016, 19, 1.38, 4, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (79, 'I0716009', 'Azis Ubaidilah', 2016, 139, 3.34, 8, 7, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (80, 'I0716010', 'Bhadrika Evandito A', 2016, 42, 3.07, 8, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (81, 'I0716011', 'Bintang Sujatmiko', 2016, 141, 3.64, 8, 2, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (82, 'I0716012', 'Daniel Aquino Purba', 2016, 139, 3.54, 8, 9, NULL, 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (83, 'I0716013', 'Erdian Dwi Laksana', 2016, 20, 1.4, 7, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (84, 'I0716014', 'Fuad Nur Kuncoro', 2016, 141, 3.37, 4, 10, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (85, 'I0716015', 'Ghufron Husnan', 2016, 135, 2.87, 9, 11, 'I0716015.png', 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (86, 'I0716016', 'Henry Probo Santoso', 2016, 138, 3.35, 6, 5, 'I0716016.png', 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (87, 'I0716017', 'I Wayan Yoga K', 2016, 137, 3.02, 3, 8, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (88, 'I0716018', 'Kevin Sebastian', 2016, 140, 3.09, 3, 4, 'I0716018.png', 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (89, 'I0716019', 'Krisna Hakim', 2016, 142, 3.37, 10, 3, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (90, 'I0716020', 'Miftahuddin Irfani', 2016, 147, 3.13, 2, 6, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (91, 'I0716021', 'Mohamad Nisman Falic', 2016, 139, 3.17, 2, 7, 'I0716021.png', 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (92, 'I0716022', 'Muhammad Amirudin S', 2016, 4, 0.37, 2, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (93, 'I0716023', 'Muhammad Fakhri Erri', 2016, 141, 3.29, 2, 6, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (94, 'I0716024', 'Muhammad Tharieq P', 2016, 0, 0, 2, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (95, 'I0716025', 'Muhammad Ulil `Azmi', 2016, 0, 0, 2, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (96, 'I0716026', 'Musyaffa\' Ahmad', 2016, 141, 3.68, 9, 9, 'I0716026.png', 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (97, 'I0716027', 'Oki Setiawan', 2016, 145, 3.42, 9, 10, 'I0716027.png', 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (98, 'I0716028', 'Rilo Pambudi Aditya Wardani', 2016, 139, 3.44, 7, 11, 'I0716028.png', 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (99, 'I0716029', 'Royani Aulia Ihsanti', 2016, 135, 3.19, 7, 5, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (100, 'I0716030', 'Salman Al Farisi', 2016, 139, 3.19, 7, 8, 'I0716030.png', 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (101, 'I0716031', 'Tyan Widotomo', 2016, 55, 2.66, 10, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (102, 'I0716032', 'Vernanda Sitorini Zul Hizmi', 2016, 141, 3.76, 6, 3, 'I0716032.png', 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (103, 'I0716033', 'Wiwik Nur Winda', 2016, 141, 3.44, 6, 2, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (104, 'I0716034', 'Yudhi Prabowo Kusuma', 2016, 140, 3.58, 3, 7, 'I0716034.png', 'LULUS');
INSERT INTO `ref_mahasiswa` VALUES (105, 'I0717001', 'Aditya Pratama', 2017, 107, 3.59, 4, 8, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (106, 'I0717002', 'Agung Budi Utomo', 2017, 126, 3.23, 4, 5, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (107, 'I0717003', 'Aimmatul Yumna Arivatul Azra', 2017, 42, 3.46, 4, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (108, 'I0717004', 'Alvin Ichwannur Ridho', 2017, 107, 3.06, 10, 3, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (109, 'I0717005', 'Arif Wibowo', 2017, 126, 3.14, 10, 5, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (110, 'I0717006', 'Athaya Cantia Putri', 2017, 105, 3.47, 6, 2, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (111, 'I0717007', 'Attar Al Mufashal Rasyid', 2017, 107, 3.4, 2, 2, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (112, 'I0717008', 'Aulia Vici Yunitasari', 2017, 107, 3.24, 2, 10, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (113, 'I0717009', 'Bakasrian Fericoari', 2017, 107, 3.42, 2, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (114, 'I0717010', 'Banu Maheswara', 2017, 107, 3.25, 2, 5, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (115, 'I0717011', 'Bayhaqi Irfani', 2017, 107, 3.44, 4, 5, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (116, 'I0717012', 'Berlianne Shanaza Andriany', 2017, 107, 3.55, 6, 4, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (117, 'I0717013', 'Bima Damar Jati', 2017, 121, 3.02, 9, 17, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (118, 'I0717014', 'Bintar Yudo Sadewo', 2017, 107, 3.37, 9, 3, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (119, 'I0717015', 'Fahmi Ismail', 2017, 126, 3.43, 9, 9, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (120, 'I0717016', 'Faishal Hanifan Ma`Ruf', 2017, 124, 3.59, 9, 9, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (121, 'I0717017', 'Gilang Satria Ajie', 2017, 107, 3.73, 9, 2, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (122, 'I0717018', 'Hanifah Yulia', 2017, 103, 3.15, 9, 10, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (123, 'I0717019', 'Harisno', 2017, NULL, NULL, NULL, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (124, 'I0717020', 'Herwin Jonathan Nababan', 2017, NULL, NULL, NULL, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (125, 'I0717021', 'Hisbullah Ahmad Fathoni', 2017, 126, 3.42, 3, 17, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (126, 'I0717022', 'Ivan Robi Septian', 2017, 128, 3.28, 3, 3, 'I0717022.png', 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (127, 'I0717023', 'Kevin Dwiyanto Saputra', 2017, 107, 3.36, 3, 5, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (128, 'I0717024', 'M. Iqbal Zidny', 2017, 126, 3.66, 3, 5, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (129, 'I0717025', 'M. Maulana Yusuf', 2017, 105, 2.98, 3, 3, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (130, 'I0717026', 'Mohammad Raihan H.', 2017, 104, 3.06, 4, 3, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (131, 'I0717027', 'Muhammad Al Hamid', 2017, 92, 2.53, 8, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (132, 'I0717028', 'Muhammad Ikyu Arqie Ramadhan', 2017, 107, 3.29, 8, 7, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (133, 'I0717029', 'Muhammad Renaldy Darmawan', 2017, 126, 3.62, 1, 18, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (134, 'I0717030', 'Muhammad Rifai', 2017, 125, 3.43, 1, 11, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (135, 'I0717031', 'Muhammad Rifyal Abubakar', 2017, 121, 3.06, 4, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (136, 'I0717032', 'Muhammad Rizqi Subeno', 2017, 107, 3.77, 4, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (137, 'I0717033', 'Muhammad Wakhid Wardani', 2017, 127, 3.37, 2, 11, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (138, 'I0717034', 'Muhammad Yahya Izzudin', 2017, NULL, NULL, NULL, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (139, 'I0717035', 'Nanda Hafidz Rivanda', 2017, 125, 3.55, 10, 9, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (140, 'I0717036', 'Rafiq Satria Yudha', 2017, 38, 3.15, 10, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (141, 'I0717037', 'Rifqi Paradisa', 2017, 103, 3.18, 3, 6, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (142, 'I0717038', 'Riski Rama Kusuma', 2017, 101, 2.99, 3, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (143, 'I0717039', 'Sony Adyatama', 2017, 105, 3.69, 2, 6, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (144, 'I0717040', 'Wahyu Aji Rahmantya Soedjono', 2017, NULL, NULL, NULL, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (145, 'I0717041', 'Weldino Panji Kurniadi', 2017, 107, 3.65, 7, 7, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (146, 'I0717042', 'Yusuf Yahya', 2017, 0, 0, 9, NULL, NULL, 'HILANG');
INSERT INTO `ref_mahasiswa` VALUES (147, 'I0718001', 'Abraham Babtistio', 2018, 63, 3.44, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (148, 'I0718002', 'Ahmad Azzam Hafidz', 2018, 66, 3.66, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (149, 'I0718003', 'Alvian Aji Pangestu', 2018, 65, 3.24, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (150, 'I0718004', 'Andhika Rizkita Putera', 2018, 63, 3.29, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (151, 'I0718005', 'Annisa Larasati Febrianingrum', 2018, 63, 3.67, 5, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (152, 'I0718006', 'Catya Afif Kasudya', 2018, 63, 3.36, 5, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (153, 'I0718007', 'Desi Sunyahni', 2018, 64, 3.23, 5, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (154, 'I0718008', 'Eri Setiawan', 2018, 42, 2.29, 5, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (155, 'I0718009', 'Fandi Surya Adinata', 2018, 63, 3.41, 9, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (156, 'I0718010', 'Firmansyah Abada', 2018, 63, 3.75, 9, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (157, 'I0718011', 'Ghozy Abror Aufan', 2018, 42, 3.54, 6, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (158, 'I0718012', 'Gibran Dzulfikar Ghaffara', 2018, 51, 2.53, 6, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (159, 'I0718013', 'Hanandya Maya Shafira', 2018, 66, 3.25, 4, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (160, 'I0718014', 'Hanif Ardiyoansyah', 2018, 2, 0.19, 4, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (161, 'I0718015', 'Ilham Gilang Pradana', 2018, 59, 3.04, 1, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (162, 'I0718016', 'Imam Arif', 2018, 60, 2.99, 8, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (163, 'I0718017', 'Khilalul Hanif', 2018, 54, 2.75, 3, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (164, 'I0718018', 'M. Fatkhi Futukhal Arifin', 2018, 65, 3.35, 3, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (165, 'I0718019', 'Moh.Adith Setiawan', 2018, 44, 2.07, 10, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (166, 'I0718020', 'Mohammad Ravi Rachman', 2018, 59, 2.78, 10, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (167, 'I0718021', 'Muhamad Miftahus Surur', 2018, 42, 2.11, 10, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (168, 'I0718022', 'Muhammad Didin Kamaludin', 2018, 61, 3.05, 10, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (169, 'I0718023', 'Muhammad Ghozy Al Hakim', 2018, 61, 3.13, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (170, 'I0718024', 'Muhammad Ibnu Sina Abbas Parlin', 2018, 61, 3.3, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (171, 'I0718025', 'Nada Syadza Azizah', 2018, 66, 3.52, 5, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (172, 'I0718026', 'Nadya Namirasepti Efendi', 2018, 0, 0, 5, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (173, 'I0718027', 'Nur Udin Galang Ga', 2018, 60, 3.03, 10, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (174, 'I0718028', 'Oga Sri Lestyana', 2018, 42, 2, 10, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (175, 'I0718029', 'Raihan Rafif Kautsar Priyanto', 2018, 45, 2.2, 9, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (176, 'I0718030', 'Ramadhan Prihantono', 2018, 65, 3.36, 6, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (177, 'I0718031', 'Rizal Mujaddid Irsyad', 2018, 63, 3.51, 4, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (178, 'I0718032', 'Rois Hasan Muhammad', 2018, 63, 3.52, 1, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (179, 'I0718033', 'Roni Tamado', 2018, 61, 3.03, 8, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (180, 'I0718034', 'Slash Arthur Edi Sumawang', 2018, 63, 3.26, 3, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (181, 'I0718035', 'Syaifullah Filard L', 2018, 57, 2.98, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (182, 'I0718036', 'Syauqy Maulanar Rahman', 2018, 2, 0.26, 4, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (183, 'I0718037', 'Taufik Widyastama', 2018, 63, 3.22, 6, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (184, 'I0719001', '\'Izzuddin \'Ulwan', 2019, 20, 2.88, 1, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (185, 'I0719002', 'Abdul Latif Priyadi', 2019, 20, 3.62, 1, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (186, 'I0719003', 'Abdul Qodir Jaelani', 2019, 20, 3.4, 8, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (187, 'I0719004', 'Adriel Satrio Nugroho', 2019, 20, 3.46, 8, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (188, 'I0719005', 'Ahmad Hanif Shalahuddin', 2019, 20, 3.48, 8, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (189, 'I0719006', 'Aji Ghanang Amurwabhumi', 2019, 20, 3.09, 8, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (190, 'I0719007', 'Akbar Dharmawan', 2019, 20, 2.86, 8, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (191, 'I0719008', 'Aldin Wildan Razaqa', 2019, 20, 3.35, 8, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (192, 'I0719009', 'Alexander Fajar Listianto Satrio Utomo', 2019, 20, 3.08, 2, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (193, 'I0719010', 'Ali Ekatma Rendra', 2019, 20, 3.24, 2, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (194, 'I0719011', 'Alloyus Bayu Hans Abram', 2019, 20, 2.88, 2, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (195, 'I0719012', 'Anas Malik Mochammad', 2019, 14, 1.78, 2, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (196, 'I0719013', 'Andika Sukma Pradana', 2019, 20, 3.18, 9, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (197, 'I0719014', 'Arif', 2019, 19, 2.58, 4, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (198, 'I0719015', 'As\'ad Syahrul Munir', 2019, 20, 2.9, 5, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (199, 'I0719016', 'Attala Surya Prima Amanda', 2019, 20, 3.22, 5, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (200, 'I0719017', 'Azis Surya Ananda', 2019, 20, 3.31, 7, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (201, 'I0719018', 'Burhanudin Khoiri Fadhlurrohman', 2019, 0, 0, 7, NULL, NULL, 'UNDUR DIRI');
INSERT INTO `ref_mahasiswa` VALUES (202, 'I0719019', 'Daffa Aminuddin', 2019, 20, 3.3, 7, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (203, 'I0719020', 'Damaris Adi Waskitho', 2019, 20, 3.48, 7, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (204, 'I0719021', 'Dika Kartika Oktaviani', 2019, 20, 3.51, 5, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (205, 'I0719022', 'Dina Mifika Sari', 2019, 20, 3.7, 5, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (206, 'I0719023', 'Faiq Izzul Islami', 2019, 20, 3.04, 5, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (207, 'I0719024', 'Fatimaharani Annisa Septiya Ningrum', 2019, 20, 3.56, 3, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (208, 'I0719025', 'Fazlur Rahman Javier', 2019, 20, 3.12, 10, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (209, 'I0719026', 'Fiqi Haiqal', 2019, 20, 3.51, 10, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (210, 'I0719027', 'Fitroh Romadhon', 2019, 20, 3.32, 10, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (211, 'I0719028', 'Ganesya Fajar Gumilang', 2019, 20, 3.12, 10, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (212, 'I0719029', 'Geovani Rahmad Illahi', 2019, 20, 3.62, 5, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (213, 'I0719030', 'Gustav Lukman Adhi Pradhityo', 2019, 17, 3.06, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (214, 'I0719031', 'Hanif Wisti Julitama', 2019, 20, 3.42, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (215, 'I0719032', 'Hayyan Yusuf', 2019, 20, 3.18, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (216, 'I0719033', 'Hilwan Hafidzsyah', 2019, 20, 2.91, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (217, 'I0719034', 'Ibnu Qoyim Al-Hafidzh', 2019, 20, 3.08, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (218, 'I0719035', 'Immanuel Chrismastyanto', 2019, 17, 2.6, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (219, 'I0719036', 'Jihan Salsabila', 2019, 20, 3.24, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (220, 'I0719037', 'Kresna Pandu Pratama', 2019, 20, 3.55, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (221, 'I0719038', 'Luqman Hadi Dwi Satryo', 2019, 20, 3.49, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (222, 'I0719039', 'Mahaputra Nur Muhammad', 2019, 20, 3.32, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (223, 'I0719040', 'Mark Reindhard Joyakin Silalahi', 2019, 20, 3.5, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (224, 'I0719041', 'Maulana Afif', 2019, 20, 3.78, 11, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (225, 'I0719042', 'Miftahhudin Aji Pitutur', 2019, 0, 0, 6, NULL, NULL, 'UNDUR DIRI');
INSERT INTO `ref_mahasiswa` VALUES (226, 'I0719043', 'Muchsin Ismail', 2019, 20, 2.86, 6, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (227, 'I0719044', 'Muhammad Ardhana Gusti Syahputra', 2019, 20, 3.65, 6, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (228, 'I0719045', 'Muhammad Ariz Fakhruddin', 2019, 17, 2.53, 6, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (229, 'I0719046', 'Muhammad Dhafier Mu\'afa', 2019, 20, 3.46, 6, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (230, 'I0719047', 'Muhammad Fikri Arifudin', 2019, 17, 2.52, 6, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (231, 'I0719048', 'Muhammad Haris Humaidi', 2019, 17, 2.81, 17, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (232, 'I0719049', 'Muhammad Hasya Nurfaizi', 2019, 20, 3.61, 17, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (233, 'I0719050', 'Muhammad Raflie Pangestu', 2019, 20, 2.91, 17, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (234, 'I0719051', 'Muhammad Rifqi Bachtiar', 2019, 20, 3.29, 17, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (235, 'I0719052', 'Muhammad Shafiy Widi Kresno Wibisono', 2019, 20, 3.03, 17, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (236, 'I0719053', 'Muhammad Wildan Alfatih', 2019, 20, 3.46, 17, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (237, 'I0719054', 'Muhammad Yusuf Thohir', 2019, 0, 0, 17, NULL, NULL, 'UNDUR DIRI');
INSERT INTO `ref_mahasiswa` VALUES (238, 'I0719055', 'Mukhlis Dwi Nugroho', 2019, 20, 3.44, 17, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (239, 'I0719056', 'Nadya Puteri Nur Utomo', 2019, 20, 3.14, 17, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (240, 'I0719057', 'Nikolaus Chrismas Ananda Pratama', 2019, 0, 0, 17, NULL, NULL, 'UNDUR DIRI');
INSERT INTO `ref_mahasiswa` VALUES (241, 'I0719058', 'Oemar Dhani Er', 2019, 20, 3.24, 17, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (242, 'I0719059', 'Pramesta Tigris', 2019, 20, 3, 17, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (243, 'I0719060', 'Pramudya Wiratama', 2019, 20, 3.17, 18, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (244, 'I0719061', 'Putra Maulana Yusuf', 2019, 20, 2.9, 18, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (245, 'I0719062', 'Rafi Panhardyansyah Dananjaya', 2019, 20, 2.89, 18, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (246, 'I0719063', 'Rebekka Siswandina Sari', 2019, 20, 3.94, 18, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (247, 'I0719064', 'Refansyah Basu Dewa', 2019, 20, 3.18, 18, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (248, 'I0719065', 'Ricky Aston Susetyo', 2019, 20, 3.22, 18, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (249, 'I0719066', 'Royyan Nurbiksa Jaka Pratama', 2019, 20, 3.42, 18, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (250, 'I0719067', 'Salsabila Ananda Putri', 2019, 20, 3.53, 18, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (251, 'I0719068', 'Serafim Lemuel Riwibowo', 2019, 20, 3.29, 18, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (252, 'I0719069', 'Stefani Widyaningrum', 2019, 20, 3.7, 18, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (253, 'I0719070', 'Stefanus Marcellindo', 2019, 20, 3.48, 18, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (254, 'I0719071', 'Talib Sahdha Wibowo', 2019, 20, 3.23, 18, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (255, 'I0719072', 'Wahono Aji Warjono', 2019, 17, 2.98, 3, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (256, 'I0719073', 'Wahyu Kusumojati Sapardi', 2019, 20, 3.24, 3, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (257, 'I0719074', 'Wisanggeni Titovandaru', 2019, 20, 3.5, 9, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (258, 'I0719075', 'Zaidan Alvin Al Hanif', 2019, 20, 3.24, 9, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (259, 'I0719076', 'Zulfikar Juan Pramasta', 2019, 20, 3.28, 5, NULL, NULL, 'AKTIF');
INSERT INTO `ref_mahasiswa` VALUES (260, 'I0719077', 'Muhammad Danish Bin Afrizal Anwar', 2019, 20, 3.02, 4, NULL, NULL, 'AKTIF');

-- ----------------------------
-- Table structure for ref_mata_kuliah
-- ----------------------------
DROP TABLE IF EXISTS `ref_mata_kuliah`;
CREATE TABLE `ref_mata_kuliah`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kode` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `nama` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sks` smallint(6) NULL DEFAULT NULL,
  `status` smallint(6) NULL DEFAULT 1,
  `created_at` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  `created_user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `updated_user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 113 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ref_mata_kuliah
-- ----------------------------
INSERT INTO `ref_mata_kuliah` VALUES (1, 'EE0101-19', 'Kalkulus I', 3, 10, NULL, '2020-02-18 05:59:45', NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (2, 'EE0102-19', 'Fisika Dasar I', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (3, 'EE0103-19', 'Matematika Diskret dan Logika', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (4, 'EE0104-19', 'Aljabar Linear', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (5, 'EE0105-19', 'Kimia', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (6, 'EE0106-19', 'Filsafat Ilmu Pengetahuan', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (7, 'EE0107-19', 'Pemrograman Dasar dan Lab', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (8, 'EE0108-19', 'Orientasi Prodi', 1, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (9, 'EE0201-19', 'Kalkulus II', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (10, 'EE0202-19', 'Fisika Dasar II', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (11, 'EE0203-19', 'Praktikum Fisika Dasar', 1, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (12, 'EE0204-19', 'Probabilitas dan Statistika', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (13, 'EE0205-19', 'Rangkaian Listrik I', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (14, 'EE0206-19', 'Organisasi dan Arsitektur Komputer', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (15, 'EE0207-19', 'Teknik Digital', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (16, 'EE0208-19', 'Proyek Kreatif I', 1, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (17, 'EE0209-19', 'Prak. Elektro Dasar I', 1, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (18, 'EE0210-19', 'Prak. Teknik Digital', 1, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (19, 'EE0301-19', 'Metode Numerik', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (20, 'EE0302-19', 'Matematika Teknik I', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (21, 'EE0303-19', 'Medan Elektromagnetis', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (22, 'EE0304-19', 'Elektronika Dasar', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (23, 'EE0305-19', 'Rangkaian Listrik II', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (24, 'EE0306-19', 'Isyarat dan Sistem', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (25, 'EE0307-19', 'Mesin Listrik Dasar', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (26, 'EE0308-19', 'Proyek Kreatif II', 1, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (27, 'EE0309-19', 'Prak. Elektro Dasar II', 1, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (28, 'EE0401-19', 'Matematika Teknik II', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (29, 'EE0402-19', 'Instrumentasi', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (30, 'EE0403-19', 'Elektronika Analog', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (31, 'EE0404-19', 'Telekomunikasi Dasar', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (32, 'EE0405-19', 'Teknik Tenaga Listrik', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (33, 'EE0406-19', 'Sistem Kendali', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (34, 'EE0407-19', 'Sistem Mikroprosessor', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (35, 'EE0408-19', 'Proyek Kreatif III', 1, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (36, 'EE0409-19', 'Prak. Elektronika', 1, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (37, 'EE0410-19', 'Prak. Teknik Tenaga Listrik', 1, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (38, 'EE0501-19', 'Jaringan Komunikasi Data', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (39, 'EE0502-19', 'Mekatronika', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (40, 'EE0503-19', 'Prak. Telekomunikasi Dasar', 1, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (41, 'EE0504-19', 'Prak. Sistem Kendali', 1, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (42, 'EE0505-19', 'Proyek Kreatif IV', 1, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (43, 'EE0601-19', 'Kerja Praktek', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (44, 'EE0602-19', 'Energi Baru dan Terbarukan', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (45, 'EE0603-19', 'Pancasila', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (46, 'EE0604-19', 'Desain Capstone', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (47, 'EE0701-19', 'Seminar Proposal Skripsi', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (48, 'EE0702-19', 'Kecerdasan Buatan', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (49, 'EE0703-19', 'Agama dan Etika', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (50, 'EE0704-19', 'Kewarganegaraan', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (51, 'EE0705-19', 'Kewirausahaan', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (52, 'EE0706-19', 'Manajemen Industri', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (53, 'EE0801-19', 'Skripsi dan Pendadaran', 4, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (54, 'EE0802-19', 'Kuliah Kerja Nyata', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (55, 'EE1501-19', 'Pembangkitan Tenaga Listrik', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (56, 'EE1502-19', 'Transmisi dan Distribusi Tenaga Listrik', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (57, 'EE1503-19', 'Analisis Sistem Tenaga', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (58, 'EE1504-19', 'Mesin Listrik Lanjut', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (59, 'EE1505-19', 'Perlengkapan Sistem Tenaga', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (60, 'EE1601-19', 'Teknik Proteksi', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (61, 'EE1602-19', 'Elektronika Daya', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (62, 'EE1603-19', 'Teknik Instalasi', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (63, 'EE1604-19', 'Topik Pilihan Teknik Tenaga', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (64, 'EE2501-19', 'Sistem Otomasi dan PLC', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (65, 'EE2502-19', 'Teknik Robot', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (66, 'EE2503-19', 'Pnenumatik Hidrolik', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (67, 'EE2504-19', 'Sistem Berbasis Mikroprosesor', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (68, 'EE2505-19', 'Teknik Kendali Lanjut', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (69, 'EE2601-19', 'Kendaraan Cerdas', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (70, 'EE2602-19', 'Kontrol Sistem Energi', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (71, 'EE2603-19', 'Sistem Terintegrasi', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (72, 'EE2604-19', 'Topik Pilihan Kontrol Mekatronika', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (73, 'EE3501-19', 'Antena dan Propagasi', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (74, 'EE3502-19', 'Sistem Tertanam dan Periferal', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (75, 'EE3503-19', 'Pengolahan Isyarat Digital', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (76, 'EE3504-19', 'Algoritma dan Struktur Data', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (77, 'EE3505-19', 'Sistem Informasi', 2, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (78, 'EE3601-19', 'Telekomunikasi Lanjut', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (79, 'EE3602-19', 'Perancangan Sistem Digital', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (80, 'EE3603-19', 'Pemrograman Lanjut', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (81, 'EE3604-19', 'Topik Pilihan Komputer dan Telekomunikasi', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (82, 'EE4001-19', 'Operasi Sistem Tenaga Listrik', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (83, 'EE4002-19', 'Dinamika Dan Stabilitas Sistem Tenaga\n Listrik', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (84, 'EE4003-19', 'Perancangan Sistem Listrik Industri', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (85, 'EE4004-19', 'Keandalan Sistem Tenaga Listrik', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (86, 'EE4005-19', 'Smart Grid', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (87, 'EE4006-19', 'Teknologi Transportasi dan Kendaraan\n Listrik', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (88, 'EE4007-19', 'Kualitas Daya', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (89, 'EE4008-19', 'Pengolahan Citra', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (90, 'EE4009-19', 'Sistem berbasis IoT', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (91, 'EE4010-19', 'Big Data dan Analitik', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (92, 'EE4011-19', 'Sistem Komunikasi Bergerak', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (93, 'EE4012-19', 'Sistem Komunikasi Satelit', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (94, 'EE4013-19', 'Remote Sensing', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (95, 'EE4014-19', 'MEMS', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (96, 'EE4015-19', 'Manajemen Proyek', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (97, 'EE4016-19', 'Manajemen Keselamatan dan Kesehatan\n Kerja', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (98, 'EE4017-19', 'Machine Learning', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (99, 'EE4018-19', 'Sistem Komunikasi Serat Optik', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (100, 'EE4019-19', 'Piranti Mikro dan Nano', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (101, 'EE4020-19', 'Mikroelektronika', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (102, 'EE4021-19', 'Instrumentasi Biomedis', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (103, 'EE4022-19', 'Teknik Kontrol Adaptif', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (104, 'EE4023-19', 'Teknik Kendali Neuro-Fuzzy', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (105, 'EE4024-19', 'Teknik Kendali Digital', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (106, 'EE4025-19', 'Sistem Pendukung Keputusan', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (107, 'EE4026-19', 'Komputasi Cerdas dalam Sistem Tenaga\n Listrik', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (108, 'EE4027-19', 'Perancangan Pembangkit Energi Baru\n dan Terbarukan', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (109, 'EE4028-19', 'Pengembangan Aplikasi Mobile', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (110, 'EE4029-19', 'Perencanaan dan Manajemen Energi', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (111, 'EE4030-19', 'Sistem Penyimpanan Energi', 3, 10, NULL, NULL, NULL, NULL);
INSERT INTO `ref_mata_kuliah` VALUES (112, 'EE4031-19', 'Pemodelan Sistem', 3, 10, NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for ref_nilai
-- ----------------------------
DROP TABLE IF EXISTS `ref_nilai`;
CREATE TABLE `ref_nilai`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batas_bawah` double(5, 2) NOT NULL,
  `batas_atas` double(5, 2) NOT NULL,
  `nilai_huruf` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ref_nilai
-- ----------------------------
INSERT INTO `ref_nilai` VALUES (1, 85.00, 100.00, 'A');
INSERT INTO `ref_nilai` VALUES (2, 80.00, 84.99, 'A-');
INSERT INTO `ref_nilai` VALUES (3, 75.00, 79.99, 'B+');
INSERT INTO `ref_nilai` VALUES (4, 70.00, 74.99, 'B');
INSERT INTO `ref_nilai` VALUES (5, 65.00, 69.99, 'C+');
INSERT INTO `ref_nilai` VALUES (6, 60.00, 64.99, 'C');
INSERT INTO `ref_nilai` VALUES (7, 55.00, 59.99, 'D');
INSERT INTO `ref_nilai` VALUES (8, 0.00, 54.99, 'E');

-- ----------------------------
-- Table structure for ref_peminatan
-- ----------------------------
DROP TABLE IF EXISTS `ref_peminatan`;
CREATE TABLE `ref_peminatan`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tahun` int(10) NULL DEFAULT NULL,
  `kode` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `nama_peminatan` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `kode`(`kode`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ref_peminatan
-- ----------------------------
INSERT INTO `ref_peminatan` VALUES (1, 2019, '1', 'Sistem Energi Listrik (SEL)', NULL, NULL);
INSERT INTO `ref_peminatan` VALUES (2, 2019, '2', 'Sistem Mekatronika (SM)', NULL, NULL);
INSERT INTO `ref_peminatan` VALUES (3, 2019, '3', 'Teknologi Informasi dan Komunikasi (ICT)', NULL, NULL);

-- ----------------------------
-- Table structure for ref_ruang
-- ----------------------------
DROP TABLE IF EXISTS `ref_ruang`;
CREATE TABLE `ref_ruang`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `nama_ruang` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ref_ruang
-- ----------------------------
INSERT INTO `ref_ruang` VALUES (1, 'Ruang Kuliah 3201', NULL, '2020-07-15 12:44:28');
INSERT INTO `ref_ruang` VALUES (2, 'Ruang Kuliah 3202', NULL, '2020-07-15 12:44:38');
INSERT INTO `ref_ruang` VALUES (3, 'Ruang 3 Laboratorium Komputer', NULL, '2020-07-15 12:46:19');
INSERT INTO `ref_ruang` VALUES (4, 'Ruang Kuliah 6404', NULL, '2020-07-15 12:45:36');
INSERT INTO `ref_ruang` VALUES (5, 'Ruang Kaprodi', NULL, NULL);
INSERT INTO `ref_ruang` VALUES (6, 'Ruang Sidang 3204', NULL, '2020-07-15 12:44:57');
INSERT INTO `ref_ruang` VALUES (7, 'Lab. Elektro', NULL, NULL);
INSERT INTO `ref_ruang` VALUES (9, 'Daring', '2020-06-26 13:12:56', '2020-06-26 13:12:56');

-- ----------------------------
-- Table structure for role_user
-- ----------------------------
DROP TABLE IF EXISTS `role_user`;
CREATE TABLE `role_user`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `role_user_user_id_foreign`(`user_id`) USING BTREE,
  INDEX `role_user_role_id_foreign`(`role_id`) USING BTREE,
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 278 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of role_user
-- ----------------------------
INSERT INTO `role_user` VALUES (1, 1, 1, NULL, NULL);
INSERT INTO `role_user` VALUES (3, 3, 3, NULL, NULL);
INSERT INTO `role_user` VALUES (17, 12, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (23, 18, 2, NULL, NULL);
INSERT INTO `role_user` VALUES (26, 3, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (27, 11, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (29, 1, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (40, 19, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (41, 20, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (42, 21, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (43, 22, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (44, 24, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (45, 25, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (46, 26, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (47, 27, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (48, 28, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (49, 18, 9, NULL, NULL);
INSERT INTO `role_user` VALUES (50, 1, 8, NULL, NULL);
INSERT INTO `role_user` VALUES (52, 19, 4, NULL, NULL);
INSERT INTO `role_user` VALUES (53, 12, 7, NULL, NULL);
INSERT INTO `role_user` VALUES (55, 30, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (56, 31, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (57, 32, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (58, 33, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (59, 34, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (60, 35, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (61, 36, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (62, 37, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (63, 38, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (64, 39, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (65, 40, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (66, 41, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (67, 42, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (68, 43, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (69, 44, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (70, 45, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (71, 46, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (72, 47, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (73, 48, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (74, 49, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (75, 50, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (76, 51, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (77, 52, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (78, 53, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (79, 54, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (81, 55, 1, NULL, NULL);
INSERT INTO `role_user` VALUES (94, 18, 1, NULL, NULL);
INSERT INTO `role_user` VALUES (97, 3, 1, NULL, NULL);
INSERT INTO `role_user` VALUES (98, 58, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (99, 59, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (100, 60, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (101, 61, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (102, 62, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (103, 63, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (104, 64, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (105, 65, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (106, 66, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (107, 67, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (108, 68, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (109, 69, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (110, 70, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (111, 71, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (112, 72, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (113, 73, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (114, 74, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (115, 75, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (116, 76, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (117, 77, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (118, 78, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (119, 79, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (120, 80, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (121, 81, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (122, 82, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (123, 83, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (124, 84, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (125, 85, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (126, 86, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (127, 87, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (128, 88, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (129, 89, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (130, 90, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (131, 91, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (132, 92, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (133, 93, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (134, 94, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (135, 95, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (136, 96, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (137, 97, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (138, 98, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (139, 99, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (140, 100, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (141, 101, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (142, 102, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (143, 103, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (144, 104, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (145, 105, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (146, 106, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (147, 107, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (148, 108, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (149, 109, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (150, 110, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (151, 111, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (152, 112, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (153, 113, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (154, 114, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (155, 115, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (156, 116, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (157, 117, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (158, 118, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (159, 119, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (160, 120, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (161, 121, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (162, 122, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (163, 123, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (164, 124, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (165, 125, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (166, 126, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (167, 127, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (168, 128, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (169, 129, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (170, 130, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (171, 131, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (172, 132, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (173, 133, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (174, 134, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (175, 135, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (176, 136, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (177, 137, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (178, 138, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (179, 139, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (180, 140, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (181, 141, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (182, 142, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (183, 143, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (184, 144, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (185, 145, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (186, 146, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (187, 147, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (188, 148, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (189, 149, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (190, 150, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (191, 151, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (192, 152, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (193, 153, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (194, 154, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (195, 155, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (196, 156, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (197, 157, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (198, 158, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (199, 159, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (200, 160, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (201, 161, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (202, 162, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (203, 163, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (204, 164, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (205, 165, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (206, 166, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (207, 167, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (208, 168, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (209, 169, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (210, 170, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (211, 171, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (212, 172, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (213, 173, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (214, 174, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (215, 175, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (216, 176, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (217, 177, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (218, 178, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (219, 179, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (220, 180, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (221, 181, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (222, 182, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (223, 183, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (224, 184, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (225, 185, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (226, 186, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (227, 187, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (228, 188, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (229, 189, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (230, 190, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (231, 191, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (232, 192, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (233, 193, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (234, 194, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (235, 195, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (236, 196, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (237, 197, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (238, 198, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (239, 199, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (240, 200, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (241, 201, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (242, 202, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (243, 203, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (244, 204, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (245, 205, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (246, 206, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (247, 207, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (248, 208, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (249, 209, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (250, 210, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (251, 211, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (253, 212, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (255, 21, 10, NULL, NULL);
INSERT INTO `role_user` VALUES (256, 213, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (257, 214, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (258, 55, 9, NULL, NULL);
INSERT INTO `role_user` VALUES (259, 215, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (261, 212, 1, NULL, NULL);
INSERT INTO `role_user` VALUES (262, 212, 3, NULL, NULL);
INSERT INTO `role_user` VALUES (263, 216, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (264, 217, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (265, 218, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (269, 220, 5, NULL, NULL);
INSERT INTO `role_user` VALUES (271, 222, 6, NULL, NULL);
INSERT INTO `role_user` VALUES (272, 19, 11, NULL, NULL);
INSERT INTO `role_user` VALUES (273, 12, 13, NULL, NULL);
INSERT INTO `role_user` VALUES (274, 20, 14, NULL, NULL);
INSERT INTO `role_user` VALUES (275, 3, 12, NULL, NULL);
INSERT INTO `role_user` VALUES (276, 18, 15, NULL, NULL);
INSERT INTO `role_user` VALUES (277, 221, 5, NULL, NULL);

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES (1, 'Admin', NULL, NULL);
INSERT INTO `roles` VALUES (2, 'Koordinator KP', NULL, NULL);
INSERT INTO `roles` VALUES (3, 'Koordinator TA', NULL, NULL);
INSERT INTO `roles` VALUES (4, 'Koordinator SEL', NULL, NULL);
INSERT INTO `roles` VALUES (5, 'Dosen', NULL, NULL);
INSERT INTO `roles` VALUES (6, 'User', NULL, NULL);
INSERT INTO `roles` VALUES (7, 'Koordinator SM', NULL, NULL);
INSERT INTO `roles` VALUES (8, 'Koordinator ICT', NULL, NULL);
INSERT INTO `roles` VALUES (9, 'Operator TA', NULL, NULL);
INSERT INTO `roles` VALUES (10, 'Kaprodi', NULL, NULL);
INSERT INTO `roles` VALUES (11, 'Kalab SEL', NULL, NULL);
INSERT INTO `roles` VALUES (12, 'Kalab TELE', NULL, NULL);
INSERT INTO `roles` VALUES (13, 'Kalab IK', NULL, NULL);
INSERT INTO `roles` VALUES (14, 'Kalab ELE', NULL, NULL);
INSERT INTO `roles` VALUES (15, 'Laboran ELE', NULL, NULL);

-- ----------------------------
-- Table structure for ta
-- ----------------------------
DROP TABLE IF EXISTS `ta`;
CREATE TABLE `ta`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `mahasiswa_id` int(15) NULL DEFAULT NULL,
  `ipk` float NOT NULL,
  `sks` int(10) NOT NULL,
  `judul` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `abstrak` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `tgl_pengajuan` datetime(0) NULL DEFAULT NULL,
  `tgl_setuju` datetime(0) NULL DEFAULT NULL,
  `status_ta` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `peminatan_id` int(11) NULL DEFAULT NULL,
  `proses_ta` tinyint(6) NULL DEFAULT 1,
  `doc_ta` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `sourcecode_ta` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `cetak_ta` int(11) NULL DEFAULT NULL,
  `tgl_selesai` datetime(0) NULL DEFAULT NULL,
  `updated_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `ta_ibfk_1`(`mahasiswa_id`) USING BTREE,
  INDEX `ta_ibfk_2`(`peminatan_id`) USING BTREE,
  CONSTRAINT `ta_ibfk_1` FOREIGN KEY (`peminatan_id`) REFERENCES `ref_peminatan` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `ta_ibfk_2` FOREIGN KEY (`mahasiswa_id`) REFERENCES `ref_mahasiswa` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 66 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ta
-- ----------------------------
INSERT INTO `ta` VALUES (33, 67, 0, 0, 'Anilisis Arus-Tegangan Terhadap Daya Dan Energi Listrik Pada Pembangkit Sumber Plasma Tegangan Tinggi Dengan Media Inverter Boost 15kv', NULL, '2019-05-27 00:00:00', '2019-05-27 00:00:00', 'SETUJU', 1, 3, NULL, NULL, 1, NULL, '2020-07-13 22:34:53');
INSERT INTO `ta` VALUES (34, 51, 0, 0, 'Sistem Monitoring Metode Submerge Arc Discharge Berbasis Arduino\r\n', NULL, '2019-05-29 00:00:00', '2019-05-29 00:00:00', 'SETUJU', 1, 3, NULL, NULL, NULL, NULL, '2020-07-16 15:13:25');
INSERT INTO `ta` VALUES (35, 49, 0, 0, 'Rancang Bangun Instrumen Power Quality Analyzer Tiga Fasa Menggunakan Low Cost USB DAQ Berbasis PC', NULL, '2019-05-29 00:00:00', '2019-05-29 00:00:00', 'SETUJU', 1, 4, NULL, NULL, NULL, NULL, '2020-07-23 18:30:43');
INSERT INTO `ta` VALUES (36, 60, 0, 0, 'Analisis Arus-Tegangan pada Plasma Tegangan Tinggi terhadap Muatan Listrik pada Inverter Boost Kit 15 kV', NULL, '2019-07-03 00:00:00', '2019-07-04 00:00:00', 'SETUJU', 1, 3, NULL, NULL, NULL, NULL, '2020-07-23 11:13:16');
INSERT INTO `ta` VALUES (37, 33, 0, 0, 'Rancang Bangun Penguat Audio Kelas D yang Dipadukan dengan Sallen-Key', NULL, '2019-07-09 00:00:00', '2019-07-10 00:00:00', 'SETUJU', 2, 3, NULL, NULL, NULL, NULL, '2020-06-29 06:12:24');
INSERT INTO `ta` VALUES (38, 38, 0, 0, 'Kendali Kecepatan Motor Induksi Menggunakan Fuzzy Logic Berbasis Mikrokontroler Arduino', NULL, '2019-07-09 00:00:00', '2019-07-10 00:00:00', 'SETUJU', 2, 2, NULL, NULL, NULL, NULL, '2020-07-31 18:06:52');
INSERT INTO `ta` VALUES (39, 39, 0, 0, 'Rancang Bangun Purwarupa Sensor Aktivitas Tubuh Portabel untuk Pemantauan Kesehatan yang Kontinyu', NULL, '2019-08-28 00:00:00', '2019-08-28 00:00:00', 'SETUJU', 2, 2, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `ta` VALUES (40, 102, 0, 0, 'Sistem Kendali Posisi VTOL (Vertical Take Off Landing) dengan Metode ANFIS Menggunakan Interface Simulink', NULL, '2020-01-27 00:01:00', '2020-01-27 00:01:00', 'SETUJU', 2, 4, 'I0716032_DraftTA.pdf', 'I0716032_SourcecodeTA.zip', NULL, NULL, '2020-08-04 12:46:05');
INSERT INTO `ta` VALUES (41, 76, 0, 0, 'Pengembangan BER Tester pada Sistem Visible Light Communication Berbasis FPGA', NULL, '2020-01-27 00:02:00', '2020-01-27 00:02:00', 'SETUJU', 3, 3, NULL, NULL, NULL, NULL, '2020-07-27 18:56:40');
INSERT INTO `ta` VALUES (42, 104, 0, 0, 'Sistem Informasi Portal Elektro dengan Metode Rapid Application Development (RAD) Menggunakan Framework Laravel', NULL, '2020-01-27 00:03:00', '2020-01-27 00:03:00', 'SETUJU', 3, 4, NULL, NULL, NULL, NULL, '2020-06-18 08:21:26');
INSERT INTO `ta` VALUES (43, 37, 0, 0, 'Implementasi Metode Object Detection untuk Sistem Pengawasan Cerdas di Fakultas Teknik Universitas Sebelas Maret (UNS) Surakarta', NULL, '2020-01-27 00:04:00', '2020-01-27 00:04:00', 'SETUJU', 2, 2, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `ta` VALUES (44, 57, 0, 0, 'Telegram Chatbot Management System Berbasis Web', NULL, '2020-01-27 00:05:00', '2020-01-27 00:05:00', 'SETUJU', 3, 3, NULL, NULL, NULL, NULL, '2020-07-24 16:10:32');
INSERT INTO `ta` VALUES (45, 42, 0, 0, 'Kendali Posisi Bola Pingpong dengan Bat Algorithm-PID Berbasis Arduino dan LabVIEW', NULL, '2020-01-27 00:06:00', '2020-01-27 00:06:00', 'SETUJU', 2, 2, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `ta` VALUES (46, 90, 0, 0, 'Desain Front-end Analog Signal Conditioning VLC Receiver untuk Mereduksi Gangguan Noise dari Cahaya Ambient', NULL, '2020-01-27 00:07:00', '2020-01-27 00:07:00', 'SETUJU', 3, 3, NULL, NULL, NULL, NULL, '2020-07-27 20:08:53');
INSERT INTO `ta` VALUES (47, 81, 0, 0, 'Sistem Manajemen Baterai (BMS) dengan Active Balancing Menggunakan Topologi Flyback Converter untuk Baterai Lithium Ion', NULL, '2020-03-16 00:01:00', '2020-03-16 00:01:00', 'SETUJU', 1, 4, NULL, NULL, NULL, NULL, '2020-07-31 18:09:17');
INSERT INTO `ta` VALUES (48, 85, 0, 0, 'Analisa Efisiensi Penggunaan Water Cooling pada Photovoltaic Cell di Solar Tracker.', NULL, '2020-03-16 00:02:00', '2020-03-16 00:02:00', 'SETUJU', 1, 4, NULL, NULL, NULL, NULL, '2020-07-30 20:39:52');
INSERT INTO `ta` VALUES (49, 82, 0, 0, 'Perancangan dan Analisis Sistem Adaptive Cruise Control Pada Sepeda Motor Listrik', NULL, '2020-03-16 00:03:00', '2020-03-16 00:03:00', 'SETUJU', 2, 4, NULL, NULL, NULL, NULL, '2020-07-10 06:52:30');
INSERT INTO `ta` VALUES (50, 103, 0, 0, 'Optimasi Efisiensi Panel Photovoltaic (PV) Menggunakan Solar Tracker dan Heatsink Cooling.', NULL, '2020-03-16 00:04:00', '2020-03-16 00:04:00', 'SETUJU', 1, 2, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `ta` VALUES (51, 100, 0, 0, 'Rancang Bangun Sistem Proteksi Cell Baterai pada Baterai Pack dengan Teknik Active Bypass Balancer.', NULL, '2020-03-16 00:05:00', '2020-03-16 00:05:00', 'SETUJU', 1, 4, NULL, NULL, NULL, NULL, '2020-07-23 18:33:18');
INSERT INTO `ta` VALUES (52, 91, 0, 0, 'Optimalisasi Desain dan Analisis Ekonomi Sistem Pembangkit Hibrida sebagai Charging Station Kendaraan Listrik di Indonesia.', NULL, '2020-03-16 00:06:00', '2020-03-16 00:06:00', 'SETUJU', 1, 4, NULL, NULL, 1, NULL, '2020-07-30 17:22:11');
INSERT INTO `ta` VALUES (53, 96, 0, 0, 'Rancang Bangun Kendali dan Monitoring pada Kecepatan Motor BLDC dengan Sensor Hall', NULL, '2020-03-16 00:07:00', '2020-03-16 00:07:00', 'SETUJU', 1, 2, NULL, NULL, NULL, NULL, '2020-08-04 13:20:45');
INSERT INTO `ta` VALUES (54, 84, 0, 0, 'Rancang Bangun Sistem Switching Dual Platform Baterai Hibrid Lead Acid dan Lithium Ferro Phosphate sebagai Manajemen Kontrol Pemakaian Baterai.', NULL, '2020-03-16 00:08:00', '2020-03-16 00:08:00', 'SETUJU', 1, 2, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `ta` VALUES (55, 74, 0, 0, 'Perancangan Alat Inspeksi Obyek Bulat pada Conveyor Menggunakan Metode Image Processing dengan Penerapan Buah Tomat.', NULL, '2020-03-16 00:09:00', '2020-03-16 00:09:00', 'SETUJU', 2, 2, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `ta` VALUES (56, 71, 0, 0, 'Pengembangan Sistem Informasi Outcome Based Education (OBE) Berbasis Website dengan Metode Rapid Application Development (RAD).', NULL, '2020-03-16 00:10:00', '2020-03-16 00:10:00', 'SETUJU', 3, 4, NULL, NULL, NULL, NULL, '2020-07-29 17:18:43');
INSERT INTO `ta` VALUES (57, 88, 0, 0, 'Sistem Informasi Manajemen Energi Berbasis Internet of Things (IoT) dengan Metode Rapid Application Development (RAD).', NULL, '2020-03-16 00:11:00', '2020-03-16 00:11:00', 'SETUJU', 3, 4, NULL, NULL, NULL, NULL, '2020-07-24 14:23:07');
INSERT INTO `ta` VALUES (58, 93, 0, 0, 'Security Constraints Unit Commitment Pembangkit Listrik Tenaga Panas Bumi pada P.T. Sorik Marapi dengan Menggunakan Algoritma Genetika.', NULL, '2020-03-16 00:12:00', '2020-03-16 00:12:00', 'SETUJU', 1, 2, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `ta` VALUES (59, 87, 0, 0, 'Pengunaan Rangkaian Boost Converter pada Kontroler Panel Surya dengna Menggunakan Metode Rapid Prototyping.', NULL, '2020-03-16 00:13:00', '2020-03-16 00:13:00', 'SETUJU', 2, 2, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `ta` VALUES (60, 89, 0, 0, 'Optimasi dan Monitoring Daya Pembangkit Listrik Tenaga Surya di Fakultas Teknik Universitas Sebelas Maret Surakarta.', NULL, '2020-03-16 00:14:00', '2020-03-16 00:14:00', 'SETUJU', 1, 2, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `ta` VALUES (61, 79, 0, 0, 'Rancang Bangun Sistem Pengisian Baterai dengan Metode Constant Current-Fuzzy Controluntuk Baterai Lithium Ion', NULL, '2020-03-16 00:15:00', '2020-03-16 00:15:00', 'SETUJU', 1, 2, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `ta` VALUES (62, 97, 0, 0, 'Sistem Manajemen Energi Berbasis Internet of Things Menggunakan Modulasi LoRa (Long Range)', NULL, '2020-03-16 00:16:00', '2020-03-16 00:16:00', 'SETUJU', 1, 4, NULL, NULL, NULL, NULL, '2020-07-28 21:45:39');
INSERT INTO `ta` VALUES (63, 86, 0, 0, 'Navigasi Robot Keseimbangan dengan Virtual Map dan Virtual Sensor', NULL, '2020-03-16 00:17:00', '2020-03-16 00:17:00', 'SETUJU', 2, 4, NULL, NULL, NULL, NULL, '2020-08-01 08:38:44');
INSERT INTO `ta` VALUES (64, 98, 0, 0, 'Sistem Kendali Posisi dengan Metode Linear Quadratic Gaussian pada VTOL (Vertical Take Off Landing)', NULL, '2020-03-16 00:18:00', '2020-03-16 00:18:00', 'SETUJU', 2, 4, NULL, NULL, NULL, NULL, '2020-07-29 17:29:16');
INSERT INTO `ta` VALUES (65, 72, 0, 0, 'Perancangan Isolated Gate Driver untuk Sistem Kendali Motor BLDC pada Pompa Air', NULL, '2020-03-16 00:19:00', '2020-03-16 00:19:00', 'SETUJU', 2, 2, NULL, NULL, 1, NULL, '2020-04-29 13:53:38');

-- ----------------------------
-- Table structure for ta_logbook
-- ----------------------------
DROP TABLE IF EXISTS `ta_logbook`;
CREATE TABLE `ta_logbook`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `mahasiswa_id` int(15) NULL DEFAULT NULL,
  `kegiatan` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `bab` int(20) NULL DEFAULT NULL,
  `kendala` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `rencana` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `komentar1` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `komentar2` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `status_logbook1` tinyint(6) NULL DEFAULT 2,
  `status_logbook2` tinyint(6) NULL DEFAULT 2,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 335 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ta_logbook
-- ----------------------------
INSERT INTO `ta_logbook` VALUES (2, 102, '1. Mencoba memrogram mikrokontroller C2000 dengan program sederhana menggunakan software matlab dan CCS.\nSebagai langkah checking connection antara hardware dan software.\n2. Mencari referensi mengenai pemodelan kendali motor BLDC menggunakan simulink matlab.', 3, 'Belum ada.\nProgress: telah menemukan build setting yang tepat.', 'Memahami referensi dan menyesuaikan dengan batasan penelitian yang akan dilakukan sehingga model dapat diterapkan pada penelitian.', NULL, NULL, 2, 2, '2020-02-06 12:17:14', '2020-02-06 12:17:14');
INSERT INTO `ta_logbook` VALUES (3, 104, 'Mengerjakan function create, read, update, dan delete pada bagian Dashboard Admin. Serta menyesuaikan bisnis proses dari Kerja Praktek mulai dari pendaftaran, sampai seminar Kerja Praktek, dan bisnis proses Tugas Akhir dari mulai pendaftaran sampai pelaksanaan tugas akhir.', 3, 'Belum Ada', 'Mengerjakan Bisnis Proses Seminar Hasil Tugas Akhir dan Bisnis Proses Pendadaran', NULL, 'Bagus, lanjutkan', 2, 1, '2020-02-19 15:07:54', '2020-06-22 19:22:36');
INSERT INTO `ta_logbook` VALUES (4, 104, 'Mengerjakan bisnis proses seminar hasil bagian (adminta) dan bisnis proses pendadaran bagian (adminta) untuk memberikan feedback/umpan balik dari pendaftaran seminar hasil/pendadaran yang dilakukan mahasiswa.', 3, 'Belum Ada', 'Testing Sistem secara langsung melibatkan mahasiswa (metode whitebox), dan konsultasi bisnis proses mengenai kerja praktek dan tugas akhir.', NULL, NULL, 2, 2, '2020-02-20 16:27:13', '2020-02-20 16:27:13');
INSERT INTO `ta_logbook` VALUES (5, 102, '1. Mencoba build program kendali motor BLDC pada software CCS. Program diambil dari example sistem dan dimodifikasi sesuai spesifikasi motor yang dipakai.\n2. Mencari referensi build program kendali motor BLDC sensorless pada software MATLAB Simulink.', 3, '1. Setting program awal telah dilakukan, tetapi output sinyal belum sesuai target yang dikehendaki, sehingga sinyal PWM belum berhasil mengendalikan motor.\n2. Referensi Simulink untuk kendali sensorless BLDC dengan TMS320F28035 yang sedikit, sehingga akan dilakukan modifikasi pada referensi yang nantinya ditemui.', 'Membaca dan memahami step kendali program pada software CCS dan MATLAB.', NULL, NULL, 2, 2, '2020-02-27 13:08:43', '2020-02-27 13:08:43');
INSERT INTO `ta_logbook` VALUES (6, 102, '1. Melakukan pengecekan motor BLDC pada mikrokontroler lain dengan hasil motor dapat dikalibrasi serta diaktifkan.\n2. Melakukan build program dengan TMS320F28035 pada software CCS dan MATLAB Simulink (example checking system dan model kendali BLDC dengan spesifikasi motor yang telah disesuaikan).\n3. Mencari referensi pengendalian motor dengan sistem yang lain.', 3, '1. Program dapat dibuild, tetapi motor belum dapat dikalibrasi/ dideteksi oleh sistem.\n2. Pengecekan output yang sulit ditelusuri karena sistem tertanam hanya ada beberapa pin i/o yang telah diperuntukkan untuk sensor, motor, input tegangan.', 'Tetap fokus pada mikrokontroler yang digunakan. Mempelajari dan memahami sistem dan pemrogramannya.', NULL, NULL, 2, 2, '2020-03-06 20:19:44', '2020-03-06 20:19:44');
INSERT INTO `ta_logbook` VALUES (7, 42, 'Konsultasi terkait tugas membuat daftar study literatur yang akan digunakan pada penyusunan skripsi, terdiri dari kendali posisi, kontrol motor DC, Kendali PID, Kontrol motor dengan PID, PID tuning Bat Algorithm, PID pada Arduino dan LabVIEW', 2, 'Studi Literatur tentang kendali posisi dengan motor DC susah mencarinya, kebanyakan tahun yang ada terlalu lama.', 'Tugas untuk minggu depan:\n1. Membuat Closeloop diagram blok Sistem Kendali Bola Pingpong\n2. Flowchart Hardware\n3. Flowchart Sofftware\n4. Teknik-teknik modeling yang akan dipakai', NULL, NULL, 2, 2, '2020-03-11 09:33:05', '2020-03-11 09:33:05');
INSERT INTO `ta_logbook` VALUES (8, 102, '1. Pengecekkan sistem yang belum menghasilkan output. Setelah melakukan pengecekkan, ditemukan kendala pengaktifan pada blok DC Bus Inverter dan dapat diatasi. \n2. Mencoba program yang sebelumnya masih gagal di build. Dihasilkan proses build/ debug program telah berhasil.\n3. Melakukan pengecekkan output dengan penggantian beberapa variasi parameter.', 3, 'Output belum sesuai dengan set parameter awal.', 'Mempelajari setting input parameter dan mencari hubungan setting input dengan output yang dihasilkan.', NULL, NULL, 2, 2, '2020-03-19 18:20:09', '2020-03-19 18:20:09');
INSERT INTO `ta_logbook` VALUES (9, 87, 'Mencari Application Note mengenai Boost Converter sebagai referensi rangkaian yang dibutuhkan. Kemudian melakukan simulasi rangkaian di Proteus. Mulai mencari referensi mengenai rangkaian kontroler panel surya. ', 3, 'Rangkaian yang disimulasikan di Proteus masih terdapat kesalahan, belum ditemukannya rangkaian kontroler panel surya yang sesuai dan dapat dikoneksikan dengan rangkaian boost converter', 'Melakukan simulasi rangkaian Boost Converter di MatLab dari referensi yang diberikan oleh Pak Hari', NULL, NULL, 2, 2, '2020-03-26 13:42:11', '2020-03-26 13:42:11');
INSERT INTO `ta_logbook` VALUES (10, 98, 'Membaca literatur yang telah diberikan, juga sedang melakukan pembelian alat dan bahan untuk mencoba menggunakan metode yang baru, nantinya setelah alat datang akan langsung dicoba dan diprogram, lalu disesuaikan dengan metode yang akan digunakan', 3, 'Tidak ada', 'Percobaan menggunakan alat baru', NULL, 'ok', 2, 1, '2020-03-26 13:42:15', '2020-07-20 11:08:47');
INSERT INTO `ta_logbook` VALUES (11, 82, 'Sudah melakukan penyusunan penulisan bab I-II, mengalami kendala dibagian bab 2 tentang Throttle yang digunakan pada Tugas Akhir ini. \n\nSensor yang akan digunakan sudah diuji, yaitu sensor Ultrasonik US-015, dengan jarak maksimal pembacaan saat uji coba adalah 335 cm atau 3,35 m. Masih diuji lagi sensor US-015 hingga mampu mendeteksi objek minimal 500 cm atau 5 m, jika tidak maka akan dicoba digantikan dengan sensor lain yaitu sensor radar.\n\n Penempatan sensor di Sepeda Motor Listrik sudah dianalisa langsung pada Sabtu, 21 Maret 2020, akan di letakkan dibawah lampu utama supaya sensor ultrasonik dapat mendeteksi dengan baik.', 2, 'Mencari referensi tentang adaptive cruise control yang minim untuk aplikasi pada sepeda motor listrik.', '1. Mencari referensi berupa simulasi cruise control menggunakan Arduino, lalu menyusun algoritma kerja cruise control yang disesuaikan dengan kontroler yang digunakan untuk mengendalikan motor BLDC pada sepeda motor listrik.\n\n2. Menyelesaikan penulisan BAB 2\n3. Melanjutkan penyusunan BAB 3', NULL, NULL, 2, 2, '2020-03-26 18:44:12', '2020-03-26 18:44:12');
INSERT INTO `ta_logbook` VALUES (12, 104, 'Mengerjakan bisnis proses kerja praktek sesuai revisi yaitu surat permohonan pembimbing, mengubah setiap action memiliki output tersendiri, membuat kondisi kerja praktek minimal 4 minggu, serta perbaikan informasi tentang upload dokumen selesai kp, presensi, dan laporan.', 3, 'tidak ada', 'Mengerjakan bisnis proses seminar hasil dan pendadaran..', NULL, NULL, 2, 2, '2020-03-27 20:16:42', '2020-03-27 20:16:42');
INSERT INTO `ta_logbook` VALUES (13, 76, 'Membuat block vppm modulator menggunakan software quartus dengan input berupa clock (sample_clk dan sym_clk), data transceiver (dtx), dan nilai dimming (nd); dan melakukan compiling untuk program dan design block vppm modulator.', 3, 'tidak ada', 'Membuat block untuk vppm demodulator', NULL, NULL, 2, 2, '2020-03-27 22:23:44', '2020-03-27 22:23:44');
INSERT INTO `ta_logbook` VALUES (14, 91, '-Konsultasi dengan dosen pembimbing mengenai bab 1 dan bab 2 pada tanggal 25 Maret 2020, terdapat beberapa penambahan untuk BAB 1 dan penulisan referensi.\n-Membaca literatur terkait dengan pemodelan pembangkit\"', 1, 'belum ada', '- Melakukan perbaikan pada bab 1\n- Mulai melakukan desain pembangkit', NULL, NULL, 2, 2, '2020-03-30 05:13:16', '2020-03-30 05:13:16');
INSERT INTO `ta_logbook` VALUES (15, 86, '1. Konsultasi online dengan dosen pembimbing, membahas mengenai pembuatan hardware dan metode kontrol\n2. Set up raspberry pi agar bisa di gunakan secara wireless melalui PC, uji coba sensor MPU6050, uji coba motor stepper nema 17', 3, 'Belum bisa mengontrol stepper dengan mudah melalui coding yang efisien', 'Pencarian referensi code program kontrol motor stepper dengan bahasa pemograman python, mencari library yang sesuai bila memungkinkan', NULL, NULL, 2, 2, '2020-03-30 09:27:53', '2020-03-30 09:27:53');
INSERT INTO `ta_logbook` VALUES (16, 97, 'Bimbingan online dengan pembimbing mengenai arsitektur dan flowchart hardware & software sistem yang akan di rancang. Juga memaparkan hal-hal yang sudah dikerjakan yaitu membuat tampilan dashboard di broker MQTT yaitu Adafruit.io, melakukan simulasi menggunakan aplikasi MQTT.fx, membuat konektivitas antara Adafruit.io dengan IFTTT serta membuat list komponen yang akan digunakan.', 3, 'tidak ada', '1. Membeli komponen yang akan digunakan.\n2. Menyesuaikan sensor dan relay yang digunakan dikarenakan akan menggunakan 2 variasi beban.\n3. Mencari referensi terakit security pada broker MQTT Adafruit.io.\n4. Mencari referensi terakit API pada broker MQTT Adafruit.io.\n5. Mencari referensi terakit rekap data pada broker MQTT Adafruit.io untuk pembahasan dan analisis.', NULL, NULL, 2, 2, '2020-03-30 12:19:10', '2020-03-30 12:19:10');
INSERT INTO `ta_logbook` VALUES (17, 81, '+ Melakukan perancangan BMS dan belanja beberapa komponen\n+ Menguji coba gate driver TLP250 dan MOSFET IRF540. Didapatkan kesimpulan bawha adanya batasan tegangan untuk mengoperasikan sisi tegangan tinggi TLP250, dan sudah menentukan nilai resistansi resistor pada sisi masukan PWM pada TLP250.', 3, 'Tidak Ada', 'Memvariasikan tegangan pada sisi tegangan tinggi TLP250', NULL, NULL, 2, 2, '2020-03-30 15:23:50', '2020-03-30 15:23:50');
INSERT INTO `ta_logbook` VALUES (18, 104, 'Mengerjakan bisnis proses seminar hasil dan pendadaran, update operator ta, update log book ta. Perbaikan bug dari pendaftaran seminar hasil, pendadaran, dashboard, update database logbook dan tawaran topik ta.', 3, 'tidak ada', 'Konsultasi sistem kpta, revisi sistem, dan mencoba implementasi push notifikasi pesan melalui email.', NULL, NULL, 2, 2, '2020-03-30 21:48:59', '2020-03-30 21:48:59');
INSERT INTO `ta_logbook` VALUES (25, 82, '\"Jumat, 27 Maret 2020\r\n1. Penulisan tentang Throttle dan Cruise Control\r\n2. Memeriksa Radar RCWL-0516\r\n\r\nSabtu, 28 Maret 2020\r\n1. Penyempurnaan penulisa throttle\r\n\r\nMinggu, 29 Maret 2020\r\n1. Penyempurnaan penulisan Cruise Control\r\n2. Membaca literatur sensor ultrasonik\r\n\r\nSenin, 30 Maret 2020\r\n1. Penyelesaian penulisan sensor Ultrasonik\"', 2, 'belum ada', '1. Penyempurnaan Bab 3', NULL, NULL, 2, 2, '2020-03-30 23:20:02', '2020-03-30 23:20:02');
INSERT INTO `ta_logbook` VALUES (26, 79, 'Membaca literatur penggunaan buck converter pada charger battery dan melakukan simulasi buck converter menggunakan driver tlp250 untuk charge battery di software proteus, melakukan percobaan driver tlp250', 3, 'Kendala pada pemrograman mikrokontroler', '\"1. Membeli komponen untuk perancangan hardware\n2. Menyelesaikan Simulasi hingga berjalan\"', NULL, NULL, 2, 2, '2020-03-31 15:10:22', '2020-03-31 15:10:22');
INSERT INTO `ta_logbook` VALUES (27, 84, '\"1. Membaca literatur tentang driver mosfet baik optocoupler, IR2110, IR2112 dan TLP dari beberapa jurnal dan data sheet komponen.\n2. Melakukan simulasi terhadap rangkaian switching menggunakan beberapa komponen driver Mosfet seperti IR2110, Optocoupler dan TLP250 dengan software Proteus dan membandingkan hasil switching\n2. Memastikan/memfixkan rangkaian switching dan driver mosfet yang digunakan pada rangkaian\"', 3, 'Belum ada', '1. Mencoba simulasi proteus dari beberapa variasi driver mosfet (IR2110, Opto, TLP) pada project board, melihat kerja komponen dan alat yang digunakan.', NULL, NULL, 2, 2, '2020-04-01 15:09:26', '2020-04-01 15:09:26');
INSERT INTO `ta_logbook` VALUES (28, 81, '\"+ Menguji coba variasi pada sisi tegangan tinggi TLP250. Didapatkan minimal tegangan sebesar 12 V. Kemudian penulis memutuskan untuk menggunakan hi-link 12 V sebagai sumber tegangan pada sisi tegangan tinggi.\n\"', 3, 'Tidak ada', 'Membuat trafo flyback', NULL, NULL, 2, 2, '2020-04-01 16:00:33', '2020-04-01 16:00:33');
INSERT INTO `ta_logbook` VALUES (29, 82, '\"Selasa,  31 Maret 2020\n1. Penyempurnaan penulisan Metode Penelitian dan Perbaikan Flowchart\n\nRabu, 1 April 2020\n1. Konsultasi penulisan skripsi Bab I-III yang ke-2\n2. Mempelajari cara setting kontroler Votol EM-Series pada manual book Votol\"', 3, '1. Tidak memiliki catu daya/baterai 48-60 VDC, harus meminjam di kampus dan kunci kendaraan yang terdapat baterai 48-60 VDC masih dibawa mahasiswa lain.', '\"1. Penyempurnaan Penulisan Bab I-III\n2. Pembuatan simulasi sistem pada Proteus atau Simul IDE\n3. Mencoba mengakses Votol EM-100 dengan PC\n4. Uji kerja sensor pada protoboard, baik sensor utama (US-015) maupun sensor cadangan (RCWL-0516)\"', NULL, NULL, 2, 2, '2020-04-01 19:22:19', '2020-04-01 19:22:19');
INSERT INTO `ta_logbook` VALUES (30, 76, 'Membuat demodulator menggunakan software Quartuz, dimana terdiri dari 3 block, yaitu block demodulator, block BER (Bit Error Rate), dan block UART. Disini, saya baru membuat yang block untuk demodulatornya.', 3, 'tidak ada', 'Membuat block untuk BER', NULL, NULL, 2, 2, '2020-04-01 20:30:49', '2020-04-01 20:30:49');
INSERT INTO `ta_logbook` VALUES (31, 90, 'Mengerjakan Software dan menyesuaikan dengan hardware namun terjadi kendala dimana hasil simulasi tidak sesuai dengan praktek dalam hal ini saya mencoba mencari jalan keluar dengan mencoba langsung praktek', 3, 'Simulasi tidak sesuai praktek', 'Mengerjakan bagian hardware langsung', 'ok', NULL, 1, 2, '2020-04-02 13:20:30', '2020-07-16 12:12:55');
INSERT INTO `ta_logbook` VALUES (32, 76, 'Konsultasi dengan Pembimbing 1 dan 2 mengenai progres Tugas Akhir yang telah dilakukan (pembuatan block modulator dan block demodualator) dan melanjutkan membuat Demodulator block untuk Bit Error Rate (BER).', 3, 'Hasil simulasi gelombang pada ModelSIM masih belum sesuai dengan yang diinginkan, yaitu pada hasil saat input pengirim dan penerima di-XOR-kan masih ada error.', 'Memperbaiki error hingga mendapat hasil yang sesuai.', NULL, NULL, 2, 2, '2020-04-02 13:22:21', '2020-04-02 13:22:21');
INSERT INTO `ta_logbook` VALUES (33, 102, '\"1. Mencari dan membaca referensi penggunaan mikrokontroller lain. Dilanjutkan dengan pengumpulan komponen pengontrolan sederhana.\n2. Mencari referensi cara dan metode pengontrolan menggunakan mikrokontroller lain.\"', 3, '\"Menunggu komponen yang cukup lama.\nReferensi pengontrolan dari beberapa sumber kurang lengkap.\"', 'Mencoba program sederhana pengontrolan motor BLDC dengan komponen yang telah ada.', NULL, NULL, 2, 2, '2020-04-02 23:35:03', '2020-04-02 23:35:03');
INSERT INTO `ta_logbook` VALUES (34, 97, 'Melakukan percobaan pada sisi end node yaitu menggabungkan antara Arduino + Lora Shield, Sensor Arus ACS712 5A dan Sensor Tegangan ZMPT101B. Pada percobaan kali ini sensor belum terhubung dengan beban.', 3, 'Tidak ada', 'Melakukan percobaan pada sisi end node dengan menambahkan relay module & solid state relay (SSR).', NULL, NULL, 2, 2, '2020-04-03 14:04:58', '2020-04-03 14:04:58');
INSERT INTO `ta_logbook` VALUES (35, 76, 'Memperbaiki error pada block Bit Error Rate (BER). Error sudah berhasil diperbaiki dan sesuai dengan logika XOR. Saat data Tx dan Rx sama, maka counting error tetap namun saat Tx dan Rx berbeda maka counting error akan bertambah. ', 3, 'Tidak ada', 'Menyempurnakan block BER dengan menambahkan program untuk counter 16 bit.', NULL, NULL, 2, 2, '2020-04-03 16:48:44', '2020-04-03 16:48:44');
INSERT INTO `ta_logbook` VALUES (36, 82, '\"Kamis,  2 April 2020\n1. Menguji kontroler Votol EM-100 yang sudah diperbaiki, untuk simulasi prototipe sistem.\n2. Mencoba sensor cadangan RCWL-0516, dapat dioperasikan dengan indikator LED merah yang berkedip-kedip.\n3. Menguji sensor Ultrasonik dengan library pengukuran yang langsung ditampilkan pada LCD dengan komunikasi I2C, hasil pengukuran jarak 313 cm.\n\nJumat,  3 April 2020\n1. Mengakses dan mempelajari cara setting kontroler Votol  dengan PC, pada hari ini menggunakan kontroler Votol EM-150.\n2. Menambah tahap validasi data pada Metodologi Penelitian Bab III.\n\"', 3, '\"Kamis,  2 April 2020\n1. Kutub positif  baterai bertegangan 60-72VDC, mengeluarkan percikan api kecil, sehingga akan dicoba mengakses ke PC pada esok hari, rangkaian dan baterai dalam kondisi baik.\n2. Sensor Ultrasonik harus benar-benar diletakkan secara tegak agar dapat mengukur jarak. secara akurat.\n\n\nJumat,  3 April 2020\n1. Packaging kontroler Votol EM-100 dengan akrilik dan penambahan MCB DC.\"', '\"1. Penyempurnaan Bab III.\n2. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n3. Merangkai rangkaian simulasi sistem pada Proteus dan Simul IDE.\n4. Test sensor Ultasonik lagi dengan metode yang berbeda.\n\"', NULL, NULL, 2, 2, '2020-04-03 20:54:44', '2020-04-03 20:54:44');
INSERT INTO `ta_logbook` VALUES (37, 97, 'Melakukan konfigurasi pada LoRa Gateway. Dimana LoRa Gateway akan menghubungkan antara End Node dengan IoT Cloud Server dalam hal ini penelitienggunakan Broker MQTT yaitu adafruit IO. Konfigurasi dilakukan dengan cara mengubah fungsi LoRa Gateway menjadi forwarder ke MQTT server. Kemudian menginput broker addres, broker port, topic format dan data string format sesuai broker Adafruit IO.', 3, 'LoRa Gateway belum bisa terhubung dengan End node dan IoT cloud server.', 'Mencari solusi atas permasalahan tersebut sehingga LoRa Gateway dapat terhubung dengan End Node dan IoT cloud server.', NULL, NULL, 2, 2, '2020-04-04 13:23:35', '2020-04-04 13:23:35');
INSERT INTO `ta_logbook` VALUES (38, 90, 'Hari ini saya masih melakukan simulasi rangkaian analog. Karena AGC sudah dibuat saya mencoba menggabungkan dengan rangkaian clamper dan rangkaian penguat op amp agar output sesuai dengan tegangan masuk FPGA. Hasil simulasi sudah sesuai dengan kebutuhan insya allah dilanjutkan dengan pembuatan rangkaian langsung', 3, 'Belum membeli komponen pasif. Resistor dan kapasitor', 'Insya allah besok saya membeli komponen dan mencobanya menggunakan protoboard', 'lanjutkan', NULL, 1, 2, '2020-04-05 19:12:11', '2020-07-16 12:13:19');
INSERT INTO `ta_logbook` VALUES (39, 82, '\"Sabtu,  4 April 2020\n1. Revisi bab III menambah validasi pada metode penelitian.\n2. Bisa mengakses dan dapat setting dengan P,  kontroler Votol EM-150 (setipe dengan EM-100), setting yang dilakukan dapat membuat sepeda motor berjalan dengan baik.\n\nMinggu,  5 April 2020\n1. Melanjutkan penyempurnaan bab III.\n2. Simulasi pada protoboard mengontrol Motor DC dengan Potensio analogi mengontrol Motor BLDC dengan Throttle menggunakan prinsip PWM Arduino UNO.\n\n\nSenin, 6 April 2020\n1. Mencari video sebagai referensi tambahan tentang pembuatan sistem Adaptive Cruise Control dengan Arduino.\n2. Melanjutkan penyempurnaan bab III.\n\n\"', 3, 'Tidak Ada', '\"1. Fiksasi dan penyempurnaan bab II dan bab III.\n2. Mencoba mengontrol motor DC dengan menggunakan sensor ultrasonik pada simulasi protoboard.\n3. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n4. Merangkai rangkaian simulasi sistem pada Proteus dan Simul IDE.\"', NULL, NULL, 2, 2, '2020-04-06 20:51:31', '2020-04-06 20:51:31');
INSERT INTO `ta_logbook` VALUES (40, 84, '\"1. Melakukan percobaan driver mosfet optocoupler, IR2110 dan TLP250 di Project Board.\n1. Membandingkan hasil simulasi pada Proteus ISIS dengan percobaan Project Board.\n2. Memastikan rangkaian switching dengan driver mosfet\"', 3, '\"1. Ketika menggunakan Opto rangkaian switching belum sepenuhnya berjalan (perbedaan VO ke gate mosfet)\n2. Ketika menggunakan IR2110, terdapat arus yang masuk melalui mosfet yang terhubung LO (Low Output)\n3. Ketika menggunakan TLP, terdapat ketidaksesuaian buka tutup antar mosfet\"', 'Memperbaiki percobaan switching(baik simulasi maupun percobaan project board) dengan variasi driver mosfet, menentukan rangkaian dan komponen switching yang digunakan', NULL, NULL, 2, 2, '2020-04-07 10:43:52', '2020-04-07 10:43:52');
INSERT INTO `ta_logbook` VALUES (41, 79, 'Mencari literatur tentang non-inverting buckboost converter, dan mensimulasikan buckboost converter di Proteus secara sederhana dengan pwm (belum menggunakan mikroprosesor), mencoba driver TLP250 sebagai driver mosfet', 3, 'belum menemukan referensi tentang perhitungan induktor, kapasitor non-inverting buck boost converter', '\"- Merancang buckboost converter pada projectboard\n- Pengujian sensor suhu dan tegangan pada rangkaian\"', NULL, NULL, 2, 2, '2020-04-07 16:15:15', '2020-04-07 16:15:15');
INSERT INTO `ta_logbook` VALUES (42, 81, '\"1. Membuat trafo flyback dengan perbandingan lilitan 1:3.\n2. Mengukur nilai induktansi trafo dan menguji coba.\n3. Membuat code dan menguji coba pada trafo dengan variasi sinyal PWM dan frekuensi tinggi.\"', 3, 'Tidak Ada', 'Melakukan desain PCB', NULL, NULL, 2, 2, '2020-04-07 19:39:11', '2020-04-07 19:39:11');
INSERT INTO `ta_logbook` VALUES (43, 96, '\"1. mencari literatur mengenai rangakain driver mosfet 3 fasa dengan IR2110 untuk motor BLDC pada sepeda listrik \n2. mencoba membuat simulasi driver mosfet 3 fasa menggunakan software Proteus 7.9 berdasarkan literatur yang diperoleh\"', 3, '1. menentukan komponen yang sesuai untuk diaplikasikan di motor BLDC sepeda listrik', '\"1. membuat coding dengan arduino IDE\n2. mencoba membuat hardware 1 fasa 1 mosfet dengan IR2110 untuk memahami prinsip kerja rangkaian.\"', NULL, NULL, 2, 2, '2020-04-07 21:37:44', '2020-04-07 21:37:44');
INSERT INTO `ta_logbook` VALUES (44, 93, '\"1. Mengerjakan coding pada aplikasi matlab untuk unit commitment dengan acuan code dari literatur (50%).\n2. Pengambilan data dari lapangan untuk menjalankan simulasi yang akan dibuat\n3. Mencari literatur terkait dengan algoritma genetika yang sederhana\"', 3, '\"1. memasukkan code algoritma genetika kedalam UC\n2. terhambatnya pengambilan data di lapangan\n3. masih banyak error dalam coding\"', '\"1. membuat code algoritma genetika yang singkat\n2. menemukan literatur yang tepat\n3. menyempurnakan coding untuk unit commitment\"', NULL, NULL, 2, 2, '2020-04-08 14:20:46', '2020-04-08 14:20:46');
INSERT INTO `ta_logbook` VALUES (45, 96, '\"1. mencari literatur mengenai rangakain driver mosfet 3 fasa dengan IR2110 untuk motor BLDC pada sepeda listrik \n2. mencoba membuat simulasi driver mosfet 3 fasa menggunakan software Proteus 7.9 berdasarkan literatur yang diperoleh\"', 3, '1. menentukan komponen yang sesuai untuk diaplikasikan di motor BLDC sepeda listrik', '\"1. membuat coding dengan arduino IDE\n2. mencoba membuat hardware 1 fasa 1 mosfet dengan IR2110 untuk memahami prinsip kerja rangkaian.\"', NULL, NULL, 2, 2, '2020-04-08 20:28:37', '2020-04-08 20:28:37');
INSERT INTO `ta_logbook` VALUES (46, 96, '\"1. membuat coding arduino untuk rangkaian driver mosfet satu fasa dan driver mosfet 3 fasa \n2. mencoba membuat rangakain hardware drive mosfet 1 fasa pada project board menggunakan IC IR2110 dan mosfet IRFZ44N\"', 3, '\"1. rangakaian masih belum dapat berjalan , sepertinya karena penggunaan project board yang kadang kurang kencang\n2. coding 3 fasa masih belum jadi, karena perlu ditambah potensiometer untuk mengatur duty cycle gelombang pwm dari arduino\"', '\"1. mencoba rangakaian 1 fasa di pcb\n2. menyelesaikan codingan 3 fasa\"', NULL, NULL, 2, 2, '2020-04-08 20:36:23', '2020-04-08 20:36:23');
INSERT INTO `ta_logbook` VALUES (47, 82, '\"Selasa, 7 April 2020\n1. Selesai melakukan fiksasi dan penyempurnaan Bab II\n2. Mencoba instalasi software Proteus, Simul IDE dan Fritzing\n\nRabu,  8 April 2020\n1. Berhasil menginstall aplikasi yang digunakan untuk TA dan melengkapi masing-masing aplikasi dengan seluruh library yang dibutuhkan.\n2. Mulai merangkai  rangkaian sistem pada aplikasi yang akan digunakan.\"', 3, '\"Selasa,  7 April 2020\n1. Mencari versi proteus yang terkini susah ditemukan\n2. Karena TA from home kuota yang dibutuhkan besar untuk mendownload software yang digunakan untuk mengerjakan Tugas Akhir\n\nRabu, 8 April 2020\n1. Mencari referensi kontrol motor BLDC dengan Arduino di Proteus.\n2. Memerlukan alat throttle elektrik dengan sensor hall sebagai pengganti potensiometer pada simulasi protoboard sebelumnya.\"', '\"1. Fiksasi dan penyempurnaan bab III.\n2. Mencoba mengontrol motor DC dengan menggunakan sensor ultrasonik pada simulasi protoboard dan mengganti potensio dengan throttle.\n3. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n4. Merangkai rangkaian simulasi sistem pada Proteus dan Simul IDE.\"', NULL, NULL, 2, 2, '2020-04-08 21:08:13', '2020-04-08 21:08:13');
INSERT INTO `ta_logbook` VALUES (48, 97, 'Melanjutkan percobaan pada sisi end node. Dalam percobaan ini end node sudah bisa terhubung ke gateway dan dapat mengirimkan data ke IoT cloud server. Akan tetapi pada percobaan kali ini pada sisi end node belum terhubung dengan beban.', 3, 'Sistem monitoring baru bisa mengirimkan satu buah data yaitu data beban, belum bisa mengirimkan dua buah data yaitu data beban dan tagihan listrik.', 'Melanjutkan coding arduino sehingga ke dua data yang diinginkan dapat dikirimkan.', NULL, NULL, 2, 2, '2020-04-08 21:57:12', '2020-04-08 21:57:12');
INSERT INTO `ta_logbook` VALUES (49, 89, 'Mempelajari konfigurasi dasar dari MPPT MPI 5.5 kW yang sesuai dengan jenis MPPT di FT UNS. Mulai dari rangkaian penyusun dasar (Hybrid, On Grid, dan Off Grid), fitur yang disediakan, konfigurasi tampilan, jenis komunikasi yang digunakan, dan komponen komponen penunjang kerja MPPT MPI 5.5 kW lainnya.', 3, 'Belum memahami jenis software yang digunakan untuk menampilkan output daya dari PV.', 'Mempelajari jenis software yang digunakan dan menampilkannya', NULL, NULL, 2, 2, '2020-04-09 09:23:21', '2020-04-09 09:23:21');
INSERT INTO `ta_logbook` VALUES (50, 96, '\"1. mencoba merangakai driver mosfet 1 fasa di pcb bolong \n2. menyelesaikan coding arduino untuk rangkaian driver mosfet 3 fasa\n3. mencoba mengaplikasikan coding ke rangkaian simulasi proteus yang sebelumnya telah dirangkai\"', 3, '\"1. rangkaian driver 1 fasa masih belum dapat berjalan\n2. simulasi dengan coding yang telah dibuat masih belum dapat berjalan dengan baik\"', '\"1. mencoba mengulangi rangkaian driver 1 fasa di pcb \n2. menyempurnakan rangkaian simulasi\"', NULL, NULL, 2, 2, '2020-04-09 20:23:09', '2020-04-09 20:23:09');
INSERT INTO `ta_logbook` VALUES (51, 97, 'Melanjutkan coding pada sisi end node. Pada kegiatan ini dilakukan coding pada end node 2 dimana perbedaan dari end node 1 adalah sensor arus yang digunakan lebih besar yaitu 30A dibandingkan dengan sensor pada end node 1 sebesar 5A. Kedua buah end node sudah bisa mengirim data ke LoRa gateway dan IoT cloud server. Akan tetapi kedua buah end node belum dihubungkan dengan beban sehingga masih mengirimkan nilai 0.', 3, 'Terkadang terdapat data yang gagal dikirimkan. Karena sistem yang saya rancang mengirimkan data setiap 1 menit sekali namun terkadang masih terdapat data yang hilang.', 'Mencari penyebab dan solusi atas masalah diatas dan mencari referensi terkait coding downlink pada relay module dan ssr.', NULL, NULL, 2, 2, '2020-04-09 20:57:20', '2020-04-09 20:57:20');
INSERT INTO `ta_logbook` VALUES (52, 104, 'Update sistem portal elektro ke Laravel 7,Penambahan fitur notifikasi untuk mahasiswa, Dosen, Koordinator TA, Koordinator KP, dan Operator TA, Penambahan fitur push notifikasi melalui email saat mengisi logbook, penambahan status cetak berkas, perbaikan tampilan sistem.', 3, 'belum ada', 'Konsultasi, Menambahkan Count time untuk Tugas Akhir', NULL, NULL, 2, 2, '2020-04-09 21:28:11', '2020-05-18 14:19:20');
INSERT INTO `ta_logbook` VALUES (55, 96, '\"1. mengulangi merangkai driver mosfet 1 fasa di pcb, masih belum berhasil, karena ada yang short\n2. menyempurnakan rangkaian simulasi agar berjalan dengan baik, rangkaian. simulasi dapat berjalan namun hanya bertahan beberapa detik, sepertinya karena CPU laptop overload\"', 3, '\"1. rangkaian di PCB masih belum dapat berjalan , sepertinya coding masih salah\n2. spesifikasi laptop kurang tinggi, dan rangkaian masih belum sederhana\"', '\"1. mencoba mengganti coding arduino untuk rangkauan driver 1 fasa\n2. mencoba rangkaian simulasi di laptop yang memiliki spesifikasi lebih tinggi\"', NULL, NULL, 2, 2, '2020-04-11 11:17:43', '2020-04-11 11:17:43');
INSERT INTO `ta_logbook` VALUES (56, 97, 'Menghubungkan sisi end node dengan beban. Dimana sensor arus ACS712 membaca arus pada beban yang digunakan, sedangkan tegangan di set pada angka 220. Hasilnya didapatkan nilai arus 0.12 pada beban kipas angin.\r\n', 3, 'Data daya belum sesuai dengan realita, karena seharusnya daya terus bertambah dengan berjalannya waktu. Serta data daya yang dikirimkan ke adafruit.io belum sesuai dengan data di serial monitor arduino. Di serial monitor menunjukkan nilai 27.26 watt, tetapi di cloud masih 0.\r\n', 'Melakukan perbaikan coding pada sisi pembacaan daya dan mempelajari data string format pada Adafruit IO.\r\n', NULL, NULL, 2, 2, '2020-04-11 11:27:03', '2020-04-11 11:27:03');
INSERT INTO `ta_logbook` VALUES (57, 81, 'Melakukan desain PCB menggunakan software proteus. PCB yang didesain terdiri dari PCB balancing, hi-link, dan battery pack. Desain pcb balancing dibuat double layer karena kerumitan dari topologi BMS.\r\n', 3, 'Tidak ada\r\n', 'Drilling, pemasangan komponen, soldering.\r\n', NULL, NULL, 2, 2, '2020-04-11 21:40:38', '2020-04-11 21:40:38');
INSERT INTO `ta_logbook` VALUES (58, 82, '\"Kamis, 9 April 2020\n1. Merangkai rangkaian Simulasi pengendalian motor DC dengan PWM di Proteus.\n2. Fiksasi dan penyempurnaan Bab III.\n\nJumat, 10 April 2020\n1. Merangkai rangkaian Simulasi di Proteus tentang Measuring Distance Sensor Ultrasonik.\n2. Selesai melakukan fiksasi dan penyempurnaan Bab III\n\nSabtu, 11 April 2020\n1. Menyatukan rangakaian sensor Ultrasonik dan kontrol motor DC pada simulasi rangkaian di Proteus.\n2. Konsultasi online dengan pembimbing 1 dan 2 mengenai Bab I-III, diijinkan mengambil data untuk bab IV oleh pembimbing 1.\"\r\n', 3, '\"Kamis, 9 April 2020\nTidak Ada\n\nJumat, 10 April 2020\nTidak Ada\n\nSabtu, 11 April 2020\n1. Aplikasi Proteus yang terkadang auto close ketika menjalankan simulasi maupun setelahnya.\n2. Mengatur pwm dengan sensor Ultrasonik atau logika untuk speed limiting ketika mode Adaptive Cruise Control diaktifkan.\"\r\n', '\"1. Mencoba mengontrol motor DC dengan menggunakan sensor ultrasonik pada simulasi protoboard dan mengganti potensio dengan throttle.\n2. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n3. Menyelesaikan rangkaian simulasi Adaptive Cruise Control pada Proteus dan mengambil data pengaruh perubahan jarak terhadap kecepatan, tegangan, dan arus motor DC.\n4. Mulai merangkai Prototipe pada Protoboard.\"\r\n', NULL, NULL, 2, 2, '2020-04-11 23:00:24', '2020-04-11 23:00:24');
INSERT INTO `ta_logbook` VALUES (59, 84, '\"1. Melakukan perbandingan (simulasi dan Projectboard) penggunaan dan performa driver Mosfet dan menentukan penggunaan driver mosfet yaitu TLP250 \n2. Melakukan uji coba sensor arus ACS712-20A sebagai pembacaan arus\n3. Memprogram sederhana pembacaan arus dengan monitor Arduino pada beban motor DC 12V\"\r\n', 3, '\"1. Hasil pembacaan sensor memiliki error yang besar. Terdapat error arus yang diserap motor dengan pembacaan sensor lebih dari 1\n2. Switching belum soft dimana program masih menggunakan program High dan Low saja pada driver\n3. Perubahan tegangan yang di alami motor belum di cek dan perlu menambahkan potensio dalam mengatur kecepatan motor\"\r\n', '\"1. Mencoba sensor arus ACS712-5A\n2. Memperbaiki program supaya hasilnya soft switching (dengan PWM)\n3. Mengecek lebih detail input dan ouput tegangan dan arus pada rangkaian\"\r\n', NULL, NULL, 2, 2, '2020-04-12 13:55:55', '2020-04-12 13:55:55');
INSERT INTO `ta_logbook` VALUES (60, 102, '\"Mencoba program dasar pengaktifan motor bldc dengan mikrokontroler arduino.\n(Berhasil untuk software arduino ide, masih mencoba menggunakan rapid prototyping di matlab simulink)\nMenyelesaikan plant pengendalian motor BLDC.\"\r\n', 3, 'Masih mencoba mengeksplore/ mempelajari komunikasi arduino dengan simulink.\r\n', 'Menemukan dan memahami referensi model pengendalian yang sesuai.\r\n', NULL, NULL, 2, 2, '2020-04-12 20:21:16', '2020-04-12 20:21:16');
INSERT INTO `ta_logbook` VALUES (61, 104, 'Mengerjakan dokumen manual book untuk penggunaan website dari sisi mahasiswa, dosen, koordinator ta, koordinator kp, operator ta, admin, koordinator kbk. Memperbaiki bug dalam website serta update login page dengan logo uns dan background khas uns.\r\n', 3, 'Belum ada\r\n', 'Membuat Flowchart dan Update Buku Panduan Kerja Praktek dan Tugas Akhir.\r\n', NULL, NULL, 2, 2, '2020-04-12 20:57:11', '2020-04-12 20:57:11');
INSERT INTO `ta_logbook` VALUES (62, 100, '\"1. Pembuatan Program untuk pembacaan tegangan antar cel menggunkan editor Arduino dan pengecekan komunikasi I2C dapat bekerja dengan baik\n2. Pembuatan Program untuk Bypass cel dan pengujian program apakah dapat bekerja dengan baik. \n3. melakukan pengecekan program apakah ada bug atau tidak.\"\r\n', 4, 'Kendala pada pengecekan bypas cel masih terjadi panas pada mosfet\r\n', 'Pengecekan Hardware dan perbaikan rangkaian yang terkendala\r\n', NULL, NULL, 2, 2, '2020-04-13 05:47:09', '2020-04-13 05:47:09');
INSERT INTO `ta_logbook` VALUES (63, 100, 'Merapikan dan penambahan BAB 3 yaitu menambahkan perancangan tiap sistem pada hardware yang berupa sistem bypass, sistem pembacaan tegangan, dan sistem pembacaan arus. dan penjabaran perancangan software dengan membagi menjadi beberapa algoritma yaitu algoritma pembacaan sensor dan monitoring, algoritma kontrol bypass dan algoritma proteksi.\r\n', 3, 'tidak ada\r\n', 'pengujian software\r\n', NULL, NULL, 2, 2, '2020-04-13 08:57:22', '2020-04-13 08:57:22');
INSERT INTO `ta_logbook` VALUES (64, 82, '\"Minggu, 12 April 2020\n1. Menyusun coding agar dapat melakukan perpindahan mode ketika push button/switch ditekan.\n2. Menguji Simulasi dengan coding yang menjalankan pengontrolan motor DC dan pembacaan sensor Ultrasonik secara bersamaan.\n3. Memulai wiring sensor ultrasonik pada protoboard dan mempelajari sensor hall dengan modul yang sudah dibeli.\n\nSenin, 13 April 2020\n1. Mencoba menjalankan simulasi switch case pada proteus dengan rangkaian sensor Ultrasonik dan pengontrolan motor DC yang sudah dirangkai.\n2. Menjalankan pengontrolan motor DC dengan PWM dan pembacaan sensor ultrasonik yang ditampilkan pada LCD 16x2, pengukuran sensor ultrasonik akan maksimal jika pin trigger diletakkan pada pin PWM yang terdapat pada Arduino UNO, karena sebelumnya telah dicoba dan hasilnya kurang maksimal ketika pin trigger diletakkan pada pin 13 Arduino yang mana bukan merupakan pin PWM.\n3. Menemukan referensi salah satu thesis mahasiswa UMS, bahwa sensor Ultrasonik HC-SR04 dapat melakukan pengukuran 496 cm, ketika dicoba untuk mengukur hambatan sejauh 500 cm, dan menemukan referensi pula data apa yang akan diambil pada simulasi, uji prototipe, dan uji sistem ketika ditempatkan pada sepeda motor.\"\r\n', 3, '\"Minggu, 12 April 2020\n1. Aplikasi Proteus yang terkadang auto close ketika menjalankan simulasi maupun setelahnya. (memerlukan laptop dengan spek yang lebih tinggi, jika diijinkan saya akan meminjam laptop ROG Prodi untuk mengambil data simulasi pada Proteus.\n2. Masih kesulitan mendapatkan logika switch case untuk perpindahan dari mode normal ke mode ACC.\n\n\nSenin, 13 April 2020\n1. Aplikasi Proteus yang terkadang auto close ketika menjalankan simulasi maupun setelahnya. (memerlukan laptop dengan spek yang lebih tinggi, jika diijinkan saya akan meminjam laptop ROG Prodi untuk mengambil data simulasi pada Proteus.\n2. Kesulitan untuk logika speed limiting dengan jarak pembacaan tertentu.\"\r\n', '\"1. Mencoba mengontrol motor DC dengan menggunakan sensor ultrasonik pada simulasi protoboard dan mengganti potensio dengan throttle.\n2. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n3. Menyempurnalan rangkaian simulasi Adaptive Cruise Control pada Proteus dan mengambil data pengaruh perubahan jarak terhadap kecepatan, tegangan, dan arus motor DC.\n4. Menambah push button pada protoboard agar dapat melakukan simulasi berpindah mode dari mode berkendara biasa ke mode Adaptive Cruise Control.\n5. Memastikan output pada sensor hall yang terdapat pada throttle sepeda motor listrik apakah sinyal digital atau analog.\"\r\n', NULL, NULL, 2, 2, '2020-04-13 22:04:13', '2020-04-13 22:04:13');
INSERT INTO `ta_logbook` VALUES (65, 91, '\"-Mencari data uji coba mobil listrik sebagai daily load\n-Melakukan uji coba pemodelan pembangkit hibrid dengan HOMER pada 5 lokasi di pulau jawa\n-Membaca literatur untuk spesifikasi mobil listrik yang akan dipakai sebagai contoh\"\r\n', 3, 'Belum ada model yang pas untuk pengkodingan pada matlab\r\n', 'Mencari literatur atau model yang pas untuk pengkodingan dengan PSO pada matlab\r\n', NULL, NULL, 2, 2, '2020-04-15 13:47:18', '2020-04-15 13:47:18');
INSERT INTO `ta_logbook` VALUES (66, 97, 'Menghubungkan rangkaian end node dengan beban. Dalam hal ini menggunakan terminal blok 4 pin yang didalamnya dihubungkan dengan kedua sensor. KemudianmMelakukan coding supaya pembacaan sensor mendapatkan nilai yag sesuai.\r\n', 3, 'Masih terdapat kesalahan dalam pengiriman data ke iot server, dimana di serial monitor arduino sudah menunjukkan nilai yang sesuai pembacaan sensor tetapi di tampilan dashboard iot server masih menunjukkan nilai 0,0.\r\n', 'Memperbaiki coding arduino di sisi pengiriman data ke iot server.\r\n', NULL, NULL, 2, 2, '2020-04-15 15:08:16', '2020-04-15 15:08:16');
INSERT INTO `ta_logbook` VALUES (67, 85, 'Membuat program pada motor stepper yang digunakan untuk tracking sinar matahari pada solar tracker melalui arduino dan merancang desain untuk tiang penyangga pada solar tracker agar dapat menopang panel surya\r\n', 4, 'Program untuk motor stepper belum pas\r\n', 'Selesai merancang tiang penyangga dan memperbaiki program pada motor stepper\r\n', NULL, NULL, 2, 2, '2020-04-15 15:36:49', '2020-04-15 15:36:49');
INSERT INTO `ta_logbook` VALUES (68, 79, 'Merangkai buckboost converter yang telah disimulasikan di projectboard masih terkendala pada pwm arduino yang belum bisa menggontrol driver tlp250 sehingga buckboost converter belum menghasilkan output.\r\n', 3, 'output PWM arduino belum dapat mengontrol driver\r\n', '\"1. Memperbaiki coding\n2. Mecoba kembali buckboost converter di projectboard\n3. Menambahkan inputan sensor tegangan, arus, dan temperature\"\r\n', NULL, NULL, 2, 2, '2020-04-15 16:57:35', '2020-04-15 16:57:35');
INSERT INTO `ta_logbook` VALUES (69, 82, '\"Selasa, 14 April 2020\n1. Sudah memastikan keluaran sinyal dari throttle sepeda motor listrik, adalah sinyal analog, sehingga memungkinkan menggunakan Arduino UNO pada pin PWM dengan menggunakan fungsi \"\"analogWrite ()\"\".\n2. Mengkoding auto generate PWM untuk mengontrol motor DC dan dapat melakukan pada simulasi pada protoboard.\n\nRabu, 15 April 2020\n1. Dapat melakukan pengontrolan motor DC dengan menggunakan sensor ultrasonik pada simulasi di protoboard.\n2. Melakukan konsultasi online di grup bimbingan via Whatshapp.\n3. Membeli Throttle sebagai pengganti potensiometer pada simulasi protoboard/uji prototipe nantinya.\n\"\r\n', 3, '\"Selasa, 14 April 2020\n1. Masih bingung tentang fungsi apa saja yang digunakan agar keluaran sinyal PWM dapat keluar dengan mulus tidak patah-patah, sehingga putaran motor halus.\n\nRabu, 15 April 2020\n1. Masih mengalami kendala ketika sistem pembacaan jarak disatukan dengan kontrol motor. Sensor ultrasonik menjadi kurang peka dalam pembacaan dan logika untuk speed limiting berdasarkan semakin mendekatnya jarak objek yang ada di depannya.\"\r\n', '\"1. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n2. Menyempurnakan rangkaian simulasi Adaptive Cruise Control pada Proteus dan mengambil data pengaruh perubahan jarak terhadap kecepatan, tegangan, dan arus motor DC.\n3. Menambah push button pada protoboard agar dapat melakukan simulasi berpindah mode dari mode berkendara biasa ke mode Adaptive Cruise Control.\n4. Penyempurnaan rangkaian di protoboard.\"\r\n', NULL, NULL, 2, 2, '2020-04-15 23:06:21', '2020-04-15 23:06:21');
INSERT INTO `ta_logbook` VALUES (70, 104, 'Konsultasi terkait alur kerja dari sistem kerja praktek, demo sistem kerja praktek, masukan tentang sistem jika kerja praktek ditolak mahasiswa mengulang pendaftaran dari awal, merevisi manual book dari sistem portal elektro yang berkaitan dengan kerja praktek.\r\n', 3, 'belum ada\r\n', 'Merevisi sistem sesuai dengan hasil konsultasi\r\n', NULL, NULL, 2, 2, '2020-04-16 22:03:15', '2020-04-16 22:03:15');
INSERT INTO `ta_logbook` VALUES (71, 100, 'Membuat program pembacaan sensor, bypass, proteksi & upload data ke blynk. Untuk hardware sudah dirangkai & bisa untuk mengambil data. Penyusunan aplikasi blynk sudah selesai. Sementara sudah bisa ngambil data tegangan per cel.\r\n', 4, 'Tidak adanya alat untuk mengambil data seperti multimeter yg presisi, powersupply variable dan load test.\r\n', 'Menyelesaikan program proteksi dan pengujian bypass.\r\n', NULL, NULL, 2, 2, '2020-04-17 06:14:47', '2020-04-17 06:14:47');
INSERT INTO `ta_logbook` VALUES (72, 104, 'Revisi sistem terkait kerja praktek yaitu membuat fungsi cetak lembar penugasan dan cetak form nilai setelah upload berkas balasan kerja praktek. Membuat fungsi upload nilai kp pada hak akses mahasiswa dan menambahkan fungsi lihat nilai kp pada hak akses koordinator kp. Serta revisi apabila kp ditolak mengulang dari awal dan terdapat riwayat kerja praktek.\r\n', 3, 'Belum ada\r\n', 'Membuat fitur lupa password dengan langsung reset ke nim/nip, dan login pertama kali harus mengubah password.\r\n', NULL, NULL, 2, 2, '2020-04-17 19:35:44', '2020-04-17 19:35:44');
INSERT INTO `ta_logbook` VALUES (73, 100, '\"- percobaan proteksi baterai dengan dikasih beban bor PCB untuk mengetahui sistem proteksi dapat berjalan\n- pengambilan data sensor pada saat tanpa beban\n- pengambilan data sensor pada saat diberi beban motor bor PCB.\"\r\n', 4, 'Sensor Arus memiliki eror sampai 100mA.\r\n', 'mencari solusi memperkecil eror sensor arus. dan memperbaiki bab bab sebelumnya.\r\n', NULL, NULL, 2, 2, '2020-04-18 14:48:38', '2020-04-18 14:48:38');
INSERT INTO `ta_logbook` VALUES (74, 82, '\"Kamis, 16 April 2020\n1. Menyempurnakan wiring rangkaian pada simulasi Proteus.\n2. Melengkapi gambar pada sub bab 3.6, tentang rangkaian prototipe pada protoboard.\n3. Mengganti potensiometer dengan throttle hall sensor dan dapat berfungsi mengendalikan motor DC.\n\nJumat, 17 April 2020\n1. Mempelajari koding pernyataan kondisi if else yang digunakan untuk berpindah mode dari berkendara biasa ke mode Adaptive Cruise Control.\n\nSabtu, 18 April 2020\n1. Menggabungkan koding if else ke koding kontrol motor DC dengan Throttle dan Pembacaan jarak dengan sensor ultrasonik. Lalu penambahan button untuk memindah mode dari berkendara biasa ke Adaptive Cruise Control. \n2. Sudah diuji coba dengan rangkaian yang dibuat pada hari Kamis, 16 April 2020, ketika koding sudah di upload pada Arduino UNO ketika push button belum ditekan mode berkendara biasa dapat dilakukan dan pembacaan sensor ultrasonik tidak dilakukan, lalu ketika tombol sudah ditekan, arduino akan mempertahankan keluaran PWM dari bukaan throtlle sebelum push button ditekan dan melakukan pembacaan jarak. Fungsi Cruise Control sudah berjalan tetapi untuk adaptive belum karena terkedala pembacaan sensor.\n3. Konsultasi di Grup Whatshapp bimbingan mengenai sensor yang masih terkendala karena pembacaan belum stabil dan sudah diberi masukan oleh pembimbing dan teman.\"\r\n', 3, '\"Kamis, 16 April 2020\nTidak Ada\n\nJumat, 17 April 2020\nTidak Ada\n\nSabtu, 18 April 2020\n1. Memerlukan driver motor DC dan encoder agar dapat berputar dengan lebih halus/selaras dengan bukaan throttle.\"\r\n', '\"1. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n2. Menyempurnakan koding untuk mode Adaptive Cruise Control dan memeriksa ulang algoritma atau konstanta yang digunakan pada koding agar Ultrasonik dapat membaca dengan baik.\n3. Mengambil data simulasi (pengaruh perubahan jarak terhadap kecepatan, tegangan, dan arus motor DC) rangkaian Adaptive Cruise Control pada Proteus.\n4. Memeriksa wiring pada protoboard dan pemasangan pin pada Arduino agar sistem dapat berjalan dengan baik.\n5. Menambah driver dan encoder pada rangkaian kontrol motor DC.\"\r\n', NULL, NULL, 2, 2, '2020-04-18 21:25:24', '2020-04-18 21:25:24');
INSERT INTO `ta_logbook` VALUES (75, 102, '\"1. Pengecekan kinerja sensor dan menyelesaikan program arduino. Pemrograman arduino masih belum sesuai keinginan.\n2. Mencari dan mengimplementasikan program/ model pembacaan sensor gyroscope di simulink.\"\r\n', 3, '\"1. Sensor kurang optimal jika dijumper ke project board (lebih prefer di jumper langsung antarmodul)\n2. Beberapa referensi pembacaan sensor menggunakan seri software yang berbeda, sehingga harus belajar menyesuaikan dengan seri software yang ada.\"\r\n', 'Memahami proses pembacaan sensor dan pengembangan modelnya.\r\n', NULL, NULL, 2, 2, '2020-04-19 21:19:06', '2020-04-19 21:19:06');
INSERT INTO `ta_logbook` VALUES (76, 104, 'Menambahkan fitur lupa password dengan button reset password yang mana akan mengembalikan ke password awal yang berupa nim untuk mahasiswa dan nip untuk dosen, serta menambahkan fungsi untuk login pertama kali pengguna diharuskan mengubah password.\r\n', 3, 'Belum ada\r\n', 'Mengupdate manual book portal elektro\r\n', NULL, NULL, 2, 2, '2020-04-19 21:35:10', '2020-04-19 21:35:10');
INSERT INTO `ta_logbook` VALUES (77, 104, 'Membuat flowchart kerja praktek dan tugas akhir, update buku panduan kerja praktek sesuai dengan revisi sistem yang terbaru. Update tampilan sistem portal elektro agar lebih user friendly atau lebih memudahkan.\r\n', 3, 'Belum ada.\r\n', 'Konsultasi sistem portal elektro.\r\n', NULL, NULL, 2, 2, '2020-04-20 22:10:32', '2020-04-20 22:10:32');
INSERT INTO `ta_logbook` VALUES (78, 82, '\"Minggu, 19 April 2020\n1. Menemukan trouble pada koding yaitu berupa penggunaan konstanta, variabel dan delay dari kondisi pengukuran sensor ultrasonik sehingga pembacaan belum sempurna.\n2. Menemukan kesalahan penulisan logika pada mode Adaptive Cruise Control yaitu memerlukan program sisipan agar ketika mode Adaptive Cruise Control dijalankan kecepatan yang sudah di atur sebelumnya dapat berjalan lagi ketika program sisipan tidak memenuhi kondisi.\n\nSenin, 20 April 2020\n1. Mempelajari tentang logika program sisipan yaitu interrupt pada Arduino UNO sehingga mode Adaptive Cruise Control dimungkinkan berjalan baik.\n2. Jika menggunakan logika interrupt diperlukan penggantian wiring pada Sensor Ultrasonik.\"\r\n', 3, '\"Minggu, 19 April 2020\nTidak ada\n\nSenin, 20 April 2020\nTidak ada\"\r\n', '\"1. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n2. Menyempurnakan koding untuk mode Adaptive Cruise Control dan memeriksa ulang algoritma atau konstanta yang digunakan pada koding agar Ultrasonik dapat membaca dengan baik.\n3. Mengambil data simulasi (pengaruh perubahan jarak terhadap kecepatan, tegangan, dan arus motor DC) rangkaian Adaptive Cruise Control pada Proteus.\n4. Menambah driver dan encoder pada rangkaian kontrol motor DC.\"\r\n', NULL, NULL, 2, 2, '2020-04-20 23:16:17', '2020-04-20 23:16:17');
INSERT INTO `ta_logbook` VALUES (79, 97, 'Melakukan konsultasi dengan pembimbing mengenai draft jurnal yang akan disubmit ke ICIMECE 2020. konsultasi dilakukan secara daring. Konsultasi melalui media chatting whatsapp. Komsultasi sampai pada bab metodologi. Pembimbing memberikan respon yang positif kepada draft yang saya ajukan.\r\n', 4, 'tidak ada\r\n', '\"melanjutkan penulisan bab kesimpulan pada draft jurnal\n\"\r\n', NULL, NULL, 2, 2, '2020-04-21 16:10:20', '2020-04-21 16:10:20');
INSERT INTO `ta_logbook` VALUES (80, 91, '\"-Menambahkan beberapa data awal beban pada pembangkit untuk menentukan kapasitas pembangkit\n-Melakukan desain ulang pembangkit karena terdapat beberapa perubahan pada data awal beban pembangkit sehingga mendapatkan nilai kapasitas baru\"\r\n', 3, 'Belum ada model yang pas untuk pengkodingan pada matlab\r\n', 'Penarikan hasil dari desain pembangkit dan mencari model pengkodingan matlab yang pas\r\n', NULL, NULL, 2, 2, '2020-04-21 17:52:44', '2020-04-21 17:52:44');
INSERT INTO `ta_logbook` VALUES (81, 97, 'Melanjutkan penulisan jurnal. Mulai melanjutkan menulis bab pembahasan. Pada bab pembahasan ini saya menuliskan hasil yang saya dapat dari penelitian yang saya lakukan. Penjabaran hasil saya lakukan dengan membubuhkan gambar screenshot hasil yang saya dapatkan\r\n', 4, 'tidak ada\r\n', 'melanjutkan penulisan bab konklusi\r\n', NULL, NULL, 2, 2, '2020-04-22 16:02:42', '2020-04-22 16:02:42');
INSERT INTO `ta_logbook` VALUES (82, 93, '\"progres pengerjaan tugas akhir minggu kemarin:\n1. membuat code matlab tentang unit commitment dan sudah bisa jalan dengan menggunakan priority list dan economic dispatch\n2. membaca literatur tentang unit commitment dengan ETAP (sebagai cadangan)\"\r\n', 3, '\"kendala yang ada:\n1. code matlab yang dibuat masih menggunakan priority list dan 50 % masih mengambil dari sumber\n2. kesulitan melakukan programing dan mengubah metode kedalam metode genetika\n3. data yang digunakan masih menggunakan IEEE 6 bus\"\r\n', '\"rencana yang akan dilakukan:\n1. mengganti metode PL pada kode kedalam GA\n2. mengghitung secara detail per bus\"\r\n', NULL, 'oke diterima', 2, 1, '2020-04-22 18:38:31', '2020-05-28 19:08:23');
INSERT INTO `ta_logbook` VALUES (83, 100, '\"1.Penulisan data pembacaan sensor dalam keadaan tanpa beban. \n2.kalibrasi sensor arus karena nilai erornya masih tinggi yaitu 100mA lebih sedangkan beban yang digunakan beban kecil.\n3. Perbaikan algoritma data pembacaan sensor.\"\r\n', 4, 'Sensor arus masih memiliki eror pembacaan yang tinggi.\r\n', 'Mengganti sensor arus acs712 dengan sensor arus ina219\r\n', NULL, NULL, 2, 2, '2020-04-22 19:19:53', '2020-04-22 19:19:53');
INSERT INTO `ta_logbook` VALUES (84, 82, '\"Selasa, 21 April 2020\n1. Mempelajari koding interrupt dan mencobanya pada protoboard.\n\nRabu, 22 April 2020\n1. Menyusun coding untuk dapat berpindah mode pada simulasi Adaptive Cruise Control di Proteus 8.9 dan mencoba untuk dilakukan simulasi, dapat switch mode, tetapi yang menjadi kendala adalah simulasi berjalan tidak real time.\n2. Mencari referensi algoritma auto braking menggunakan sensor ultrasonik.\n3. Membenarkan wiring rangkain pada simulasi di Proteus 8.9.\"\r\n', 3, '\"Selasa, 21 April 2020\nTidak ada\n\nRabu, 22 April 2020\n1. Memerlukan laptop dengan spesifikasi lebih tinggi untuk simulasi Proteus 8.9.\"\r\n', '\"1. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n2. Menyempurnakan koding untuk mode Adaptive Cruise Control dan memeriksa ulang algoritma atau konstanta yang digunakan pada koding agar Ultrasonik dapat membaca dengan baik.\n3. Mengambil data simulasi (pengaruh perubahan jarak terhadap kecepatan, tegangan, dan arus motor DC) rangkaian Adaptive Cruise Control pada Proteus.\n4. Menambah driver dan encoder pada rangkaian kontrol motor DC.\"\r\n', NULL, NULL, 2, 2, '2020-04-22 22:16:13', '2020-04-22 22:16:13');
INSERT INTO `ta_logbook` VALUES (85, 84, '\"1. Masih menunggu komponen yang sedang dibeli meliputi sensor arus acs712-5A, sensor Suhu DS18b20.\n2. Mencoba variasi rangkaian driver dengan TLP, mensimulasikan rangkaian non inverting isolated High side dengan input PWM. Membaca literatur datasheet TLP (fiksasi rangkaian)\n3. Membuat ARES PCB Layout pada Proteus\n4. Melakukan etching desain PCB\n5. Mempelajari program (if then) pada arduino\"\r\n', 3, '\"1. Pada simulasi terdapat warning yang sangat banyak mengenai arus yang mengalir.\n2. Etching layout PCB belum berhasil sempurna, sering terjadi jalur yang terputus atau hilang.\"\r\n', '\"1. Mencari solusi mengurangi warning atau gangguan pada rangkaian.\n2. Mencoba kembali etching dengan beberapa teknik/metode yang lain.\n3. Memodelkan kontrol motor untuk melihat kerja rangkaian switching baterai (pada proteus)\"\r\n', NULL, NULL, 2, 2, '2020-04-23 10:12:21', '2020-04-23 10:12:21');
INSERT INTO `ta_logbook` VALUES (86, 86, '\"1. Mengerjakan kontrol stepper motor, stepper motor dapat dikontrol dengan mudah dengan lbrary pigpio, kontrol stepper motor dilakukan dengan pemberian sinyal PWM yang diatur berdasarkan frekuensinya.\n2. Pembuatan chasing balancing robot, balancing robot chasing menggunakan papan kayu balsa\n3. Pembuatan shield PCB stepper driver untuk dipasang ke raspberry pi, pembuatan menggunakan PCB lubang 2 layer\n4. wiring dan soldering komponen\n\"\r\n', 3, '\"1. Kurangnya peralatan yang memadai serta terbatasnya komponen karena kondisi pandemik saat ini, membuat saya harus mencari pinjaman beberapa alat dan bahan\n2. robot menggunakan baterai 12v, saat ini baterai telah ada, namun tidak memiliki charger\"\r\n', '\"1. Pembelian charger baterai lipo 12V\n2. Perangkaian robot balancing\n\"\r\n', NULL, NULL, 2, 2, '2020-04-23 16:17:36', '2020-04-23 16:17:36');
INSERT INTO `ta_logbook` VALUES (87, 97, 'Melakukan pengiriman end node ke MQTT Broker (Cloud server) yang berbeda. Jadi dikarenakan kesulitan untuk mengirimkan data end node ke server adafruit, maka saya mencoba mengirim ke server lain yaitu Thingspeak. Hasilnya data berhasil dikirimkan ke Thingspeak.\r\n', 3, 'Nilai tegangan yang masih memiliki error besar.\r\n', 'Memperbaiki error dan mencari referensi terkait TalkBack / Upstream / Uplink pada server Thingspeak.\r\n', NULL, NULL, 2, 2, '2020-04-23 20:18:28', '2020-04-23 20:18:28');
INSERT INTO `ta_logbook` VALUES (88, 104, 'Revisi sistem terkait kerja praktek yaitu menambahkan fungsi baru pada koordinator kerja praktek report mahasiswa kerja praktek, memperbaiki pemberian nilai kerja praktek dengan pembagian 60% perusahaan dan 40% pembimbing, serta memperbaiki pengajuan kerja praktek untuk fungsi belum setuju.\r\n', 3, 'belum ada\r\n', 'Menambahkan fungsi claim keikutsertaan seminar kerja praktek\r\n', NULL, NULL, 2, 2, '2020-04-23 22:42:05', '2020-04-23 22:42:05');
INSERT INTO `ta_logbook` VALUES (89, 85, 'Melakukan pengerjaan programming pada motor stepper telah selesai dan dapat dicoba dengan baik. Kemudia untuk pengerjaan penyangga pada silar tracker masi dalam tahap pengerjaan yang belum selesai dan akan tetap terus dilanjutkan. Untuk target minggu depan pengerjaan tiang penyangga pada solar tracker sudah selesai dan mensinkronkan dengan motor stepper yang ada.\r\n', 4, 'Belum ada\r\n', 'Menyelesaikan tiang penyangga dan menggabungkan dengan motor\r\n', NULL, NULL, 2, 2, '2020-04-23 22:56:09', '2020-04-23 22:56:09');
INSERT INTO `ta_logbook` VALUES (90, 82, '\"Kamis, 23 April 2020\n1. Mencoba deselari motor DC menggunakan sensor Ultrasonik dan menemukan koding algoritmanya.\n2. Mencoba menggunakan modul driver motor L298N, tidak efektif karena akan menyedot power cukup banyak.\n\nJumat, 24 April 2020\n1. Melakukan checking algoritma koding dan penggunaan delay pada koding dan menemukan penempatan delay sensor Ultrasonik yang benar agar pembacaan berjalan baik.\n2. Mencoba menggunakan sensor Ultrasonik mengukur jarak dapat medeteksi 429 cm atau 4,29 m naik dari deteksi pembacaan sebelumnya.\n3. Ketika program dijalankan dapat switch ke mode Adaptive Cruise Control. Tetapi mendapat kendala karena turunnya kecepatan didasarkan pada perubahan jarak, maka perlu jarak yang sangat dekat sekali dengan sensor sekitar ±20cm agar motor dapat berhenti. Lalu ketika motor sudah berhenti karena kendala pembacaan ketika jarak sudah mulai menjauh didapati kecepatan motor lama untuk kembali ke kecepatan saat mode Adaptive Cruise Control diaktifkan.\"\r\n', 3, '\"Kamis, 23 April 2020\nTidak ada\n\nJumat, 24 April 2020\n1. Penyusunan koding, masih bingung apakah perlu menggunakan interrupt atau tidaknya. Jika perlu perintah mana yang perlu di masukkan kedalam interrupt.\"\r\n', '\"1. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n2. Menyempurnakan koding untuk mode Adaptive Cruise Control dan memeriksa ulang algoritma atau konstanta yang digunakan pada koding agar Ultrasonik dapat membaca dengan baik.\n3. Mengambil data simulasi (pengaruh perubahan jarak terhadap kecepatan, tegangan, dan arus motor DC) rangkaian Adaptive Cruise Control pada Proteus.\"\r\n', NULL, NULL, 2, 2, '2020-04-24 20:29:49', '2020-04-24 20:29:49');
INSERT INTO `ta_logbook` VALUES (91, 96, '\"1. menyelesaikan rangkaian driver 1 fasa, rangkaian dapat selesai dan berjalan dengan baik\n2. menyempurnakan simulasi drive motor 3 fasa, simulasi dapat berjalan\n3. mengumpulkan komponen untuk pembuatan hardware driver motor BLDC\"\r\n', 3, '\"\nbeberapa komponen masih belum dapat diperoleh\"\r\n', '\"1. membuat layout PCB dengan proteus Ares dari simulasi yang telah dibuat\n2. melengkapi komponen yang diperlukan\"\r\n', NULL, NULL, 2, 2, '2020-04-24 22:19:34', '2020-04-24 22:19:34');
INSERT INTO `ta_logbook` VALUES (92, 97, 'Melakukan update firmware pada Dragino Lora Gateway LG01-N. Hal ini ilakukan karena akan dilakukan pengujian pada sisi control beban yang digunakan dan juga karena firmware yang saat ini terinstall belum mendukung fitur Talkback.\r\n', 3, 'Tidak ada\r\n', 'Menyelesaikan sisi kontrol beban.\r\n', NULL, NULL, 2, 2, '2020-04-26 21:19:29', '2020-04-26 21:19:29');
INSERT INTO `ta_logbook` VALUES (93, 104, 'Menambahkan fungsi klaim keikutsertaan seminar kerja praktek dalam pendaftaran seminar kerja praktek, fungsi edit klaim, fungsi untuk check klaim disetujui atau ditolak, dan fungsi apabila klaim ditolak harus mengajukan kembali dengan mengedit data serta form keikutsertaan.\r\n', 3, 'Tidak ada\r\n', 'Memperbarui flow chart kp, dan konsul tugas akhir.\r\n', NULL, NULL, 2, 2, '2020-04-26 23:35:19', '2020-04-26 23:35:19');
INSERT INTO `ta_logbook` VALUES (94, 100, '\"* Pengujian dan pengambilan data Akurasi Pembacaan sensor tegangan tiap cel baterai dengan menggunakan multimeter gwinstek. hasil pembacaan memiliki selisih eror dengan multimeter sebesar 0.002 sampai 0.004 Volt. \n* membuat data logger dengan PLX-DAQ untuk merekam data melalui serail komunikasi.\"\r\n', 4, 'PLX_DAQ belum bisa bekerja pada Excel 64-bit.\r\n', 'menyelesaikan bug pada PLX-DAQ dan pengambilan data pengujian proteksi.\r\n', NULL, NULL, 2, 2, '2020-04-27 12:54:43', '2020-04-27 12:54:43');
INSERT INTO `ta_logbook` VALUES (95, 82, '\"Sabtu, 25 April 2020\n1. Konsultasi online di grup WA Bimbingan terkait progress Tugas Akhir yang sudah dibuat.\n2. Mempelajari membuat speed sensor apakah menggunakan hall sensor atau sensor IR.\n\nMinggu, 26 April 2020\n1. Mencoba merangkai sensor IR untuk mengukur kecepatan motor yang diberi beban roda.\n2. Berhasil melakukan pengukuran kecepatan motor DC, ketika melakukan simulasi prototipe pada protoboard, tetapi mengalami kendala.\n\nSenin, 27 April 2020\n1. Diskusi dengan teman (Salman) untuk memperbaiki koding yang menjadikan simulasi kurang halus yaitu mapping sensor ultrasonik dan juga mapping inputan throttle, lalu memperbaiki rangkaian transistor darlington NPN yang ternyata salah wiring.\"\r\n', 3, '\"Sabtu, 25 April 2020\nTidak ada\n\nMinggu, 26 April 2020\n1. Kendala yang dialami motor DC yang digunakan kualitasnya tidak baik sehingga ketika jarak mendekat, motor sudah berkurang kecepatanya, setelah jarak menjauh terdapat delay yang sangat lama untuk motor berjalan ke posisi sebelumnya.\n\nSenin, 27 April 2020\n1. Perlunya menambah data logger dan memperbaiki sensor yang akan digunakan untuk mengambil data.\"\r\n', '\"1. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n2. Menyempurnakan koding untuk mode Adaptive Cruise Control dan memeriksa ulang algoritma atau konstanta yang digunakan pada koding agar Ultrasonik dapat membaca dengan baik.\n3. Memperbaiki algoritma sesnsor agar dapat mengatur kecepatan berdasarkan jarak tertentu.\n4. Membuat sistem pengambilan data maupun membeli hardware yang dibutuhkan agar pengambilan data dapat dilakukan dengan baik.\n5. Mengambil data simulasi (pengaruh perubahan jarak terhadap kecepatan, tegangan, dan arus motor DC) rangkaian Adaptive Cruise Control pada Proteus.\"\r\n', NULL, NULL, 2, 2, '2020-04-27 22:37:15', '2020-04-27 22:37:15');
INSERT INTO `ta_logbook` VALUES (96, 91, '\"Progress TA:\n-Mengubah program matlab yang digunakan dari sebelumnya menggunakan metode Particle Swarm Optimization menjadi Genetic Algorithm dengan saran dari pembimbing\n-Mengumpulkan data - data teknis yang diperlukan untuk coding matlab\"\r\n', 3, 'Masih ada beberapa fungsi error pada pengcodingan matlab\r\n', 'Melanjutkan pengcodingan hingga mendapatkan hasil yang diinginkan\r\n', NULL, NULL, 2, 2, '2020-04-28 11:15:16', '2020-04-28 11:15:16');
INSERT INTO `ta_logbook` VALUES (97, 86, '\"1. Mengerjakan balancing robot, berupa penggabungan chasis balancing robot, pemasangan roda dengan motor stepper, penggabungan raspberry pi dengan aktuator dan sensor.\n2. setting PID control secara manual\n3. mencari literatur mengenai tuning PID dengan beberapa metode.\"\r\n', 3, '\"Uji coba menunjukan bahwa balancing robot masih mengalami banyak osilasi, toleransi sudut ketika robot akan jatuh terlalu sempit. identifikasi telah dilakukan dan mendapatkan beberapa analisa :\n1. Setting konstanta PID yang belum tepat\n2. algoritma program yang kurang sesuai\n3. roda ban yang terlalu kecil sedangkan body robot yang besar menyebabkan stepper kurang mampu mencapai keseimbangan, padahal stepper motor memiliki batas kecepatan.\"\r\n', '\"1. konsultasi dengan dosen pembimbing\n2. Mencari literatur mengenai balancing robot dan tunning PID\n3. Memperbesar diameter roda ban\"\r\n', NULL, NULL, 2, 2, '2020-04-29 09:00:53', '2020-04-29 09:00:53');
INSERT INTO `ta_logbook` VALUES (98, 100, '\"1. mengambil data pengujian proteksi overdischarg dimana pada pengujian menggunakan beban resistor 22 ohm 10W.\n2. mengambil data pengujian proteksi overcharg\n3. mengambil data pengujian bypass cel1,cel2,cel3,cel4.\n4. pengujian pwm charger cutoff charger.\"\r\n', 4, 'output optocoupler PWM tidak terbentuk sinyal PWM.\r\n', 'mengganti opto dengan frekuensi yg lbih baik.\r\n', NULL, NULL, 2, 2, '2020-04-29 16:56:44', '2020-04-29 16:56:44');
INSERT INTO `ta_logbook` VALUES (99, 82, '\"Selasa, 28 April 2020\n1. Mencoba membagi jarak untuk limitasi keluaran PWM agar kecepatan motor DC memiliki batasan tertentu pada setiap jarak.\n2. Mengerjakan Power Supply 9V, 6V, dan 5V untuk sumber listrik yang digunakan untuk pengujian prototipe pada protoboard.\n\nRabu, 29 April 2020\n1.Mengambil data awal dari pengujian prototipe awal menggunakan Putty yaitu korelasi data antara inputan dari throttle dan keluaran PWM, serta data ketika mode ACC diaktifkan yang berkaitan perubahan kecepatan motor yang dinilai dari perubahan keluaran PWM terhadap jarak.\n2. Penyempurnaan power supply yang digunakan untuk pengujian prototipe.\"\r\n', 4, '\"Selasa, 28 April 2020\n1. Partisi jarak yang masih membuat pembacaan sensor ultrasonik kurang baik.\n\nRabu, 29 April 2020\n1. File yang diambil dengan putty sulit untuk di eksport ke Excel agar data dapat dipisahkan pada baris yang berbeda.\"\r\n', '\"1. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n2. Menyempurnakan koding untuk mode Adaptive Cruise Control dan memeriksa ulang algoritma atau konstanta yang digunakan pada koding agar Ultrasonik dapat membaca dengan baik.\n3. Memperbaiki algoritma sensor agar dapat mengatur kecepatan berdasarkan jarak tertentu.\n4. Membuat sistem pengambilan data maupun membeli hardware yang dibutuhkan agar pengambilan data dapat dilakukan dengan baik.\n5. Mengambil data simulasi (pengaruh perubahan jarak terhadap kecepatan, tegangan, dan arus motor DC) rangkaian Adaptive Cruise Control pada Proteus.\"\r\n', NULL, NULL, 2, 2, '2020-04-29 21:55:11', '2020-04-29 21:55:11');
INSERT INTO `ta_logbook` VALUES (100, 85, 'Progres yang telah dilakukan untuk pekan ini adalah Pembuatan peralatan untuk cooling water pada solar panel yang terbuat dari pipa pipa yang dihubungkan dengan pompa yang nantinya berguna untuk mendinginkan panel surya\r\n', 4, 'Tiang penyangga panel belum selesai dikerjakan\r\n', 'Menyelesaikan pembuatan alat cooling water\r\n', NULL, NULL, 2, 2, '2020-05-01 12:54:29', '2020-05-01 12:54:29');
INSERT INTO `ta_logbook` VALUES (101, 82, '\"Kamis, 30 April 2020\n1. Mengerjakan hardware prototipe dengan menyolder rangkaian prototipe yang sudah diuji pada protoboard di PCB dan menambahkan rangkaian LED untuk indikator jarak.\n2. Menguji prototipe yang sudah di solder apakah bisa berfungsi atau tidaknya.\n\nJumat, 1 Mei 2020\n1. Menyempurnakan rangkaian prototipe pada PCB dengan menambahkan L7805 IC regulator voltage +5V agar rangkaian lebih simple.\n2. Mengambil data uji prototipe dengan koding baru.\n\nSabtu, 2 Mei 2020\n1. Konsultasi online di grup WA Bimbingan terkait progress Tugas Akhir yaitu uji prototipe yang sudah di solder dan memberikan data hasil pengujian awal.\n\nMinggu, 3 Mei 2020\n1. Dokumentasi uji prototipe untuk dimasukkan sebagai hasil uji prototipe pada bab IV.\n\"\r\n', 4, '\"Kamis, 30 April 2020\n1. Pembacaan sensor yang masih random akibat peletakan sensor yang kurang tegak lurus.\n\nJumat, 1 Mei 2020\nTidak Ada\n\nSabtu, 2 Mei 2020\nTidak Ada\n\nMinggu, 3 Mei 2020\nTidak Ada\"\r\n', '\"1. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n2. Menyempurnakan koding untuk mode Adaptive Cruise Control agar dapat diaplikasikan pada real sepeda motor listrik.\n3. Membuat sistem pengambilan data maupun membeli hardware yang dibutuhkan agar pengambilan data Uji Prototipe dapat dilakukan dengan baik.\n4. Mengambil data simulasi (pengaruh perubahan jarak terhadap kecepatan, tegangan, dan arus motor DC) rangkaian Adaptive Cruise Control pada Proteus.\"\r\n', NULL, NULL, 2, 2, '2020-05-04 00:33:45', '2020-05-04 00:33:45');
INSERT INTO `ta_logbook` VALUES (102, 85, 'Mengerjakan hardware berupa alat cooling pada panel Surya dan mencoba untuk menyesuaikan dengan program yang ada pada motor stepper. Melakukan pengerjaan pada tiang penyangga pada panel Surya yang masih belum selesai dikerjakan\r\n', 4, 'Penyesuaian yang kurang pas dari tiang dan motor\r\n', 'Menyelesaikan tiang dan cooling\r\n', NULL, NULL, 2, 2, '2020-05-07 11:03:34', '2020-05-07 11:03:34');
INSERT INTO `ta_logbook` VALUES (103, 100, 'Konsultasi mengenai data pengujian pembacaan sensor, pengujian bypass tiap cel bateria, pengujian proteksi overcurrent,overvoltage dan undervoltage, pegujian akurasi pembacaan tegangan dan arus. Dan pembuatan grafik data menggunakan Origin.\r\n', 4, 'Tidak ada\r\n', 'Membuat draft semhas\r\n', NULL, NULL, 2, 2, '2020-05-07 11:13:41', '2020-05-07 11:13:41');
INSERT INTO `ta_logbook` VALUES (104, 82, '\"Senin, 4 Mei 2020\n1. Perbaikan penulisan TA Bab III\n2. Menguji prototipe dengan program jarak 3m-5m. Berhasil partisi 4m, 4-3m, 3-1.5m dan 1.5 m kebawah motor berhenti.\n3. Mengambil data sementara dan melihat grafik sinyal keluaran PWM dengan Oscilloscope\n4. Mengamati dan mengambil data tegangan motor baik mode Throttle biasa maupun mode ACC aktiv.\n\nSelasa,5 Mei 2020\n1. Merapikan pengkabelan yang digunakan untuk prototyping.\n\nRabu, 6 Mei 2020\n1. Mengolah data yang didapat pada hari Senin, 4 Mei 2020.\n2. Membuat sensor speed untuk mengambil data kecepatan motor pada prototype.\n\nKamis,7 Mei 2020\n1. Konsultasi online di grup Whatshapp bimbingan TA, diperbolehkan untuk melakukan tahap berikutnya yang merupakan penempatan sensor pada sepeda motor listrik.\n2. Membuat koding yang akan digunakan untuk software simulasi alternatif yaitu proteus 7.9 Profesional.\n\nJumat,8 Mei 2020\n1. Menyelesaikan koding yang digunakan untuk simulasi pada software.\n2. Merangkai ulang rangkaian simulasi pada software Proteus 7.9 lalu mencoba untuk disimulasikan.\"\r\n', 4, '\"Senin-Kamis \nTidak ada\n\nJumat, 8 Mei 2020\n1. Simulasi memang tetap susah untuk berjalan real-time tetapi simulasi tidak force close sehingga memungkinkan diambil data simulasi.\"\r\n', '\"1. Akses kontroler Votol EM-100 yang diperbaiki dengan PC.\n2. Menyempurnakan koding untuk mode Adaptive Cruise Control agar dapat membaca sensor dengan baik\n3. Mengambil data simulasi (pengaruh perubahan jarak terhadap kecepatan, tegangan, dan arus motor DC) rangkaian Adaptive Cruise Control pada Proteus.\n4. Merapikan dan penyempurnaan prototipe baik dari segi Hardware maupun Software lalu mengambil data dengan oscilloscope dan alat lainnya.\n5. Penempatan alat pada sepeda motor listrik dan mengambil data percobaan pada sepeda motor listrik.\"\r\n', NULL, NULL, 2, 2, '2020-05-09 23:58:33', '2020-05-09 23:58:33');
INSERT INTO `ta_logbook` VALUES (105, 103, '\"1. Membaca literatur simulasi input iradiasi dan tempeterature PV menggunakan Simulink dan plotting grafik Arus-Tegangan, Daya-Tegangan\n2. Membaca literatur heatsink cooling\n3. Membuat desain untuk Heatsink cooling\"\r\n', 3, 'Tidak ada\r\n', 'Melakukan simulasi menggunakan simulink\r\n', NULL, 'Ok. Lanjutkan', 2, 1, '2020-05-12 13:35:41', '2020-07-16 11:49:09');
INSERT INTO `ta_logbook` VALUES (106, 97, 'Melakukan kalibrasi terhadap kedua sensor yaitu sensor arus ACS712 dan sensor tegangan ZMPT101. Didapatkan error hasil penghitungan sebesar +-7.5%. Nilai ini sedikit lebih besar dari yang ditargetkan yaitu sebesar kurang dari 5%.\r\n', 4, 'Error yang cukup besar.\r\n', 'Melakukan kalibrasi ulang dengan metode lain.\r\n', NULL, NULL, 2, 2, '2020-05-12 22:04:41', '2020-05-12 22:04:41');
INSERT INTO `ta_logbook` VALUES (107, 104, 'Menambahkan fungsi perubahan judul tugas akhir, perubahan pembimbing tugas akhir, perpanjangan tugas akhir, dan pembatalan tugas akhir. Update manual book portal elektro. Dan memperbarui flow chart kerja praktek. Fix bug, serta update tampilan.\r\n', 3, 'Belum ada\r\n', 'Konsultasi\r\n', NULL, 'lanjutkan', 2, 1, '2020-05-14 21:50:15', '2020-05-29 16:59:29');
INSERT INTO `ta_logbook` VALUES (108, 97, 'Melakukan pengambilan data daya pada beban yang digunakan. Beban yang digunakan terdiri dari 5 variasi beban. Didapatkan hasil nikai rata-rata error antara data daya sesungguhnya (menggunakan clamp meter) dengan data yang ditampilkan di Thingspeak sebesar +-3 %.\r\n', 4, 'Clamp meter memiliki akurasi 0.1A sehingga kurang akurat jika digunakan pada beban yang kecil.\r\n', 'Mencari referensi untuk sisi kontrol.\r\n', NULL, NULL, 2, 2, '2020-05-15 17:17:43', '2020-05-15 17:17:43');
INSERT INTO `ta_logbook` VALUES (109, 104, 'Menambahkan fitur notifikasi log book baru pada hak akses dosen, fitur cetak log book pada hak akses dosen, koordinator ta, dan mahasiswa sendiri, update database kode mata kuliah, update tampilan dashboard pada bagian bimbingan dosen, dan log book ta, update pendaftaran ta kode matkul auto fill.\r\n', 4, 'tidak ada\r\n', 'Fix error persetujuan semhas dan pendadaran, Tambah fitur penguji untuk memberikan nilai, revisi, dll.\r\n', 'Oke diterima', NULL, 1, 2, '2020-05-17 21:23:56', '2020-05-28 19:07:33');
INSERT INTO `ta_logbook` VALUES (110, 91, '\"17 Mei 2020:\nMelakukan pencarian data data yang dibutuhkan untuk pemilihan provinsi dengan memperhatikan:\n-Jumlah data mobil berpenumpang berdasarkan Badan Pusat Statistik\n-Potensi energi terbarukan surya dan bayu berdasarkan Rancangan Umum Energi Nasional\n\n18 Mei 2020:\nMelakukan percobaan dengan menggunakan beberapa model desain:\n-PV dan WTG\n-PV, WTG dan Baterai\n-PV dan Baterai\"\r\n', 3, 'Untuk desain WTG dan baterai memiliki beberapa kelemahan yaitu harganya yang terlalu mahal serta beberapa titik kota memiliki kecepatan angin yang rendah\r\n', 'Melakukan konsultasi untuk menuliskan hasil dan pembahasan atau terdapat pengoreksian dari dosen pembimbing\r\n', NULL, NULL, 2, 2, '2020-05-18 11:02:14', '2020-05-18 11:02:14');
INSERT INTO `ta_logbook` VALUES (111, 97, 'Melakukan pengambilan data daya beban selama 20 menit. Hal ini dilakukan untuk menghasilkan grafik daya yang kontinu. Variasi beban yang digunakan yaitu dimulai dari 0 beban, beban magic com, beban magic com + charger laptop, beban magic com + charger laptop + kipas angin dan beban magic com + charger laptop + kipas angin + setrika.\r\n', 4, 'Koneksi internet yang tidak stabil menyebabakan beberapa data daya gagal dikirimkan ke cloud Thingspeak.\r\n', 'Melanjutkan sisi kontrol.\r\n', NULL, NULL, 2, 2, '2020-05-20 07:36:21', '2020-05-20 07:36:21');
INSERT INTO `ta_logbook` VALUES (115, 81, 'Proses manufakturing alat. Drilling, Pemasangan komponen, soldering komponen pada PCB. Kemudian melakukan uji coba alat (sistem monitoring tegangan). sistem monitoring menggunakan 3 pembagi tegangan. tiap pembagi tegangan dikalibrasi terlebih dahulu, dengan cara membaca nilai tegangan variabel dan membandingkannya dengan nilai ADC.', 3, 'Tidak ada', 'Uji coba sensor arus dan temperatur', NULL, NULL, 2, 2, '2020-07-09 16:14:10', '2020-07-09 16:14:10');
INSERT INTO `ta_logbook` VALUES (116, 81, 'Kalibrasi pembagi tegangan dilakukan agar dapat menemukan persamaan regresi linier, yang nantinya digunakan untuk pemrograman. Setelah melakukan kalibrasi pembagi tegangan, yaitu melakukan uji sensor arus ACS712 dan sensor temperatur DS18B20.', 3, 'Tidak ada', 'Pengujian sensor arus dan temperatur', NULL, NULL, 2, 2, '2020-07-09 16:17:20', '2020-07-09 16:17:20');
INSERT INTO `ta_logbook` VALUES (117, 81, 'Pengujian sensor arus acs712 dengan rating 5 A. Pengujian sensor dilakukan dengan memberi variasi masukan arus melalui catu daya dari arus masukan 0,1 A hingga 4,0 A. Pengujian dilakukan dengan pengambilan data yang terbaca oleh sensor, setiap kenaikan 0,1 A.', 3, 'Tidak Ada', 'Pengujian sensor temperatur', NULL, NULL, 2, 2, '2020-07-13 06:48:03', '2020-07-13 06:48:03');
INSERT INTO `ta_logbook` VALUES (118, 81, 'Sensor temperatur yang digunakan adalah sensor DS18B20. Sensor ini memiliki tingkat akurasi yang tinggi. Pengujian dilakukan mencoba memrogram arduino dan berhasil dilakukan. Setelah pengujian sensor temperatur, dilakukan uji coba sistem switching pada balancing.', 3, 'tidak ada', 'Uji coba switching pada sistem balancing', NULL, NULL, 2, 2, '2020-07-13 06:57:24', '2020-07-13 06:57:24');
INSERT INTO `ta_logbook` VALUES (119, 67, 'membuat presentasi progres mengenai rangkaian awal yang disimulasikan berupa desain trafo step down dan rangkaian pembagi tegangan kemudian ditampilkan pada saat pertemuan rutin dengan dosen pembimbing , perbaikan proposal yang telah di buat ulang untuk kelanjutan skripsi ', 3, 'ditemukan kesulitan untuk mendesain trafo step down yang digunakan karena belum ada spesifikasi sumber yang di gunakan', 'mencari dan mendesai trafo step down dengan mencari artikel atau jurnal yang memiliki hubyngan dengan sumber tegangan plasma korona', NULL, NULL, 2, 2, '2019-07-07 20:04:08', '2019-07-07 20:04:08');
INSERT INTO `ta_logbook` VALUES (120, 67, 'mengambil data arus dan tegangan arc discharge dari alat las di lab elektro menggunakan alat dari penelitian sebelumnya yang dikerjakan oleh ayub untuk lemudian data yang di dapat digunakan untuk data awal penelitian', 3, 'alat sebelumnya tidak bekerja seperti seharusnya dan data yang diamabil hanya data tegangan yang nilai nya belum valid', 'perlu mendatangkan ayub untuk mengoperasikan alat jika mungkin', NULL, NULL, 2, 2, '2019-07-07 20:10:30', '2019-07-07 20:10:30');
INSERT INTO `ta_logbook` VALUES (121, 67, 'mencari dan mempelajari spesifikasi dari trafo step down untuk penelitian yang saya lakukan, kemudian membuat ulang simulasi trafo step down di multisim dan melakukan evaluasi berulang untuk menemukan simulasi yang tepat', 3, 'kesulitan menentukan nilai dari perbandingan yang tepat untuk menurunkan dari 5000 volt ke 220 volt', 'mendiskusikan hasil simulasi dengan Pak Chico', NULL, NULL, 2, 2, '2019-07-07 20:23:27', '2019-07-07 20:23:27');
INSERT INTO `ta_logbook` VALUES (122, 67, 'mengunjungi sub lab Kimia di fakultas MIPA untuk mengambil data dari Plasma Korona, awalnya kami di berikan pilihan untuk mengunakan beberapa gas pada penelitian kami tapi dengan beberapa pertimbangan kami memilih satu gas saja sebagai penelitian di skripsi saya ', 2, 'alat yang dibawa tidak dapat mengambil data dari plasma tersebut  dugaan awal dikarenakan medan eletromagnetik yang besar dan mengganggu alat elektronik di sekitarnya', 'mencari sumber masalah tersebut dan mencarian solusinya', NULL, NULL, 2, 2, '2019-07-07 20:35:40', '2019-07-07 20:35:40');
INSERT INTO `ta_logbook` VALUES (123, 67, 'meeting pertama denga seluruh tim yang dibimbing oleh pak anwar dan penjelasan tentang konsep dasar dari tegangan tinggi, tegangan rendah, arus, konsep dasar dari plasma korona, konsep arc discharge dan dilanjutkan dengan laporan dari masing masing tim', 3, 'masih harus belajar banyak mengenai konsep plasma untuk keperluan tinjauan pustaka', 'mempelajari konsep dasar plasma korona', NULL, NULL, 2, 2, '2019-07-07 20:40:13', '2019-07-07 20:40:13');
INSERT INTO `ta_logbook` VALUES (124, 67, 'pagi harinya menemui pak chico untuk mendiskusikan spesifikasi dari trafo step down yang ingin di buat kemudian siangnya meeting dangan bimbingan pak anwar dan mempresentasikan beberapa hasil simulasi yang didapatkan dari diskusi dengan Pak Chico', 3, 'menentukan menggunakan spesifikasi yang mana dari 2 spesifikasi yang sudah dipilih dari beberapa spesifikasi', 'mengevaluasi ulang spesifikasi yang sudah ditentukan untuk mengetahui mana yang lebih baik', NULL, NULL, 2, 2, '2019-07-07 21:00:11', '2019-07-07 21:00:11');
INSERT INTO `ta_logbook` VALUES (125, 67, 'menemui Pak Anwar untuk membahas tentang referensi yang digunakan dan mendiskusikan tentang beberapa referensi yang sudah di dapat, setelah itu membahas progres dari revisi proposal yang sudah di perbaiki', 3, 'masih minim referensi tentang monitoring tegangan dan arus untuk Plasma', 'mencari referensi untuk acuan utama', NULL, NULL, 2, 2, '2019-07-07 21:19:13', '2019-07-07 21:19:13');
INSERT INTO `ta_logbook` VALUES (126, 67, 'membaca literatur \"ANALISIS MEDAN LISTRIK PADA PLASMA KORONA DENGAN KONFIGURASI CINCIN BIDANG\", mencoba rangkaian yang didapatkan dari internet dengan modifikasi. hasil yang diinginkan adalah tegangan dari sumber 5000 Volt menjadi 220 Volt menggunakan trafo step down kemudian dengan rangkaian voltage devider menurunkan dari 220 Volt menjadi 5 Volt (kurang lebih)', 2, 'tidak ada', 'melanjutkan menulis bab 2 untuk segera di selesaikan', NULL, NULL, 2, 2, '2019-07-07 21:35:39', '2019-07-07 21:35:39');
INSERT INTO `ta_logbook` VALUES (127, 67, 'Pengambilan data arc discharge berupa arus dan tegangan yang keluar dari mesin las, alat yang di gunakan alat yang sudah ada yang sudah di buat oleh salah satu mahasiswa elektro, alat tersebut menggunakan sensor arus memanfaatkan hall effect dengan aplikasi buatan sendiri', 3, 'Tidak bisa didapatkan hasil pembacaan secara simultan arus dan tegangan', 'Menggunakan 2 laptop agar bisa mengambil data secara simultan', NULL, NULL, 2, 2, '2019-07-18 20:34:26', '2019-07-18 20:34:26');
INSERT INTO `ta_logbook` VALUES (128, 67, 'keliling ke beberapa toko elektronik untuk mencari trafo penurun tegangan 5000 volt ke 220 volt dan kabel coaxial untuk melakukan pengambilan data ulang pada plasma korona untuku kebutuhan validasi data dan mencoba salah satu cara menhindari medan elektromagnetik, ke pasar klitikan, ke woow elektrobik, cahaya elektronik', 4, 'belum didapatnya trafo penurun tegangan dengan spesifikasi yang sesuai', 'mencari alternatif custom trafo di solo atau di jawa tengah', NULL, NULL, 2, 2, '2019-07-22 22:12:02', '2019-07-22 22:12:02');
INSERT INTO `ta_logbook` VALUES (129, 67, 'Diskusi dengan Pak Anwar mengenai progres tugas akhir sampai tahap pembuatan alat dan masih menemui kesulitan di bagaimana agar tegangan 5000 sampai 10000 Volt dapat di pantau, di butuhkan pengujian tegangan yang bisa di jadikan nilai validasi, mencari cara untuk mengambil data tersebut', 3, 'Belum adanya solusi yang benar menurunkan tegangan', 'Membeli kabel untuk pengukuran tegangan dan arus di plasma', NULL, NULL, 2, 2, '2019-07-26 11:10:54', '2019-07-26 11:10:54');
INSERT INTO `ta_logbook` VALUES (130, 67, 'Diskusi dengan pak Anwar dan seluruh tim bimbingan tentang konsep pengambilan data pada alat yang akan saya buat, ide yang saya usulkan adalah membuat 2 trafo dengan perbedaan pada kabel tembaga dengan diameter 0.05 dan 0.1 dengan jumlah lilitan yang sama. Kami juga merencanakan mengambil data plasma korona di sub lab kimia', 3, 'Belum membeli kabel coaxial dan kabel biasa untuk membandingkan data yang diambil', 'Membeli kabel yang diperlukan', NULL, NULL, 2, 2, '2019-08-07 13:35:10', '2019-08-07 13:35:10');
INSERT INTO `ta_logbook` VALUES (131, 67, 'Melakukan uji kenaikan tegangan menggunakan baterai litium 3,6 volt untuk di naikkan menjadi 15 ribu volt menggunakan rangkaian high voltagr arc generator, membongkar ulang rangkaian dan di pasang kembali dengan mengganti konfigurasi dari kabel kumparan primer dan sekunder yang akhirnya berhasil membuat spark dari rangkaian muncul, tetapi belum di ambil data tegangan dari rangkaian untuk memastikan besar tegangannya', 3, 'Kabel keluaran daribrangkaian terkelupas dan harus di ganti dengan yang baru', 'Membeli kabel untuk mengganti kabel output dari rangkaian dan mencoba mengambil data tegangan menggunalan intrustar', NULL, NULL, 2, 2, '2019-08-19 13:28:08', '2019-08-19 13:28:08');
INSERT INTO `ta_logbook` VALUES (132, 67, 'Pengambilan data untuk validasi dengan cara membandingkan nilai input dan nilai output dengan variasi sumber tegangan yang berbeda beda, input yang di berikan menggunakan power supply dan akan di ukur menggunakan probe dengan perbandingan 1:1000 agar multimeter dan intrustar tidak mengalami kerusakan', 3, 'Alat yang di gunakan mengalami kerusakan pada komponen nya danntidak bisa berfungsi lagi karena kesalahan pada setting inputnya karena terlalu besar memberikan input', 'Mencari komponen pengganti', NULL, NULL, 2, 2, '2019-09-05 11:34:20', '2019-09-05 11:34:20');
INSERT INTO `ta_logbook` VALUES (133, 67, 'menguji ulang apakah intrustar yang di gunakan untuk validasi data apakah mengalami masalah karena saat akan di lakukan pengambilan data terjadi disconnect pada sambungan dari intrustar ke komputer, belum di ketahui penyebab pastinya tetapi dari 10 kali percobaan pengambilan data semua nya mengalami disconnect saat di sambungkan dengan output dari kit yang digunakan sebagai data uji coba', 3, 'osiloscop yang akan di gunakan belum bisa di pinjam karena di gunakan untuk praktikum dan masih belum disimpulkan apakah intrustar mengalami masalah atau tidak', 'meminjam osiloscop untuk mengecek apakah intrustar mengalami gangguan dan mencoba mengambil data uji coba kembali', NULL, NULL, 2, 2, '2019-10-02 12:55:34', '2019-10-02 12:55:34');
INSERT INTO `ta_logbook` VALUES (134, 67, 'Mengambil data arus dan sudah berhasil dengan beberapa catatan dan penambahan batasan masalah karena jumlah data yang di inginkan tidak sesuai dengan yang di dapatkan,pengambilan data dilakukan beloum termasuk pengambilan voltage dan hanya arus dibutuhlan rangkaian baru untuk mengambil data voltage', 3, 'Jumlah data yang di ambil tidak sesuai dengan yg di inginkan, butuh rangkaian untuk mengambil data tegangan ', 'Membuat rangkaian pembagi tegangan dan berdiskusi dengan dosen pembimbing', NULL, NULL, 2, 2, '2019-10-14 19:21:27', '2019-10-14 19:21:27');
INSERT INTO `ta_logbook` VALUES (135, 67, 'Mencoba kembali sensor arus dengan menggunakan arduino dan inturstar, lalu di lanjutkan dengan pengambilan data tegangan menggunakan intrustar, kedua data tersebut dapat di ambil tapi untuk arus baru bisa diambil menggunakan arduino, kedua data tersebut dapat di simpan dalam bentuk excel tetapi dalam file yang berbeda, selain itu kami juga mencoba membuat ulang rangkaian inverter atau kit tanpa papan pcb', 3, 'Belum didapatkan data arus menggunakan intrustar. Rangkaian yang di buat ulang tidak menyala dan belum diketahui penyebabnya. Penyimpanan data belum bisa di lihat karena ada kesalahan teknis berupa update dari microsoft yang tidak berjalan dengan lancar', 'Membetulkan microsoft office yang bermasalah dan menguji lagi pengambilan data arus tegangan secara bersamaan dan sendiri sendiri', NULL, NULL, 2, 2, '2019-10-21 15:25:49', '2019-10-21 15:25:49');
INSERT INTO `ta_logbook` VALUES (136, 67, 'analisis data yang sudah diambil berupa data tegangan dan arus, untuk melihat data yang diambil menggunakan software origin 2016 untuk di buat menjadi grafik dan di analisis, data diambil sebanyak 5 kali, data yang diambil adalah voltage primer dan sekunder dan juga arus primer', 3, 'data dari voltage primer di duga kurang tepat dikarenakan hanya terbaca pada nilai dibawah 1, pada pengambilan data sebelumnya nilai voltage primer berada pada kisaran 2-3 volt', 'ada beberapa asumsi yang perlu di cekkembali yaitu tegangan baterai, intrsutar bermasalah atau tidak, rangkaian inverter boost bermasalah atau tidak, atau laptop yang digunakan bermaslah pada port usb, kemudian dilakukan pegambilan data ulang', NULL, NULL, 2, 2, '2019-12-02 13:10:12', '2019-12-02 13:10:12');
INSERT INTO `ta_logbook` VALUES (137, 67, 'Konsultasi secara online dengan pembinmbing 2 soal teknis penulisan dan mendapatkan beberapa revisi mengenai kesimpupan tabel penelitian dan typo penulisan serta penulisan bahasa asing yang masih kurang tept', 5, 'Tidak ada kendala berarti', 'Menyelesaikan revisi dari pembimbing 2 sesegera mungkin', NULL, NULL, 2, 2, '2020-07-13 08:57:47', '2020-07-13 08:57:47');
INSERT INTO `ta_logbook` VALUES (140, 72, 'Selasa, 7 April 2020\r\n1. Mencari alat dan bahan\r\n\r\nSenin, 13 April 2020\r\n1. Membuat simulasi three phase isolated gate driver pada software Proteus 8 dengan TLP250.\r\n2. Melakukan pengecekan keluaran sinyal pada rangkaian 1 MOSFET dan 1 TLP di Project Board.\r\n\r\nKamis, 16 April 2020\r\n1. Melakukan pengecekan keluaran sinyal pada rangkaian 2 MOSFET dan 2 TLP di Project Board.\r\n2. Simulasi three phase isolated gate driver pada software Proteus 8 dengan TLP250 masih belum bekerja.\r\n\r\nMinggu, 19 April 2020\r\n1. Melakukan pengecekan keluaran sinyal pada rangkaian 4 MOSFET dan 4 TLP di Project Board.\r\n\r\nSenin, 20 April 2020\r\n1.Karena simulasi driver masih belum bekerja, maka mencoba simulasi 2 MOSFET 2 TLP dan sudah mengeluarkan sinyal\r\n\r\nJumat, 24 April 2020\r\n1. Melakukan pengecekan ulang keluaran sinyal pada rangkaian 1 MOSFET dan 1 TLP di Project Board.\r\n2. Mencoba lagi simulasi driver tiga fasa yang belum berhasil\r\n\r\nSenin, 4 Mei 2020\r\n1. Membuat simulasi 4 MOSFET 4 TLP, namun switching nya hanya terjadi pada fasa atas\r\n\r\n\r\nKamis, 7 Mei 2020\r\n1. Membuat kembali simulasi three phase isolated gate driver pada software Proteus 8 dengan TLP250, namun masih belum bekerja.\r\n\r\nJumat, 15 Mei 2020\r\n1. Mencoba lagi simulasi driver tiga fasa sambil mencari motor tiga fasa untuk pengambilan data\r\n\r\nJumat, 29 Mei 2020\r\n1. Mendapatkan truth table antara hubungan switching MOSFET, sensor hall, dan kecepatan motor yang nantinya diterapkan di coding\r\n\r\nKamis, 4 Juni 2020\r\n1. Mencari beberapa referensi coding driver tiga fasa\r\n2. Menerapkannya dalam simulasi\r\n\r\nMinggu, 7 Juni 2020\r\n1. Konsultasi online terkait hubungan antara cara kerja sensor hall dengan switching MOSFET\r\n\r\nSelasa, 9 Juni 2020\r\n1. Membuat 3 rangkaian 2 MOSFET 2 TLP pada PCB, dan kemudian memeriksa sinyal rangkaian menggunakan mini function generator\r\n2. Mencari kembali beberapa coding untuk dicoba di simulasi\r\n\r\nSenin, 15 Juni 2020\r\n1. Mencari-cari motor BLDC tiga fasa dengan harga terjangkau dan tegangan serta daya yang tidak terlalu besar.\r\n\r\nJumat, 19 Juni 2020\r\n1. Beberapa coding sudah dicoba, namun tidak ada yang sesuai dengan simulasi rangkaian\r\n\r\nRabu, 24 Juni 2020\r\n1. Memperbaiki penulisan pada Bab III\r\n\r\nSenin, 29 Juni 2020\r\n1. Karena motor BLDC yang dapat terjangkau untuk dibeli adalah motor BLDC CD-ROM maka harus mencari IC LM324 sebagai komparator\r\n\r\nJumat, 3 Juli 2020\r\n1. Membuat rangkaian komparator pada Motor BLDC CD-ROM\r\n\r\nRabu, 8 Juli 2020\r\n1. Mendapat referensi driver tiga fasa motor BLDC CD-ROM.\r\n2. Menerapkan referensi program dan rangkaian pada simulasi\r\n\r\nKamis, 9 Juli 2020\r\n1. Merombak rangkaian simulasi dengan optocoupler PC817\r\n2. Pada simulasi rangkaian, switching diatur dengan MOSFET IRF4905 pada masing-masing output high phase dan MOSFET IRF540N pada masing-masing output low phase\r\n\r\nJumat, 10 Juli 2020\r\n1. Simulasi rangkaian sudah bekerja namun coding nya masih dalam bentuk inisiasi pin dengan bilangan heksadesimal dan tanpa potensiometer\r\n2. Menerapkan coding switching dengan output digital pada simulasi\r\n\r\nSenin, 13 Juli 2020\r\n1. Menerapkan coding switching dengan output analog dan menambahkan potensiometer pada coding', 3, 'Coding masih dalam bentuk inisiasi pin heksadesimal, masih tanpa potensiometer', 'Coding sudah dalam bentuk inisiasi pin desimal, dan sudah ada input sensor hall', 'Saat coding mohon berhati-hati', NULL, 1, 2, '2020-07-13 20:01:28', '2020-07-24 12:10:33');
INSERT INTO `ta_logbook` VALUES (141, 88, '\"1. Berdiskusi mengenai design Building Energy Management System yang telah dibuat oleh Pak Ramelan dengan menggunakan Skype.  2. Mencari referensi mengenai CSS dan JS pada sebuah website 3. Membuat UI sistem sesuai dengan design yang telah dibuat\"\r\n', 3, 'Tidak ada', 'Meneruskan dalam pembuatan UI sesuai dengan design yang telah dibuat', NULL, NULL, 2, 2, '2020-05-21 23:32:35', '2020-05-21 23:32:35');
INSERT INTO `ta_logbook` VALUES (142, 88, '1. Mencari referensi mengenai pembuatan chart dengan diintegrasikan dengan API 2. Membuat real time chart pada halaman dashboard Building Energy Management System 3. Menyelesaikan halaman dashboard sesuai dengan design yang telah dibuat\r\n', 3, 'Tidak ada', 'Konsultasi dengan pembimbing', NULL, NULL, 2, 2, '2020-05-22 00:17:29', '2020-05-22 00:17:29');
INSERT INTO `ta_logbook` VALUES (143, 88, '1. Melakukan perbaikan UI pada halaman dashboard sesuai dengan arahan dari pembimbing (model chart, dan beberapa style) 2. Mengkonsultasikan kembali hasil perbaikan dengan pembimbing 3. Melanjutkan pembuatan halaman usages pada website BEMS 4. Mencari referensi mengenai pembuatan statistic chart dan navigation button (today, month, year) 5. Menyelesaikan halaman usages sesuai dengan design yang telah ada', 3, 'Tidak ada', 'Konsultasi dengan pembimbing mengenai halaman usages yang telah dibuat', NULL, NULL, 2, 2, '2020-05-22 17:55:42', '2020-05-22 17:55:42');
INSERT INTO `ta_logbook` VALUES (144, 82, 'Minggu, 10 Mei 2020 1. Penyempurnaan penulisan Bab III, dikarenakan penggantian software simulasi yang digunakan menjadi Proteus 7.9. Senin, 11 Mei 2020 1. Membuat sistem logger untuk mengambil data kecepatan motor di prototipe. 2. Set up sensor speed agar dapat melakukan pembcaan motor DC dengan baik. Selasa, 12 Mei 20201. Penyempurnaan data logger untuk RPM motor DC Rabu, 13 Mei 2020 1. Penyempurnaan data logger untuk RPM motor DC tahap 2.2. Melakukan simulasi dan mengambil data simulasi rangkaian Adaptive Cruise Control pada software Proteus 7.9. Kamis, 14 Mei 2020 1. Melakukan pengujian prototipe dan mengambil data keseluruhan uji prototipe di laboratorium Elektronika Teknik Elektro UNS. Jumat, 15 Mei 2020 1. Mengolah data yang sudah diambil dari simulasi dan pengujian pada prototipe.Sabtu, 16 Mei 2020 1. Mengukur kebutuhan kabel dan komponen konverter tegangan pada sepeda motor listrik konversi agar sistem dapat ditanamkan pada sepeda motor listrik.Minggu, 17 Mei 2020 1. Membuat konverter tegangan yang diperlukan untuk menyuplai sistem di sepeda motor listrik. Senin, 18 Mei 2020 1. Revisi bab III membetulkan diagram sensor yang digunakan pada sepeda motor listrik.Selasa, 19 Mei 2020 1. Memasang alat pada sepeda motor listrik, sistem utama/kontroller utama diletakkan dibelakang karena posisi tersebut dekat dengan sumber listrik dan mempermudah untuk wiring rangkaian.Rabu,  20 Mei 2020 1. Penyempurnaan pemasangan alat di sepeda motor listrik. 2. Konsultasi online dan melaporkan progress instalasi di Sepeda motor listrik.Kamis, 21 Mei 2020 1. Penyempurnaan agar mode adaptive dapat berjalan di sepeda motor listrik. 2. Konsultasi online terkait bisa bypass throttle di sepeda motor listrik.Jumat, 22 Mei 2020 1. Memulai penulisan Bab IV. 2. Konsultasi online progress mode adaptive dapat dijalankan di sepeda motor listrik tetapi menggunakan koding prototipe.', 4, 'Minggu, 10 Mei 2020 Tidak ada Senin, 11 Mei 2020 1. Logger memerlukan catu daya lain sehingga harus menggunakan arduino lain untuk sistem sensor dan logger kecepatan motor .Selasa, 12 Mei 2020 Tidak ada Rabu, 13 Mei 2020 Tidak ada Kamis, 14 Mei 2020 Tidak ada Jumat, 15 Mei 2020 Tidak ada Sabtu, 16 Mei 2020 Tidak ada Minggu, 17 Mei 2020 Tidak ada Senin, 18 Mei 2020 Tidak ada Selasa, 19 Mei 2020 1. Terkendala mencari kabel sinyal throttle untuk melakukan bypass ke Arduino Rabu,  20 Mei 2020 1. Bypass Throttle berhasil dilakukan tetapi mode adaptive masih belum bisa dijalankan. Kamis, 21 Mei 2020 1. Mode adaptive bisa berjalan pada sepeda motor listrik tetapi menggunakan koding prototipe yang berarti jarak yang ditedeksi sangat dekat Jumat, 22 Mei 2020 Tidak ada', '1. Akses kontroler Votol EM-100 yang diperbaiki dengan PC. 2. Menyempurnakan koding untuk mode Adaptive Cruise Control agar dapat menjalankan sepeda motor listrik dengan baik saat mode diaktifkan. 3. Mengambil data pengujian di sepeda motor listrik. 4. Menyelesaikan penulisan Bab IV dan menyicil penulisan Jurnal ICIMECE 2020.', NULL, NULL, 2, 2, '2020-05-23 11:24:11', '2020-05-23 11:24:11');
INSERT INTO `ta_logbook` VALUES (145, 88, '1. Melakukan perbaikan UI pada halaman usages sesuai dengan arahan dari pembimbing 2. Memperbaiki chart pada halaman dashboard supaya dapat beroperasi dengan baik 3. Melanjutkan dalam pembuatan UI pada halaman control sesuai dengan design yang ada', 3, 'Tidak ada', 'Konsultasi dengan pembimbing mengenai halaman usages dan beberapa perubahan yang lainnya', NULL, NULL, 2, 2, '2020-05-23 14:59:19', '2020-05-23 14:59:19');
INSERT INTO `ta_logbook` VALUES (146, 88, '1. Melanjutkan pembuatan UI pada halaman control 2. Menyelesaikan UI pada halaman control dilanjutkan konsultasi dengan pembimbing 3. Melakukan perbaikan pada halaman control berupa penggantian warna pada button on/off dan style yang lainnya 4. Mengubah bahasa indonesia menjadi bahasa inggris pada kata yang ada pada BEMS 5. Merubah jumlah ruangan yang ada menjadi 6 ruangan', 3, 'Tidak ada', 'Konsultasi dengan pembimbing mengenai perubahan yang telah dilakukan', NULL, NULL, 2, 2, '2020-05-24 18:23:01', '2020-05-24 18:23:01');
INSERT INTO `ta_logbook` VALUES (147, 88, '1. Membuat UI pada halaman cost sesuai dengan design yang telah dibuat 2. Mencari referensi chart yang cocok dengan kebutuhan pada halaman cost 3. Menyelesaikan pembuatan chart pada halaman cost 4. Mencari referensi mengenai pembuatan datepicker yang diterapkan di dalam chart 5. Menyelesaikan UI pada halaman cost', 3, 'Tidak ada', 'Konsultasi dengan pembimbing mengenai perubahan yang telah dilakukan', NULL, NULL, 2, 2, '2020-05-27 23:15:15', '2020-05-27 23:15:15');
INSERT INTO `ta_logbook` VALUES (148, 88, '1. Memperbaiki UI pada halaman cost sesuai dengan arahan pembimbing 2. Melanjutkan dengan pembuatan UI pada halaman statistic 3. Mencari referensi mengenai pembuatan chart statistic yang sesuai dengan design yang telah ada, serta fungsi - fungsi yang ada di dalamnya 4. Memperbaiki beberapa code CSS yang bermasalah 5. Mencari referensi mengenai pembuatan export button pada chart di halaman statistic 6. Konsultasi dengan pembimbing mengenai perubahan yang telah dilakukan', 3, 'Tidak ada', 'Mengintegrasikan antara website BEMS dengan hardware dengan menggunakan API', NULL, NULL, 2, 2, '2020-05-30 18:57:05', '2020-05-30 18:57:05');
INSERT INTO `ta_logbook` VALUES (149, 98, 'Membaca literatur yang telah diberikan, juga sedang melakukan pembelian alat dan bahan untuk mencoba menggunakan metode yang baru, nantinya setelah alat datang akan langsung dicoba dan diprogram, lalu disesuaikan dengan metode yang akan digunakan', 3, 'Tidak ada', 'Percobaan menggunakan alat baru', NULL, NULL, 2, 2, '2020-06-03 20:34:07', '2020-06-03 20:34:07');
INSERT INTO `ta_logbook` VALUES (150, 98, '1. Telah melakukan desain dan cetak lengan (arm) dengan bahan akrilik sebagai alas (base) untuk motor brushless 2. Telah dilakukan perangkaian alat Arduino dan sensor Gyroscope. Dan juga merakukan kalibrasi sensor Gyro terhadap sumbu X', 3, 'Sensitivitas sensor gyro kurang baik', 'Melakukan kalibrasi esc terhadap motor brushless', NULL, NULL, 2, 2, '2020-06-03 20:41:25', '2020-06-03 20:41:25');
INSERT INTO `ta_logbook` VALUES (151, 97, 'Melakukan rancangan pada end nodes yang ke 2. Dimana perbedaan antara nodes 1 dan 2 terletak pada sensor arus yang digunakan, dimana pada nodes 1 menggunakan ACS712 5A sedangkan pada nodes 2 menggunakan ACS712 30A. Serta melakukan singkronisasi dengan web BEMS FT yang dibuat pada TA Kevin.', 3, 'Tidak ada', 'Melakukan kalibrasi pada ACS712 yang dipakai di nodes 2.', NULL, NULL, 2, 2, '2020-06-03 21:13:11', '2020-06-03 21:13:11');
INSERT INTO `ta_logbook` VALUES (152, 102, '1. Telah berhasil membaca sensor gyroscope menggunakan simulink. Menemukan compiler dan support yang tepat. 2. Mencari beberapa model referensi yang sesuai dengan plant. 3. Mencoba model referensi yang sesuai untuk mendapat data awal.', 3, 'Beberapa model terkendala dalam pengiriman dan penerimaan data serial', 'Mencari solusi pembacaan data serial sederhana dengan simulink', NULL, NULL, 2, 2, '2020-06-03 21:15:17', '2020-06-03 21:15:17');
INSERT INTO `ta_logbook` VALUES (153, 98, '1. Perangkaian motor, propeller (baling - baling) dan esc terhadap arduino, serta kalibrasi esc dengan variasi kecepatan motor yang berbeda - beda. 2. Membuat program kendali motor sederhana, menggunakan potentiometer', 3, 'Tidak ada', 'Perancangan program menggunakan metode PID', NULL, NULL, 2, 2, '2020-06-04 16:56:06', '2020-06-04 16:56:06');
INSERT INTO `ta_logbook` VALUES (154, 98, '1. Perangkaian motor, propeller (baling - baling) dan esc terhadap arduino, serta kalibrasi esc dengan variasi kecepatan motor yang berbeda - beda. 2. Membuat program kendali motor sederhana, menggunakan potentiometer', 3, 'Tidak ada', 'Perancangan program menggunakan metode PID', NULL, NULL, 2, 2, '2020-06-05 21:47:18', '2020-06-05 21:47:18');
INSERT INTO `ta_logbook` VALUES (155, 98, '1. Telah melakukan pembuatan algoritma serta program kendali motor BLDC yang terhubung melalui nilai PWM ESC ke Arduino dengan menggunakan metode PID 2. Menentukan nilai koefisien PID secara trial error', 3, 'Nilai PID yang ada belum bagus hasilnya', 'Trial Error nilai PID agar hasil lebih maksimal', NULL, NULL, 2, 2, '2020-06-05 21:50:58', '2020-06-05 21:50:58');
INSERT INTO `ta_logbook` VALUES (156, 98, '1. Telah berhasil menentukann nilai PID dengan trial and error, sehingga hasil yang didapatkan dapat membuat sensor gyro stabil pada sudut sekitar -5 sampai 5 derajat 2. Pengambilan data dari sensor gyro dan kecepatan motor BLDC menggunakan data logger pada program PID untuk membuat transfer function', 3, 'Tidak ada', 'Pembuatan transfer function pada MATLAB', NULL, NULL, 2, 2, '2020-06-07 00:43:16', '2020-06-07 00:43:16');
INSERT INTO `ta_logbook` VALUES (157, 104, 'Melakukan perbaikan User Interface pada halaman welcoma page, dashboard, dan sidebar. Memperbaiki menu penguji semhas dan pendadaran. Memperbaiki fitur logbook tugas akhir mahasiswa pada hak akses dosen dan koordinator. Menambahkan fitur status ta mahasiswa, data record data mahasiswa ta.', 4, 'tidak ada', 'Memperbarui manual book dan dokumen ta.', NULL, NULL, 2, 2, '2020-06-10 00:08:07', '2020-06-10 00:08:07');
INSERT INTO `ta_logbook` VALUES (158, 84, '1. Telah membuat baterai pack dengan spesifikasi 12 V 5.2 Ah LFP 2. Membuat permodelan pengaturan kecepatan motor dengan Throttle Handle sepeda listrik 3. Melakukan drilling, soldering Harware alat kontrol switching serta perakitan komponen', 3, '1. Program PWM pada motor masih belum benar, motor ketika idle masih bergerak. 2. Program switching belum selesai belum adanya program sensor SOC dan suhu. 3. Hardware ketika di coba masih belum berjalan switchingnya berdasarkan arus motor.', '1. Menyelesaikan program arduino driver motor dan switching 2. Memperbaiki hardware yang belum berjalan.', NULL, NULL, 2, 2, '2020-06-12 10:43:41', '2020-06-12 10:43:41');
INSERT INTO `ta_logbook` VALUES (159, 104, 'Revisi Draft Tugas Akhir, Menambahkan fitur upload link draft tugas akhir pada seminar hasil dan pendadaran tugas akhir. Memperbaiki bug pada sistem, menambahkan fitur upload surat permohonan, penugasan dan surat tugas pada kerja praktek.', 4, 'tidak ada', 'menambahkan fitur approval pembimbing kerja praktek', NULL, NULL, 2, 2, '2020-06-13 22:33:13', '2020-06-13 22:33:13');
INSERT INTO `ta_logbook` VALUES (160, 97, 'Melakukan perancangan terhadap sisi kontrol node 1. Kontrol yang digunakan menggunakan metode downlink Thingspeak Talkback ke Gateway. Telah dibuat juga aplikasi (.apk) dari platform MIT App Inventor sederhana untuk mengirim string dari android ke talkback thingspeak yang selanjutnya melakukan eksekusi relay pada node.', 3, 'Tidak ada', 'Melakukan penyempurnaan perancangan apk untuk sisi monitoring dan kontrol.', NULL, NULL, 2, 2, '2020-06-15 14:39:41', '2020-06-15 14:39:41');
INSERT INTO `ta_logbook` VALUES (161, 100, '1. pengolahan data pengujian pembacaan sensor tegangan, arus, dan suhu. 2. Pengolahan data pengujian bypass cel. 3. pengolahan data pengujian sistem proteksi. 4. pembuatan grafik dengan origin lab. 5. Penulisan BAB IV.', 4, 'tidak ada.', 'konsultasi draft TA.', NULL, NULL, 2, 2, '2020-06-16 18:39:46', '2020-06-16 18:39:46');
INSERT INTO `ta_logbook` VALUES (162, 102, '1. Menyelesaikan pemrograman PID dengan arduino ide. Mengambil data nilai sudut, nilai PID dan nilai PWM. 2. Mengolah data PID (error dan derivative error) untuk input FLC. 3. Menyelesaikan model block FLC pada ANFIS. 4. Mencoba memperbaki pembacaan single serial data yang terputus ditengah running program simulink.', 3, 'Model yang belum berjalan sesuai keinginan.', 'Memahami dan memperbaiki model dari beberapa referensi yang ada.', NULL, NULL, 2, 2, '2020-06-17 21:27:42', '2020-06-17 21:27:42');
INSERT INTO `ta_logbook` VALUES (163, 100, 'Konsultasi draft Skripsi.1. Revisi bab I pada bagian latar belakang perlud ditambahin dukungan mengenai alasan pembuatan alat. 2. Revisi BAB I pada bagian tujuna perlu diperjelas dikarenakan masih terlalu umum.', 1, 'Tidak ada', 'Memperbaiki hasil revisian pada bab 1.', NULL, NULL, 2, 2, '2020-06-17 23:14:17', '2020-06-17 23:14:17');
INSERT INTO `ta_logbook` VALUES (164, 71, 'Mempelajari Proses bisnis penggunaan sistem OBE , mencatat kebutuhan-kebutuhan sistem, serta merancang database sistem. pada aplikasi OBE nilai pada mahasiswa dimasukkan sesuai dengan kebutuhan akreditasi IABEE, nilai mata kuliah dibagi menjadi CPMK(Capaian Pembelajaran Lulusan) dan setiap CPMK berelasi dengan CPL(Capaian Pembelajaran Lulusan) ', 4, 'tidak ada', 'Mengubah kebutuhan-kebutuhan user menjadi kebutuhan sistem dan merancang gambaran UI dan databasenya', NULL, NULL, 2, 2, '2020-06-18 09:45:47', '2020-06-18 09:45:47');
INSERT INTO `ta_logbook` VALUES (165, 71, '1. Menginstal yii2 advanced 2. menghubungkan framework ke database local 3. menginstal GII(Generator YII) 4. melakukan generate CRUD beberapa tabel referensi(ref_kelas, ref_tahun_ajaran, ref_mahasiswa dll)  ', 4, 'Hasil pada generate YII2 memiliki tampilan yang kurang menarik dan beberapa pengolahan data yang kurang sesuai keinginan, perlu di ubah dan perlu memahami struktur generate YII agar bisa dilakukan modifikasi', 'Mempelajari struktur CRUD generate YII2Mengedit tampilan pada sistemmelakukan migrate User untuk membuat fitur login', NULL, NULL, 2, 2, '2020-06-18 09:57:15', '2020-06-18 09:57:15');
INSERT INTO `ta_logbook` VALUES (166, 71, '1. Memperbaiki tampilan hasil Generate CRUD yii2 yang telah dibuat 2. Memperbaiki alur data CRUD sesuai kebutuhan sistem 3. Mencari Referensi Pembuatan Import File Excel ke Sistem 4. Mempelajari Cara kerja import file excel 5. Merancang tampilan dan alur data import', 4, 'pada pembuatan import file excel perlu dilakukan pembelajaran lebih dalam dikarenakan fitur import yang tidak sederhana dan harus dapat memenuhi kebutuhan sistem', 'Membaca dokumentasi yii2 dan dokumentasi fitur file import excel dari kartik, serta mempelajari penggunaan phpoffice untuk read & write file excel', NULL, NULL, 2, 2, '2020-06-18 16:16:30', '2020-06-18 16:16:30');
INSERT INTO `ta_logbook` VALUES (167, 100, '1. memperbaiki BAB I pada bagian Manfaat dikarenakan masih terlalu sedikit sesuai permintaan dosen pembimbing yaitu menambahi manfaat untuk peneliti, manfaat untuk pemerintah dan manfaat untuk Industri.', 1, 'tidak ada', 'memperbaiki BAB II pada bagian penelitian sebelumnya.', NULL, NULL, 2, 2, '2020-06-18 20:24:36', '2020-06-18 20:24:36');
INSERT INTO `ta_logbook` VALUES (168, 71, '1. Membuat tampilan import file excel 2. Membuat function controller untuk import file nilai 3. Membuat tampilan untuk proses import agar bisa realtime 4. Mencoba tampilan import apakah sudah bisa berjalan realtime', 4, 'Masih terdapat error untuk menampilkan proses import file', 'Mencari tau dan memperbaiki error tampilann file import', NULL, NULL, 2, 2, '2020-06-19 07:34:48', '2020-06-19 07:34:48');
INSERT INTO `ta_logbook` VALUES (169, 57, 'Mencari referensi contoh format penulisan bab 4 yang ber hubu ngan dengan topik yang saya tulis. Pencarian di lakukan dari contoh hasil skripsi yang sudah ada. Dari sana saya mencoba mempelajari format dan model penulisannya', 4, 'tidak ada', 'mencari refrensi penulisan lebih lanjut', NULL, NULL, 2, 2, '2020-06-19 09:30:32', '2020-06-19 09:30:32');
INSERT INTO `ta_logbook` VALUES (170, 97, 'Melakukan finalisasi hardware yang dirancang. Hardware sudah bisa bekerja sesuai keinginan. Sisi monitoring sudah bisa mengirimkan data energi (Wh) ke Thingspeak. Pada sisi control, sudah bisa melakukan control terhadap keseluruhan relay melalui apk yang dibuat di MIT App Inventor.', 3, 'Tidak ada', 'Melakukan kalibrasi ulang untuk sensor arus dan tegangan.', NULL, NULL, 2, 2, '2020-06-19 13:05:40', '2020-06-19 13:05:40');
INSERT INTO `ta_logbook` VALUES (171, 100, 'memperbaiki studi literatur yaitu dengan menjabarkan dalam sebuah paragraf dari penelitian-penelitian sebelumnya yang tertulis dalam tabel dan memberikan perbedaan beserta penjelasan dari alat yang dibuat berdasarkan referensi tersebut.', 2, 'tidak ada', 'konsultasi hasil revisi', NULL, NULL, 2, 2, '2020-06-20 02:07:39', '2020-06-20 02:07:39');
INSERT INTO `ta_logbook` VALUES (172, 71, '1. Membuat proses import nilai dari file excel 2. Membuat generate template untuk import nilai 3. konsultasi bisnis proses lebih lanjut kepada pembimbing 4. konsultasi database  sistem kepada pembimbing', 4, 'ketika generate template excel perlu melakukan penulisan data dari database ke template excel, perlu mempelajari dokumentasi phpoffice agar bisa melakukan penlusian', 'Membaca dokumentasi php officeMerancang struktur database baru sesuai arahan pembimbingMengerjakan import nilai', NULL, NULL, 2, 2, '2020-06-20 09:10:45', '2020-06-20 09:10:45');
INSERT INTO `ta_logbook` VALUES (173, 71, '1. Merancang database yang menampung KRS mahasiswa 2. Mengerjakan proses import nilai, dikarenakan masih ada error feedback ke user 3.  Mengerjakan generate template excel sehingga dari database bisa ditulis ulang ke template', 4, 'Error feedback dan validation pada proses import nilai yang diprogram menggunakan javascript', 'Mempelajari program javascript untuk menghitung data yang masuk, data update dan data error ketika import nilai berlangsung', NULL, NULL, 2, 2, '2020-06-20 09:20:17', '2020-06-20 09:20:17');
INSERT INTO `ta_logbook` VALUES (174, 57, 'Melanjutkan mencari referensi tambahan untuk model dan format penulisan bab 4 hasil dan pembahasan. Penacrian masih bersumber dari karya ilmiah skripsi maupun tugas akhir yang sudah pernah dibuat sebelumnya dan dipublikasikan di Internet.', 4, 'belum ada', 'Memulai penulisan bab 4', NULL, NULL, 2, 2, '2020-06-20 21:57:34', '2020-06-20 21:57:34');
INSERT INTO `ta_logbook` VALUES (175, 71, '1. Menyiapkan database baru 2. Generate CRUD mata kuliah tayang 3. Mengedit tampilan dan proses data pada mata kuliah tayang 4. Mengerjakan import nilai, mengedit tampilan bagian CSS dan proses import ajax', 4, 'CSS pada Yii2 belum bisa termuat pada halaman', 'Mengerjakan import nilaiMembuat tampilan untuk import KRSMencari tau cara register CSS di Yii2', NULL, NULL, 2, 2, '2020-06-21 05:59:58', '2020-06-21 05:59:58');
INSERT INTO `ta_logbook` VALUES (176, 100, 'Konsultasi pendaftaran seminar hasil.1. melakukan konsultasi dan pengajuan persetujuan dengan pembimbing 1 tentang pengajuan seminar hasil dan pengecekan hasil revisi. 2. melakukan konsultasi dan pengajuan persetujuan dengan pembimbing 2 tentang pengajuan seminar hasil dan pengecekan hasil revisi.', 4, 'tidak ada.', 'pengajuan seminar hasil', NULL, NULL, 2, 2, '2020-06-22 15:42:03', '2020-06-22 15:42:03');
INSERT INTO `ta_logbook` VALUES (177, 71, '1. Membuat tampilan, function controller untuk import KRS 2. Membuat template untuk import KRS 3. Memperbaiki bug import nilai pada bagian penyimpanan file 4. Mengganti alur proses ajax pada import nilai, menyesuaikan database yang baru', 4, 'perlu mensinkronkan program dengan database yang baru', 'Membuat import file krs', NULL, NULL, 2, 2, '2020-06-22 20:11:45', '2020-06-22 20:11:45');
INSERT INTO `ta_logbook` VALUES (178, 71, '1. Membuat tampilan monitoring evaluasi untuk monitoring individu, monitoring semester, monitoring angkatan. 2. membuat chart radar dan chart histogram menggunakan chart JS untuk menampilkan data (untuk sementara data yang digunakan adalah data hardcode bentuk array).', 4, 'bentuk data pada chart JS harus mengikuti aturan dari chart JS, sehingga perlu memperlajari dokumentasinya lebih lanjut', 'mempelajari penggunaan chart JS lebih lanjut dan melanjutkan pengerjaan import krs dan import nilai', NULL, NULL, 2, 2, '2020-06-22 20:29:22', '2020-06-22 20:29:22');
INSERT INTO `ta_logbook` VALUES (179, 71, '1. Mengerjakan import krs dan import nilai 2. membuat query perhitungan dari nilai nilai mahasiswa menjadi capaian pembelaharan lulusan 3. membuat template modal yii2 untuk digunakan di monitoring evaluasi', 4, 'query perhitungan yii2 perlu dipelajari lebih lanjut, dan pembuatan template modal untuk Yii2 perlu mempelajari konfigurasinya', 'membaca dokumentasi query builder yii2 dan mengkonfigurasi modal dari yii2', NULL, NULL, 2, 2, '2020-06-23 08:24:40', '2020-06-23 08:24:40');
INSERT INTO `ta_logbook` VALUES (180, 57, 'Menyusun kerangka penulisan bab 4 hasil dan pembahasan. Rencananya penulisan tugas akhir untuk bab 4 hasil dan pembahasan ini akan dibagi menjadi dua sub bab. Yaitu implementasi dan juga pengujian software.', 4, 'belum ada', 'memulai penulisan', NULL, NULL, 2, 2, '2020-06-23 16:26:39', '2020-06-23 16:26:39');
INSERT INTO `ta_logbook` VALUES (181, 71, '1. Mengerjakan chart radar dan chart histogram untuk monitoring evaluasi 2. membuat tampilan hasil dari import krs dan import nilai yang sudah diupload 3. mengerjakan controller import KRS dan import nilai', 4, 'Bentuk data belum sesuai dengan template dari chart JS sehingga chart radar dan chart histogram belum muncul', 'perlu mempelajari penggunaan array helper agar data sesuai dengan template chart JS', NULL, NULL, 2, 2, '2020-06-23 20:32:10', '2020-06-23 20:32:10');
INSERT INTO `ta_logbook` VALUES (182, 100, 'pembuatan PPT semhas.1. mengisi bagian latar belekang dengan mengambil point-point penting pada latar belakang draft skripsi yang telah dibuat. 2. mengisi bagian tinjauan pustaka dengan beberapa project terdahulu yang memiliki kesamaan dengan alat yang dibuat.', 1, 'tidak ada', 'konsultasi tentang pelaksanaan semhas dan materi yang di sampaikan.', NULL, NULL, 2, 2, '2020-06-23 20:52:08', '2020-06-23 20:52:08');
INSERT INTO `ta_logbook` VALUES (183, 100, 'Pembuatan ppt dan persiapan semhas.1. Pembuatan ppt melanjutkan yg kmarin dengan mengisi bagian metodologi alat yg sudah dikerjakan. 2. Mengisi bagian hasil dan pembahasan dengan menampilkan data- data yang telah di dapatkan pada saat pengujian.', 3, 'Tidak ada', 'Semhas', NULL, NULL, 2, 2, '2020-06-24 23:17:47', '2020-06-24 23:17:47');
INSERT INTO `ta_logbook` VALUES (184, 71, '1. Melakukan testing mandiri untuk ke seluruhan sistem 2. Mengecek perhitungan monitoring evaluasi untuk individu, semester, angkatan dan alumni 3. Melakukan pengecekan data yang masuk pada saat import KRS dan import Nilai', 4, 'terdapat beberapa error query, seharusnya diberikan ->where([\'status\'=>1]) untuk data yang aktif atau digunakan', 'menambahkan query dan memperbaiki bug, serta akan memindahkan sistem ke online', NULL, NULL, 2, 2, '2020-06-25 07:48:55', '2020-06-25 07:48:55');
INSERT INTO `ta_logbook` VALUES (185, 57, 'Menulis bab 4 hasil dan pembahasan. Penulisan didasarkan pada kerangka yang telah dibuat sebelumnya. Pada kali ini, yang ditulis adalah bagian implementasi. Mulai dari dashboard hingga halaman pembuatan perintah bot.', 4, 'belum ada', 'konsultasi', NULL, NULL, 2, 2, '2020-06-25 16:47:09', '2020-06-25 16:47:09');
INSERT INTO `ta_logbook` VALUES (186, 100, '1. Melakukan hosting sistem ke si.ft.uns.ac.id/obeelektro 2. Melakukan Mapping Data Teknik Elektro untuk kebutuhan sistem OBE Elektro 3. Testing sistem oleh pembimbing 1 dan pembimbing 2 tugas akhir, serta beberapa teman elektro', 4, 'Pada saat melakukan hosting terdapat bug, perlu mempelajari cara melakukan hosting lebih lanjut, tentang permission dan akses index.php', 'Memperbaiki bug terkait hosting dan bug hasil testing', NULL, NULL, 2, 2, '2020-06-26 18:57:01', '2020-06-26 18:57:01');
INSERT INTO `ta_logbook` VALUES (187, 57, 'Jumat, 26 Juni 2020 : Konsultasi kepada pembimbing 1 mengenai bab 4 hasil dan pembahasan yang sudah ditulis sebelumnya. Pembimbing 1 menyarankan untuk segera menyelesaikannya terlebih dahulu. Sehingga dapat dikoreksi secara utuh.', 4, 'belum ada', 'melanjutkan menulis bab 4', NULL, NULL, 2, 2, '2020-06-27 11:27:48', '2020-06-27 11:27:48');
INSERT INTO `ta_logbook` VALUES (188, 91, 'Melakukan analisa pada bab 4 untuk hasil desain pembangkit yang telah dibuat dengan membandingkan 5 ibukota pada tiap provinsi dan mencari nilai Net Present Cost dan Cost of Energy terendah dari ke 5 hasil tersebut dengan melihat nilai PV, WTG dan konverternya', 4, 'belum ada', 'melakukan revisi bab 4', NULL, NULL, 2, 2, '2020-06-28 20:53:30', '2020-06-28 20:53:30');
INSERT INTO `ta_logbook` VALUES (189, 88, '1. membuat database untuk menyimpan data dari hardware 2. mencari referensi mengenai pengintegrasian antara laravel dan thingspeak dengan menggunakan API 3. mencoba integrasi data antara website BEMS dengan thingspeak', 3, 'Tidak ada', 'Menerapkan metode pengiriman data dari hardware ke website BEMS', NULL, NULL, 2, 2, '2020-06-29 00:29:24', '2020-06-29 00:29:24');
INSERT INTO `ta_logbook` VALUES (190, 88, '1. mencari referensi mengenai react dan pengaplikasiannya pada thingspeak 2. mencari referensi mengenai thinghttp dan pengaplikasiannya pada thingspeak 3. mencoba menggunakan API dari thingspeak dalam pengiriman data ke server', 4, 'tidak ada', 'konsultasi dengan pembimbing mengenai alur data yang telah diterapkan', NULL, NULL, 2, 2, '2020-06-29 14:11:03', '2020-06-29 14:11:03');
INSERT INTO `ta_logbook` VALUES (191, 88, '1. konsultasi dengan pembimbing mengenai progress dan alur data yang telah diterapkan 2. mengubah metode yang telah diterapkan menjadi menggunakan MQTT 3. mencari referensi mengenai api mqtt yang ada pada thingspeak', 4, 'tidak ada', 'mencoba menggunakan mqtt untuk mengirim data', NULL, NULL, 2, 2, '2020-06-29 15:57:35', '2020-06-29 15:57:35');
INSERT INTO `ta_logbook` VALUES (192, 88, '1. mencoba menggunakan mqtt.fx sebagai client penerimaan data 2. mencari referensi metode api mqtt yang ada 3. mencoba melakukan pengiriman dan penerimaan data dengan menggunakan client mqtt.fx di localhost', 4, 'tidak ada', 'mencoba mengintegrasikan mqtt dengan thingspeak', NULL, NULL, 2, 2, '2020-06-29 16:47:09', '2020-06-29 16:47:09');
INSERT INTO `ta_logbook` VALUES (193, 71, '1. Memperbaiki beberapa bug/kesalahan ketika hosting, melakukan beberapa konfigurasi dan memperbaiki beberapa koding yang berhubungan dengan url sistem 2. Memperbaiki bug hasil temuan testing oleh pembimbing dan teman teman', 4, 'Beberapa CSS dan JS di localhost dapat berjalan namun ketika dihosting terdapat beberapa error sehingga perlu dilakukan registrasi CSS dan JS pada kodingan.', 'Mempelajari penggunaan registrasi CSS dan JS pada Yii2, dan memperbaiki error hasil temuan testing', NULL, NULL, 2, 2, '2020-07-01 00:12:56', '2020-07-01 00:12:56');
INSERT INTO `ta_logbook` VALUES (194, 71, '1. Migrasi Database Teknik Elektro ke sistem online yang telah dimasukkan data referensi dan data mata kuliah tayang 2. Melakukan hosting sistem OBE sipil di si.ft.uns.ac.id/obesipil, dan meminta data keperluan sistem seperti data referensi kelas, tahun ajaran, dosen pengajar, mahasiswa, mata kuliah, CPMK, CPL, relasi CPMK ke CPL dan data mata kuliah tayang dari semester 1 hingga semester 8', 4, 'Tidak Ada', 'Memperbaiki bug hosting pada sistem obe sipil dan melakukan mapping data keperluan sistem untuk obe sipil', NULL, NULL, 2, 2, '2020-07-01 00:17:22', '2020-07-01 00:17:22');
INSERT INTO `ta_logbook` VALUES (195, 98, '1. Konsultasi pada pembimbing mengenai hasil dari data logger. 2. Pembuatan transfer function pada matlab berdasarkan data yang diperoleh dari data logger menggunakan nilai pole = 2 dan zero = 1 menggunakan Matlab System Identification Toolbox', 3, 'Tidak ada', 'Melanjutkan ke pembuatan state space', NULL, NULL, 2, 2, '2020-07-01 12:58:20', '2020-07-01 12:58:20');
INSERT INTO `ta_logbook` VALUES (196, 102, '1. Menyelesaikan integrasi Simulink-Arduino. Menyelesaikan error komunikasi pada kedua sistem. 2. Memperbaiki error block dan menguji sistem kendali PID. 3. Membuat dan menguji sistem kendali ANFIS. 4. Membuat dan menguji sistem kendali FLC.5. Merapikan interface block block simulink. Untuk pengambilan data dan dokumentasi.', 3, 'Belum ada', 'Mulai menulis laporan TA.', NULL, NULL, 2, 2, '2020-07-01 22:23:08', '2020-07-01 22:23:08');
INSERT INTO `ta_logbook` VALUES (197, 102, '1. Menyelesaikan integrasi Simulink-Arduino. Menyelesaikan error komunikasi pada kedua sistem. 2. Memperbaiki error block dan menguji sistem kendali PID. 3. Membuat dan menguji sistem kendali ANFIS.4. Membuat dan menguji sistem kendali FLC.5. Merapikan interface block block simulink. Untuk pengambilan data dan dokumentasi.', 3, 'Belum ada', 'Mulai menulis laporan TA.', NULL, NULL, 2, 2, '2020-07-02 05:31:47', '2020-07-02 05:31:47');
INSERT INTO `ta_logbook` VALUES (198, 57, 'Melanjutkan penulisan bab 4 hasil dan pembahasan untuk sub bagian dua, yaitu untuk bagian pengujian. Pengujian disini dilakukan dengan metode black box yang hanya akan melihat hasil output sistem berdasarkan inputan user', 4, 'belum ada', 'konsultasi', NULL, NULL, 2, 2, '2020-07-02 23:46:44', '2020-07-02 23:46:44');
INSERT INTO `ta_logbook` VALUES (199, 103, '1. Mengerjakan simulasi simulink module PV dengan mathematic model sesuai dengan studi literature yang telah dibaca 2. Melakukan assembly solar tracker dengan PV yang terpasang dan tanpa PV 3. Menyelesaikan heatsink cooling untuk panel PV 100 WP', 3, '1. Simulasi simulink module PV dengan mathematic model berdasarkan literature yang telah dibaca mengalami algebraic loop error 2. Motor stepper solar tracker tidak mampu mengangkat beban panel 100 WP', '1. Memperbaiki error algebraic loop 2. Mengganti motor stepper dan coding tracker', NULL, 'Ok. Lanjutkan', 2, 1, '2020-07-03 19:26:41', '2020-07-16 11:49:35');
INSERT INTO `ta_logbook` VALUES (200, 57, 'Mengoreksi kembali isi bab 4 hasil dan pembahasan sebelum nantinya di konsultasikan kepada pembimbing satu maupun pembimbing dua. Karena pada penulisan sebelumnya terdapat bagian bagian yang belum disertakan ke dalamnya', 4, 'belum ada', 'mengajukan konsultasi', NULL, NULL, 2, 2, '2020-07-04 18:37:56', '2020-07-04 18:37:56');
INSERT INTO `ta_logbook` VALUES (201, 98, '1. Pembuatan state space berdasarkan dari transfer function yang telah didapatkan sebelumnya menggunakan command tf2ss pada matlab sehingga dapat menunjukkan hasil state space berupa nilai A B C dan D 2. Konsultasi pada pembimbing mengenai hasil state space', 3, 'Tidak ada', 'Simulasi menggunakan simulink untuk PID dan LQG', NULL, NULL, 2, 2, '2020-07-04 21:24:55', '2020-07-04 21:24:55');
INSERT INTO `ta_logbook` VALUES (202, 57, 'Melakukan konsultasi draft tugas akhir hingga bab 4 hasil dan pembahasan kepada pembimbing tugas akhir dua, pak sutrisno secara daring melalui media whatsapp. Tanggapan yang diberikan oleh pak sutrisno cukup baik.', 4, 'belum ada', 'melanjutkan penulisan ke bab 5', NULL, NULL, 2, 2, '2020-07-06 19:29:39', '2020-07-06 19:29:39');
INSERT INTO `ta_logbook` VALUES (203, 71, '1. Melakukan Mapping Data yang dibutuhkan untuk sistem OBE sipil 2. Melakukan import data dan migrasi database ke sistem sipil yang sudah online 3. Membuat RBAC sistem OBE dengan hak akses administrator dan hak akses dosen', 4, 'Perlu memahami RBAC yang telah disediakan oleh Yii2', 'Mempelajari dokumentasi dan penggunaan RBAC pada Yii2', NULL, NULL, 2, 2, '2020-07-07 18:49:57', '2020-07-07 18:49:57');
INSERT INTO `ta_logbook` VALUES (204, 57, 'Melanjutkan penulisan ke bab 5 kesimpulan. Pada bab 5 ini saya menuliskannya menjadi dua sub bab, yaitu sub bab kesimpulan dan sub bab saran. Pada sub bab kesimpulan memiliki dua poin sedangkan pada sub bab saran memiliki empat poin', 5, 'belum ada', 'konsultasi', NULL, NULL, 2, 2, '2020-07-07 19:57:06', '2020-07-07 19:57:06');
INSERT INTO `ta_logbook` VALUES (205, 97, 'Melakukan pengambilan data pada node 2. Data yang diambil berupa data presisi sensor tegangan ZMPT101B dan sensor arus ACS712. Setelah itu dilakukan pengambilan data akurasi pembacaan kedua sensor. Serta pengambilan data time delay dari respon masing-masing relay yang digunakan. Setelah pengambilan data, dilakukan pembuatan grafik melalui software OriginLab.', 4, 'Tidak ada', 'Melakukan pengambilan data node 1', NULL, NULL, 2, 2, '2020-07-07 21:39:17', '2020-07-07 21:39:17');
INSERT INTO `ta_logbook` VALUES (206, 88, '1. mengintegrasikan mqtt.fx dengan data dari thingspeak 2. mencari referensi mengenai topic dan message yang ada pada API MQTT 3. mencari package MQTT yang ada pada Framework Laravel 4. mencari referensi pengintegrasian MQTT yang ada pada Framework Laravel', 4, 'Tidak ada', 'Mengintegrasikan MQTT yang ada pada Laravel dengan Thingspeak', NULL, NULL, 2, 2, '2020-07-08 00:27:59', '2020-07-08 00:27:59');
INSERT INTO `ta_logbook` VALUES (207, 88, '1. Melakukan integrasi antara MQTT yang ada pada laravel dengan thingspeak 2. Mencari referensi mengenai topic yang memiliki multi level topic 3. Mengubah pengaturan dan controller yang ada pada Laravel supaya dapat mengambil multi level topic', 4, 'Tidak ada', 'Menyelesaikan pengintegrasian data dari thingspeak ke mqtt pada laravel', NULL, NULL, 2, 2, '2020-07-08 00:39:05', '2020-07-08 00:39:05');
INSERT INTO `ta_logbook` VALUES (208, 88, '1. Memperbaiki controller supaya dapat mengambil multi level topic pada MQTT yang ada di laravel 2. Mengintegrasikan data dari thingspeak ke MQTT yang ada pada Laravel 3. Mengintegrasikan control supaya dapat mengontrol device yang ada', 4, 'Tidak ada', 'Melakukan pengujian pada control yang ada pada BEMS', NULL, NULL, 2, 2, '2020-07-08 01:15:54', '2020-07-08 01:15:54');
INSERT INTO `ta_logbook` VALUES (209, 102, 'Mengerjakan draf Laporan TA.Mulai dari bagian awal, isi bab satu sampai bab 5, dan bagian akhir lampiran.Selanjutnya mengonsultasikan draf dengan pembimbing satu dan dua untuk mendapat saran mengenai penulisan.', 5, 'Belum ada', 'Mengerjakan revisi mengenai pengujian dan beberapa bagian penulisan.', NULL, NULL, 2, 2, '2020-07-08 05:53:25', '2020-07-08 05:53:25');
INSERT INTO `ta_logbook` VALUES (210, 57, 'Mengajukan konsultasi ke pembimbing satu, yaitu pak subuh pramono. Yang saya ajukan adalah draft tugas akhir yang sudah selesai dari bab pertama hingga bab ke-lima. dan selanjutnya akan konsultasi ke pembimbing dua', 5, 'belum ada', 'konsultasi pembimbing 2', NULL, NULL, 2, 2, '2020-07-08 16:23:20', '2020-07-08 16:23:20');
INSERT INTO `ta_logbook` VALUES (211, 57, 'Mengajukan konsultasi  kepada  dosen pembimbing dua , pak sutrisno . Yang saya ajukan ialah draft tugas  akhir saya yang sudah saya tuliskan dari bab pertama hingga bab 5 kesimpulan. dan selanjutnya jika sudah disetujui, maka akan saya ajukan  untuk semhas ', 5, 'belum ada', 'revisi jika ada', NULL, NULL, 2, 2, '2020-07-09 16:34:53', '2020-07-09 16:34:53');
INSERT INTO `ta_logbook` VALUES (212, 88, '1. Melakukan pengujian pada control yang ada di BEMS 2. Melakukan pengujian sistem informasi BEMS 3. Memperbaiki id device pada halaman control yang tidak cocok dengan hardware 4. Melanjutkan penulisan sampai bab 4 dan memperbaiki serta menambahkan pada bab-bab yang sebelumnya', 4, 'Tidak ada', 'Konsultasi dengan pembimbing mengenai sistem dan draft TA', NULL, NULL, 2, 2, '2020-07-10 09:17:26', '2020-07-10 09:17:26');
INSERT INTO `ta_logbook` VALUES (213, 88, '1. Konsultasi dengan pembimbing mengenai sistem dan draft TA 2. Mencoba pengambilan data dengan menggunakan hardware yang sudah dibuat 3. Melakukan perbaikan pada draft TA (revisi) dan konsultasi dengan pembimbing', 4, 'Tidak ada', 'Mengerjakan revisi pada draft TA jika ada', NULL, NULL, 2, 2, '2020-07-10 20:16:19', '2020-07-10 20:16:19');
INSERT INTO `ta_logbook` VALUES (214, 86, '1. Melakukan desain casing baru untuk balancing robot 2. Melakukan cutting akrilik dengan desain yang telah dibuat 3. Pemindahan, perakitan dan pemasangan komponen dari casing lama ke casing baru 4. Uji coba fungsionalitas komponen pasca pemindahan', 3, 'tidak ada', 'Pembuatan coding algoritma control PID yang baru agar menghasilkan kendali yang lebih smooth', NULL, NULL, 2, 2, '2020-07-10 21:21:52', '2020-07-10 21:21:52');
INSERT INTO `ta_logbook` VALUES (215, 98, 'Membaca literatur yang telah diberikan, juga sedang melakukan pembelian alat dan bahan untuk mencoba menggunakan metode yang baru, nantinya setelah alat datang akan langsung dicoba dan diprogram, lalu disesuaikan dengan metode yang akan digunakan', 3, 'Tidak ada', 'Percobaan menggunakan alat baru', NULL, NULL, 2, 2, '2020-07-11 00:11:57', '2020-07-11 00:11:57');
INSERT INTO `ta_logbook` VALUES (216, 86, 'Melakukan penyempurnaan penggunaan sensor MPU6050. MPU6050 merupakan sensor 6 DOF yang memberikan keluaran 3 axis gyro dan 3 axis accelerometer. Setiap keluaran memiliki kelebihan dan kekurangan masing\". Keluaran gyro tidak terlalu terganggu dengan getaran namun mengalami drifting over time, sedangkan keluaran dari accelerometer tidak mengalami drifting namun sangat mudah terganggu oleh getaran. Maka dari itu digunakan filter untuk mendapatkan sudut yang lebih akurat dengan menggabungkan keluaran dari gyro dan accelerometer.', 3, 'sensor mpu6050 mengalami drift dan error yang cukup tinggi saat motor stepper bergerak. Respon dari mpu6050 kurang cepat', 'Studi literatur, perbaikan coding, kalibrasi lanjutan', NULL, NULL, 2, 2, '2020-07-11 22:18:47', '2020-07-11 22:18:47');
INSERT INTO `ta_logbook` VALUES (217, 86, 'Integrasi arduino uno dan esp8266 pada robot balancing dengan ros pada laptop. ROS melakukan publish data kecepatan linier dan angular, robot balancing menerima data linier dan angular melalui wifi menggunakan esp8266. ESP8266 menyampaikan data melalui serial komunikasi ke arduino uno. Arduino uno melakukan kontrol stepper sesuai data yang diterima.', 3, 'Komunikasi hanya berjalan beberapa saat saja setelah beberapa saat berhenti. Analisa awal karena data yang dikirim kan cukup banyak dengan jeda yang singkat, padahal diperlukan waktu untuk konversi dari hasil komunikasi untuk bisa diolah.', 'Mencari metode konversi data yang lebih cepat dan tepat.', NULL, NULL, 2, 2, '2020-07-12 23:43:49', '2020-07-12 23:43:49');
INSERT INTO `ta_logbook` VALUES (218, 100, '1. Revisi pengambilan data bypass discharging dan pengolahan data. 2. Revisi penulisan draft sekripsi pada abstrack, latar belakang. 3. penambahan arsitektur IoT. 4. penambahan fitur calibrasi arus dan kontrol bypass pada aplikasi.', 4, 'tidak ada', 'konsultasi pendaftaran sidang.', NULL, NULL, 2, 2, '2020-07-13 04:37:42', '2020-07-13 04:37:42');
INSERT INTO `ta_logbook` VALUES (219, 79, '1. Mengecek keluaran dari buck converter menggunakan driver optocoupler 2. Mengecek keluaran dari boost converter menggunakan driver optocoupler 3. Membuat desain PCB dari rangkaian 4. Membuat PCB berdasarkan desain yang telah di buat menggunakan Proterus 7.9', 3, 'tidak ada', '1. Merangkai komponen pada PCB yang telah dibuat 2. Menguji rangkaian pada mode buck dan boost3. Membuat coding pada saat mode CC dan fuzzy control', NULL, NULL, 2, 2, '2020-07-13 15:44:28', '2020-07-13 15:44:28');
INSERT INTO `ta_logbook` VALUES (220, 84, '1. Melakukan perancangan simulasi rangkaian switching dengan driver IR2104/IR2101dengan Proteus ISIS 2. Melakukan desain PCB dan melakukan pencetakan PCB layout 3. Melakukan Perakitan komponen drilling dan soldering 4. Melakukan uji coba hardware', 3, 'Belum ada', '1. Melakukan uji coba prototipe dengan driver motor', NULL, NULL, 2, 2, '2020-07-13 18:58:09', '2020-07-13 18:58:09');
INSERT INTO `ta_logbook` VALUES (221, 102, '1. Mencari referensi/ literatur mengenai spesifikasi hardware maupun software dan setting awal. Mencoba menghubungkan antara hardware dan software yang digunakan. 2. Konsultasi fitur hardware dan rencana penggunaanya.', 3, '1. Beberapa part setting awal masih belum terkoneksi. 2. Referensi tentang hardware masih sedikit.', '1. Mencari build software yang tepat, memahami setiap step pemasangan software. 2. Mencari referensi dari setiap bagian hardware yang digunakan.', NULL, NULL, 2, 2, '2020-01-27 19:36:01', '2020-01-27 19:36:01');
INSERT INTO `ta_logbook` VALUES (222, 86, 'Penyempurnaan komunikasi data serial antara ROS dengan balancing robot. Dengan bantuan library arduino json, komunikasi yang sebelumnya mudah terputus, saat ini sudah stabil dan berjalan dengan baik. Arduinojson memberikan kemudahan dalam melakukan perpindahan data melalui komunikasi serial.', 3, 'tidak ada', 'Kalibrasi antara robot balancing dengan navigasi pada RVIZ', NULL, NULL, 2, 2, '2020-07-13 21:17:53', '2020-07-13 21:17:53');
INSERT INTO `ta_logbook` VALUES (223, 102, 'Mengonsultasikan draf dan mendapat revisi mengenai pengujian sistem, analisis di bab4 diperdalam dan diberi analisis eksak (bukan hanya kualitatif) dan beberapa perbaikan gambar (grafik, foto alat, dan flowchart) serta beberapa penulisan.', 4, 'Belum ada', 'Melakukan perbaikan pada draf sesuai ide referensi yang diberikan', NULL, NULL, 2, 2, '2020-07-13 23:01:44', '2020-07-13 23:01:44');
INSERT INTO `ta_logbook` VALUES (224, 76, 'Dalam modulasi, menambahkan program counter 16 bit untuk mengubah parallel to serial yaitu inputan dtx 16 bit menjadi data 1 bit. Selain itu output sym_clk adalah clock tiap 16 sample_clk.\r\nOutput serial data pada counter 16 bit tadi menjadi input data  yang akan dikirim dalam  modulasi dan menghasilkan output svppm.', 3, 'Tidak ada', 'Membuat block demodulator', NULL, NULL, 2, 2, '2020-07-14 09:48:35', '2020-07-14 09:48:35');
INSERT INTO `ta_logbook` VALUES (225, 98, '1. Simulasi kendali PID berdasarkan diagram blok fungsi alih (transfer function) yang telah didapatkan sebelumnya.\r\n2. Simulasi kendali LQG berdasarkan diagram blok state space yang telah didapatkan sebelumnya.', 3, 'Tidak ada', 'Pembuatan program pada mikrokontroler', NULL, NULL, 2, 2, '2020-07-14 13:58:52', '2020-07-14 13:58:52');
INSERT INTO `ta_logbook` VALUES (226, 98, '1. Pembuatan program kendali posisi menggunakan metode PID pada mikrokontroler Arduino berdasarkan blok diagram yang telah disimulasikan pada Simulink\r\n2. Pembuatan program kendali posisi menggunakan metode LQG pada mikrokontroler Arduino berdasarkan blok diagram yang telah disimulasikan pada Simulink', 3, 'Operasi matriks pada mikrokontroler cukup sulit', 'Menyelesaikan operasi matriks pada mikrokontroler', NULL, NULL, 2, 2, '2020-07-14 13:59:39', '2020-07-14 13:59:39');
INSERT INTO `ta_logbook` VALUES (227, 98, 'Memperbaiki penulisan dalam BAB 3 serta menampilkan perhitungan matriks secara manual pada sub bab perhitungan gain pada LQR dan Kalman Filter sehingga dapat membuktikan dan membandingkan langsung hasil dari perhitungan manual dengan hasil simulasi', 3, 'Tidak ada', 'Lanjut BAB 4', NULL, NULL, 2, 2, '2020-07-14 14:01:51', '2020-07-14 14:01:51');
INSERT INTO `ta_logbook` VALUES (228, 98, 'Menampilkan hasil simulasi Simulink pada kendali PID dan kendali LQG dan menganalisis mengenai parameter rise time, overshoot, undershoot beserta peak time sehingga dapat membandingkan langsung dari kedua metode tersebut', 4, 'Tidak ada', 'Pengujian alat', NULL, NULL, 2, 2, '2020-07-14 14:03:32', '2020-07-14 14:03:32');
INSERT INTO `ta_logbook` VALUES (229, 98, 'Pengujian alat berdasarkan program yang sudah dibuat sebelumnya pada kendali PID dan kendali LQG dalam kendali posisi  menggunakan parameter sudut dimulai dari -23 derajat sehingga dapat menghasilkan plot yang selanjutnya dapat dianalisis mengenai kendali masing - masing.', 4, 'Tidak ada', 'Pengujian parameter lain', NULL, NULL, 2, 2, '2020-07-14 14:05:31', '2020-07-14 14:05:31');
INSERT INTO `ta_logbook` VALUES (230, 102, 'Menganalisis hasil pengujian, mengolah data hasil, membandingkan parameter respons sistem, kemudian menyimpulkan hasil pengujian. Mengonsultasikan lagi kepada pembimbing mengenai perbaikan/ revisi yang dikerjakan.', 5, 'Tidak ada', 'Mendaftar semhas', NULL, NULL, 2, 2, '2020-07-14 15:48:34', '2020-07-14 15:48:34');
INSERT INTO `ta_logbook` VALUES (231, 72, 'Mempelajari kembali coding heksadesimal yang sudah bekerja pada simulasi. Hasilnya ada beberapa tambahan komentar pada coding berikut:\r\n\r\nbyte bldc_step, motor_speed;\r\n \r\nvoid setup() {\r\n  DDRD  |= 0x1C;           // Configure pins 2, 3 and 4 as outputs (0b00011100)\r\n  PORTD  = 0x00;           // Configure pins 2, 3, and 4 as LOW outputs (0b00000000)\r\n  DDRB  |= 0x0E;           // Configure pins 9, 10 and 11 as outputs (0b0001110)\r\n  PORTB  = 0x39;           // Configure pins 9, 10 and 11 as HIGH outputs (0b00111001)\r\n  // Timer1 module setting: set clock source to clkI/O / 1 (no prescaling)\r\n  TCCR1A = 0;              //timer\r\n  TCCR1B = 0x01;           //timer\r\n  // Timer2 module setting: set clock source to clkI/O / 1 (no prescaling)\r\n  TCCR2A = 0;              //timer\r\n  TCCR2B = 0x01;           //timer\r\n  // ADC module configuration\r\n  ADMUX  = 0x60;                     // Configure ADC module and select channel 0\r\n  ADCSRA = 0x84;                     // Enable ADC module with 16 division factor (ADC clock = 1MHz)\r\n  // Pin change interrupt configuration\r\n  PCICR  = 4;                        // Enable pin change interrupt for pins 0 to 7\r\n  PCMSK2 = 0xE0;                     // Enable pin change interrupt for pins 5, 6 and 7\r\n  // BLDC motor first move\r\n  bldc_step = (PIND >> 5) & 7;       // Read hall effect sensors status (PIND: read from PORTD which is arduino pins 0..7)\r\n  bldc_move();                       // Move the BLDC motor (first move)\r\n}\r\n \r\nISR (PCINT2_vect){\r\n  bldc_step = (PIND >> 5) & 7;       // Read hall effect sensors status (PIND: read from PORTD which is arduino pins 0..7)\r\n  bldc_move();                       // Move the BLDC motor\r\n}\r\n \r\nvoid bldc_move(){        // BLDC motor commutation function\r\n  switch(bldc_step){\r\n    case 1:\r\n      AH_CL();\r\n      break;\r\n    case 2:\r\n      BH_AL();\r\n      break;\r\n    case 3:\r\n      BH_CL();\r\n      break;\r\n    case 4:\r\n      CH_BL();\r\n      break;\r\n    case 5:\r\n      AH_BL();\r\n      break;\r\n    case 6:\r\n      CH_AL();\r\n      break;\r\n    default:\r\n      PORTD = 0;\r\n      break;\r\n  }\r\n}\r\n \r\nvoid loop() {\r\n  ADCSRA |= 1 << ADSC;               // Start conversion\r\n  while(ADCSRA & 0x40);              // Wait for conversion complete (64)\r\n  motor_speed = ADCH;                // Read ADC data (8 bits)\r\n  SET_PWM_DUTY(motor_speed);\r\n}\r\n \r\nvoid AH_BL(){\r\n  PORTD &= ~0x14;         // (00010100) Pin 2,4 OFF\r\n  PORTD |=  0x08;         // (00001000) Pin 3 ON\r\n  TCCR2A =  0;            // Turn pin 9 (OC1A) PWM ON (pin 10 & pin 11 OFF)\r\n  TCCR1A =  0x81;         // (10000001)\r\n}\r\nvoid AH_CL(){\r\n  PORTD &= ~0x0C;         // (00001100) Pin 2,3 OFF\r\n  PORTD |=  0x10;         // (00010000) Pin 4 ON\r\n  TCCR2A =  0;            // Turn pin 9 (OC1A) PWM ON (pin 10 & pin 11 OFF)\r\n  TCCR1A =  0x81;         // (10000001)129\r\n}\r\nvoid BH_CL(){\r\n  PORTD &= ~0x0C;         // (00001100) Pin 2,3 OFF\r\n  PORTD |=  0x10;         // (00010000) Pin 4 ON\r\n  TCCR2A =  0;            // Turn pin 10 (OC1B) PWM ON (pin 9 & pin 11 OFF)\r\n  TCCR1A =  0x21;         // (00100001)33\r\n}\r\nvoid BH_AL(){\r\n  PORTD &= ~0x18;         // (00011000) Pin 3,4 OFF\r\n  PORTD |=  0x04;         // (00000100) Pin 2 ON\r\n  TCCR2A =  0;            // Turn pin 10 (OC1B) PWM ON (pin 9 & pin 11 OFF)\r\n  TCCR1A =  0x21;         // (00100001)33\r\n}\r\nvoid CH_AL(){\r\n  PORTD &= ~0x18;         // (00011000) Pin 3,4 OFF\r\n  PORTD |=  0x04;         // (00000100) Pin 2 ON\r\n  TCCR1A =  0;            // Turn pin 11 (OC2A) PWM ON (pin 9 & pin 10 OFF)\r\n  TCCR2A =  0x81;         // (10000001)129\r\n}\r\nvoid CH_BL(){\r\n  PORTD &= ~0x14;         // (00010100) Pin 2,4 OFF\r\n  PORTD |=  0x08;         // (00001000) Pin 3 ON\r\n  TCCR1A =  0;            // Turn pin 11 (OC2A) PWM ON (pin 9 & pin 10 OFF)\r\n  TCCR2A =  0x81;         // (10000001)33\r\n}\r\n \r\nvoid SET_PWM_DUTY(byte duty){\r\n  OCR1A  = duty;                   // Set pin 9  PWM duty cycle\r\n  OCR1B  = duty;                   // Set pin 10 PWM duty cycle\r\n  OCR2A  = duty;                   // Set pin 11 PWM duty cycle\r\n}', 3, 'Belum mengetahui fungsi dari TCCR1A, TCCR1B, TCCR2A, TCCR2B, ADMUX, ADCSRA, PCICR, PCMSK2, ISR, PCINT2, ADCSRA, ADSC, dan ADCH', 'Mengetahui keseluruhan coding diatas', 'Silakan dilanjutkan. Sudah benar prosesnya', NULL, 1, 2, '2020-07-14 18:43:44', '2020-07-24 12:11:28');
INSERT INTO `ta_logbook` VALUES (232, 102, 'Membuat slide presentasi dari laporan yang telah dikerjakan, menyertakan video dokumentasi demonstrasi singkat mengenai kinerja alat, mempelajari dan membuat rangkuman singkat mengenai materi dalam presentasi yang akan disampaikan.', 5, 'Belum ada', 'Mempresentasikan laporan dengan baik.', NULL, NULL, 2, 2, '2020-07-14 19:35:32', '2020-07-14 19:35:32');
INSERT INTO `ta_logbook` VALUES (233, 86, 'Mencoba kontrol motor stepper dengan data yang dihasilkan oleh navigasi pada rviz. Motor stepper dapat bergerak, sesuai data data dari rviz. Namun putaran roda masih belum sesuai dengan representasi di rviz.', 3, 'tidak ada', 'kalibrasi putaran rodo dengan rviz', NULL, NULL, 2, 2, '2020-07-14 22:52:37', '2020-07-14 22:52:37');
INSERT INTO `ta_logbook` VALUES (234, 72, 'Saat ini saya sedang mengerjakan hardware di aplikasi Proteus 8, dimana hardware yang saya buat adalah isolated driver motor bldc tiga fasa pada motor bldc cd-rom. Saya menggunakan bldc cd-rom karena arus nya kecil sehingga bisa disuplai dengan power supply yg tegangannya tidak terlalu besar. Pada driver saya terdapat arduino sebagai pengontrol cara kerja driver dan inverter,. Kemudian  terdapat 6 optocoupler pc817 sebagai saklar digital terisolasi. Keduanya terisolasi menjadi transmitter dan receiver. Pada receiver berfungsi untuk menerima sinyal untuk mendeteksi adanya sinar inframerah yang berasal dari cahaya atau LED. Receiver terdiri dari pin anoda kan katoda. Pada transmitter berfungsi untuk mengirim sinyal ke beban dimana berasal dari phototransistor yang terkena sinar, sehingga kaki collector dan emitter akan terhubung. Lalu terdapat 6 MOSFET, 3 diantara adalah mosfet tipe p untuk dipasang di output high dan 3 lainnya adalah mosfet tipe n untuk dipasang di output low.', 3, 'Pada simulasi switching fasa hanya terdeteksi di Fasa U dan Fasa V, sedangkan sensor hall hanya terdeteksi di Hall U', 'Merangkai driver sesuai dengan rangkaian di simulasi', 'Rangkaian driver mohon disesuaikan dengan simulasi', NULL, 1, 2, '2020-07-15 12:33:11', '2020-07-24 12:12:30');
INSERT INTO `ta_logbook` VALUES (235, 72, 'Membuat coding yang saya gunakan untuk rangkaian driver, coding tersebut yaitu :\r\n//\r\nint UL=4;\r\nint UH=11;\r\nint VL=3;\r\nint VH=10;\r\nint WH=9;\r\nint WL=2;\r\n//hall pin\r\nint H1=5;\r\nint H2=6;\r\nint H3=7;\r\n//\r\nint HU,HV,HW;\r\nint n=0;\r\n//\r\nint Pot,mSpeed;\r\nvoid setup() {\r\n  // put your setup code here, to run once:\r\npinMode(UH,OUTPUT);\r\npinMode(UL,OUTPUT);\r\npinMode(VH,OUTPUT);\r\npinMode(VL,OUTPUT);\r\npinMode(WH,OUTPUT);\r\npinMode(WL,OUTPUT);\r\npinMode(H1,INPUT);\r\npinMode(H2,INPUT);\r\npinMode(H3,INPUT);\r\nanalogWrite(UH,0);\r\nanalogWrite(UL,0);\r\nanalogWrite(VH,0);\r\nanalogWrite(VL,0);\r\nanalogWrite(WH,0);\r\nanalogWrite(WL,0);\r\n\r\nSerial.begin(9600);\r\n\r\n}\r\n\r\nvoid loop() {\r\n  // put your main code here, to run repeatedly:\r\nhall_read();\r\nhall_logic();\r\nmotor_run();\r\npot();\r\n}\r\n\r\nvoid pot(){\r\n  Pot=analogRead(A0);\r\n  mSpeed=map(Pot,200,1023,0,255);\r\n  }\r\n\r\nvoid hall_read(){\r\n  HU=digitalRead(H1);\r\n  HV=digitalRead(H2);\r\n  HW=digitalRead(H3);\r\n  }\r\n\r\nvoid hall_logic(){\r\n  if(HU==1&&HV==0&&HW==0){\r\n    n=1;\r\n    }\r\n  else if(HU==0&&HV==1&&HW==0){\r\n    n=2;\r\n    }\r\n  else if(HU==1&&HV==1&&HW==0){\r\n    n=3;\r\n    }\r\n  else if(HU==0&&HV==0&&HW==1){\r\n    n=4;\r\n    }\r\n  else if(HU==1&&HV==0&&HW==1){\r\n    n=5;\r\n    }\r\n  else if(HU==0&&HV==1&&HW==1){\r\n    n=6;\r\n    };\r\n  }\r\n\r\nvoid motor_run(){\r\nif (pot > 200){\r\n  switch(n){\r\n    case 1:\r\n    //hall sensor value = 001 (UH:WL)\r\n    analogWrite(UL,mSpeed);//pwm\r\n    analogWrite(UH,255);//1\r\n    analogWrite(VL,0);//0\r\n    analogWrite(VH,0);//0\r\n    analogWrite(WL,255);//1\r\n    analogWrite(WH,0);//0\r\n    break;\r\n    case 2:\r\n    //hall sensor value = 010 (VH:UL)\r\n    analogWrite(UL,255);//1\r\n    analogWrite(UH,0);//0\r\n    analogWrite(VL,mSpeed);//pwm\r\n    analogWrite(VH,255);//1\r\n    analogWrite(WL,0);//0\r\n    analogWrite(WH,0);//0\r\n    break;\r\n    case 3:\r\n    //hall sensor value = 011 (VH:WL)\r\n    analogWrite(UL,0);//0\r\n    analogWrite(UH,0);//0\r\n    analogWrite(VL,mSpeed);//pwm\r\n    analogWrite(VH,255);//1\r\n    analogWrite(WL,255);//1\r\n    analogWrite(WH,0);//0    \r\n    break;\r\n    case 4:\r\n    //hall sensor value = 100 (WH:VL)\r\n    analogWrite(UL,0);//0\r\n    analogWrite(UH,0);//0\r\n    analogWrite(VL,255);//1\r\n    analogWrite(VH,0);//0\r\n    analogWrite(WL,mSpeed);//pwm\r\n    analogWrite(WH,255);//1     \r\n    break;\r\n    case 5:\r\n    //hall sensor value = 101 (UH:VL)\r\n    analogWrite(UL,mSpeed);//pwm\r\n    analogWrite(UH,255);//1\r\n    analogWrite(VL,255);//1\r\n    analogWrite(VH,0);//0\r\n    analogWrite(WL,0);//0\r\n    analogWrite(WH,0);//0    \r\n    break;\r\n    case 6:\r\n    //hall sensor value = 110 (WH:UL)\r\n    analogWrite(UL,255);//1\r\n    analogWrite(UH,0);//0\r\n    analogWrite(VL,0);//0\r\n    analogWrite(VH,0);//0\r\n    analogWrite(WL,mSpeed);//pwm\r\n    analogWrite(WH,255);//1    \r\n    break;\r\n  \r\n    }\r\n  }\r\n  else{\r\n    switch(n){\r\n    default:\r\n    analogWrite(UH,0);\r\n    analogWrite(UL,0);\r\n    analogWrite(VH,0);\r\n    analogWrite(VL,0);\r\n    analogWrite(WH,0);\r\n    analogWrite(WL,0);\r\n    break;\r\n    }\r\n  }\r\n}', 3, 'Belum ada fitur pengereman dan tampilan PLX-DAQ pada coding', 'Menerapkan coding di rangkaian yg saya buat di pcb', 'Ok good', NULL, 1, 2, '2020-07-15 12:36:22', '2020-07-24 12:12:57');
INSERT INTO `ta_logbook` VALUES (236, 72, 'Membuat coding yang saya gunakan untuk rangkaian driver, coding tersebut yaitu :\r\n//\r\nint UL=4;\r\nint UH=11;\r\nint VL=3;\r\nint VH=10;\r\nint WH=9;\r\nint WL=2;\r\n//hall pin\r\nint H1=5;\r\nint H2=6;\r\nint H3=7;\r\n//\r\nint HU,HV,HW;\r\nint n=0;\r\n//\r\nint Pot,mSpeed;\r\nvoid setup() {\r\n  // put your setup code here, to run once:\r\npinMode(UH,OUTPUT);\r\npinMode(UL,OUTPUT);\r\npinMode(VH,OUTPUT);\r\npinMode(VL,OUTPUT);\r\npinMode(WH,OUTPUT);\r\npinMode(WL,OUTPUT);\r\npinMode(H1,INPUT);\r\npinMode(H2,INPUT);\r\npinMode(H3,INPUT);\r\nanalogWrite(UH,0);\r\nanalogWrite(UL,0);\r\nanalogWrite(VH,0);\r\nanalogWrite(VL,0);\r\nanalogWrite(WH,0);\r\nanalogWrite(WL,0);\r\n\r\nSerial.begin(9600);\r\n\r\n}\r\n\r\nvoid loop() {\r\n  // put your main code here, to run repeatedly:\r\nhall_read();\r\nhall_logic();\r\nmotor_run();\r\npot();\r\n}\r\n\r\nvoid pot(){\r\n  Pot=analogRead(A0);\r\n  mSpeed=map(Pot,200,1023,0,255);\r\n  }\r\n\r\nvoid hall_read(){\r\n  HU=digitalRead(H1);\r\n  HV=digitalRead(H2);\r\n  HW=digitalRead(H3);\r\n  }\r\n\r\nvoid hall_logic(){\r\n  if(HU==1&&HV==0&&HW==0){\r\n    n=1;\r\n    }\r\n  else if(HU==0&&HV==1&&HW==0){\r\n    n=2;\r\n    }\r\n  else if(HU==1&&HV==1&&HW==0){\r\n    n=3;\r\n    }\r\n  else if(HU==0&&HV==0&&HW==1){\r\n    n=4;\r\n    }\r\n  else if(HU==1&&HV==0&&HW==1){\r\n    n=5;\r\n    }\r\n  else if(HU==0&&HV==1&&HW==1){\r\n    n=6;\r\n    };\r\n  }\r\n\r\nvoid motor_run(){\r\nif (pot > 200){\r\n  switch(n){\r\n    case 1:\r\n    //hall sensor value = 001 (UH:WL)\r\n    analogWrite(UL,mSpeed);//pwm\r\n    analogWrite(UH,255);//1\r\n    analogWrite(VL,0);//0\r\n    analogWrite(VH,0);//0\r\n    analogWrite(WL,255);//1\r\n    analogWrite(WH,0);//0\r\n    break;\r\n    case 2:\r\n    //hall sensor value = 010 (VH:UL)\r\n    analogWrite(UL,255);//1\r\n    analogWrite(UH,0);//0\r\n    analogWrite(VL,mSpeed);//pwm\r\n    analogWrite(VH,255);//1\r\n    analogWrite(WL,0);//0\r\n    analogWrite(WH,0);//0\r\n    break;\r\n    case 3:\r\n    //hall sensor value = 011 (VH:WL)\r\n    analogWrite(UL,0);//0\r\n    analogWrite(UH,0);//0\r\n    analogWrite(VL,mSpeed);//pwm\r\n    analogWrite(VH,255);//1\r\n    analogWrite(WL,255);//1\r\n    analogWrite(WH,0);//0    \r\n    break;\r\n    case 4:\r\n    //hall sensor value = 100 (WH:VL)\r\n    analogWrite(UL,0);//0\r\n    analogWrite(UH,0);//0\r\n    analogWrite(VL,255);//1\r\n    analogWrite(VH,0);//0\r\n    analogWrite(WL,mSpeed);//pwm\r\n    analogWrite(WH,255);//1     \r\n    break;\r\n    case 5:\r\n    //hall sensor value = 101 (UH:VL)\r\n    analogWrite(UL,mSpeed);//pwm\r\n    analogWrite(UH,255);//1\r\n    analogWrite(VL,255);//1\r\n    analogWrite(VH,0);//0\r\n    analogWrite(WL,0);//0\r\n    analogWrite(WH,0);//0    \r\n    break;\r\n    case 6:\r\n    //hall sensor value = 110 (WH:UL)\r\n    analogWrite(UL,255);//1\r\n    analogWrite(UH,0);//0\r\n    analogWrite(VL,0);//0\r\n    analogWrite(VH,0);//0\r\n    analogWrite(WL,mSpeed);//pwm\r\n    analogWrite(WH,255);//1    \r\n    break;\r\n  \r\n    }\r\n  }\r\n  else{\r\n    switch(n){\r\n    default:\r\n    analogWrite(UH,0);\r\n    analogWrite(UL,0);\r\n    analogWrite(VH,0);\r\n    analogWrite(VL,0);\r\n    analogWrite(WH,0);\r\n    analogWrite(WL,0);\r\n    break;\r\n    }\r\n  }\r\n}', 3, 'Belum ada fitur pengereman dan tampilan PLX-DAQ pada coding', 'Menerapkan coding di rangkaian yg saya buat di pcb', 'Silakan dilanjutkan ke tahap berikutnya', NULL, 1, 2, '2020-07-15 12:36:23', '2020-07-24 12:13:37');
INSERT INTO `ta_logbook` VALUES (237, 51, 'Pertama konsultasi konsep dan referensi monitoring arus dan tegangan pada arc discharge. Membaca literatur tentang arc discharge dan monitoring untuk arus tinggi.  Membuat rancangan skematik untuk monitoring arus dan tegangan.  Melakukan simulasi rangkaian pembagi tegangan sebagai sistem monitoring tegangan menggunakan multisim.  Mempresentasikan hasil simulasi kepada dosen pembimbing.  Mengambil data pada alat yang akan digunakan untuk proyek TA. Membuat rancangan BAB 1 dan BAB 2.   ', 1, 'Kendala dalam menuangkan ide dalam tulisan', 'Menyelesaikan rangkain alat dan menyelesaikan bab 1 dan bab 2 ', '', '', 2, 2, '2019-07-05 04:20:40', '2019-07-05 04:20:40');
INSERT INTO `ta_logbook` VALUES (238, 51, 'Melakukan pengambilan data arus dan tegangan pada plasma arc discharge tahap satu menggunakan sensor arus WCS1500. Sensor arus dan tegangan diitegrasikan menggunakan instrustar. Dilakukan lima kali percobaan dengan nilai arus yang bebeda, yaitu 10A, 20A, 40A, 70A dan 100A', 3, 'Sulit mengambil data menggunakan Instrustar karena belum mengerti cara menggunakan Instrustar', 'Mempelajari cara mengambil data menggunakan Instustar melalui sumber referensi dari internet dan mencoba-coba sendiri.', NULL, NULL, 2, 2, '2020-07-15 15:10:39', '2020-07-15 15:10:39');
INSERT INTO `ta_logbook` VALUES (239, 51, 'Mengambil data arc discharge tahap dua yaitu mengulang kembali percobaan yang sebelumnya. Karena pada tahap pertama belum berhasil mengambil data arus dan tegangan. Pada percobaan ini menggunakan fitur data recorder, kemudian data arus dan tegangan dari instrustar dapat dikonversi menjadi data excel. Dilakukan percobaan menggunakan sensor Arus dari WCS1500 dan sensor tegangan menggunakan probes instrustar secara simultan. Data arus dari sensor arus ditampilkan menggunakan program LabView. Sedangkan data tegangannya ditampilkan menggunakan fitur data recorder dari software MultiVir Analyzer.', 3, 'tidak ada', 'Mengolah data arus dan tegangan yang sudah didapatkan', NULL, NULL, 2, 2, '2020-07-15 15:57:16', '2020-07-15 15:57:16');
INSERT INTO `ta_logbook` VALUES (240, 51, 'Melakukan pengambila data arus dan tegangan arc discharge tahap tiga, karena pada percobaan yang sebelum nya. Nilai arus yang di dapatkan menggunakan sensor WCS 1500 kurang akurat, lebih akurat pengambilan data menggunakan instrustar. Data yang diambil instrustar dapat mencapai 1ns per data. Pengambilan data arus dan tegangan dilakukan secara simultan menggunakan fitur data recorder. Sehingga nilai arus dan tegangannya lebih akurat.', 3, 'Menghubungkan sensor arus WCS 1500 langsung pada isntrstar, agar data nya dapat lansung terbaca menggunakan data recorder', 'Mengolah data arus dan tegangan yang telah di dapatkan', NULL, NULL, 2, 2, '2020-07-15 16:03:14', '2020-07-15 16:03:14');
INSERT INTO `ta_logbook` VALUES (241, 51, 'Melakukan pengambilan data arus dan tegangan kembali, karena data yang sebelumnya tidak valid. Hal ini dikarenakan ada kemungkinan elektroda menempel selama proses arc discharge, sehingga tidak ada lonjakan arus pada hasil data pembacaan arus nya. Dilakukan pengambilan arc discharge dengan metode yang sama seperti yang sebelumnya, namun elektroda ditempatkan pada jarak sedekat mungkin agar tidak menempel satu sama lain.', 3, 'Sulit menempatkan elektroda pada jarak yang dekat meggunakan tangan, karena cahaya yang dihasilkan membuat kita sulit untuk melihat jarak antara elektroda.', 'Mengolah data arus dan tegangan yang telah di dapatkan', NULL, NULL, 2, 2, '2020-07-15 16:08:47', '2020-07-15 16:08:47');
INSERT INTO `ta_logbook` VALUES (242, 51, 'Mengolah data arus dan tegangan yang telah didapatkan menggunakan software Oirigin. Data arus dan tegangan dibandingkan agar dapat diketahui bagaimana hubungan arus dan tegangan pada arc discharge. Hal ini dilakukan pada lima arus input yang berbeda, agar dapat terlihat bagaimana pengaruh arus input terhadap arus arc discharge.', 3, 'tidak ada', 'melakukan analisis arus dan tegangan', NULL, NULL, 2, 2, '2020-07-15 16:11:33', '2020-07-15 16:11:33');
INSERT INTO `ta_logbook` VALUES (243, 51, 'Data arus dan tegangan yang telah didapat digunakan untuk mengetahui konsumsi daya dan jarak antara elektroda pada masing-masing arus input. Dilakukan studi literatur untuk menemukan rumus untuk mencari jarak antara elektroda. Sedangkan menghitung konsumsi daya nya menggunakan rumus daya seperti biasa.', 4, 'Data yang didapat sangat banyak mencapai 10.000 data', 'Mengolah data arus dan tegangan menjad jumlah konsumsi daya dan jarak antara elektroda', NULL, NULL, 2, 2, '2020-07-15 16:17:07', '2020-07-15 16:17:07');
INSERT INTO `ta_logbook` VALUES (244, 51, 'Konsultasi dengan pembimbing cara untuk menghitung jarak antara elektroda. Pertama dicari jumlah muatan dan kapasitansi, menentukan luas area pada ujung elektroda yang mengalami pengikisan akibat proses arc discharge.', 4, 'data yang didapatkan terlalu banyak', 'Menghitung rumus untuk mencari jarak antara elektroda', NULL, NULL, 2, 2, '2020-07-15 16:20:56', '2020-07-15 16:20:56');
INSERT INTO `ta_logbook` VALUES (245, 51, 'Menganalisis hasil perhitungan yang telah di dapatkan yaitu, jumlah muatan, kapasitansi, jarak antara elektroda, dan daya nya. Data hasil perhitungan di tampilkan dalam bentuk grafik berserta standar deviasi nya. Menganalisa data tersebut dengan membandingkan dengan ke lima percobaan yang berbeda, dan bagaimana pengaruhnya terhadap arus input.', 4, 'tidak ada', 'Menulis hasil dan analisa', NULL, NULL, 2, 2, '2020-07-15 16:24:33', '2020-07-15 16:24:33');
INSERT INTO `ta_logbook` VALUES (246, 51, 'Konsultasi hasil dan analisa yang telah di dapatkan kepada pembimbing. Kemudian mendaftarkan judul penelitian untuk paper ICIMECE 2019. Data dan analisa yang telah dikonsultasikan dibuat menjadi abstrak untuk di summit mengikuti konferensi paper.', 4, 'tidak ada', 'Menulis paper untuk ICIMECE 2019', NULL, NULL, 2, 2, '2020-07-15 16:27:46', '2020-07-15 16:27:46');
INSERT INTO `ta_logbook` VALUES (247, 51, 'Memaparkan hasil penelitian dalam konferensi ICIMECE 2019. Grafik yang dipaparkan hanya pada data arus 10A , namun analisa dari lima hasil percobaan dijelaskan secara keseluruhan. Input perbaikan yang didapatkan setelah konferensi digunakan untuk memperbaiki hasil dan analisa dalam skripsi.', 4, 'tidak ada', 'Mencari referensi tambahan mengenai arc discharge', NULL, NULL, 2, 2, '2020-07-15 16:34:29', '2020-07-15 16:34:29');
INSERT INTO `ta_logbook` VALUES (248, 51, 'Melakukan studi literatur tentang plasma untuk mengetahui jenis plasma  arc discharge yang dihasilkan. Investigasi jenis plasma dilakukan dengan membandingkan arus arc yang dihasilkan dengan grafik jenis-jenis plasma berdasarkan arus dan tegangannya.', 2, 'tidak ada', 'Menulis tinjauan pustaka tentang plasma', NULL, NULL, 2, 2, '2020-07-15 16:38:37', '2020-07-15 16:38:37');
INSERT INTO `ta_logbook` VALUES (249, 51, 'Konsultasi secara online dengan pembimbing. Mencari referensi tentang ionisasi pada plasma, membagi grafik arus menjadi dua step yaitu step arus elektron dan arus ion. Mencari bagaimana membedakan arus ion dan arus elektron dalam arus arc.', 2, 'Mencari referensi tentang arus ion dan arus elektron', 'Melakukan studi literatur', NULL, NULL, 2, 2, '2020-07-15 16:42:58', '2020-07-15 16:42:58');
INSERT INTO `ta_logbook` VALUES (250, 51, 'Membuat histogram dari tegangan arc untuk melihat bagaimana persebaran arus ion dan arus elektron dalam arus arc. Setelah melihat dua data terbanyak maka kita dapat menentukan nilai arus ion dan arus elektron menggunakan perhitungan.', 4, 'menemukan rumus untuk menghitung arus ion dan arus elektron', 'Menghitung arus ion dan arus elektron', NULL, NULL, 2, 2, '2020-07-15 16:48:05', '2020-07-15 16:48:05');
INSERT INTO `ta_logbook` VALUES (251, 51, 'Konsultasi dengan pembimbing mengenai hasil perhitungan arus ion dan aru elektron. Hasil nya arus ion dan arus elektron yang didapatkan tidak valid karena tidak memenuhi karakteristik arus arc. Jumlah arus ion dan arus elektron harus sama dengan arus arc yang ditampilkan pada grafik arus.', 4, 'variabel dalam perhitungan yang sulit ditemukan', 'Mencar referensi tentang arus ion dan arus elektron', NULL, NULL, 2, 2, '2020-07-15 16:52:49', '2020-07-15 16:52:49');
INSERT INTO `ta_logbook` VALUES (252, 51, 'Konsultasi dengan pembimbing mengenai penulisan skripsi. Membuat kesimpulan dan saran dari hasil penelitian. Membuat daftar pustaka, daftar gambar, dan daftar tabel. Memeriksa format penulisan sesuai dengan panduan tugas akhir.', 5, 'tidak ada', 'Membuat draft skripsi', NULL, NULL, 2, 2, '2020-07-15 16:56:44', '2020-07-15 16:56:44');
INSERT INTO `ta_logbook` VALUES (253, 86, 'kalibrasi putaran roda balancing robot dengan rviz. Pembuatan kode transformasi kecepatan sudut linear x dan angular z pada rviz kemudian ditransfer ke balancing robot melalui esp8266. Kode transformasi kecepatan diolah pada esp8266 kemudian hasil berupa kecepatan roda kiri dan roda kanan di kirimkan ke arduino uno melalui serial komunikasi', 3, 'kalibrasi masih belum berhasil karena pada balancing masih terjadi kesalahan pengukuran sudut, dimana sudut mengalami drifting', 'kalibrasi ulang', NULL, NULL, 2, 2, '2020-07-15 23:13:27', '2020-07-15 23:13:27');
INSERT INTO `ta_logbook` VALUES (254, 71, '1. Membuat tulisan BAB 4 dan BAB 5\r\n2. Membuat manual book untuk user\r\n3. Membuat Clone sistem OBE untuk teknik mesin\r\n4. Melakukan Mapping data kebutuhan sistem OBE teknik mesin\r\n5. Melakukan migrasi sistem OBE teknik mesin ke hosting online', 4, 'belum ada', 'melakuka konsul kepada pembimbing 1 dan pembimbing 2 serta segera melakukan pendaftaran seminar hasil', NULL, NULL, 2, 2, '2020-07-16 10:10:57', '2020-07-16 10:10:57');
INSERT INTO `ta_logbook` VALUES (255, 98, 'Menyelesaikan analisis pengujian serta kesimpulan pada skripsi, serta memperbaiki revisi yang diberikan oleh dosen pembimbing, yaitu menambahkan daftar singkatan dan daftar notasi. Serta memperbaiki tabel - tabel pada pengujian. Sudah meminta izin untuk mendaftar seminar hasil.', 5, 'Tidak ada', 'Daftar Seminar Hasil', NULL, NULL, 2, 2, '2020-07-17 12:43:58', '2020-07-17 12:43:58');
INSERT INTO `ta_logbook` VALUES (256, 102, 'Memperbaiki revisi draf dan presentasi dari masukan penguji serta pembimbing setelah seminar hasil, Mempelajari dan mencari jawaban dari pertanyaan/ bahasan yang dipertanyakan pada seminar hasil yang lalu.', 5, 'Belum ada', 'Berkonsultasi dan mendaftar pendadaran.', NULL, NULL, 2, 2, '2020-07-17 20:24:05', '2020-07-17 20:24:05');
INSERT INTO `ta_logbook` VALUES (257, 91, 'Melakukan analisa arus kas dan perhitungan daya total dengan pada bab 4 untuk tiap hasil desain pembangkit yang telah dibuat dengan membandingkan hasilnya dari 5 ibukota pada tiap provinsi disajikan dalam bentuk tabel', 4, 'tidak ada', 'membuat coding program matlab', NULL, NULL, 2, 2, '2020-07-17 22:31:33', '2020-07-17 22:31:33');
INSERT INTO `ta_logbook` VALUES (258, 91, 'Melakukan penambahan pada coding matlab untuk metode algoritma genetika yaitu rating pembangkit, radiasi sinar matahari, kecepatan angin serta rumus yang digunakan untuk mencari output dari pembangkit PV dan WTG dari lokasi terbaik yang digunakan sebagai acuan', 4, 'tidak ada', 'menulis hasil dan pembahasan untuk sistem PV dan WTG serta grid', NULL, NULL, 2, 2, '2020-07-17 22:37:19', '2020-07-17 22:37:19');
INSERT INTO `ta_logbook` VALUES (259, 91, 'Melakukan analisa perbandingan sistem PV dengan WTG standalone + baterai serta perbandingan sistem On-Grid dengan Off-Grid dengan menggunakan lokasi terbaik yaitu kota semarang yang digunakan sebagai acuan', 4, 'tidak ada', 'menulis kesimpulan dan saran', NULL, NULL, 2, 2, '2020-07-17 22:48:39', '2020-07-17 22:48:39');
INSERT INTO `ta_logbook` VALUES (260, 96, '\"1. Membuat Layout PCB dari simulasi menggunakan Proteus-Ares untuk kemudian dicetak pada PCB\r\n2. melengkapi komponen yang dibutuhkan untuk mengerjakan hardware\r\n3. menyempurnakan simulasi pada proteus.    \"', 3, 'tidak ada', '1. mencetak layout pcb yang telah dibuat \r\n2. memulai mengerjakan hardware\"', NULL, NULL, 2, 2, '2020-07-18 10:24:34', '2020-07-18 10:24:34');
INSERT INTO `ta_logbook` VALUES (261, 96, '1. mencetak layout pcb yang sebelumnya telah dibuat di Proteus-Ares\r\n2. Assembly komponen yang digunakan ke papan PCB yang telah selesai dibuat\r\n3. melakukan pengetesan terkait jalannya alat yang telah dibuat', 3, 'tidak ada', '1. pembenahan susunan komponen\r\n2. pengujian alat pada motor bldc', NULL, NULL, 2, 2, '2020-07-18 10:26:18', '2020-07-18 10:26:18');
INSERT INTO `ta_logbook` VALUES (262, 96, '1. melakukan pembenahan susunan komponen pada papan PCB yang telah dibuat sebelum dilakukan pengujian\r\n2. Pengecekan Jalur setelah pemasangan komponen agar tidak terjadi hubung singkat maupun eror pada alat\r\n3. pengujian pada motor BLDC', 3, 'tidak ada', '1. melakukan pengujian menyeluruh\r\n2. pengambilan data', NULL, NULL, 2, 2, '2020-07-18 10:27:01', '2020-07-18 10:27:01');
INSERT INTO `ta_logbook` VALUES (263, 91, 'Menulis kesimpulan dari hasil dan pembahasan pada bab 4 meliputi hasil desain pembangkit, analisis ekonomi pembangkit, optimalisasi hasil pembangkit, perbandingan PV dengan WTG, perbandingan On-Grid dengan Off-Grid.', 5, 'tidak ada', 'konsultasi pembimbing dan mendaftar semhas', NULL, NULL, 2, 2, '2020-07-18 10:46:43', '2020-07-18 10:46:43');
INSERT INTO `ta_logbook` VALUES (264, 96, '1. melakukan pengujian driver motor pada motor BLDC dan pengecekan apakah berjalan dengan baik tanpa adanya konslet\r\n2. melakukan pengambilan data pada motor BLDC dan pengujian pembebanan pada motor BLDC', 3, 'tidak ada', '1. melakukan pengambilan seluruh data yang diperlukan\r\n2. memulai penulisan laporan skripsi', NULL, NULL, 2, 2, '2020-07-18 20:37:18', '2020-07-18 20:37:18');
INSERT INTO `ta_logbook` VALUES (265, 79, '1. Merangkai komponen pada PCB yang telah dibuat ulang menggunakan software Eagle\r\n2. Menguji rangkaian dengan melihat tegangan keluaran pada saat mode buck converter dan boost converter dengan menggunakan program sederhana', 3, 'tidak ada', '1. Membuat coding untuk mode CC dan fuzzy control\r\n2. Menguji alat untuk mengisi daya baterai', NULL, NULL, 2, 2, '2020-07-19 19:59:48', '2020-07-19 19:59:48');
INSERT INTO `ta_logbook` VALUES (266, 86, 'Kalibrasi antara robot balancing dengan sistem ROS untuk bergerak maju dan mundur sesuai dengan command pada ROS telah berhasil dilakukan. Command berupa kecepatan linear x yang dikonversi menjadi kecepatan roda kiri dan kanan. Kecepatan roda kiri dan kanan diterima oleh ESP dan dikirim ke arduino uno melalui komunikasi serial. Pengaturan kecepatan disesuaikan dengan sudut setpoint dari balancing robot.', 3, 'Kalibrasi masih pada satu sumbu, dimana robot baru bisa berjalan maju mundur, belum dilakukan kalibrasi untuk berbelok', 'kalibrasi dengan inputan kecepatan sudut angular z', NULL, NULL, 2, 2, '2020-07-19 23:38:08', '2020-07-19 23:38:08');
INSERT INTO `ta_logbook` VALUES (267, 72, 'Sudah merangkai driver di PCB dan mencoba coding yg dibuat. Hasilnya motor sudah bisa bergerak, namun motor bergerak konstan dan tidak ada pengaruh dari potensiometer. Padahal tegangan dari potensiometer sudah bisa berubah setelah diukur dengan multimeter saat motor berputar', 3, 'Tidak ada pengaruh dari potensiometer', 'Driver sudah bisa jalan dengan gerak motor bisa diatur dengan potensiometer', 'Driver terlihat sudah jalan', NULL, 1, 2, '2020-07-20 08:33:07', '2020-07-24 12:14:18');
INSERT INTO `ta_logbook` VALUES (268, 72, 'Pada rangkaian driver perlu ditambahkan monitoring daya input dan daya output. Karena tidak memungkinkan mengukur ketiga input DC pada sensor hall dan mengukur ketiga output AC pada motor maka hanya mengukur masing-masing satu input dan satu output saja, dengan asumsi input dan output lain nilainya sama.', 3, 'Belum mencoba di rangkaian sembarang', 'Mencoba di rangkaian sembarang dan digabungkan di coding driver', 'yang dimaksud rangkaian sembarang itu apa?', NULL, 1, 2, '2020-07-20 08:37:41', '2020-07-24 12:15:02');
INSERT INTO `ta_logbook` VALUES (269, 60, 'Pengambilan Data Arc Discharge. Pengambilan data dilakukan menggunakan peralatan welding, instrustar, dan sensor arus yang telah dibuat oleh Ayub. Menambah pengetahuan tentang Plasma dan tindak lanjutnya, disertai konsultasi skripsi.', 3, 'Masih belum menemukan sensor yang tepat', 'Membaca literatur lebih lanjut. Membongkar rangkaian sensor yang bisa digunakan dari alat yang sudah ada. ', NULL, NULL, 2, 2, '2019-08-02 15:40:01', '2019-08-02 15:40:01');
INSERT INTO `ta_logbook` VALUES (270, 60, 'Merangkai generator kit, merakit beberapa komponen alat pembangkit tegangan, serta melakukan beberapa pengujian terhadap pembangkit tegangan tersebut. Membuat pembangkit tegangan 15 kV dari baterai lithium dan generator kit. ', 3, 'kabel yang digunakan perlu diganti', 'membeli kabel dan beberapa komponen baru, seperti probes, dll untuk pengambilan data', NULL, NULL, 2, 2, '2019-08-19 13:17:03', '2019-08-19 13:17:03');
INSERT INTO `ta_logbook` VALUES (271, 60, 'Konsultasi dengan dosen pembimbing. Konsultasi mengenai sensor arus yang akan digunakan pada alat. Sensor arus yang dipakai, konsep pemasangan sensor pada alat, serta konsultasi sensor lain apabila bisa digunakan juga', 3, 'Besarnya tegangan ditakutkan dapat merusak sensor', 'Membeli sensor terlebih dahulu untuk percobaan', NULL, NULL, 2, 2, '2019-08-19 14:18:22', '2019-08-19 14:18:22');
INSERT INTO `ta_logbook` VALUES (272, 60, 'Kamis 22 Agustus 2019 Meeting lab, memaparkan progress report tentang plasma, konsultasi mengenai sensor arus yang akan digunakan dan membeli sensor arus ina219, untuk percobaan pengambilan data minggu berikutnya. ', 3, 'Menunggu datangnya sensor arus', 'Merangkai sensor arus', NULL, NULL, 2, 2, '2019-08-26 12:20:42', '2019-08-26 12:20:42');
INSERT INTO `ta_logbook` VALUES (273, 60, 'Mengerjakan hardware boost inverter untuk menghasilkan plasma, serta membaca berbagai literasi mengenai penggunaan sensor arus ina219. Melakukan pengukuran tegangan pada boost inverter menggunakan probes', 3, 'Belum terdapatnya arduino dan adanya kemungkinan rusaknya inverter boost sehingga tidak menghasilkan plasma', 'Mencari arduino dan menunggu inverter boost lainnya untuk digunakan pada saat penelitian di hari selanjutnya', NULL, NULL, 2, 2, '2019-08-26 12:24:39', '2019-08-26 12:24:39');
INSERT INTO `ta_logbook` VALUES (274, 60, 'Senin, 2 September 2019. Konsultasi mengenai pergantian sensor arus. Sensor arus INA219 diganti menjadi INA169. Diganti karena perbedaan output antara 2 sensor arus tersebut. Dan melakukan pembacaan literatur mengenai sensor arus tersebut', 3, 'Melakukan pembacaan ulanh tentang sensor yg akan digunakan', 'Mencoba sensor arus di Arduino', NULL, NULL, 2, 2, '2019-09-05 10:54:15', '2019-09-05 10:54:15');
INSERT INTO `ta_logbook` VALUES (275, 60, 'Rabu, 4 September 2019. Konsultasi mengenai percobaan sensor arus pada arduino. Sensor Arus INA219 akan dicoba terlebih dahulu di arduino sebelum dicoba di intrustar. Dikarenakan alat pembangkit sedang rusak', 3, 'Tutorial mengenai Sensor Arus INA169 yang masih sedikit di internet', 'membaca literatur dan mempraktekannya di arduino', NULL, NULL, 2, 2, '2019-09-05 10:58:14', '2019-09-05 10:58:14');
INSERT INTO `ta_logbook` VALUES (276, 60, 'Senin, 9 September 2019 Mempelajari program yang akan digunakan pada sensor arus apabila memakai arduino, membuat program untuk sensor arus INA169 pada arduino. Membuat rangkaian untuk sensor arus INA169 pada arduino', 3, 'terdapat beberapa komponen yg belum ada, harus beli dulu', 'membeli komponen', NULL, NULL, 2, 2, '2019-09-10 14:04:25', '2019-09-10 14:04:25');
INSERT INTO `ta_logbook` VALUES (277, 60, 'Selasa, 10 September 2019 Mempelajari sensor arus INA169 untuk intrustar, penggunaan berserta rumus yg akan digunakan setelah data keluaran dari intrustar. Akan dicoba langsung menggunakan intrustar sebagai output', 3, 'terdapat komponen yg belum dibeli', 'membeli komponen', NULL, NULL, 2, 2, '2019-09-10 14:07:49', '2019-09-10 14:07:49');
INSERT INTO `ta_logbook` VALUES (278, 60, 'Rabu, 25 September 2019 Konsultasi mingguan mengenai sensor arus dan tegangan pada plasma. Mengkonsultasikan tentang percobaan yang telah dilakukan dan mencari solusi. Telah dilakukan percobaan pengambilan data menggunakan intrustar tetapi belum mendapatkan hasil', 3, 'Tegangan yang terlalu tinggi', 'mencari cara lainnya untuk mendapatkan data', NULL, NULL, 2, 2, '2019-09-26 15:27:42', '2019-09-26 15:27:42');
INSERT INTO `ta_logbook` VALUES (279, 60, 'Kamis, 26 September 2019 Membaca literasi, untuk mendapatkan keterangan mengenai pengukuran tegangan tinggi dan arus pada plasma, merangkai dan memprogram sensor arus untuk plasma agar dapat segera mengambil data', 3, 'belum menemukan literasi mengenai pengukuran plasma tegangan tinggi', 'Langsung melakukan percobaan pada alat', NULL, NULL, 2, 2, '2019-09-26 15:30:35', '2019-09-26 15:30:35');
INSERT INTO `ta_logbook` VALUES (280, 60, 'Pengambilan data menggunakan sensor arus INA 169. Pengambilan data arus menggunakan sensor arus ina169 yang terhubung dengan arduino, namun setelah beberapa kali dicoba, terdapat batasan waktu jumlah data yang di ambil per satuan detik. ', 3, 'terdapat batasan masalah baru yang perlu didiskusikan', 'konsultasi kembali dgn dosen pembimbing', NULL, NULL, 2, 2, '2019-10-14 19:23:37', '2019-10-14 19:23:37');
INSERT INTO `ta_logbook` VALUES (281, 60, 'Mencoba kembali pengukuran sensor arus dan sensor tegangan. Sensor arus menggunakan INA169, sensor tegangan menggunakan intrustar. Pertama - tama menggunakan rangkaian inverter tanpa papan pcb, tetapi belum mendapatkan hasil karena tidak terdapat plasma. Lalu dicoba kembali menggunakan inverter yang sebelumnya. Sudah mendapatkan hasil, namun terdapat kendala karena pengambilan data yang tertunda akibat kesalahan teknis', 3, 'Belum diketahui penyebab mengapa rangkaian inverter tanpa pcb tidak bisa dinyalakan', 'menganalisis kembali data dan mencoba pengambilan data kembali', NULL, NULL, 2, 2, '2019-10-21 15:25:08', '2019-10-21 15:25:08');
INSERT INTO `ta_logbook` VALUES (282, 60, 'Pengambilan data voltase pada sisi sekunder. Pengambilan data dilakukan untuk mengetahui nilai voltase pada output. Pengambilan data mendapatkan hasil. Hasil yang didapatkan masih perlu divalidasi dan dianalisis lebih lanjut', 3, 'Hasil yang didapatkan belum valid', 'Melakukan pengambilan data kembali', NULL, NULL, 2, 2, '2019-10-28 13:15:56', '2019-10-28 13:15:56');
INSERT INTO `ta_logbook` VALUES (283, 60, 'Pengambilan data arus dan tegangan pada sisi primer, serta pengambilan data tegangan pada sisi primer dan sekunder. Dilanjutkan dengan mengambil data resistansi pada alat yang digunakan. Didapatkan ketiga data tersebut yang dilanjutkan dikirim ke dosen pembimbing', 3, 'Data yang didapatkan belum dianalisis', 'menganalisis data', NULL, NULL, 2, 2, '2019-10-30 23:57:02', '2019-10-30 23:57:02');
INSERT INTO `ta_logbook` VALUES (284, 60, 'Pengambilan data menggunakan sensor ACS712. Pengambilan data dilakukan 2 kali. Pengambilan data menggunakan Sensor arus ACS712 5A, dan menggunakan sensor ACS712 30 A. Pengambilan data dilanjutkan dgn cara simultan antara arus dan tegangan, tetapi belum mendapatkan hasil kendala errornya alat pengambilan data', 3, 'Error pada intrustar', 'Mencoba lagi', NULL, NULL, 2, 2, '2019-11-25 23:04:27', '2019-11-25 23:04:27');
INSERT INTO `ta_logbook` VALUES (285, 81, 'Uij coba trafo flyback dengan merangkai rangkaian driver flyback. Trafo flyback di-switching dengan frekuensi tinggi. Hasil pengujian berhasil, dengan indikator yaitu trafo mampu mengeluarkan tegangan dan arus. Setelah pengujian driver flyback, yaitu pengujian switch on-off pada sistem balancing berdasarkan algoritma atau baterai yang ingin dibalancing.', 3, 'Tidak ada', 'Uji coba mosfet sistem balancing dan cutoff', NULL, NULL, 2, 2, '2020-07-20 21:52:13', '2020-07-20 21:52:13');
INSERT INTO `ta_logbook` VALUES (286, 81, 'Uji coba switch on-off pada mosfet sistem balancing dan cut-off berhasil dilakukan, dengan indikator yaitu switch berjalan sesuai dengan algoritma sel baterai yang ingin di-discharge atau dibalancing. dan mosfet cut-off berfungsi dengan baik, dapat memutus rangkaian sesuai dengan keinginan.', 3, 'Tidak ada', 'Pengambilan data monitoring', NULL, NULL, 2, 2, '2020-07-20 21:55:24', '2020-07-20 21:55:24');
INSERT INTO `ta_logbook` VALUES (287, 81, 'Pengujian pembacaan sensor merupakan pengujian sensor pembaca tegangan tiap sel baterai yang menggunakan prinsip pembagi tegangan. Pengujian dilakukan tanpa menggunakan beban selama 30 menit untuk mengetahui tingkat akurasi dan presisi pembacaan sensor.', 4, 'Tidak ada', 'Pengambilan data balancing', NULL, NULL, 2, 2, '2020-07-20 21:59:46', '2020-07-20 21:59:46');
INSERT INTO `ta_logbook` VALUES (288, 81, 'Pengujian sistem balancing dilakukan untuk mengetahui perfoma penyeimbang tegangan baterai pada BMS. Instrumen yang digunakan pada pengujian ini berupa catu daya RIGOL DP831 dan DC load Rigol DL3031, dan adapun pengujian dibagi menjadi 3 kasus. Kasus 1 dihadapkan pada tegangan salah satu sel mendekati nilai tertinggi dan tiga sel yang lain memiliki nilai tegangan yang lebih rendah. Kasus 2 dihadapkan pada tegangan 2 sel berada mendekati nilai maksimal dan 2 sel lainnya dengan tegangan yang lebih rendah. Dan kasus 3 dihadapkan pada tegangan 3 sel baterai dibuat mendekati nilai maksimal dan 1 sel lainnya memiliki tegangan yang lebih rendah.', 4, 'Tidak ada', 'Pengambilan data proteksi', NULL, NULL, 2, 2, '2020-07-20 22:02:36', '2020-07-20 22:02:36');
INSERT INTO `ta_logbook` VALUES (289, 81, 'Pengujian ini dimaksudkan untuk mengetahui kinerja BMS pada saat terjadi pengoperasian yang tidak sesuai dengan keamanan dari battery pack. Proteksi BMS yang diuji berupa pengujian over-charge, over-discharge, over-current, dan over-temperature.', 4, 'Tidak ada', 'analisis data dan penulisan', NULL, NULL, 2, 2, '2020-07-20 22:03:31', '2020-07-20 22:03:31');
INSERT INTO `ta_logbook` VALUES (290, 81, 'Analisis data untuk sistem monitoring nilai tegangan memiliki root mean square error (RMSE) sebesar 0,1650 atau tingkat akurasi sebesar 99,8349 % dan nilai mean relative standard deviation (MRSD) sebesar 0,2301 atau tingkat presisi sebesar 99,7699 %.', 4, 'Tidak ada', 'Analisis data balancing', NULL, NULL, 2, 2, '2020-07-20 22:04:56', '2020-07-20 22:04:56');
INSERT INTO `ta_logbook` VALUES (291, 81, 'Analisis data untuk sistem balancing yaitu, mampu melakukan penyeimbangan hingga perbedaan tegangan antar baterai sebesar 0,3 V dan lama waktu yang dibutuhkan untuk menyeimbangkan tergantung pada besarnya perbedaan tegangan dan banyaknya baterai yang memiliki tegangan berbeda', 4, 'Tidak ada', 'Analisis data proteksi', NULL, NULL, 2, 2, '2020-07-20 22:06:19', '2020-07-20 22:06:19');
INSERT INTO `ta_logbook` VALUES (292, 81, 'Analisis data untuk sistem proteksi yaitu, sistem proteksi dapat bekerja dengan baik untuk mengatasi permasalahan seperti over-charge, over-discharge, over-current dan over-temperature. Proteksi over-charge dapat dilakukan seketika pemantauan tegangan mendeteksi adanya tegangan baterai yang melebihi batas tegangan lebih besar dari 4,20 V. Proteksi over-discharge dapat dilakukan seketika pemantauan tegangan mendeteksi adanya tegangan baterai yang melebihi batas kurang dari 3,60 V. Proteksi over-current dapat dilakukan seketika pemantauan arus mendeteksi adanya arus charging atau discharging baterai yang melebihi batas lebih dari 3,0 A. Proteksi over-temperature dapat dilakukan seketika pemantauan temperatur mendeteksi adanya temperatur baterai yang melebihi batas 50oC.', 4, 'Tidak ada', 'Penulisan skripsi dan konsultasi', NULL, NULL, 2, 2, '2020-07-20 22:09:01', '2020-07-20 22:09:01');
INSERT INTO `ta_logbook` VALUES (293, 81, 'Penulisan skripsi dan melakukan perbaikan hingga sampai bab 5. Melakukan konsultasi online dengan kedua pembimbing. Mulai menyicil membuat presentasi powerpoint. Menentukan tanggal dan mendaftar seminar hasil', 5, 'Tidak ada', 'Seminar hasil', NULL, NULL, 2, 2, '2020-07-20 22:12:17', '2020-07-20 22:12:17');
INSERT INTO `ta_logbook` VALUES (294, 96, '1. melakukan pengambilan seluruh data yang diperlukan , berupa nilai kecepatan, nilai bukaan potensio, nilai pwm, arus dan tegangan\r\n2. menguji pembebanan dan respon pada sistem yang telah dibuat\r\n3 . memulai penulisan laporan skripsi', 4, 'tidak ada', '1. menyusun laporan skripsi\r\n2. membenahi data yang kurang', NULL, NULL, 2, 2, '2020-07-21 18:55:13', '2020-07-21 18:55:13');
INSERT INTO `ta_logbook` VALUES (295, 96, '1. menyusun laporan skripsi dan memasukkan data data yang telah diambil\r\n2. konsultasi dengan pembimbing mengenai laporan yang telah disusun, apakah perlu ditambahkan atau tidak\r\n3. menyusun packaging untuk rangkaian yang dibuat', 4, 'tidak ada', '1. membenahi revisian dari pembimbing', NULL, NULL, 2, 2, '2020-07-21 18:57:48', '2020-07-21 18:57:48');
INSERT INTO `ta_logbook` VALUES (296, 96, '1. merapikan pacakging pada alat yang telah dibuat, berupa penyusunan pada bidang akrilik\r\n2. menambah revisian dari pembimbing dengan menguji pemberian variasi pembebanan pada sistem untuk mengetahui respon dan keandalan dari sistem', 4, 'tidak ada', '1. konsultasi dengan pembimbing', NULL, NULL, 2, 2, '2020-07-21 18:59:34', '2020-07-21 18:59:34');
INSERT INTO `ta_logbook` VALUES (297, 96, '1. konsultasi pada pembimbing mengenai hasil pengujian yang telah dilakukan\r\n2. melakukan pengujian untk mengetahui Respon waktu transien pada motor BLDC\r\n3. merapikan penyusunan BAB 2 dan menambahkan subbab mengenai sistem kendali otomatis', 4, 'tidak ada', '1. mengecek ulang draft yang sudah dibuat\r\n2. konsultasi ke pembimbing', NULL, NULL, 2, 2, '2020-07-21 19:01:50', '2020-07-21 19:01:50');
INSERT INTO `ta_logbook` VALUES (298, 96, '1. konsultasi ke pembimbing mengenai laporan yang telah dibuat\r\n2. menambahkan pembahasan mengenai sistem kendali otomatis yang telah diaplikasikan di rangkaian\r\n3. menyempurnakan rangkaian dengan menambahkan rangkaian monitoring dengan menggunakan Blynk', 4, 'tidak ada', '1. menyusun bab 5 mengenai kesimpulan dan saran', NULL, NULL, 2, 2, '2020-07-21 19:03:52', '2020-07-21 19:03:52');
INSERT INTO `ta_logbook` VALUES (299, 96, '1. mengecek ulang draft yang telah dibuat dan kesesuaiannya antara tujuan dan hasil \r\n2. membuat kesimpulan dan saran pada bab 5 yang sesuai dengan tujuan \r\n3. konsultasi ke pembimbing untuk mengajukan pendaftaran seminar hasil', 5, 'tidak ada', 'mendaftarkan seminar hasil', NULL, NULL, 2, 2, '2020-07-21 19:05:35', '2020-07-21 19:05:35');
INSERT INTO `ta_logbook` VALUES (300, 72, 'Menerapkan kerja motor BLDC pada pompa air pada motor BLDC CD-ROM. Karena kecepatan pompa air adalah konstan, maka perlu menghilangkan bagian potensiometer di codingnya. Setelah jadi codingnya kemudian diterapkan di hardware. Jika sudah bisa diterapkan di hardware maka akan ditemukan hubungan antara nilai PWM, duty cycle, dan rpm ketika motor BLDC dalam keadaan tidak diberi beban', 3, 'Coding belum bisa di compile', 'Mengganti coding yang sudah dibuat minggu kemarin supaya bisa di compile kemudian diterapkan di hardware', 'silakan dilanjut', NULL, 1, 2, '2020-07-22 16:35:17', '2020-07-24 12:15:46');
INSERT INTO `ta_logbook` VALUES (301, 86, 'pembuatan program pada arduino untuk menerima inputan kecepatan angular z, digunakan untuk kontrol stepper untuk berbelok, untuk berbelok robot tetap harus mengalami proses penambahan sudut  kemudian ditambahkan perbedaan kecepatan antara roda kiri dan kanan', 3, 'kalibrasi yang cukup sulit, karena tidak adanya debugging saat uji coba', 'Uji coba robot untuk maju mundur dan berbelok', NULL, NULL, 2, 2, '2020-07-23 08:29:11', '2020-07-23 08:29:11');
INSERT INTO `ta_logbook` VALUES (302, 86, 'Uji coba navigasi sederhana pada ROS, kemudian data dikirimkan ke robot, sehingga robot dapat bergerak sesuai perintah langsung dari navigasi ROS, mengamati pergerakan robot dan melakukan pengukuran kalibrasi ROS', 3, 'robot masih belum stabil', 'Uji coba tracking simulasi', NULL, NULL, 2, 2, '2020-07-23 08:44:54', '2020-07-23 08:44:54');
INSERT INTO `ta_logbook` VALUES (303, 86, 'pembuatan sketsa denah ruangan real life, melakukan pembuatan denah ruangan real life pada simulasi di gazebo berdasarkan sketsa yang dibuat, uji coba simulasi model robot pada gazebo dengan model ruangan simulasi', 3, 'tidak ada', 'menghubungkan simulasi gazebo dengan rviz', NULL, NULL, 2, 2, '2020-07-23 08:57:39', '2020-07-23 08:57:39');
INSERT INTO `ta_logbook` VALUES (304, 86, 'menghubungkan simulasi gazebo pada rviz, model robot ditampilkan pada rviz, data output sensor laser dimunculkan pada rviz, melakukan uji coba pergerakan manual dengan keyboard, antara gazebo dan rviz pergerakan sudah sama', 3, 'tidak ada', 'pembuatan map', NULL, NULL, 2, 2, '2020-07-23 09:08:27', '2020-07-23 09:08:27');
INSERT INTO `ta_logbook` VALUES (305, 86, 'Pembuatan map, pembuatan map dilakukan dengan gmapping, pembuatan dilakukan dengan cara menggerakan robot manual melalui keyboard, kemudian di arahkan menuju ke seluruh denah map, map yang dihasilkan disimpan', 3, 'tidak ada', 'uji coba hasil map', NULL, NULL, 2, 2, '2020-07-23 09:11:54', '2020-07-23 09:11:54');
INSERT INTO `ta_logbook` VALUES (306, 57, 'Melanjutkan mencari referensi tambahan untuk model dan format penulisan bab 4 hasil dan pembahasan. Penacrian masih bersumber dari karya ilmiah skripsi maupun tugas akhir yang sudah pernah dibuat sebelumnya dan dipublikasikan di Internet.', 4, 'belum ada', 'Memulai penulisan bab 4', NULL, NULL, 2, 2, '2020-07-23 09:14:45', '2020-07-23 09:14:45');
INSERT INTO `ta_logbook` VALUES (307, 57, 'Menyusun kerangka penulisan bab 4 hasil dan pembahasan. Rencananya penulisan tugas akhir untuk bab 4 hasil dan pembahasan ini akan dibagi menjadi dua sub bab. Yaitu implementasi dan juga pengujian software.', 4, 'belum ada', 'memulai penulisan', NULL, NULL, 2, 2, '2020-07-23 09:15:41', '2020-07-23 09:15:41');
INSERT INTO `ta_logbook` VALUES (308, 86, 'Uji coba hasil generating map, file map di hubungkan dengan rviz dan simulasi gazebo, map dapat dimuat pada rviz, model robot juga dapat dimunculkan ke gazebo, dari hasil pemuatan map, dapat dilakukan navigasi', 3, 'tidak ada', 'uji coba tracking', NULL, NULL, 2, 2, '2020-07-23 09:17:51', '2020-07-23 09:17:51');
INSERT INTO `ta_logbook` VALUES (309, 57, 'Menulis bab 4 hasil dan pembahasan. Penulisan didasarkan pada kerangka yang telah dibuat sebelumnya. Pada kali ini, yang ditulis adalah bagian implementasi. Mulai dari dashboard hingga halaman pembuatan perintah bot.', 4, 'belum ada', 'konsultasi', NULL, NULL, 2, 2, '2020-07-23 09:20:39', '2020-07-23 09:20:39');
INSERT INTO `ta_logbook` VALUES (310, 57, 'Mengajukan konsultasi ke pembimbing satu, yaitu pak subuh pramono. Yang saya ajukan adalah draft tugas akhir yang sudah selesai dari bab pertama hingga bab ke-lima. dan selanjutnya akan konsultasi ke pembimbing dua', 5, 'belum ada', 'konsultasi ke pembimbing dua', NULL, NULL, 2, 2, '2020-07-23 09:24:31', '2020-07-23 09:24:31');
INSERT INTO `ta_logbook` VALUES (311, 57, 'Mengajukan konsultasi  kepada  dosen pembimbing dua , pak sutrisno . Yang saya ajukan ialah draft tugas  akhir saya yang sudah saya tuliskan dari bab pertama hingga bab 5 kesimpulan. dan selanjutnya jika sudah disetujui, maka akan saya ajukan  untuk semhas', 5, 'belum ada', 'revisi jika ada', NULL, NULL, 2, 2, '2020-07-23 09:25:30', '2020-07-23 09:25:30');
INSERT INTO `ta_logbook` VALUES (312, 86, 'Uji coba tracking simulasi, melakukan pemunculan gazebo, melakukan pemunculan sistem navigasi, melakukan pemunculan rviz, mencoba fitur 2D nav goal, 2D nav goal dicoba pada rviz, robot dapat bergerak sesuai tujuan yang ditentukan', 4, 'terjadi beberapa kesalahan dan perlu dilakukan beberapa konfigurasi', 'uji coba tracking real', NULL, NULL, 2, 2, '2020-07-23 09:25:55', '2020-07-23 09:25:55');
INSERT INTO `ta_logbook` VALUES (313, 57, 'Membuat persiapan untuk seminar hasil. Persiapan berupa mengoreksi kembali TA yang sudah dibuat. selain itu juga memersiapkan presentasi yang nantinya akan digunakan pada seminar hasil. Juga mencoba menghitung waktu yang dibutuhkan untuk presentasi.', 5, 'belum ada', 'seminar hasil', NULL, NULL, 2, 2, '2020-07-23 09:28:26', '2020-07-23 09:28:26');
INSERT INTO `ta_logbook` VALUES (314, 86, 'Uji coba navigasi pada robot real, memunculkan simulasi gazebo, memunculkan sistem navigasi, memunculkan RVIZ, mengkoneksikan robot dengan sistem robot, memberikan command titik tujuan pada sistem navigasi', 4, 'terjadi beberapa error, sehingga perlu kalibrasi dan konfigurasi', 'pendaftaran semhas', NULL, NULL, 2, 2, '2020-07-23 09:31:06', '2020-07-23 09:31:06');
INSERT INTO `ta_logbook` VALUES (315, 79, '1. Melakukan pengujian dan kalibrasi sensor, kalibrasi sensor tegangan (pembagi tegangan) dengan memvariasikan tegangan input dengan kenaikan 0.5 volt hasil yang didapat akan digunakan untuk kalibrasi sensor tegangan tersebut. Menguji pembacaan sensor arus, menggunakan ACS712 5A \r\n2. Membuat koding untuk mode CC dan Fuzzy menggunakan Arduino IDE', 3, 'tidak ada', '1. Melakukan pengambilan data untuk mengisi daya baterai Li-ion', NULL, NULL, 2, 2, '2020-07-23 10:31:44', '2020-07-23 10:31:44');
INSERT INTO `ta_logbook` VALUES (316, 103, '1. Membuat dan upload program motor stepper dan sensor LDR untuk solar tracker \r\n2. Melakukan penyolderan sensor LDR pada PCB \r\n3. Membaca literatur heatsink cooling\r\n4. Menyelesaikan desain 2D dan 3D untuk heatsink', 3, 'Tidak ada', '1. Uji coba solar tracker menggunakan Panel PV 100 WP \r\n2. Membeli sensor suhu MLX90614, sensor arus INA219, SD card module', NULL, NULL, 2, 2, '2020-07-24 17:23:09', '2020-07-24 17:23:09');
INSERT INTO `ta_logbook` VALUES (317, 76, 'Memuat clock dengan PLL dan LPMCounter. Frekuensi PLL diatur untuk menentukan besar clock yang akan menjadi inputan pada sistem. Pada perancangan ini, besar frekunsi PLL diatur 50MHz dan di counter menggunakan LPMCounter sebanyak 2 pangkat 12.', 3, 'tidak ada', 'membuat delay menggunakan FIFO', NULL, NULL, 2, 2, '2020-07-26 07:40:43', '2020-07-26 07:40:43');
INSERT INTO `ta_logbook` VALUES (318, 76, 'Membuat PRBS15. PRBS dibuat pada sistem ini sebagai input random yang menghasilkan output satu bit. Output dari PRBS ini nanti yang akan dicabangkan menjadi dua jalur yaitu yang langsung menuju block BER dan yang melewati modulasi, error generator, dan demodulasi sebelum menuju ke BER.', 3, 'Tidak ada', 'membuat delay menggunakan FIFO', NULL, NULL, 2, 2, '2020-07-26 07:42:06', '2020-07-26 07:42:06');
INSERT INTO `ta_logbook` VALUES (319, 76, 'Pembuatan block FIFO pada sistem tujuannya adalah untuk delay. Jadi, output dari PRBS tadi menjadi input pada block FIFO yang juga mendapat inputan maksimal 4 bit delay. Input bit dari PRBS yang sudah terdelay pada block ini akan menghasilkan output yang langsung akan dibandingkan dengan output dari block demodulasi di block BER.', 3, 'Tidak ada', 'menyempurnakan block modulasi dan demodulasi', NULL, NULL, 2, 2, '2020-07-26 07:43:17', '2020-07-26 07:43:17');
INSERT INTO `ta_logbook` VALUES (320, 76, 'Mengedit block modulasi. Pada block modulasi terdapat input dtx yang berasal dari output PRBS dan input dimming 3 bit dimana input dimming ini juga terkoneksi pada input dimming di demodulasi. Pada block modulasi menghasilkan output yang akan menjadi inputan pada block error generator.', 3, 'tidak ada', 'memeriksa ulang block demodulasi', NULL, NULL, 2, 2, '2020-07-26 07:44:40', '2020-07-26 07:44:40');
INSERT INTO `ta_logbook` VALUES (321, 76, 'Membuat block demodulasi. Pada block demodulasi terdapat input dimming yang terkoneksi dengan input dimming pada block modulasi. Input svppm pada block ini didapat dari output pada error generator. Pada block ini juga terdapat input enable, dimana saat implementasi di FPGA, setelah semua reset di on dan off kan, lalu harus meng on kan input enable pada block demodulasi ini agar saat sistem dapat berjalan. Output result dari block ini akan menjadi input pada block BER untuk dibandingkan dengan  output FIFOdelay.', 3, 'tidak ada', 'membuat error generator', NULL, NULL, 2, 2, '2020-07-26 07:45:56', '2020-07-26 07:45:56');
INSERT INTO `ta_logbook` VALUES (322, 76, 'Pembuatan block error generator. Pembuatan block error generator pada dasarnya adalah sebagai pengganti untuk Analog Front-End. Pada block ini mendapat inputan dari ouput modulasi dan input number error 16 bit, dimana number error nanti akan menjadi input error pada implementasi di FPGA. Output dari block ini menjadi input ke block demodulasi.', 3, 'tidak ada', 'mengedit block bit error rate', NULL, NULL, 2, 2, '2020-07-26 07:47:02', '2020-07-26 07:47:02');
INSERT INTO `ta_logbook` VALUES (323, 76, 'Block bit error rate adalah block hasil dari dua output yang sudah dijelaskan sehingga dengan membandingkan kedua output tersebut maka akan mendapatkan hasil Bit Error Rate nya. Hasil BER yang didapat telah diatur pada program menggunakan logika XOR sehingga jika ke dua inputan pada block BER berbeda maka hasilnya 1 dan jika kedua inputan sama maka hasilnya 0 yang berarti tidak ada error', 3, 'tidak ada', 'meg-upload program ke FPGA dan melakukan pengujian alat', NULL, NULL, 2, 2, '2020-07-26 07:48:34', '2020-07-26 07:48:34');
INSERT INTO `ta_logbook` VALUES (324, 76, 'Tahap pengujian alat integrasi bit error rate dengan modulasi dan demodulasi. Didapatkan pengaruh clock, dimming, dan delay.\r\nClock sebelumnya telah dibuat mengguanakan PLL dan LPMCounter. Frekuensi PLL yang diatur adalah 50MHz dan nilai LPMCounter 2pangkat12. Output LPMCounter (q) akan di wire dengan sistem dan menjadi input q[5] pada sistem. Semakin besar nilai q, maka clock akan semakin lambat dan semakin kecil nilai q maka clock akan semakin cepat.\r\nDelay dibuat untuk bisa mensinkron dan menyelaraskan output modulasi dan demodulasi. Setelah melalui berbagai percobaan, delay yang didapat agar gelombang modulasi dan demodulasi sinkron adalah sebesar 4.\r\nInput dimming juga berpengaruh pada sinkronisasi gelombang modulasi dan demodulasi. Setelah melalui berbagai percobaan, nilai dimming yang sesuai agar gelombang modulasi dan demodulasi sinkron adalah 4.', 4, 'tidak ada', 'menganalisa pengaruh error generator pada integrasi ber dengan vppm', NULL, NULL, 2, 2, '2020-07-26 07:51:05', '2020-07-26 07:51:05');
INSERT INTO `ta_logbook` VALUES (325, 76, 'Pengujian alat, mendapatkan pengaruh error generator pada hasil BER.\r\nInput dari error generator sangat berpengaruh pada output dari BER. Error generator yang dibuat adalah 16 bit dimana setiap bitnya diinputkan melalui switch yang terhubung pada pin GPIO FPGA. Kondisi switch yang diatur adalah pull-up yaitu jika ditekan maka kondisi 0.', 4, 'tidak ada', 'melakukan integrasi BER dan analog front-end', NULL, NULL, 2, 2, '2020-07-26 07:52:54', '2020-07-26 07:52:54');
INSERT INTO `ta_logbook` VALUES (326, 76, 'Mengedit file quartus dengan menghilangkan block error generator dan meng set pin input dan output svppm pada modulasi dan demodulasi untuk duhubungkan dengan rangkaian analog front end. Lalu mengcompile dan mengupload ulang ke FPGA.', 3, 'tidak ada', 'melakukan integrasi BER dan rangkaian analog front end', NULL, NULL, 2, 2, '2020-07-26 07:56:18', '2020-07-26 07:56:18');
INSERT INTO `ta_logbook` VALUES (327, 76, 'Melakukan integrasi Bit Error Rate (BER) dengan rangkaian Analog Front-End. Integrasi antara BER dengan rangkaian analog sudah berhasil dilakukan walau masih menunjukkan banyak error yang terdeteksi. Akan dilakukan penyempurnaan untuk integrasi ini.', 4, 'Ingin melakukan komunikasi serial menggunakan UART, namun kabel USB RS232 masih belum terdeteksi oleh port COM di PC', 'Membuat draft TA dan mengkomunikasikan BER dengan komunikasi serial agar hasil BER dapat terbaca di PC', NULL, NULL, 2, 2, '2020-07-26 08:00:10', '2020-07-26 08:00:10');
INSERT INTO `ta_logbook` VALUES (328, 98, '1. Penambahan pengujian beban pada kendali posisi VTOL sesuai dengan revisi pada seminar hasil.\r\n2. Perbaikan kata bahasa asing yang belum italic sesuai dengan revisi pada seminar hasil\r\n3. Penambahan diagram blok pemodelan sistem sesuai dengan revisi pada seminar hasil', 4, 'Tidak ada', 'Daftar pendadaran', NULL, NULL, 2, 2, '2020-07-26 21:05:21', '2020-07-26 21:05:21');
INSERT INTO `ta_logbook` VALUES (329, 79, '1. Membuat coding untuk fuzzy dua input berupa nilai suhu dan nilai delta suhu lalu terdapat satu input berupa nilai pengurangan atau penambahan pwm.\r\n2. Mencoba sensor suhu DS18B20 pada alat untuk masukan dari fuzzy control\r\n3. Menguji coding Constant Current untuk mengisi daya baterai Lithium Ion', 3, 'tidak ada', '1. Mengambil data secara\r\n2. Memperbaiki draft TA', NULL, NULL, 2, 2, '2020-07-27 12:47:46', '2020-07-27 12:47:46');
INSERT INTO `ta_logbook` VALUES (330, 103, '1. Melakukan uji coba solar tracker dengan panel PV 100 WP\r\n2. Melakukan coding sensor suhu dan sensor arus\r\n3. Membuat skematik/soldering rangkaian sensor suhu dan sensor arus \r\n4. Memasukkan desain 2D/3D heatsink ke bengkel bubut', 3, '1, Solar tracker mengalami keadaan \"lock\" tidak bisa berputar kearah barat atau pun timur', '1. Memperbaiki coding dan wiring dari solar tracker \r\n2. Mengganti panel PV ukuran 100 WP menjadi 50 WP', NULL, NULL, 2, 2, '2020-07-27 15:40:54', '2020-07-27 15:40:54');
INSERT INTO `ta_logbook` VALUES (331, 79, 'Mengambil data untuk pengujian akurasi dan presisi sensor pembagi tegangan dan mengambil data respon pulsa driver mosfet, nilai pwm yang dibangkitkan, serta tegangan output dari buck boost converter dengan beban resistor 32ohm', 3, 'tidak ada', 'Mengambil data pengujian pada saat pengisian daya baterai', NULL, NULL, 2, 2, '2020-07-29 08:50:17', '2020-07-29 08:50:17');
INSERT INTO `ta_logbook` VALUES (332, 87, 'Mencari komponen yang akan digunakan untuk kendali motor induksi 3 fasa. Komponen yang akan digunakan adalah motor induksi 3 fasa, butuh 2 karena 1 motor untuk dikontrol dan motor lainnya berfungsi sebagai beban. Lalu ada Inverter Schneider Altivar sebagai driver dari motor yang akan dikontrol. Kemudian ada Arduino sebagai mikrokontroller utama dari rangkaian. Dilengkapi dengan sensor tegangan untuk mengukur tegangan, dan sensor IR untuk mengukur kecepatan putar (RPM) dari motor yang dikontrol. Mencari referensi tentang alat yang akan dirancang.', 1, 'Tidak ada', 'Setelah alat datang, mulai merancang alat seperti yang sudah direncanakan', NULL, NULL, 2, 2, '2020-07-30 12:02:53', '2020-07-30 12:02:53');
INSERT INTO `ta_logbook` VALUES (333, 72, 'Pembuatan hardware dengan dua arduino beserta pembuatan komparator motor BLDC untuk disambungkan ke rangkaian driver. Komparator dibuat supaya driver lebih butuh sedikit pengkabelan dalam penghubungan ke sensor motor BLDC. Menggunakan dua arduino karena arduino satu membaca logika sensor hall dan arduino lainnya memonitor arus dan tegangan', 3, 'Coding arduino tidak dapat menjalankan hardware, sedangkan sensor di motor tidak dapat dibaca oleh arduino melalui rangkaian komparator', 'Membuat hardware baru dengan cara etching dan membuat komparator baru', NULL, NULL, 2, 2, '2020-08-01 17:52:00', '2020-08-01 17:52:00');
INSERT INTO `ta_logbook` VALUES (334, 103, '1. Memperbaiki coding dari tracker agar tidak stuck dalam kondisi \"lock\"\r\n2. Mengganti panel surya ukuran 100 WP dengan 50 WP agar motor stepper mampu mengangkat beban panel surya\r\n3. Heatsink masuk tahap pengerjaan (pemotongan alumunium)', 3, 'Solar tracker masih mengalami keadaan \"lock\"', '1. Memperbaiki coding dan wiring solar tracker \r\n2. Memasang rangkaian motor stepper dan rangkaian sensor serta panel ke rangka besi', NULL, NULL, 2, 2, '2020-08-04 13:25:59', '2020-08-04 13:25:59');

-- ----------------------------
-- Table structure for ta_matkul
-- ----------------------------
DROP TABLE IF EXISTS `ta_matkul`;
CREATE TABLE `ta_matkul`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ta_id` int(15) NULL DEFAULT NULL,
  `nama_matkul` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `kode_matkul` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `ip` float NULL DEFAULT NULL,
  `huruf` varchar(6) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `id_ta`(`ta_id`) USING BTREE,
  CONSTRAINT `ta_matkul_ibfk_1` FOREIGN KEY (`ta_id`) REFERENCES `ta` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 187 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ta_matkul
-- ----------------------------
INSERT INTO `ta_matkul` VALUES (88, 33, 'Pembangkitan Tenaga Listrik\r\n', 'EL1407', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (89, 33, 'Teknik Tegangan Tinggi\r\n', 'EL1507', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (90, 33, 'Analisis Sistem Tenaga\r\n', 'EL1607', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (91, 34, 'Perlengkapan Sistem Tenaga\r\n', 'EL1508', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (92, 34, 'Transmisi dan Distribusi\r\n', 'EL1408', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (93, 34, 'Manajemen Energi\r\n', 'EL1608', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (94, 35, 'Elektronika Daya\r\n', 'EL0502', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (95, 35, 'Analisis Sistem Tenaga\r\n', 'EL1607', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (96, 35, 'Instrumentasi\r\n', 'EL0304', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (97, 36, 'Pembangkitan Tenaga Listrik\r\n', 'EL1407', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (98, 36, 'Teknik Tegangan Tinggi\r\n', 'EL1507', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (99, 36, 'Analisis Sistem Tenaga\r\n', 'EL1607', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (100, 37, 'Teknik Proteksi', 'EL1509', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (101, 37, 'Manajemen Energi', 'EL1608', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (102, 37, 'Kualitas Daya', 'ELP18', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (103, 38, 'Sistem Berbasis Mikroprosesor', 'EL4507', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (104, 38, 'Sistem Kontrol Terintegrasi', 'EL4608', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (105, 38, 'Sistem Otomasi', 'EL4508', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (106, 39, 'Mekatronika', 'EL0504', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (107, 39, 'Sistem Berbasis Mikroprosesor', 'EL4507', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (108, 39, 'Sistem Kontrol Terinegrasi', 'EL4608', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (109, 40, 'Sistem Otomotif', 'EL0603', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (110, 40, 'HMI', 'EL4607', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (111, 40, 'Teknik Kendali Digital', 'EE4024-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (112, 41, 'Perancangan Sistem Digital', 'EE3602-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (113, 41, 'Teknik Pengolahan Isyarat Digital', 'EL2508\r\n', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (114, 41, 'Sistem Tertanam dan Periferal', 'EE3502-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (115, 42, 'Pemrograman Jaringan Web', 'EL3609\r\n', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (116, 42, 'Sistem Informasi', 'EE3505-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (117, 42, 'Sistem Pendukung Keputusan', 'EE4025-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (118, 43, 'Teknik Komputasi', 'EL0204\r\n', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (119, 43, 'Kecerdasan Buatan', 'EE0702-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (120, 43, 'Pengenalan Pola', 'ELP36\r\n', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (121, 44, 'Sistem Pendukung Keputusan', 'EE4025-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (122, 44, 'Pemrograman Lanjut', 'EE3603-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (123, 44, 'Teknologi Basis Data', 'EL3409', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (124, 45, 'Sistem Kendali Adaptif', 'ELP42', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (125, 45, 'HMI', 'EL4607', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (126, 45, 'Sistem Berbasis Mikroprosesor', 'EE2504-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (127, 46, 'Elektronika Frekuensi Tinggi', 'ELP706\r\n', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (128, 46, 'Sistem Tertanam dan Periferal', 'EE3502-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (129, 46, 'Elektronika Digital', 'EL2507\r\n', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (130, 47, 'Sistem Penyimpanan Energi', 'EE4030-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (131, 47, 'Elektronika Daya', 'EE1602-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (132, 47, 'Instrumentasi', 'EE0402-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (133, 48, 'Managemen Energi', 'EL1608', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (134, 48, 'Energi Baru Terbarukan', 'EE0602-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (135, 48, 'Perancangan Pembangkit Energi Baru Terbarukan', 'EE4027-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (136, 49, 'Instrumentasi', 'EE0402-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (137, 49, 'Sistem Berbasis Mikroprosesor', 'EE2504-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (138, 49, 'Sistem Terintegrasi', 'EE2603-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (139, 50, 'Energi Baru Terbarukan', 'EE0602-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (140, 50, 'Manajemen Energi', 'EL1608', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (141, 50, 'Perencanaan dan Manajemen Energi', 'EE4029-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (142, 51, 'Elektronika Daya', 'EE1602-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (143, 51, 'Teknik Proteksi', 'EE1601-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (144, 51, 'Smart Grid', 'EE4005-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (145, 52, 'Pembangkitan Tenaga Listrik', 'EE1501-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (146, 52, 'Energi Baru Terbarukan', 'EE0602-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (147, 52, 'Smart Grid', 'EE4005-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (148, 53, 'Elektronika Daya', 'EE1602-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (149, 53, 'Teknologi dan Kendaraan Listrik', 'ELP17\r\n', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (150, 53, 'Teknik Kendali Digital', 'EE4024-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (151, 54, 'Elektronika Daya', 'EE1602-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (152, 54, 'Sistem Penyimpanan Energi', 'EE4030-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (153, 54, 'Teknologi Transportasi dan Kendaraan Listrik', 'EE4006-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (154, 55, 'Mekatronika', 'EE0502-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (155, 55, 'Pengolahan Citra', 'EE4008-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (156, 55, 'Kecerdasan Buatan', 'EE0702-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (157, 56, 'Sistem Pendukung Keputusan', 'EE4025-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (158, 56, 'Pemrograman Jaringan WEB', 'EL3609', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (159, 56, 'Rekayasa Perangkat Lunak', 'EL3508', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (160, 57, 'Pemrograman Jaringan Web', 'EL3609', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (161, 57, 'Sistem Informasi', 'EE3505-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (162, 57, 'Sistem Pendukung Keputusan', 'EE4025-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (163, 58, 'Smart Grid', 'EE4005-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (164, 58, 'Perencanaan dan Manajemen Energi', 'EE4029-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (165, 58, 'Pembangkitan Tenaga Listrik', 'EE1501-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (166, 59, 'Elektronika Daya', 'EE1602-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (167, 59, 'Energi Baru Terbarukan', 'EE0602-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (168, 59, 'Teknik Kendali Digital', 'EE4024-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (169, 60, 'Inatrumentasi', 'EE0402-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (170, 60, 'Teknik Instalasi', 'EE1603-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (171, 60, 'Perancangan Pembangkit Energi Baru Terbarukan', 'EE4027-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (172, 61, 'Sistem Penyimpanan Energi', 'EE4030-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (173, 61, 'Elektronika Daya', 'EE1602-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (174, 61, 'Kecerdasan Buatan', 'EE0702-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (175, 62, 'Managemen Energi', 'EL1608', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (176, 62, 'Instrumentasi', 'EE0402-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (177, 62, 'Teknik Instalasi', 'EE1603-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (178, 63, 'Mekatronika', 'EE0502-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (179, 63, 'Sistem Kontrol Terintegrasi', 'EL4608\r\n', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (180, 63, 'Teknik Robot', 'EE2502-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (181, 64, 'Sistem Berbasis Mikroprosesor', 'EE2504-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (182, 64, 'Sistem Otomotif', 'EL0603', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (183, 64, 'HMI', 'EL4607', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (184, 65, 'Teknik Tenaga Listrik', 'EE0405-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (185, 65, 'Elektronika Daya', 'EE1602-19', NULL, NULL);
INSERT INTO `ta_matkul` VALUES (186, 65, 'Teknik Kendali Digital', 'EE4024-19', NULL, NULL);

-- ----------------------------
-- Table structure for ta_nilaibimbingan
-- ----------------------------
DROP TABLE IF EXISTS `ta_nilaibimbingan`;
CREATE TABLE `ta_nilaibimbingan`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ta_pembimbing_id` int(11) NULL DEFAULT NULL,
  `n1` int(15) NULL DEFAULT NULL,
  `n2` int(15) NULL DEFAULT NULL,
  `n3` int(15) NULL DEFAULT NULL,
  `n4` int(15) NULL DEFAULT NULL,
  `n5` int(15) NULL DEFAULT NULL,
  `n6` int(15) NULL DEFAULT NULL,
  `total_skripsi` int(15) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 31 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ta_nilaibimbingan
-- ----------------------------
INSERT INTO `ta_nilaibimbingan` VALUES (3, 85, 90, 87, 90, 85, 85, 88, 87, '2020-07-03 08:44:52', '2020-07-03 08:46:01');
INSERT INTO `ta_nilaibimbingan` VALUES (4, 84, 95, 90, 90, 93, 90, 90, 91, '2020-07-03 09:41:13', '2020-07-03 09:42:54');
INSERT INTO `ta_nilaibimbingan` VALUES (5, 71, 90, 90, 90, 90, 90, 90, 90, '2020-07-10 08:54:10', '2020-07-10 08:54:10');
INSERT INTO `ta_nilaibimbingan` VALUES (6, 70, 90, 95, 95, 90, 90, 88, 91, '2020-07-15 11:29:54', '2020-07-15 11:29:54');
INSERT INTO `ta_nilaibimbingan` VALUES (7, 88, 98, 98, 98, 98, 98, 96, 98, '2020-07-16 08:32:26', '2020-07-16 08:32:26');
INSERT INTO `ta_nilaibimbingan` VALUES (8, 89, 87, 87, 87, 87, 87, 90, 87, '2020-07-16 09:16:00', '2020-07-16 09:16:00');
INSERT INTO `ta_nilaibimbingan` VALUES (9, 67, 95, 95, 95, 95, 95, 95, 95, '2020-07-20 13:17:13', '2020-07-20 13:17:13');
INSERT INTO `ta_nilaibimbingan` VALUES (10, 66, 90, 85, 90, 85, 86, 82, 86, '2020-07-20 14:18:18', '2020-07-20 14:44:55');
INSERT INTO `ta_nilaibimbingan` VALUES (11, 38, 80, 80, 80, 90, 96, 90, 87, '2020-07-23 13:55:35', '2020-07-23 13:55:35');
INSERT INTO `ta_nilaibimbingan` VALUES (12, 34, 85, 84, 85, 85, 85, 84, 85, '2020-07-23 16:02:16', '2020-07-23 16:02:16');
INSERT INTO `ta_nilaibimbingan` VALUES (13, 33, 75, 75, 85, 90, 90, 75, 83, '2020-07-23 18:30:13', '2020-07-23 18:30:13');
INSERT INTO `ta_nilaibimbingan` VALUES (14, 101, 90, 95, 95, 95, 95, 95, 95, '2020-07-24 11:05:05', '2020-07-24 11:07:04');
INSERT INTO `ta_nilaibimbingan` VALUES (15, 100, 89, 94, 94, 94, 95, 96, 94, '2020-07-24 11:12:15', '2020-07-24 11:12:15');
INSERT INTO `ta_nilaibimbingan` VALUES (16, 81, 90, 85, 85, 90, 87, 87, 87, '2020-07-27 09:29:22', '2020-07-27 09:30:50');
INSERT INTO `ta_nilaibimbingan` VALUES (17, 80, 90, 90, 92, 93, 90, 85, 90, '2020-07-27 09:30:41', '2020-07-27 09:30:41');
INSERT INTO `ta_nilaibimbingan` VALUES (18, 111, 90, 90, 90, 90, 90, 90, 90, '2020-07-28 21:23:04', '2020-07-28 21:23:04');
INSERT INTO `ta_nilaibimbingan` VALUES (19, 110, 95, 95, 95, 95, 95, 90, 94, '2020-07-28 21:27:31', '2020-07-28 21:27:51');
INSERT INTO `ta_nilaibimbingan` VALUES (20, 98, 90, 90, 95, 90, 90, 90, 91, '2020-07-29 16:24:01', '2020-07-29 16:24:01');
INSERT INTO `ta_nilaibimbingan` VALUES (21, 114, 87, 85, 88, 86, 86, 87, 87, '2020-07-29 16:32:10', '2020-07-29 16:32:10');
INSERT INTO `ta_nilaibimbingan` VALUES (22, 115, 89, 89, 89, 89, 89, 89, 89, '2020-07-29 16:53:24', '2020-07-29 16:53:24');
INSERT INTO `ta_nilaibimbingan` VALUES (23, 99, 90, 88, 91, 88, 91, 87, 89, '2020-07-29 17:14:04', '2020-07-29 17:14:04');
INSERT INTO `ta_nilaibimbingan` VALUES (24, 112, 88, 89, 87, 85, 86, 85, 87, '2020-07-29 19:40:19', '2020-07-29 20:47:12');
INSERT INTO `ta_nilaibimbingan` VALUES (25, 113, 90, 90, 92, 95, 93, 93, 92, '2020-07-29 20:40:27', '2020-07-29 20:40:27');
INSERT INTO `ta_nilaibimbingan` VALUES (26, 90, 80, 90, 80, 90, 90, 90, 87, '2020-07-30 17:09:50', '2020-07-30 17:09:50');
INSERT INTO `ta_nilaibimbingan` VALUES (27, 91, 95, 95, 95, 95, 95, 95, 95, '2020-07-30 17:11:59', '2020-07-30 17:11:59');
INSERT INTO `ta_nilaibimbingan` VALUES (28, 82, 95, 95, 95, 95, 95, 95, 95, '2020-07-30 20:32:31', '2020-07-30 20:32:31');
INSERT INTO `ta_nilaibimbingan` VALUES (29, 83, 78, 78, 78, 85, 85, 85, 82, '2020-07-30 20:38:52', '2020-07-30 20:38:52');
INSERT INTO `ta_nilaibimbingan` VALUES (30, 37, 88, 89, 87, 86, 88, 89, 88, '2020-08-04 15:10:11', '2020-08-04 15:10:11');

-- ----------------------------
-- Table structure for ta_nilaipendadaran_pembimbing
-- ----------------------------
DROP TABLE IF EXISTS `ta_nilaipendadaran_pembimbing`;
CREATE TABLE `ta_nilaipendadaran_pembimbing`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ta_pembimbing_id` int(11) NULL DEFAULT NULL,
  `a` int(15) NULL DEFAULT NULL,
  `a1` int(15) NULL DEFAULT NULL,
  `a2` int(15) NULL DEFAULT NULL,
  `a3` int(15) NULL DEFAULT NULL,
  `a4` int(15) NULL DEFAULT NULL,
  `b` int(15) NULL DEFAULT NULL,
  `b1` int(15) NULL DEFAULT NULL,
  `b2` int(15) NULL DEFAULT NULL,
  `b3` int(15) NULL DEFAULT NULL,
  `b4` int(15) NULL DEFAULT NULL,
  `b5` int(15) NULL DEFAULT NULL,
  `c` int(15) NULL DEFAULT NULL,
  `c1` int(15) NULL DEFAULT NULL,
  `c2` int(15) NULL DEFAULT NULL,
  `c3` int(15) NULL DEFAULT NULL,
  `total` int(15) NULL DEFAULT NULL,
  `revisi` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `status_nilai` tinyint(6) NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 31 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ta_nilaipendadaran_pembimbing
-- ----------------------------
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (3, 85, NULL, 88, 86, 87, 85, NULL, 90, 90, 88, 85, 85, NULL, 87, 85, 85, 87, '1) hal 12,34, 82 sisa banyak hal kosong\r\n2) diagram alir tambahkan blok if\r\n3) gambar 4.8 kan skala kurva beda, bisa tdk sumbu y dibuat kanan kiri dengan\r\n   skala beda biar grafik tidk menumpuk. Gambar 4.9 juga,biar arus tidak kelihatan\r\n   nol. Gambar 4.14, 4.16, 4.29, 4.30, 4.35, 4.36\r\n4) Disebut dulu di text baru gambar, bukan gambar dulu baru disebut\r\n5) Validasi sensor di skala prototipe dan meteran perlu dilakukan juga', 1, '2020-07-03 08:44:52', '2020-07-03 10:04:12');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (4, 84, NULL, 95, 95, 95, 95, NULL, 95, 90, 90, 90, 95, NULL, 90, 90, 95, 93, 'Secara umum ybs menampilkan presentasi TA dengan baik. REvisi yang disarankan penguji pada seminar hasil telah dimasukkan pada TA ini. Ada revisi tentang pengurangan teori pada laporan, hanya berdasarkan yang dipakai dalam penelitian ini saja.', 1, '2020-07-03 09:41:13', '2020-07-03 09:43:14');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (5, 71, NULL, 90, 80, 90, 89, NULL, 90, 90, 90, 90, 90, NULL, 90, 90, 90, 89, 'Sudah ok, perbaiki draft dari typo dan kalimat tidak lengkap.', 1, '2020-07-10 08:54:10', '2020-07-10 08:54:17');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (6, 70, NULL, 90, 90, 90, 90, NULL, 90, 90, 90, 93, 95, NULL, 90, 90, 90, 91, 'Sudah bagus. Tinggal selesaikan developer manualnya', 1, '2020-07-15 11:29:54', '2020-07-15 11:30:09');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (7, 88, NULL, 98, 98, 98, 98, NULL, 98, 98, 98, 98, 98, NULL, 98, 98, 98, 98, 'Masukan sesuai dari team penguji.', 1, '2020-07-16 08:32:26', '2020-07-16 09:03:24');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (8, 89, NULL, 90, 90, 90, 90, NULL, 87, 87, 87, 87, 87, NULL, 90, 90, 90, 89, '-Judul diperjelas \r\n-Kalimat pada abstrak \r\n-ballancing cell atau cell ballancing?  \r\n- Bypass cell, cell to cell, cell to pack, pack to cell dan cell to pack to\r\ncell, Jelaskan? \r\n- wifi module pakai hotspot pribadi, jika pakai wifi UNS bisa?\r\n- Diagram Alir Perancangan Perangkat Keras \r\n- Flowchart, sudah OK?\r\nTabel 4.3 Hasil uji tingkat presisi sensor \r\nTabel 4.5 Hasil uji tingkat akurasi sensor arus \r\nBeda nya? Sensor Arus Presisi 37%, AKurasi 91%? \r\nUntuk T tidak dilakukan? \r\nOverheating tidak dilakukan? \r\nSupply board control berapa Volt? \r\nError pengujian proteksi 0.2 A ada dampaknya?', 1, '2020-07-16 09:16:00', '2020-07-16 09:16:55');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (9, 67, NULL, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 'Direvisi masukan dari dewan penguji. sesuai di naskah/text.', 1, '2020-07-20 13:17:13', '2020-07-20 14:03:04');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (10, 66, NULL, 87, 88, 85, 88, NULL, 90, 86, 85, 85, 87, NULL, 86, 84, 83, 86, '1) validasi model dengan hardware\r\n2) perbaiki model dengan input-output yg benar', 1, '2020-07-20 14:18:18', '2020-07-20 14:45:04');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (11, 38, NULL, 87, 89, 88, 87, NULL, 90, 87, 88, 88, 87, NULL, 89, 87, 88, 88, 'n.a', 1, '2020-07-23 13:55:35', '2020-07-23 13:55:43');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (12, 34, NULL, 85, 85, 85, 87, NULL, 85, 85, 84, 84, 86, NULL, 85, 84, 84, 85, 'Perlu revisi dengan penambahan data perbandingan untuk menampilkan gelombang sinusoidal, selain itu justifikasi sampling perlu dilakukan untuk menyamakan antara alat yang dibuat dengan yang digunakan untuk validator. dan dilakukan pengambilan data ulang lagi.', 1, '2020-07-23 16:02:16', '2020-07-23 16:03:05');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (13, 33, NULL, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 85, NULL, 80, 80, 80, 87, '+ Ambil data dengan sampling rate sama dengan AEMC yaitu 12.8 kHz, bandingkan\r\n+ Ukur PF Factor (Tinggal modif di software)', 1, '2020-07-23 18:30:13', '2020-07-23 18:30:17');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (14, 101, NULL, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 90, NULL, 95, 95, 95, 92, '1. Sesuai saran penguji. \r\n2. Dijelaskan mengapa pengujian Peforma nilainya 70%?', 1, '2020-07-24 11:05:05', '2020-07-24 11:08:45');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (15, 100, NULL, 94, 93, 95, 92, NULL, 91, 92, 93, 94, 92, NULL, 92, 94, 96, 93, 'dikerjakan revisi dari bapak2 penguji', 1, '2020-07-24 11:12:15', '2020-07-24 11:12:35');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (16, 81, NULL, 87, 87, 85, 84, NULL, 94, 90, 86, 87, 85, NULL, 88, 85, 85, 87, '1) penulisan bab sistematika penulisan dirapikan, bisa tanya sy via wa\r\n2) tabel usahakan tidak terputus di halaman yg beda, misal tabel 4.2\r\n3) lampiran dan foto dokumentasi+penjelasan tanpa nomor gambar', 1, '2020-07-27 09:29:22', '2020-07-27 09:31:55');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (17, 80, NULL, 90, 95, 85, 87, NULL, 90, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 'Beberapa tambahan revisi perlu dilakukan untyuk penyempurnaan skripsi ini.', 1, '2020-07-27 09:30:40', '2020-07-27 09:30:56');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (18, 111, NULL, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 'masukan dewan penguji ditindaklanjuti.', 1, '2020-07-28 21:23:04', '2020-07-28 21:23:10');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (19, 110, NULL, 95, 90, 95, 95, NULL, 90, 90, 95, 95, 95, NULL, 95, 95, 95, 94, 'Sesuaikan dewan dewan penguji dan pembimbing', 0, '2020-07-28 21:27:31', '2020-07-28 21:27:51');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (20, 98, NULL, 90, 95, 90, 90, NULL, 90, 91, 90, 90, 90, NULL, 95, 90, 90, 91, 'Sudah cukup bagus tinggal diteliti lagi penulisan dan formating', 0, '2020-07-29 16:24:01', '2020-07-29 16:24:01');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (21, 114, NULL, 87, 89, 87, 86, NULL, 90, 89, 88, 86, 86, NULL, 87, 85, 85, 87, '1) pemodelan motor BLDC gambar diganti sperti yg sy kirim wa\r\n2) pada simulasi gangguan, kmu menghitung performa settling time dll bagaimana caranya?\r\n3) grafik hasil, waktu dan sudut, berikan satuannya misal: waktu (s)\r\n4) nilai undershoot kok minus?\r\n5) validasi model', 1, '2020-07-29 16:32:10', '2020-07-29 17:29:00');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (22, 115, NULL, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 90, NULL, 88, 88, 88, 89, 'mohon disesuaikan sesuai masukan dari dewan penguji', 1, '2020-07-29 16:53:24', '2020-07-29 16:53:27');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (23, 99, NULL, 90, 91, 90, 86, NULL, 90, 88, 89, 90, 90, NULL, 92, 91, 90, 90, 'koordinasi back up data dengan Pak Subhan', 1, '2020-07-29 17:14:04', '2020-07-29 17:14:42');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (24, 112, NULL, 90, 87, 88, 87, NULL, 92, 87, 86, 85, 85, NULL, 87, 88, 88, 88, '1) masukkan nilai kuantitatif(rata2 eror) di kesimpulan dan abstract\r\n2) sesuai masukan penguji', 1, '2020-07-29 19:40:19', '2020-07-29 21:06:47');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (25, 113, NULL, 90, 93, 90, 93, NULL, 90, 93, 93, 88, 93, NULL, 93, 94, 92, 92, 'Perlu ditambahkan beberapa kajian dari kajian teori.\r\nrevisi yang lainnya ada di draft TA.', 1, '2020-07-29 20:40:27', '2020-07-29 20:40:36');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (26, 90, NULL, 80, 85, 90, 80, NULL, 90, 85, 90, 90, 85, NULL, 90, 90, 80, 86, 'Silahkan direvisi sesuai masukan para penguji.\r\nDari saya ada beberapa masukan:\r\n1. Gambar-gambar grafik diperjelas.\r\n2. Kesimpulan diperbaiki dibagian selisih', 1, '2020-07-30 17:09:50', '2020-07-30 17:10:12');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (27, 91, NULL, 95, 95, 95, 95, NULL, 95, 95, 95, 95, 95, NULL, 95, 95, 95, 95, 'masukan dewan penguji diperbaiki', 1, '2020-07-30 17:11:59', '2020-07-30 17:12:04');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (28, 82, NULL, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 'mohon revisi dibenarkan sesuai permintaan dewan penguji', 1, '2020-07-30 20:32:31', '2020-07-30 20:37:38');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (29, 83, NULL, 80, 80, 90, 87, NULL, 87, 85, 80, 80, 85, NULL, 78, 78, 80, 82, '1. Grafik 4.4 dan 4.9 noise nya besar kenapa?\r\n2. Persamaan efisiensi termal tolong dicek persamaannya\r\n3. PV materialnya Si itu apa?', 1, '2020-07-30 20:38:52', '2020-07-30 20:39:01');
INSERT INTO `ta_nilaipendadaran_pembimbing` VALUES (30, 37, NULL, 88, 89, 87, 89, NULL, 87, 88, 88, 89, 90, NULL, 90, 88, 89, 89, 'cukup', 1, '2020-08-04 15:10:11', '2020-08-04 15:10:36');

-- ----------------------------
-- Table structure for ta_nilaipendadaran_penguji
-- ----------------------------
DROP TABLE IF EXISTS `ta_nilaipendadaran_penguji`;
CREATE TABLE `ta_nilaipendadaran_penguji`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ta_penguji_id` int(11) NULL DEFAULT NULL,
  `a` int(15) NULL DEFAULT NULL,
  `a1` int(15) NULL DEFAULT NULL,
  `a2` int(15) NULL DEFAULT NULL,
  `a3` int(15) NULL DEFAULT NULL,
  `a4` int(15) NULL DEFAULT NULL,
  `b` int(15) NULL DEFAULT NULL,
  `b1` int(15) NULL DEFAULT NULL,
  `b2` int(15) NULL DEFAULT NULL,
  `b3` int(15) NULL DEFAULT NULL,
  `b4` int(15) NULL DEFAULT NULL,
  `b5` int(15) NULL DEFAULT NULL,
  `c` int(15) NULL DEFAULT NULL,
  `c1` int(15) NULL DEFAULT NULL,
  `c2` int(15) NULL DEFAULT NULL,
  `c3` int(15) NULL DEFAULT NULL,
  `total` int(15) NULL DEFAULT NULL,
  `revisi` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `status_nilai` tinyint(6) NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 31 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ta_nilaipendadaran_penguji
-- ----------------------------
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (3, 28, NULL, 90, 90, 90, 85, NULL, 80, 80, 90, 90, 80, NULL, 90, 90, 80, 86, 'Masukan dan Saran:\r\n1. Kata-kata \"Rancang Bangun\" diganti agar tidak seperti TA mahasiswa D3.\r\n2. Persamaan di Bab 2 halaman 10-12 tidak perlu dimasukkan jika tidak dipakai pada analisis atau perhitungan hasil penelitian.\r\n3. Gambar alur penelitian (Gambar 3.2) perlu ditambahkan bentuk decision (belah ketupat).\r\n4. Gambar 4.48 dan 4.50 grafik tegangan diperbesar atau dipisah agar terlihat korelasinya dengan arus.\r\n5. Kesimpulan pada point 3 belum menjawab tujuan no.3\r\n6. Penulisan referensi dalam kalimat harus berurutan karena menggunakan angka.\r\n7. Gambar 4.35 Grafik pengujian: penurunan tiba2 nilai RPM khawatir membahayakan pengemudi.', 1, '2020-07-03 09:58:20', '2020-07-03 10:05:07');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (4, 29, NULL, 84, 88, 85, 80, NULL, 85, 85, 85, 80, 80, NULL, 80, 80, 80, 82, '1. persamaan yang tidak digunakan dapat dihilangkan.\r\n2. sebaiknya disebutkan batasan penelitian pada naskah ini\r\n3. perlu pembahasan mendalam terkait pertanyaan penelitian nomer 3', 1, '2020-07-03 10:07:37', '2020-07-03 10:07:54');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (5, 30, NULL, 80, 80, 85, 80, NULL, 86, 85, 85, 85, 84, NULL, 88, 89, 90, 85, 'dilenfkapu tanda tangan digital', 1, '2020-07-10 09:28:53', '2020-07-10 09:29:12');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (6, 31, NULL, 95, 93, 92, 94, NULL, 88, 92, 90, 91, 90, NULL, 91, 93, 94, 92, 'Dikasih pesan jika pembimbing skripsi sudah mengklik tombol setuju atau belum di seminar hasil maupun pendadaran', 1, '2020-07-11 19:41:53', '2020-07-11 19:43:14');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (7, 36, NULL, 90, 90, 86, 90, NULL, 85, 91, 86, 86, 85, NULL, 85, 90, 85, 87, 'Permasalahan adalah pada proteksi untuk menyelamatkan drop baterai akibat unbalance. Penguatan teori perlu ditambahkan pada naskah skripsi', 1, '2020-07-16 08:51:00', '2020-07-16 08:51:08');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (8, 37, NULL, 86, 85, 85, 87, NULL, 86, 87, 89, 88, 80, NULL, 86, 86, 87, 86, 'revisi ada di draf', 1, '2020-07-16 09:18:53', '2020-07-16 09:19:05');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (9, 45, NULL, 86, 85, 86, 85, NULL, 89, 88, 85, 85, 84, NULL, 85, 85, 86, 86, 'draf sudah di revisi', 1, '2020-07-20 14:25:16', '2020-07-20 14:25:22');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (10, 44, NULL, 84, 85, 84, 88, NULL, 88, 80, 84, 85, 88, NULL, 80, 82, 83, 84, '1. Perlu validasi model matematis yang diperoleh, untuk mengetahui tingkat keakuratan dan kesahihan hasil penelitian.\r\n\r\ncatatan revisi yang lain ada pada draft TA.', 1, '2020-07-20 14:35:18', '2020-07-20 14:35:35');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (11, 41, NULL, 87, 88, 88, 86, NULL, 90, 90, 87, 88, 85, NULL, 88, 87, 87, 88, '1)Tabel 4.4, 4.5, 4.6 letakkan di lampiran\r\n2)Grafik 4.27-4.29 axisnya dikasih nama', 1, '2020-07-23 13:53:09', '2020-07-23 14:05:58');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (12, 40, NULL, 85, 85, 85, 85, NULL, 90, 90, 90, 90, 90, NULL, 90, 90, 85, 88, 'Perbaiki x axis dari THD, karena dipengaruhi sampling rate', 1, '2020-07-23 14:11:10', '2020-07-23 14:11:30');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (13, 63, NULL, 81, 83, 84, 85, NULL, 86, 85, 86, 83, 84, NULL, 80, 85, 81, 83, '1. merubah judul, ganti kata Rancang Bangun dengan istilah yang lain yang merepresentasikan karya S1.\r\n2. Belum ada analisa gelombang sinus dan ketidakseimbangan pada frekuensi 35 Hz.\r\n3. jika memungkinkan ditambah analisis matematis dari rumus yang telah paparkan.\r\n\r\nTERUS SEMANGAT, SEMANGAT TERUS!!!', 1, '2020-07-23 16:48:28', '2020-07-23 16:48:37');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (14, 62, NULL, 80, 82, 79, 85, NULL, 81, 75, 74, 78, 83, NULL, 75, 75, 76, 78, 'samakan kondisi alat yg dibandingkan saat pengukuran', 1, '2020-07-23 17:08:55', '2020-07-23 17:09:11');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (15, 48, NULL, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 90, NULL, 90, 90, 90, 90, '+ Tambahkan satu menu, yang menampilkan x grafik (x km tentukan sendiri), yang tiap grafik berisi 1 topik yang ditentukan user\r\n+ Tambahkan tutorial untuk developer, pilih salah satu case yang kira2 mencakup semuanya (misalnya cara menambahkan menu input data dan grafik)', 0, '2020-07-24 11:12:25', '2020-07-24 11:12:25');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (16, 49, NULL, 90, 90, 95, 90, NULL, 90, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 'Sudah bagus. Tdk ada koreksi dari saya. Cuma buku silahkan ditulis lebih baik.', 1, '2020-07-24 11:14:39', '2020-07-24 11:17:05');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (17, 43, NULL, 90, 95, 90, 87, NULL, 80, 85, 85, 90, 90, NULL, 90, 90, 90, 89, 'Masukan:\r\n1. Masukkan tahun pada tabel referensi utama. \r\n2. Silahkan dicek kejelasan gambar (gambar 2.1)\r\n3. nilai akurasi dan presisi dapat dimasukkan ke dalam grafik menjadi eror bar\r\n4. sensor temperatur sebaiknya ditempatkan disetiap baterai utk memonitoring secara detil.\r\n5. temperatur cut off yang kamu terapkan pada baterai (50 oC) terlalu tinggi, mungkin bisa diturunkan dan ditambah LED utk mengingatkan pengguna agar hati2.', 1, '2020-07-27 08:56:04', '2020-07-27 09:32:04');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (18, 42, NULL, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 'Bagaimana cara menghitung tahanan internal baterai', 1, '2020-07-27 09:05:54', '2020-07-27 09:06:24');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (19, 50, NULL, 80, 80, 75, 80, NULL, 80, 75, 80, 80, 80, NULL, 85, 85, 85, 81, 'Fotmat tabel dll, kesesuaian tujuan dan kesimuplan saran dll', 1, '2020-07-28 21:14:26', '2020-07-28 21:14:50');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (20, 51, NULL, 80, 80, 80, 81, NULL, 80, 79, 81, 80, 81, NULL, 82, 81, 80, 80, 'diuji dalam 1 hari', 1, '2020-07-28 21:26:11', '2020-07-28 21:26:23');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (21, 57, NULL, 86, 85, 85, 84, NULL, 85, 89, 86, 85, 87, NULL, 80, 83, 80, 84, 'revisi draf sudah selesai', 1, '2020-07-29 16:34:01', '2020-07-29 16:34:33');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (22, 47, NULL, 90, 90, 95, 90, NULL, 90, 90, 90, 90, 90, NULL, 90, 85, 85, 89, 'Dari saya sudah cukup. Sesuaikan dengan saran pembimbing dan penguji yang lainnya.', 1, '2020-07-29 17:03:52', '2020-07-29 17:04:12');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (23, 46, NULL, 81, 83, 82, 82, NULL, 86, 81, 82, 82, 83, NULL, 88, 81, 87, 83, '-kemudahan user...pemetaan cmpk ke cpl sehungga dosen mudah memahami nilai\r\n-sistem back up', 1, '2020-07-29 17:10:02', '2020-07-29 17:10:10');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (24, 56, NULL, 85, 84, 86, 83, NULL, 80, 82, 78, 77, 80, NULL, 77, 78, 76, 80, 'lengkapi block diagram dgn model nya\r\nlengkapi flow chart pd programnya', 1, '2020-07-29 17:20:11', '2020-07-29 17:20:29');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (25, 66, NULL, 84, 85, 88, 83, NULL, 85, 85, 87, 84, 83, NULL, 84, 86, 85, 85, 'Abstract revisi:\r\nThe need for autonomous robots has recently increased, along with the rapid development of robotics technology. The ability to move from one point to another without the need for human intervention is one of the advantages of autonomous robots. To make an autonomous robot, robots with high efficiency, flexibility, and a reliable navigation system are needed. High efficiency and flexibility can be handled with the use of a two-wheeled balancing robot. A reliable navigation system can be achieved by using the ROS (robot operating system) platform. The research produces virtual robots, virtual maps, and virtual sensors on simulations in the GAZEBO application, which can be visualized in RVIZ. Map development and navigation system usage, run in the ROS system, producing speed data that sent to GAZEBO simulations and balancing robot in the real world. The tracking simulation test shows that the virtual robot can reach the destination location with an error in the range of 0.1 m along the X and Y axes. The real tracking test shows the balancing robot can receive speed data from the ROS system, to move towards the destination point based on the virtual map and virtual sensor, with errors in the range 0.1 m on the X-axis and 0.4 m on the Y-axis.', 1, '2020-07-29 20:18:53', '2020-07-29 20:19:03');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (26, 67, NULL, 90, 90, 90, 90, NULL, 91, 91, 90, 90, 90, NULL, 90, 90, 90, 90, 'Sudah bagus. Tinggal cek lagi kalau misal ada typo dan format TA yg kurang tepat', 1, '2020-07-29 20:19:43', '2020-07-29 22:01:21');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (27, 58, NULL, 80, 85, 85, 80, NULL, 80, 80, 85, 85, 90, NULL, 80, 80, 80, 82, '- Kesimpulan agak membingungkan (selisih, mengapa semarang? klaimatnya dibuat enak dibaca)\r\n- Latar belakang masalah di perjelas (mengapa hybrida)\r\n- Bagaimana dengan COE PV-WTG dengan baterai? kalau sempat dianalisis, kalau tidak kira2 bagaimana lebih murah/mahal?', 1, '2020-07-30 17:19:31', '2020-07-30 17:19:38');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (28, 59, NULL, 85, 85, 85, 70, NULL, 85, 80, 83, 80, 80, NULL, 80, 80, 78, 81, 'revisi ada di draft, silahkan hubungi saya', 1, '2020-07-30 17:21:40', '2020-07-30 17:21:44');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (29, 65, NULL, 84, 83, 84, 85, NULL, 82, 82, 83, 83, 86, NULL, 81, 82, 83, 83, '1. perbaiki daftar isi, daftar gambar, belum rapi. \r\n2. pelajari mengapa cahaya matahari bisa diserap dan menghasilkan tegangan, cahaya mahasiswa mengandung apa.\r\n3. gambar di bab 4 belum diberi penjelasan\r\n4. lampiran 3 data hasil penelitian belum menggambarkan 7 hari pengamatan, jangan dirata2 meskipun jam nya sama\r\n5. pelajari lagi spesifikasi alat penelitianmu', 1, '2020-07-30 20:31:18', '2020-07-30 20:37:37');
INSERT INTO `ta_nilaipendadaran_penguji` VALUES (30, 64, NULL, 87, 85, 90, 90, NULL, 87, 84, 85, 80, 85, NULL, 78, 78, 78, 83, 'Tambahkan presisi', 1, '2020-07-30 20:31:50', '2020-07-30 20:32:23');

-- ----------------------------
-- Table structure for ta_nilaisemhas_pembimbing
-- ----------------------------
DROP TABLE IF EXISTS `ta_nilaisemhas_pembimbing`;
CREATE TABLE `ta_nilaisemhas_pembimbing`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ta_pembimbing_id` int(11) NULL DEFAULT NULL,
  `a` int(15) NULL DEFAULT NULL,
  `a1` int(15) NULL DEFAULT NULL,
  `a2` int(15) NULL DEFAULT NULL,
  `a3` int(15) NULL DEFAULT NULL,
  `a4` int(15) NULL DEFAULT NULL,
  `b` int(15) NULL DEFAULT NULL,
  `b1` int(15) NULL DEFAULT NULL,
  `b2` int(15) NULL DEFAULT NULL,
  `b3` int(15) NULL DEFAULT NULL,
  `b4` int(15) NULL DEFAULT NULL,
  `b5` int(15) NULL DEFAULT NULL,
  `c` int(15) NULL DEFAULT NULL,
  `c1` int(15) NULL DEFAULT NULL,
  `c2` int(15) NULL DEFAULT NULL,
  `c3` int(15) NULL DEFAULT NULL,
  `total` int(15) NULL DEFAULT NULL,
  `revisi` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `status_nilai` tinyint(6) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `ibfk_pembimbing_1`(`ta_pembimbing_id`) USING BTREE,
  CONSTRAINT `ibfk_pembimbing_1` FOREIGN KEY (`ta_pembimbing_id`) REFERENCES `ta_pembimbing` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 60 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ta_nilaisemhas_pembimbing
-- ----------------------------
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (17, 71, NULL, 80, 80, 85, 75, NULL, 90, 90, 90, 90, 90, NULL, 90, 90, 90, 87, 'Sudah bagus, tambahkan dokumentasi', 0, '2020-06-18 09:54:15', '2020-06-18 09:56:27');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (18, 70, NULL, 90, 90, 90, 90, NULL, 95, 90, 90, 90, 90, NULL, 95, 90, 90, 91, 'Buat buku panduan user dan developer', 1, '2020-06-18 09:58:42', '2020-06-18 09:58:58');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (19, 84, NULL, 90, 90, 90, 90, NULL, 90, 92, 90, 90, 90, NULL, 90, 90, 90, 90, 'Secara umum sudah bagus, namun demikian perlu perbaikan di presentasi dan presentasi data agar kelihatan lebih baik lagi.', 1, '2020-06-18 14:29:10', '2020-06-18 14:29:29');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (20, 85, NULL, 88, 85, 85, 85, NULL, 86, 85, 85, 87, 82, NULL, 85, 80, 83, 85, 'Sesuai masukan semhas. Tambahkan batasan masalah di bagian tujuan bahwa sistem rem elektrik tidak dinyalakan sehingga pembaca clear apa yg terjadi', 1, '2020-06-18 15:46:10', '2020-06-18 15:47:18');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (21, 88, NULL, 95, 95, 95, 93, NULL, 95, 95, 95, 95, 95, NULL, 100, 100, 100, 96, '1. Disesuiakan dengan masukan penguji. Segera revisi untuk sidang pendadaran TA. max awal Juli\r\n2. Memulai untuk menulis publikasi yang jurnal internasional kita kejar data yang lengkap simulasi dan harware. untuk conference cukup simulasi saja, tapi sebaiknya ke IEEE conference.', 1, '2020-06-25 09:22:12', '2020-06-25 09:22:16');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (22, 89, NULL, 86, 86, 86, 86, NULL, 86, 86, 86, 86, 86, NULL, 90, 90, 90, 87, '- Penyesuaian Rumusan Masalah \r\n- Arsitektur IoT', 1, '2020-06-25 09:24:12', '2020-06-25 09:29:47');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (23, 38, NULL, 87, 86, 85, 82, NULL, 83, 85, 87, 85, 80, NULL, 80, 83, 83, 84, 'Beberapa revisi draf langsung dituliskan di draf TA', 1, '2020-06-30 10:47:11', '2020-07-23 11:12:27');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (24, 37, NULL, 86, 90, 87, 80, NULL, 88, 89, 90, 88, 90, NULL, 89, 87, 86, 88, 'Silahkan direvisi sesuai saran dan pembahasan dewan penguji', 1, '2020-06-30 11:11:43', '2020-06-30 11:13:49');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (25, 81, NULL, 85, 88, 85, 80, NULL, 90, 88, 86, 86, 85, NULL, 86, 84, 85, 86, 'Pengujian kasus 1 grafiknya diperbaiki sampai balancing tercapai\r\nTambahkan perbedaan alatmu dibanding yg lain di bab 2, beda method juga bisa ditambahkan', 1, '2020-07-13 08:52:29', '2020-07-13 09:42:44');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (26, 80, NULL, 93, 93, 90, 85, NULL, 90, 90, 91, 92, 90, NULL, 92, 92, 92, 91, 'Perlu perbaikan untuk disesuakan ke keadaan sesungguhnya.', 1, '2020-07-13 09:35:21', '2020-07-13 09:35:38');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (27, 101, NULL, 87, 87, 87, 85, NULL, 90, 90, 90, 90, 90, NULL, 95, 95, 95, 90, '1. Pada sistem masih ada beberapa bhs Indo, misal nama bulan maret, april, mei, dll di bhs Inggriskan \r\n2. Fleksibilitas software penting sekali vin, ada add button untuk jumlah room dst \r\n3. Challanges nya dicari tahu mana yg bisa dikerjakan terlebih dahulu sampai pendadaran', 1, '2020-07-15 13:40:20', '2020-07-15 13:40:42');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (28, 100, NULL, 93, 92, 94, 90, NULL, 90, 91, 92, 93, 91, NULL, 91, 93, 95, 92, '-', 1, '2020-07-15 13:40:51', '2020-07-15 13:40:59');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (29, 98, NULL, 95, 90, 90, 90, NULL, 90, 90, 90, 90, 90, NULL, 93, 90, 88, 90, 'Sdh cukup bagus. Kemarin sudah dibuat user manual. Tolong buat video tutorial singkat (misal 10 menit), baik untuk user atau developer.  Minta feedback user ke prodi-prodi yang mengimplementasikan (T Elektro, T Sipil, T Mesin)', 1, '2020-07-15 14:52:26', '2020-07-15 14:58:44');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (30, 99, NULL, 86, 86, 85, 88, NULL, 85, 86, 87, 86, 90, NULL, 88, 85, 87, 87, '-', 1, '2020-07-15 14:58:49', '2020-07-15 14:58:58');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (31, 66, NULL, 87, 85, 88, 80, NULL, 90, 88, 88, 84, 85, NULL, 85, 84, 84, 86, '1) Perlu penyesuaian antara tujuan dan kesimpulan\r\n2) Koreksi batasan masalah\r\n3) Maksimum slide pendadaran 20 pages, durasi presentasi 20menit, fokus di hasil\r\n4) Satuan sumbu x dan y', 1, '2020-07-15 17:18:41', '2020-07-15 17:37:07');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (32, 67, NULL, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 'Sesuikan dengan yang di buku text dan permitaan penguji', 1, '2020-07-15 17:36:21', '2020-07-15 17:36:24');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (33, 111, NULL, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 'Masukan penguji diperbaiki kedepan.', 1, '2020-07-16 11:17:33', '2020-07-16 11:17:37');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (34, 110, NULL, 90, 90, 90, 85, NULL, 90, 90, 90, 90, 90, NULL, 95, 95, 95, 91, '1. Challenges : Lakukan pengujian jangkauan \r\n2. Semua saran dari Penguji dan Pembimbing dilakukan', 1, '2020-07-16 11:18:07', '2020-07-16 11:18:15');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (35, 30, NULL, 85, 85, 85, 85, NULL, 87, 87, 87, 87, 87, NULL, 88, 88, 88, 87, '1. dutty cycle alat yang digunakan apakah bias dihitung?. 2. Apakah ada disipasi daya yang terjadi.?bagaimanna perhitungannya? Saran perbaikan typo di lapoaran TA.', 1, '2020-07-16 13:43:09', '2020-07-16 13:43:12');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (36, 29, NULL, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 'Silahkan direvisi sesuai dengan pertanyaan yang diberikan pembimbing 2, penguji, maupun peserta.', 1, '2020-07-16 14:21:25', '2020-07-16 14:23:00');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (37, 32, NULL, 85, 85, 87, 87, NULL, 90, 85, 85, 87, 85, NULL, 85, 80, 80, 85, '1) Maksimalkan penggunaan halaman, hilangkan halaman yg hanya terisi separuh text dengan menarik ke atas text dibawahnya\r\n2) Gambar 4.8 skala y diperkecil sehingga tren grafik jelas', 1, '2020-07-20 09:05:37', '2020-07-20 09:07:17');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (38, 31, NULL, 90, 95, 95, 90, NULL, 90, 90, 90, 90, 89, NULL, 95, 90, 90, 91, 'Silahkan dirangkum pertanyaan-pertanyaan dari penguji dan pembimbing untuk menjadi perbaikan naskah TA kamu.', 1, '2020-07-20 09:08:44', '2020-07-20 09:09:24');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (39, 115, NULL, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 'Ikuti masukan dari dewan pneguji. jelaskan kelebihan alat dan software yang rilo rancang.', 1, '2020-07-20 11:07:07', '2020-07-20 11:07:10');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (40, 114, NULL, 87, 88, 85, 86, NULL, 90, 87, 85, 80, 85, NULL, 85, 87, 85, 86, '1) perbaiki kata kunci abstrac\r\n2) revisi pak agus, sinyal disturbance dr luar, bisa berupa load dibawah lengan', 1, '2020-07-20 11:08:04', '2020-07-20 11:15:21');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (41, 33, NULL, 80, 80, 80, 80, NULL, 80, 80, 80, 80, 80, NULL, 80, 80, 80, 80, '1.Tambahkan anailis dan alarm 2.Tambahkan analisis perhitungan', 1, '2020-07-20 21:01:39', '2020-07-20 21:01:39');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (42, 34, NULL, 80, 80, 80, 80, NULL, 80, 80, 80, 80, 80, NULL, 80, 80, 80, 80, '1.Memberikan hasil run spectrum pada frekuensi tertentu dengan salah satu fasa 2.Merubah sample rate', 1, '2020-07-20 21:01:43', '2020-07-20 21:01:43');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (43, 91, NULL, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 'masukan dewan penguhi ditindak lanjuti', 1, '2020-07-23 09:36:49', '2020-07-23 09:36:53');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (44, 90, NULL, 90, 75, 85, 78, NULL, 86, 88, 90, 88, 90, NULL, 90, 90, 87, 87, '1. Silahkan dicatat dan diperbaiki sesuai dengan masukan dan pertanyaan para penguji.\r\n2. Beberapa gambar grafik diperbaiki agar lebih jelas.\r\n3. Referensi yang dijadikan acuan utama ditambahkan, jangan hanya 2.', 1, '2020-07-23 09:38:41', '2020-07-23 09:38:49');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (45, 36, NULL, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 'masukan dewan penguji mohon ditindaklanjuti', 1, '2020-07-23 11:05:40', '2020-07-23 11:05:44');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (46, 35, NULL, 90, 90, 88, 90, NULL, 90, 88, 90, 90, 88, NULL, 90, 87, 87, 89, 'Silahkan dicatat dan diperbaiki sesuai dengan saran dan masukan dari dosen penguji dan pembimbing.', 1, '2020-07-23 11:06:33', '2020-07-23 11:06:39');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (47, 83, NULL, 90, 85, 90, 90, NULL, 90, 83, 85, 82, 85, NULL, 90, 90, 85, 87, 'Saran dan masukan:\r\n1. Pada PPT, penelitian terdahulu tidak dilengkapi tahun dan penomoran referensi.\r\n2. Disain rangkaian alat tidak ada keterangan.\r\n3. Penomoran pengukuran suhu 4.5-4.8 terlihat rancu\r\n4. Validasi hasil arus menggunakan Clamp meter memiliki eror yang lebih tinggi mungkin karena perbedaan metode.\r\n5. Persamaan suhu, intensitas dan torsi bisa dimasukkan di metode.\r\n6. Tambahkan analisis pengaruh pemakaian water cooling dengan hasil arus dan voltase.', 1, '2020-07-24 09:12:21', '2020-07-24 09:12:30');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (48, 82, NULL, 89, 89, 89, 89, NULL, 89, 89, 89, 89, 89, NULL, 89, 89, 89, 89, 'Masukan Dewan penguji mohon untuk ditindaklanjuti', 1, '2020-07-24 09:14:31', '2020-07-24 09:14:33');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (49, 93, NULL, 90, 87, 87, 87, NULL, 90, 87, 88, 87, 85, NULL, 87, 84, 86, 87, '1)	Nilai overshoot wujudkan dalam %\r\n2)	Tabel terpotong di 2 halaman satukan\r\n3)	Batasan masalah, masukkan spek motor yg dipakai\r\n4)	Tambahkan respon tegangan dan arus pada variasi pembebanan\r\n5)	Gambar tampilan blink tambahkan', 1, '2020-07-24 10:46:54', '2020-07-24 11:24:49');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (50, 112, NULL, 87, 88, 87, 88, NULL, 90, 85, 85, 87, 84, NULL, 88, 85, 85, 87, '1) tabel usahakan dalam 1 halaman, jangan terputus\r\n2) tambahkan data kuantitatif, data eror sepanjang perjalanan\r\n3) tambahkan skema robot(koneksi rangkaian/ blok diagram)', 1, '2020-07-24 14:13:57', '2020-07-24 14:24:16');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (51, 113, NULL, 88, 87, 86, 87, NULL, 83, 83, 88, 85, 87, NULL, 90, 90, 90, 87, '- perlu menambahkan beberapa kajian pustaka serta flohchart agar lebih jelas.\r\n- catatan saran yang lainnya ada di draft akan dikirim kemudian.', 1, '2020-07-24 14:20:37', '2020-07-24 14:26:16');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (52, 75, NULL, 85, 85, 89, 88, NULL, 90, 90, 85, 90, 90, NULL, 85, 90, 90, 88, 'Abstrak direvisi, kutipan diurutkan, penelitian terdahulu dibahas secara ringkas (jangan hanya tabel), sasar satu atau dua applikasi dari sistem yang kamu buat', 1, '2020-07-24 16:06:05', '2020-07-24 16:06:48');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (53, 74, NULL, 80, 88, 83, 81, NULL, 80, 82, 84, 85, 82, NULL, 88, 84, 82, 83, 'koreksi dari para penguji dikerjakan secepatnya', 1, '2020-07-24 16:08:35', '2020-07-24 16:08:44');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (54, 68, NULL, 80, 80, 80, 90, NULL, 80, 80, 80, 90, 90, NULL, 90, 80, 80, 83, '- Perbaiki Draft sehingga enak dibaca\r\n- Ambil data lebih banyak, dan sajikan', 1, '2020-07-27 17:31:23', '2020-07-27 17:31:30');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (55, 69, NULL, 80, 82, 52, 83, NULL, 80, 81, 86, 84, 80, NULL, 83, 81, 80, 80, '-parameter pemodelqn error generator diperjelas dan dihububgkan dengan BER\r\n-AFE...ambil data tentang karakteristik led dan photodiode,jarak tx rx dihubungkan dengan BER...buat grafik', 1, '2020-07-27 17:31:23', '2020-07-27 17:31:39');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (56, 79, NULL, 85, 89, 90, 82, NULL, 83, 83, 84, 84, 83, NULL, 80, 82, 83, 84, 'Revisi di dalam draf TA', 1, '2020-07-27 20:00:48', '2020-07-27 20:01:19');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (57, 78, NULL, 90, 90, 85, 80, NULL, 75, 80, 80, 80, 80, NULL, 95, 95, 95, 86, '- Draf diperbaiki dan ditata sesuai saran penguji\r\n- Mengambil data lagi untuk uji BER', 1, '2020-07-27 20:01:29', '2020-07-27 20:02:21');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (58, 41, NULL, 90, 90, 90, 90, NULL, 90, 95, 90, 90, 90, NULL, 90, 90, 90, 90, 'Perbanyak pembahasan tentang alat yg kamu buat dan hasilnya. Untuk info2 umum diringkas.', 0, '2020-08-03 16:54:40', '2020-08-03 16:54:40');
INSERT INTO `ta_nilaisemhas_pembimbing` VALUES (59, 42, NULL, 90, 92, 90, 88, NULL, 89, 88, 88, 92, 90, NULL, 88, 90, 94, 90, 'Perbaiki penulisan, ujicoba alat dan penggunaan/aplikasinya', 1, '2020-08-03 17:18:16', '2020-08-03 17:19:23');

-- ----------------------------
-- Table structure for ta_nilaisemhas_penguji
-- ----------------------------
DROP TABLE IF EXISTS `ta_nilaisemhas_penguji`;
CREATE TABLE `ta_nilaisemhas_penguji`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ta_penguji_id` int(11) NULL DEFAULT NULL,
  `a` int(15) NULL DEFAULT NULL,
  `a1` int(15) NULL DEFAULT NULL,
  `a2` int(15) NULL DEFAULT NULL,
  `a3` int(15) NULL DEFAULT NULL,
  `a4` int(15) NULL DEFAULT NULL,
  `b` int(15) NULL DEFAULT NULL,
  `b1` int(15) NULL DEFAULT NULL,
  `b2` int(15) NULL DEFAULT NULL,
  `b3` int(15) NULL DEFAULT NULL,
  `b4` int(15) NULL DEFAULT NULL,
  `b5` int(15) NULL DEFAULT NULL,
  `c` int(15) NULL DEFAULT NULL,
  `c1` int(15) NULL DEFAULT NULL,
  `c2` int(15) NULL DEFAULT NULL,
  `c3` int(15) NULL DEFAULT NULL,
  `total` int(15) NULL DEFAULT NULL,
  `revisi` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `status_nilai` tinyint(6) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 56 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ta_nilaisemhas_penguji
-- ----------------------------
INSERT INTO `ta_nilaisemhas_penguji` VALUES (12, 31, NULL, 94, 92, 91, 93, NULL, 86, 91, 88, 90, 88, NULL, 90, 92, 93, 91, '1, untuk meminimalisir penggunaan user manual, sebaiknya per user interface menunjukkan saling interaktif\r\n2. text box yang wajib diisi perlu diberi tanda *) dan jika belum diisi, ada pesan yang menandakan tidak boleh di klik tombok OK/Submit\r\n3. perlu dokumentasi untuk user (cara penggunaan aplikasi ini) dan developer (beri komentar fungsi di source code)\r\n4. pemberian warna tegas di beberapa tab pada suatu user interface\r\n5. garis flowchart pelaksanaan kerja praktek ada yang masuk ke kolom lain\r\n6. perlu Data Flow Diagram (DFD), levelnya disesuaikan dengan aplikasimu ini', 1, '2020-06-18 10:10:39', '2020-06-18 10:11:00');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (13, 30, NULL, 80, 80, 85, 79, NULL, 85, 84, 84, 83, 82, NULL, 87, 86, 86, 84, '-DFD\r\n-admin dan kaprodi dilengkapi', 1, '2020-06-18 10:33:47', '2020-06-18 10:33:59');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (14, 28, NULL, 80, 80, 85, 80, NULL, 85, 80, 90, 75, 75, NULL, 80, 80, 85, 81, 'Beberapa masukan dari saya:\r\n1. Tinjauan Pustaka dimasukkan penelitian-penelitian sebelumnya tentang cruise control\r\n2. Analisis hasil percobaan diperkuat.\r\n3. Dibuat tabel yg bisa merangkum grafik2 yang sudah ada.\r\n4. informasi validasi data diberikan\r\n5. Kata-kata \"Rancang Bangun\" sebaiknya dihilangkan diganti yang lebih fundamental seperti \"analisis\", \"investigasi\" dll. Kata2 Rancang Bangun biasa digunakan di D3.\r\n6. Keterangan sumbu x dan y diperjelas pada grafik.', 1, '2020-06-18 14:17:08', '2020-06-18 14:26:25');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (15, 29, NULL, 88, 85, 88, 80, NULL, 95, 90, 90, 85, 85, NULL, 85, 85, 85, 87, '1. perlu refrensi yang akurat mengenai faktor-faktor kecelakaan sepeda motor dan juga data kecelakaan sepeda motor yang disebabkan oleh hal tsb\r\n2. spesifikkan pertanyaan yang ada pada rumusan masalah (pertanyaan ke dua) beserta kesimpulannya.\r\n3. penambahan saran berdsarkan kelemahan yang anda alami setelah adaptif bekerja utk ke mode normal/ membuka throtle.\r\n4. sajikan grafik seberapa besar pengaruh pengaturan pwm pada throtle terhadap degradasi kecepatan laju kendaraan / putaran motor listrik.', 1, '2020-06-18 14:36:05', '2020-06-18 14:39:54');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (16, 36, NULL, 86, 86, 86, 86, NULL, 83, 83, 86, 86, 86, NULL, 86, 86, 86, 86, 'perlu ditambahkan pengujian pada waktu discharge untuk naskah akhir.', 1, '2020-06-25 08:56:51', '2020-06-25 08:56:56');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (17, 37, NULL, 85, 84, 85, 86, NULL, 80, 80, 85, 86, 84, NULL, 80, 83, 87, 84, '1.	Abstrak. Halaman ii: \r\nSetelah kalimat: “ penggunaan baterai litium dibuat titik\r\ntertulis kata bateria…seharusnya baterai\r\ntertulis ketidak seimbangan …seharusnya ketidakseimbangan\r\ntertulis  cell….seharusnya cell\r\ntertulis maka….seharusnya Oleh karena itu\r\ntertulis menujukan ….seharusnya menunjukan\r\ntertulis cel…seharus cell \r\n\r\n2. Bab 1 Pendahuluan ….latar belakang masalah:\r\nalinea  pertama hal 1….\r\ntertulis  contohnya pada baterai litium karena memiliki daya tahan yang lebih lama, kurangnya efek memori dan kepadatan energi yang tinggi \r\nseharusnya. Sebagai contoh….\r\ntertulis baterai lithium…..tidak konsisten dengan penulisan sebelum dan sesudahnya nya baterai litium \r\nalinea kedua hal 1….\r\ntertulis dapa dapa….seharusnya dapat\r\ntertulis berada pada tegangan aman.Pada ….seharusnya berada pada tegangan aman. Pada\r\ntertulis cell….seharusnya cell \r\ntertulis menyebabkan menurunya ….seharusnya menyebabkan menurunnya \r\nalinea ke tiga hal 1…\r\nTertulis Cara paling mudah untuk membatasi tegangan maksimal dan minimal yaitu dengan memutus koneksi baterai tetapi….seharusnya Cara paling mudah untuk membatasi tegangan maksimal dan minimal yaitu dengan memutus koneksi baterai. Akan tetapi…..\r\nalinea terakhir hal 1\r\nhanya satu kalimat dalam satu alinea?\r\nseharusnya kalimat setelahnya bergabung dg kalimat sebelumnya. \r\nSaya cek dg referensi 6…ternyata Fan Zhang menulis bersama dg penulis lainnya….seharusnya Fan Zhang dkk [6] \r\nCoba jelaskan hasil penelitian Zhang dkk? dalam hasil tidak disebutkan adanya pengukuran SOC\r\nalinea terakhir pada latar belakang masalah hal 2\r\nTertulis : \r\nDari beberapa penelitian tersebut kebanyakan menggunakan sistem pasif maupun sistem penyeimbang aktif yang menggunakan konverter sehingga permasalahan yang hampir sama yaitu pada keandalan dan kerumitan sistem yang menjadi dasar dari penelitian ini. Adapun dalam penelitian ini akan diusulkan rancang bangun yang bersifat eksperimental untuk melakukan proteksi dan balancing pada tiap cell baterai lithium ion dengan teknik bypass menggunakan MOSFET dengan harapan memiliki tingkat efisiensi yang tinggi, balancing yang cepat dengan kesulitan sistem yang lebih rendah. \r\ndi revisi\r\n\r\nMohon di cek tujusan penelitian dengan kesimpulan:\r\nTujuan penelitian:\r\n1.	Merancang simulasi proteksi cell baterai dengan teknik bypass untuk mengetahui apakah sistem bypass cell dengan 3 mosfet dapat dilakukan.  \r\n2.	Merancang hardware sistem proteksi cell baterai dengan teknik bypass.  \r\n3.	Menguji sistem proteksi cell baterai dengan teknik bypass dengan melakuakan pengujian nilai presisi dan akurasi pembacaan sensor, pengujian bypass cell dengan 3 mosfet pada tiap cel, pengujian proteksi overcharging, discharging dan overcurrent, dan pengujian monitoring baterai pada aplikasi  blynk.  \r\n4.	Menganalisis sistem proteksi cell baterai dengan teknik bypass untuk  mengetahui apakan sistem seperti pembacaan sensor, bypass, proteksi dan monitoring dapat bekerja dengan baik atau tidak.  \r\nKesimpulan:\r\n1. Dengan menggunakan sensor ADC 16 bit yang terisolasi pembacaan tegangan memiliki tingkat presisi rata-rata 99,98% dengan tingkat akurasi rata-rata 99,94%. Sedangkan pada sensor arus menggunakan ACS712 dengan range 5 ampere memiliki tingkat presisi 36,97% dengan tingkat akurasi 91%.  \r\n2. Hasil pengujian Active Bypass pada sistem yang dibuat dapat bekerja pada keadaan pengisian baterai dengan tidak terjadi kenaikan tegangan pada cel yang terbypass saat proses pengisian sedangkan pada keadaan dengan beban bypass cel tidak dapat dilakukan dikarenakan nilai tegangan yang tidak mencukupi untuk mengaktifkan mosfet sehingga terjadi Cutoff.  \r\n3. Hasil pengujian proteksi undervoltage dengan nilai tegangan minimal 2,6V sistem proteksi dapat bekerja dengan terjadi cutoff pada tegangan 2,59987V. pada pengujian proteksi overvoltage dengan tegangan maksimal 3,5V sistem proteksi dapat bekerja dengan terjadi bypass pada baterai 1 pada tegangan 3,54169V. Pada pengujian overcurrent dengan arus maksimal 0,5Ampere dapat bekerja dengan terjadi cutoff pada arus lonjakan 0,72 Ampere.  \r\n\r\nBab 2:\r\nGambar 2 hal  8 tidak jelas….jika bisa digambar sendiri sebaiknya digambar.\r\nPenulisan kutipan dalam artikel menggunakan last name….Ricco dan Manenti', 1, '2020-06-25 09:03:23', '2020-06-25 09:03:42');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (18, 40, NULL, 80, 80, 85, 75, NULL, 90, 90, 85, 85, 90, NULL, 85, 85, 85, 85, '- Perlu diberi analisis distorsi (THD dan singnal clipping)\r\n- Pengukuran THD bisa dilakukan dengan mengambil data dari osiloskop\r\n- Langkah Desain filter sebaiknya dibalik, dari penentuan fc kemudian penentuan nilai R dan C yang digunakan', 1, '2020-06-30 11:02:44', '2020-06-30 11:02:49');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (19, 41, NULL, 88, 86, 85, 80, NULL, 90, 85, 80, 87, 87, NULL, 86, 82, 82, 85, 'Cek dan perbaiki typo\r\nGambar dilampiran diberikan keterangan.\r\nGambar 4.19 dan 4.23 gambar dan keterangan dipisah, biar lebih jelas', 1, '2020-06-30 11:04:26', '2020-06-30 11:06:58');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (20, 42, NULL, 80, 80, 80, 80, NULL, 80, 80, 80, 80, 80, NULL, 80, 80, 80, 80, 'Nanti diihat di tesk yang saya kirimkan. 1.	Pengujian dan pembuatan trafo belum terlihat\r\n2.	Apa fungsi menggunakan H-Link 12 V\r\n3.	SoC?\r\n4.	Balancing discharging?\r\n5.	Masalah penelitian yan inigin doselesiakan\r\n6.	Alasana memlihi metode flyback converter\r\n7.	Perbedaan penelitian dengan no,13\r\n8.	Kelebihan penelitian\r\n9.	Letak kontribusi penelitian\r\n10.	Efisiensi alat yang diguanakan\r\n11.	Pembuktian fungsi bms\r\n12.	Proses penambahan BMS untuk seri paralenya bagaimna?\r\n13.	Speks Mosfet sampai berpaa\r\n14.	Spesifikasi alatnya?\r\n15.	PPT presentais dibuat menarik dan bisa dibaca dengan baik\r\n16.	Typo dll', 1, '2020-07-13 09:09:38', '2020-07-13 09:09:42');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (21, 43, NULL, 85, 90, 80, 70, NULL, 85, 90, 90, 85, 85, NULL, 90, 90, 90, 86, '1. Judul \"Rancang Bangun\" saran saya diganti atau dihilangkan.\r\n2. Tuuan diperbaiki.\r\n3. Referensi skripsi ITS diperjelas. Sebaiknya gunakan paper atau proceeding.\r\n4. Referensi 5 tahun terakhir diperbanyak.\r\n5. Mungkin perlu ditambahkan proses Balancing waktu charging.', 1, '2020-07-13 10:31:44', '2020-07-13 10:31:55');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (22, 48, NULL, 90, 80, 80, 85, NULL, 85, 85, 80, 85, 85, NULL, 90, 90, 90, 86, '1. Tambahkan fleksibilitas dalam penambahan node dan sensor\r\n2. Mitigasi eror karena terlalu banyak data di database, misal backup atau delete berjalan', 1, '2020-07-15 13:26:31', '2020-07-15 13:27:49');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (23, 49, NULL, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 90, NULL, 90, 90, 90, 90, 'Sudah bagus. Tinggal diujikan secara realtime.', 1, '2020-07-15 13:39:16', '2020-07-15 13:39:24');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (24, 47, NULL, 88, 88, 88, 85, NULL, 89, 89, 89, 89, 88, NULL, 90, 90, 90, 89, '1. Rumusan Masalah poin A disesuaikan dengan judul. \r\n2. Sumber Gambar dikonsistenkan penulisan sumber nya.\r\n3. Hasil Pengjuian Peforma Sistem OBE dijelaskan', 1, '2020-07-15 14:51:48', '2020-07-15 14:54:18');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (25, 46, NULL, 80, 82, 79, 80, NULL, 82, 83, 80, 78, 80, NULL, 79, 78, 78, 80, 'kenapa RAD? \r\npengujian realibility', 1, '2020-07-15 15:02:24', '2020-07-15 15:02:36');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (26, 45, NULL, 87, 88, 87, 80, NULL, 85, 84, 84, 85, 83, NULL, 85, 86, 85, 85, 'Revisi saya lampirkan di halaman tersendiri dan saya kirimkan ke mahasiswa', 1, '2020-07-15 17:07:41', '2020-07-16 10:57:53');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (27, 44, NULL, 80, 85, 85, 77, NULL, 88, 85, 88, 87, 75, NULL, 83, 81, 83, 83, 'catatan revisi ada pada draft TA (terlampir).', 1, '2020-07-15 17:44:35', '2020-07-15 17:44:58');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (28, 50, NULL, 75, 75, 85, 75, NULL, 75, 75, 75, 75, 75, NULL, 85, 80, 80, 78, 'Metodologi diperbaiki terutama terkait uji performa.\r\nBatasan dan asumsi juga perlu', 1, '2020-07-16 11:19:37', '2020-07-16 11:20:55');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (29, 51, NULL, 78, 76, 79, 80, NULL, 75, 76, 73, 74, 75, NULL, 76, 78, 77, 76, 'analisa jarak terhadap realibility system\r\narsitektur perancangan', 1, '2020-07-16 11:21:22', '2020-07-16 11:21:28');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (30, 52, NULL, 85, 84, 82, 85, NULL, 90, 85, 85, 82, 85, NULL, 82, 82, 84, 84, '1) Cek typo\r\n2) Gambar 3.1, dalam flowchart alur hindari mencantumkan rumus, cukup hitung Is dll\r\n3) Validasi sensor arus dgn multimeter', 1, '2020-07-16 13:58:24', '2020-07-16 14:15:46');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (31, 53, NULL, 80, 80, 84, 78, NULL, 85, 80, 83, 84, 78, NULL, 82, 81, 80, 81, 'Catatan perbaikan ada pada draft TA.', 1, '2020-07-16 14:21:01', '2020-07-16 14:21:14');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (32, 54, NULL, 85, 87, 89, 87, NULL, 85, 88, 87, 87, 85, NULL, 85, 86, 85, 86, 'Revisi saya sertakan langsung di draf TA', 1, '2020-07-20 09:02:57', '2020-07-20 09:03:14');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (33, 55, NULL, 85, 85, 90, 90, NULL, 85, 80, 85, 85, 85, NULL, 85, 85, 85, 85, 'Saran\r\n- tambahkan gambar/foto saat penelitian\r\n- Beri penjelasan saat analisis\r\n- Tambahkan karakteristik V-A , apakah sesuai dengan teori?\r\n- Konfirmasi 4.6 sampai 4.10, apakah sesuai dengan teori?', 1, '2020-07-20 09:07:38', '2020-07-20 09:07:44');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (34, 57, NULL, 85, 87, 89, 84, NULL, 88, 85, 85, 89, 88, NULL, 85, 86, 86, 86, 'Revisi disertakan langsung di draf', 1, '2020-07-20 10:23:40', '2020-07-20 10:23:46');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (35, 56, NULL, 85, 83, 81, 86, NULL, 80, 75, 80, 76, 77, NULL, 75, 80, 76, 79, 'berikan permodelannya', 1, '2020-07-20 11:09:51', '2020-07-20 11:10:04');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (36, 62, NULL, 80, 80, 80, 80, NULL, 80, 80, 80, 80, 80, NULL, 80, 80, 80, 80, '1.Proses Analisis 2.Hasil Analisis untuk apa', 1, '2020-07-20 21:04:20', '2020-07-20 21:04:20');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (37, 63, NULL, 80, 80, 80, 80, NULL, 80, 80, 80, 80, 80, NULL, 80, 80, 80, 80, '1.Ada analisa matematik 2.Pastikan parameternya sama 3.Sesuaikan kesimpulan dengan pertanyaan', 1, '2020-07-20 21:04:52', '2020-07-20 21:04:52');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (38, 70, NULL, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 88, NULL, 88, 88, 88, 88, 'Masukan dewan penguji ditindak lanjuti', 1, '2020-07-23 09:30:33', '2020-07-23 09:30:40');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (39, 58, NULL, 80, 60, 70, 75, NULL, 70, 85, 85, 75, 60, NULL, 80, 75, 75, 74, 'SARAN:\r\nPakai bookmark\r\nKesimpulan no.1 dan 2  hanya Semarang saja?\r\nKesimpulan no.3 dan 4 selisih?\r\n\r\nREVISI:\r\n1. Mengapa Pembangkit hybrida?\r\n2. Bagaimana konfigurasi Sistem on grid vs offgrid?\r\nuntuk on grid bagaimana asumsi harga jual dan beli ke grid? sesuaikan dengan Permen ESDM\r\n3. Lebih detail dalam analisis penggunaannya untuk Charging station EV (komponen charger EV apa saja dan capital berapa)\r\n4. Tunjukkan perbandingan HOMER dan optimasi GA? Jelaskan mengapa lebih baik/buruk\r\n5. Breakdown cost dalam pie chart, olah lagi \r\n6. Tambahkan payback period, kemudian bandingkan\r\n- Hybrid On grid\r\n- Hybrid  Off grid\r\n- PV saja\r\n- WTG saja', 1, '2020-07-23 09:32:14', '2020-07-23 09:32:29');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (40, 59, NULL, 80, 80, 82, 75, NULL, 80, 78, 80, 76, 80, NULL, 82, 80, 82, 80, '1. nilai optimasi kurang optimal, belum jelas poin mana yang akan dioptimalkan.\r\n2. catatan lainya ada di draft TA.', 1, '2020-07-23 09:37:35', '2020-07-23 09:37:56');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (41, 60, NULL, 85, 85, 84, 84, NULL, 84, 85, 87, 88, 86, NULL, 84, 85, 86, 85, 'revisi ada pada draf TA', 1, '2020-07-23 10:50:19', '2020-07-23 10:50:37');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (42, 61, NULL, 85, 84, 84, 86, NULL, 90, 86, 85, 82, 85, NULL, 82, 80, 80, 84, '1) Format penulisan daftar isi dirapikan\r\n2) Jelaskan rangkaian pengujian, kenapa input DC output AC, bagaimana prosesnya', 1, '2020-07-23 10:57:31', '2020-07-23 11:07:13');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (43, 64, NULL, 78, 80, 85, 90, NULL, 78, 78, 78, 80, 80, NULL, 85, 85, 85, 82, '1.	Rujukan dalam daftar pustaka \r\n2.	Batasan Masalah \r\n4.	Bab 3 saya tidak memasukkan perhitungan sama sekali, torsi yg diperlukan, rumus suhu, temperatur, arus, Effesiensi \r\n6.	Validasi di situ presisi atau akurasi? \r\n7.	Gambar 4.1 ?\r\n8.	Saat uji water cooling dan tracking, mengapa watt nya sama?', 1, '2020-07-24 09:00:30', '2020-07-24 09:01:03');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (44, 65, NULL, 84, 85, 84, 87, NULL, 80, 82, 83, 84, 87, NULL, 82, 84, 85, 84, 'Data-data lengkap selama 7 hari berkaitan dengan hasil penelitianmu ditampilkan dalam naskah tugas akhir, batasan-batasan masalah dalam naskah tugas akhir seperti single axis, dan lain-lain, spesifikasi peralatan penelitianmu serta cara pengukuran, pengambilan data ditampilkan dalam naskah tugas akhir.', 1, '2020-07-24 09:12:46', '2020-07-24 09:12:54');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (45, 71, NULL, 85, 85, 80, 85, NULL, 88, 83, 80, 83, 75, NULL, 83, 84, 81, 83, '- perlu penyelarasan antara Rumusan masalah dan kesimpulan penelitian.\r\n- catatan revisi yang lainnya ada di draft elektronik, mohon menghubungi untuk kemudian saya kirimkan.', 1, '2020-07-24 11:36:44', '2020-07-24 11:36:53');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (46, 66, NULL, 84, 85, 87, 83, NULL, 86, 85, 84, 80, 85, NULL, 86, 85, 84, 85, 'Revisi disertakan di draf', 1, '2020-07-24 13:55:01', '2020-07-24 13:55:19');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (47, 67, NULL, 85, 85, 85, 90, NULL, 90, 86, 90, 90, 90, NULL, 85, 85, 90, 88, 'Edit abstrak untuk menjelaskan metoder dan ringkasan hasil, beri flowchart atau diagram alat, kemudian daftar istilah', 1, '2020-07-24 14:16:38', '2020-07-24 14:16:43');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (48, 69, NULL, 80, 80, 80, 80, NULL, 70, 60, 70, 70, 70, NULL, 70, 70, 70, 72, '- Salah ketik (typo) mohon diperbaiki. Mohon dibaca secara menyeluruh dambil dicek kesalahan kata yang muncul.\r\n- Laporan bisa dilengkapi dengan penggalian user requirement dalam pengembangan perangkat lunak \r\n- Pengujian user acceptance testing bisa melengkapi laporan skripsi ini\r\n- Kode javascript dari luar apa tidak bisa dilokalkan?\r\n- Bisa dipertimbangkan cara intelejensia dengan FAQ', 1, '2020-07-24 15:59:26', '2020-07-24 15:59:46');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (49, 68, NULL, 85, 85, 85, 85, NULL, 85, 85, 85, 85, 85, NULL, 85, 85, 85, 85, '+ Dispesikkan topiknya, misalnya Chatbot untuk Covid, untuk Toko dsb\r\n+ Tambahkan fungsi intelligence yang sederhana , (misal mengingat pertanyaan yang sering ditanyakan, kemudian langsung ditampilkan)', 1, '2020-07-24 16:08:48', '2020-07-24 16:08:52');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (50, 72, NULL, 75, 80, 80, 80, NULL, 78, 78, 78, 78, 78, NULL, 80, 80, 80, 79, 'Mohon dinyatakan urgensi riset terutama terkait dengan posisi riset2 terkini.', 1, '2020-07-27 16:50:05', '2020-07-27 16:59:21');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (51, 73, NULL, 85, 84, 86, 88, NULL, 87, 86, 84, 80, 82, NULL, 82, 85, 83, 84, '1. dilengkapi tabel 4.1 terutama posisi LED yang hidup dan mencerminkan hasil penelitianmu\r\n2. gambar di bab 4 dijelaskan lebih detail\r\n3. gambar diperjelas agar lebih kelihatan\r\n4. perbaiki naskah TA mu agar mudah dimengerti oleh pembaca\r\n5. mengambil data lagi\r\n6. saya masih mendapatkan teori dasar di bab 2 mengacu pada paper, seperti BER, cari handbook atau text book', 1, '2020-07-27 17:31:52', '2020-07-27 17:32:01');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (52, 75, NULL, 78, 85, 80, 90, NULL, 80, 80, 80, 80, 85, NULL, 90, 90, 90, 84, '1. VLC? Minimal di Abstrak ada kepanjangannya \r\n2. Penelitian ini diharapkan mampu menjadi salah satu inovasi baru didunia\r\nkomunikasi khususnya pada Visible Light Communication dengan penambahan\r\nkecerdasan buatan pada pagian modulasi antenna. Dimana kecerdasan buatannya? \r\n3. Hipotesis??? di Buku TA gak ada \r\n4. Judul Gambar 3.1 kurang pas  \r\n5. Skematik PCB/Rangkaian? \r\n6. Pengujian jarak/frekuensi untuk apa? di Bab 3 tidak ada? \r\n7. Bab 3 tidak ada rumus perhitungan sama sekali \r\n8. Foto Prototype kurang jelas \r\n9. Bab 4 uji prototipe banyak gambar, tanpa Penjelasan? \r\n10. Kesimpulan harus sesuai dengan Rumusan Masalah', 1, '2020-07-27 19:42:29', '2020-07-27 20:07:52');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (53, 74, NULL, 85, 85, 87, 87, NULL, 85, 80, 80, 78, 80, NULL, 80, 82, 82, 82, '1)	Istilah asing miring\r\n2)	Bab 2 lebih detail, usahakan ada gambar biar menarik dan lebih mudah dipahami. Usahakan pada bab 2 menjelaskan teori tentang alat/ desain yg kmu buat, sehingga orang yang tidak mendalamami bidang ini jg tahu. Seperti yg ada di ppt presentasimu itu ada ilustrasinya\r\n3)	Bab 3 tambahkan flowchart alur penelitian\r\n4)	Sub-bab 3.5-3.7 sangat kurang penjelasan\r\n5)	Daftar isi dan citasi gunakan IEEE style, dengan nomor, misal [1], dst.\r\n6)	Tambahkan lampiran code dan foto dokumentasi', 1, '2020-07-27 19:57:11', '2020-07-27 19:58:05');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (54, 76, NULL, 80, 80, 80, 80, NULL, 80, 80, 80, 80, 80, NULL, 75, 80, 70, 79, '- Apakah penyadap ECG bisa digunakan berulangkali? Gambar ilustrasi penyadapan yang nyata perlu dilampirkan.\r\n- Sebaiknya aplikasi bisa menyimpan history\r\n- Apakah gambar grafik menanjak bisa dimodifikasi mendatar sebagaimana denyut jantung yang tampak pada alat ECG (Gambar 3.17)\r\n- Perlu dijelaskan mengapa perlu sensor detak jantung dan ECG.\r\n- Dari perangkat embedded ke Android apakah perlu koneksi internet? Komunikasi datanya perlu diperjelas.', 1, '2020-08-03 16:11:19', '2020-08-03 16:51:16');
INSERT INTO `ta_nilaisemhas_penguji` VALUES (55, 77, NULL, 87, 86, 85, 85, NULL, 90, 88, 85, 82, 82, NULL, 84, 82, 82, 85, '1)	Perbaiki daftar isi, setelah BAB I itu Pendahuluan bukan titik-titik. Lampiran kalua tidak ada halaman tidak usah titik-titik\r\n2)	Gunakan sitasi yg konsisten, tabel 2.1 citasi tidak pakai angka. Selain itu dibagian text citasi dicampur, pakai tahun tapi pakai angka juga, pilih salah satu dan konsisten. Di TE UNS biasanya kita pakai angka\r\n3)	Jelaskan keunikan punyamu dibanding lainya di bab 2.1\r\n4)	Flowchart 3.8 kok tidak ada selesainya\r\n5)	Aplikasi Blink dibahas juga di bab 4 dek, GUI yg kmu buat utk pengujian', 1, '2020-08-03 16:58:19', '2020-08-03 16:58:27');

-- ----------------------------
-- Table structure for ta_pembimbing
-- ----------------------------
DROP TABLE IF EXISTS `ta_pembimbing`;
CREATE TABLE `ta_pembimbing`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ta_id` int(15) NULL DEFAULT NULL,
  `pembimbing` int(15) NULL DEFAULT NULL,
  `pem` int(15) NULL DEFAULT NULL,
  `status_pem` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `status_semhas` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `status_pendadaranpem` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `nilai_semhas` float NULL DEFAULT NULL,
  `nilai_pendadaran` float NULL DEFAULT NULL,
  `status_perubahanjudul` smallint(6) NULL DEFAULT 2,
  `status_perubahanpembimbing` smallint(6) NULL DEFAULT 2,
  `status_perpanjangan1` smallint(6) NULL DEFAULT 2,
  `status_perpanjangan2` smallint(6) NULL DEFAULT 2,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `pembimbing_ta`(`ta_id`) USING BTREE,
  INDEX `pembimbing_ref`(`pembimbing`) USING BTREE,
  CONSTRAINT `ta_pembimbing_ibfk_1` FOREIGN KEY (`pembimbing`) REFERENCES `ref_dosen` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `ta_pembimbing_ibfk_2` FOREIGN KEY (`ta_id`) REFERENCES `ta` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 118 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ta_pembimbing
-- ----------------------------
INSERT INTO `ta_pembimbing` VALUES (29, 33, 3, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2019-05-27 00:00:00', '2020-08-04 18:16:39');
INSERT INTO `ta_pembimbing` VALUES (30, 33, 2, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2019-05-27 00:00:00', '2020-08-04 18:16:39');
INSERT INTO `ta_pembimbing` VALUES (31, 34, 3, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2019-05-29 00:00:00', '2020-08-04 18:15:30');
INSERT INTO `ta_pembimbing` VALUES (32, 34, 5, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2019-05-29 00:00:00', '2020-08-04 18:15:30');
INSERT INTO `ta_pembimbing` VALUES (33, 35, 9, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2019-05-29 00:00:00', '2020-07-21 20:19:20');
INSERT INTO `ta_pembimbing` VALUES (34, 35, 8, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2019-05-29 00:00:00', '2020-07-21 20:19:20');
INSERT INTO `ta_pembimbing` VALUES (35, 36, 3, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2019-07-03 00:00:00', '2020-08-04 18:15:52');
INSERT INTO `ta_pembimbing` VALUES (36, 36, 2, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2019-07-03 00:00:00', '2020-08-04 18:15:52');
INSERT INTO `ta_pembimbing` VALUES (37, 37, 1, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2019-07-09 00:00:00', '2020-07-21 20:18:49');
INSERT INTO `ta_pembimbing` VALUES (38, 37, 4, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2019-07-09 00:00:00', '2020-07-21 20:18:49');
INSERT INTO `ta_pembimbing` VALUES (39, 38, 1, 1, 'SETUJU', NULL, NULL, NULL, NULL, 1, 2, 2, 2, '2019-07-09 00:00:00', '2020-07-31 18:06:52');
INSERT INTO `ta_pembimbing` VALUES (40, 38, 5, 2, 'SETUJU', NULL, NULL, NULL, NULL, 1, 2, 2, 2, '2019-07-09 00:00:00', '2020-07-31 18:06:52');
INSERT INTO `ta_pembimbing` VALUES (41, 39, 11, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2019-08-28 00:00:00', '2020-08-04 18:15:10');
INSERT INTO `ta_pembimbing` VALUES (42, 39, 19, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2019-08-28 00:00:00', '2020-08-04 18:15:10');
INSERT INTO `ta_pembimbing` VALUES (66, 40, 5, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-07-17 19:56:49');
INSERT INTO `ta_pembimbing` VALUES (67, 40, 2, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-07-17 19:56:49');
INSERT INTO `ta_pembimbing` VALUES (68, 41, 9, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-08-04 18:18:22');
INSERT INTO `ta_pembimbing` VALUES (69, 41, 10, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-08-04 18:18:22');
INSERT INTO `ta_pembimbing` VALUES (70, 42, 11, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-07-07 17:05:10');
INSERT INTO `ta_pembimbing` VALUES (71, 42, 9, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-07-07 17:05:10');
INSERT INTO `ta_pembimbing` VALUES (72, 43, 11, 1, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-01-27 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (73, 43, 7, 2, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-01-27 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (74, 44, 10, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-08-04 16:17:08');
INSERT INTO `ta_pembimbing` VALUES (75, 44, 11, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-08-04 16:17:08');
INSERT INTO `ta_pembimbing` VALUES (76, 45, 17, 1, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-01-27 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (77, 45, 5, 2, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-01-27 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (78, 46, 9, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-08-04 18:18:03');
INSERT INTO `ta_pembimbing` VALUES (79, 46, 4, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-01-24 00:00:00', '2020-08-04 18:18:03');
INSERT INTO `ta_pembimbing` VALUES (80, 47, 8, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2020-03-04 00:00:00', '2020-07-31 18:09:17');
INSERT INTO `ta_pembimbing` VALUES (81, 47, 5, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2020-03-04 00:00:00', '2020-07-31 18:09:17');
INSERT INTO `ta_pembimbing` VALUES (82, 48, 2, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-03-06 00:00:00', '2020-07-27 20:12:56');
INSERT INTO `ta_pembimbing` VALUES (83, 48, 3, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-03-06 00:00:00', '2020-07-27 20:12:56');
INSERT INTO `ta_pembimbing` VALUES (84, 49, 8, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2020-03-06 00:00:00', '2020-07-10 06:52:31');
INSERT INTO `ta_pembimbing` VALUES (85, 49, 5, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2020-03-06 00:00:00', '2020-07-10 06:52:31');
INSERT INTO `ta_pembimbing` VALUES (86, 50, 2, 1, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-06 00:00:00', '2020-03-06 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (87, 50, 6, 2, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-06 00:00:00', '2020-03-06 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (88, 51, 2, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-03-09 00:00:00', '2020-07-13 18:52:16');
INSERT INTO `ta_pembimbing` VALUES (89, 51, 17, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-03-09 00:00:00', '2020-07-13 18:52:16');
INSERT INTO `ta_pembimbing` VALUES (90, 52, 3, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-03-11 00:00:00', '2020-07-28 12:49:00');
INSERT INTO `ta_pembimbing` VALUES (91, 52, 2, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-03-11 00:00:00', '2020-07-28 12:49:00');
INSERT INTO `ta_pembimbing` VALUES (92, 53, 1, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2020-03-11 00:00:00', '2020-08-04 13:45:46');
INSERT INTO `ta_pembimbing` VALUES (93, 53, 5, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2020-03-11 00:00:00', '2020-08-04 13:45:46');
INSERT INTO `ta_pembimbing` VALUES (94, 54, 8, 1, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-11 00:00:00', '2020-03-11 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (95, 54, 5, 2, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-11 00:00:00', '2020-03-11 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (96, 55, 1, 1, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-11 00:00:00', '2020-03-11 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (97, 55, 9, 2, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-11 00:00:00', '2020-03-11 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (98, 56, 11, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-03-13 00:00:00', '2020-07-26 16:09:12');
INSERT INTO `ta_pembimbing` VALUES (99, 56, 7, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-03-13 00:00:00', '2020-07-26 16:09:12');
INSERT INTO `ta_pembimbing` VALUES (100, 57, 7, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-03-13 00:00:00', '2020-07-22 16:42:47');
INSERT INTO `ta_pembimbing` VALUES (101, 57, 17, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 2, 2, 2, 2, '2020-03-13 00:00:00', '2020-07-22 16:42:47');
INSERT INTO `ta_pembimbing` VALUES (102, 58, 2, 1, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-13 00:00:00', '2020-03-13 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (103, 58, 11, 2, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-13 00:00:00', '2020-03-13 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (104, 59, 18, 1, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-13 00:00:00', '2020-07-14 12:04:15');
INSERT INTO `ta_pembimbing` VALUES (105, 59, 5, 2, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-13 00:00:00', '2020-07-14 12:04:15');
INSERT INTO `ta_pembimbing` VALUES (106, 60, 10, 1, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-13 00:00:00', '2020-03-13 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (107, 60, 2, 2, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-13 00:00:00', '2020-03-13 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (108, 61, 8, 1, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-13 00:00:00', '2020-03-13 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (109, 61, 5, 2, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-13 00:00:00', '2020-03-13 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (110, 62, 17, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2020-03-13 00:00:00', '2020-07-26 16:08:13');
INSERT INTO `ta_pembimbing` VALUES (111, 62, 2, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2020-03-13 00:00:00', '2020-07-26 16:08:13');
INSERT INTO `ta_pembimbing` VALUES (112, 63, 5, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2020-03-13 00:00:00', '2020-08-01 08:38:44');
INSERT INTO `ta_pembimbing` VALUES (113, 63, 18, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2020-03-13 00:00:00', '2020-08-01 08:38:44');
INSERT INTO `ta_pembimbing` VALUES (114, 64, 5, 1, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2020-03-13 00:00:00', '2020-07-27 18:42:25');
INSERT INTO `ta_pembimbing` VALUES (115, 64, 2, 2, 'SETUJU', 'SETUJU', 'SETUJU', NULL, NULL, 1, 2, 2, 2, '2020-03-13 00:00:00', '2020-07-27 18:42:25');
INSERT INTO `ta_pembimbing` VALUES (116, 65, 4, 1, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-16 00:00:00', '2020-03-16 00:00:00');
INSERT INTO `ta_pembimbing` VALUES (117, 65, 5, 2, 'SETUJU', NULL, NULL, NULL, NULL, 2, 2, 2, 2, '2020-03-16 00:00:00', '2020-03-16 00:00:00');

-- ----------------------------
-- Table structure for ta_pendadaran
-- ----------------------------
DROP TABLE IF EXISTS `ta_pendadaran`;
CREATE TABLE `ta_pendadaran`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `ta_id` int(15) NOT NULL,
  `tanggal` date NULL DEFAULT NULL,
  `tempat` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `jam_mulai` time(0) NULL DEFAULT NULL,
  `jam_selesai` time(0) NULL DEFAULT NULL,
  `nilai_pendadaran` float NULL DEFAULT NULL,
  `status_pendadaran` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cetak_pendadaran` int(11) NULL DEFAULT NULL,
  `kelulusan` tinyint(6) NULL DEFAULT 2,
  `nilai_angka` double(15, 2) NULL DEFAULT NULL,
  `nilai_huruf` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `nilai_skala` double(6, 2) NULL DEFAULT NULL,
  `draft_pendadaran` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `id_ta`(`ta_id`) USING BTREE,
  CONSTRAINT `ta_pendadaran_ibfk_1` FOREIGN KEY (`ta_id`) REFERENCES `ta` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 34 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ta_pendadaran
-- ----------------------------
INSERT INTO `ta_pendadaran` VALUES (12, 49, '2020-07-03', '9', '08:00:00', '10:00:00', NULL, 'SETUJU', 0, 1, 88.20, 'A', 4.00, 'https://drive.google.com/file/d/19qE25CVqWs4M-SLfyFoXSoj7sJ4Bjv7N/view?usp=sharing', '2020-07-01 12:36:11', '2020-07-03 10:08:14');
INSERT INTO `ta_pendadaran` VALUES (13, 42, '2020-07-10', '9', '08:00:00', '10:00:00', NULL, 'SETUJU', 0, 1, 90.00, 'A', 4.00, 'https://drive.google.com/drive/folders/1QKjWx6IAPYgtRt4q3qrfjBa9x8z62PE8?usp=sharing', '2020-07-07 11:57:33', '2020-07-15 11:31:20');
INSERT INTO `ta_pendadaran` VALUES (14, 51, '2020-07-16', '9', '08:00:00', '10:00:00', NULL, 'SETUJU', 0, 1, 91.50, 'A', 4.00, 'https://drive.google.com/file/d/17sxW0wOx_oiChzNMn5TU3LwE6RWvFdlP/view?usp=sharing', '2020-07-13 04:32:50', '2020-07-23 18:33:18');
INSERT INTO `ta_pendadaran` VALUES (15, 40, '2020-07-20', '9', '13:00:00', '15:00:00', NULL, 'SETUJU', 0, 1, 88.90, 'A', 4.00, 'https://bit.ly/skripsivernanda1', '2020-07-17 17:42:46', '2020-07-24 20:08:24');
INSERT INTO `ta_pendadaran` VALUES (16, 35, '2020-07-22', '9', '15:30:00', '17:30:00', NULL, 'SETUJU', 0, 1, 83.70, 'A-', 3.70, 'https://drive.google.com/file/d/1LyYW7iN4FoQ1F6sqEoUWZYQIHSR6h5H-/view?usp=sharing', '2020-07-21 12:00:31', '2020-08-04 14:26:43');
INSERT INTO `ta_pendadaran` VALUES (17, 37, '2020-07-23', '9', '13:00:00', '15:00:00', NULL, 'SETUJU', 0, 2, NULL, NULL, NULL, 'https://drive.google.com/file/d/1vG_p65owI53KX4UeMXlpk81W4q4X4w34/view?usp=sharing', '2020-07-21 15:01:02', '2020-07-21 20:18:48');
INSERT INTO `ta_pendadaran` VALUES (18, 57, '2020-07-24', '9', '10:00:00', '12:00:00', NULL, 'SETUJU', 0, 1, 93.20, 'A', 4.00, 'https://drive.google.com/file/d/146NEhZWkFt2vL_L_2QC4DXNRpBraNyol/view?usp=sharing', '2020-07-22 13:01:12', '2020-07-24 14:23:07');
INSERT INTO `ta_pendadaran` VALUES (19, 62, '2020-07-28', '9', '20:00:00', '22:00:00', NULL, 'SETUJU', 0, 1, 89.70, 'A', 4.00, 'https://drive.google.com/file/d/1DCKSju-1wLLSOEIxncMOxPW9Bk6z34NY/view?usp=sharing', '2020-07-23 14:26:57', '2020-07-28 21:45:39');
INSERT INTO `ta_pendadaran` VALUES (20, 47, '2020-07-27', '9', '08:00:00', '10:00:00', NULL, 'SETUJU', 0, 1, 88.50, 'A', 4.00, 'https://drive.google.com/drive/folders/17PRLg5wuflCAemfRFFH5Lc0XKAr3n23V?usp=sharing', '2020-07-23 15:11:18', '2020-07-27 09:34:20');
INSERT INTO `ta_pendadaran` VALUES (21, 56, '2020-07-29', '9', '16:00:00', '18:00:00', NULL, 'SETUJU', 0, 1, 89.30, 'A', 4.00, 'https://bit.ly/draft_ta_adip_I071001', '2020-07-24 13:05:33', '2020-07-29 17:18:43');
INSERT INTO `ta_pendadaran` VALUES (22, 48, '2020-07-30', '9', '19:00:00', '21:00:00', NULL, 'SETUJU', 0, 1, 86.90, 'A', 4.00, 'https://drive.google.com/file/d/1M-8utmTTPLv4K7DkTVU6GTGa30QqXNWX/view?usp=sharing', '2020-07-27 10:41:13', '2020-07-30 20:39:52');
INSERT INTO `ta_pendadaran` VALUES (23, 64, '2020-07-29', '9', '15:30:00', '17:30:00', NULL, 'SETUJU', 0, 1, 86.80, 'A', 4.00, 'https://drive.google.com/file/d/1PSAkBwOjsysoRlQB8deR58AzV-cwS2G7/view?usp=sharing', '2020-07-27 10:47:32', '2020-07-29 17:29:16');
INSERT INTO `ta_pendadaran` VALUES (24, 63, '2020-07-29', '9', '19:00:00', '21:00:00', NULL, 'SETUJU', 0, 1, 89.20, 'A', 4.00, 'https://drive.google.com/file/d/1e_BvZ9BmzMN31dt1ikzooeGX2t6YyvCO/view?usp=sharing', '2020-07-27 15:03:35', '2020-07-29 22:10:30');
INSERT INTO `ta_pendadaran` VALUES (25, 52, '2020-07-30', '9', '16:00:00', '18:00:00', NULL, 'SETUJU', 0, 1, 89.00, 'A', 4.00, 'https://drive.google.com/file/d/1RfS1NwpQOgl3A2aOaJHAxgO7TNsNrpsv/view?usp=sharing', '2020-07-28 02:47:02', '2020-07-30 17:22:11');
INSERT INTO `ta_pendadaran` VALUES (26, 44, '2020-08-06', '9', '16:00:00', '18:00:00', NULL, 'SETUJU', 0, 2, NULL, NULL, NULL, 'https://drive.google.com/file/d/1ibAPk0wk-xFxOFyzGhWCFk1qMqoIAhdW/view?usp=sharing', '2020-07-31 21:02:49', '2020-08-04 18:19:57');
INSERT INTO `ta_pendadaran` VALUES (27, 53, '2020-08-06', '9', '16:00:00', '18:00:00', NULL, 'SETUJU', 0, 2, NULL, NULL, NULL, 'https://drive.google.com/drive/folders/1ZEc9ckEbFNfJ3o1WqHWKrdGmjsSNKLkF?usp=sharing', '2020-08-04 10:52:41', '2020-08-04 18:19:03');
INSERT INTO `ta_pendadaran` VALUES (28, 41, '2020-08-07', '9', '19:00:00', '21:00:00', NULL, 'SETUJU', 0, 2, NULL, NULL, NULL, 'https://drive.google.com/drive/folders/1aPzArM_Kr9ljlPPvWRmGDMx_n1Zo5_py?usp=sharing', '2020-08-04 14:15:05', '2020-08-04 18:18:22');
INSERT INTO `ta_pendadaran` VALUES (29, 46, '2020-08-06', '9', '19:00:00', '21:00:00', NULL, 'SETUJU', 0, 2, NULL, NULL, NULL, 'https://drive.google.com/drive/folders/14mdoiPvjL6cClViW717_b72W-HdXImEc?usp=sharing', '2020-08-04 14:25:56', '2020-08-04 18:18:02');
INSERT INTO `ta_pendadaran` VALUES (30, 33, '2020-08-07', '9', '19:00:00', '21:00:00', NULL, 'SETUJU', 0, 2, NULL, NULL, NULL, 'https://drive.google.com/file/d/10ABUjq5ZINa_i2lWmJWrhuQI9LdFtKQG/view?usp=sharing', '2020-08-04 14:42:29', '2020-08-04 18:16:39');
INSERT INTO `ta_pendadaran` VALUES (31, 36, '2020-08-07', '9', '09:00:00', '11:00:00', NULL, 'SETUJU', 0, 2, NULL, NULL, NULL, 'https://drive.google.com/drive/u/7/folders/1CW88twMbYl6ulZAcX8cl5Ce5zu_kj0NI', '2020-08-04 14:44:02', '2020-08-04 18:15:52');
INSERT INTO `ta_pendadaran` VALUES (32, 34, '2020-08-07', '9', '07:00:00', '09:00:00', NULL, 'SETUJU', 0, 2, NULL, NULL, NULL, 'https://drive.google.com/file/d/16KnvNwIitmfVH5a5ER_154EZwg_LroyF/view?usp=sharing', '2020-08-04 14:55:38', '2020-08-04 21:53:32');
INSERT INTO `ta_pendadaran` VALUES (33, 39, '2020-08-07', '9', '16:00:00', '18:00:00', NULL, 'SETUJU', 0, 2, NULL, NULL, NULL, 'https://drive.google.com/file/d/16iTEv0DtxoW5zWIuAzCI7ZiB3BV-7k-I/view', '2020-08-04 15:03:35', '2020-08-04 18:15:10');

-- ----------------------------
-- Table structure for ta_penguji
-- ----------------------------
DROP TABLE IF EXISTS `ta_penguji`;
CREATE TABLE `ta_penguji`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `ta_id` int(15) NULL DEFAULT NULL,
  `penguji_ke` tinyint(6) NULL DEFAULT NULL,
  `penguji_semhas` int(15) NULL DEFAULT NULL,
  `penguji_pendadaran` int(15) NULL DEFAULT NULL,
  `nilai_semhas` float NULL DEFAULT NULL,
  `nilai_pendadaran` float NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `pendadaran`(`ta_id`) USING BTREE,
  CONSTRAINT `ta_penguji_ibfk_1` FOREIGN KEY (`ta_id`) REFERENCES `ta` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 78 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ta_penguji
-- ----------------------------
INSERT INTO `ta_penguji` VALUES (28, 49, 1, 3, 3, NULL, NULL, '2020-06-10 15:33:13', '2020-07-01 13:17:06');
INSERT INTO `ta_penguji` VALUES (29, 49, 2, 18, 18, NULL, NULL, '2020-06-10 15:33:13', '2020-07-01 13:17:06');
INSERT INTO `ta_penguji` VALUES (30, 42, 1, 10, 10, NULL, NULL, '2020-06-11 07:05:36', '2020-07-07 17:05:10');
INSERT INTO `ta_penguji` VALUES (31, 42, 2, 7, 7, NULL, NULL, '2020-06-11 07:05:36', '2020-07-07 17:05:10');
INSERT INTO `ta_penguji` VALUES (36, 51, 1, 8, 8, NULL, NULL, '2020-06-22 15:06:47', '2020-07-13 18:52:16');
INSERT INTO `ta_penguji` VALUES (37, 51, 2, 4, 4, NULL, NULL, '2020-06-22 15:06:47', '2020-07-13 18:52:16');
INSERT INTO `ta_penguji` VALUES (40, 37, 1, 9, 9, NULL, NULL, '2020-06-28 14:32:15', '2020-07-21 20:18:48');
INSERT INTO `ta_penguji` VALUES (41, 37, 2, 5, 5, NULL, NULL, '2020-06-28 14:32:15', '2020-07-21 20:18:48');
INSERT INTO `ta_penguji` VALUES (42, 47, 1, 2, 2, NULL, NULL, '2020-07-09 15:11:52', '2020-07-23 18:22:00');
INSERT INTO `ta_penguji` VALUES (43, 47, 2, 3, 3, NULL, NULL, '2020-07-09 15:11:52', '2020-07-23 18:22:00');
INSERT INTO `ta_penguji` VALUES (44, 40, 1, 18, 18, NULL, NULL, '2020-07-11 00:51:33', '2020-07-17 19:56:48');
INSERT INTO `ta_penguji` VALUES (45, 40, 2, 4, 4, NULL, NULL, '2020-07-11 00:51:33', '2020-07-17 19:56:48');
INSERT INTO `ta_penguji` VALUES (46, 56, 1, 10, 10, NULL, NULL, '2020-07-11 06:07:11', '2020-07-26 16:09:12');
INSERT INTO `ta_penguji` VALUES (47, 56, 2, 17, 17, NULL, NULL, '2020-07-11 06:07:11', '2020-07-26 16:09:12');
INSERT INTO `ta_penguji` VALUES (48, 57, 1, 9, 9, NULL, NULL, '2020-07-11 18:52:25', '2020-07-23 18:16:31');
INSERT INTO `ta_penguji` VALUES (49, 57, 2, 11, 11, NULL, NULL, '2020-07-11 18:52:25', '2020-07-23 18:16:31');
INSERT INTO `ta_penguji` VALUES (50, 62, 1, 6, 6, NULL, NULL, '2020-07-13 13:00:39', '2020-07-26 16:08:13');
INSERT INTO `ta_penguji` VALUES (51, 62, 2, 10, 10, NULL, NULL, '2020-07-13 13:00:39', '2020-07-26 16:08:13');
INSERT INTO `ta_penguji` VALUES (52, 33, 1, 5, 5, NULL, NULL, '2020-07-13 19:20:04', '2020-08-04 18:16:39');
INSERT INTO `ta_penguji` VALUES (53, 33, 2, 18, 18, NULL, NULL, '2020-07-13 19:20:04', '2020-08-04 18:16:39');
INSERT INTO `ta_penguji` VALUES (54, 34, 1, 4, 4, NULL, NULL, '2020-07-16 12:29:23', '2020-08-04 21:53:32');
INSERT INTO `ta_penguji` VALUES (55, 34, 2, 9, 9, NULL, NULL, '2020-07-16 12:29:23', '2020-08-04 21:53:32');
INSERT INTO `ta_penguji` VALUES (56, 64, 1, 1, 1, NULL, NULL, '2020-07-17 12:44:43', '2020-07-27 20:32:45');
INSERT INTO `ta_penguji` VALUES (57, 64, 2, 4, 4, NULL, NULL, '2020-07-17 12:44:43', '2020-07-27 20:32:45');
INSERT INTO `ta_penguji` VALUES (58, 52, 1, 9, 9, NULL, NULL, '2020-07-18 15:22:06', '2020-07-28 12:49:00');
INSERT INTO `ta_penguji` VALUES (59, 52, 2, 18, 18, NULL, NULL, '2020-07-18 15:22:06', '2020-07-28 12:49:00');
INSERT INTO `ta_penguji` VALUES (60, 36, 1, 4, 4, NULL, NULL, '2020-07-20 12:54:40', '2020-08-04 18:15:52');
INSERT INTO `ta_penguji` VALUES (61, 36, 2, 5, 5, NULL, NULL, '2020-07-20 12:54:41', '2020-08-04 18:15:52');
INSERT INTO `ta_penguji` VALUES (62, 35, 1, 1, 1, NULL, NULL, '2020-07-20 20:59:09', '2020-08-04 14:26:43');
INSERT INTO `ta_penguji` VALUES (63, 35, 2, 18, 18, NULL, NULL, '2020-07-20 20:59:12', '2020-08-04 14:26:43');
INSERT INTO `ta_penguji` VALUES (64, 48, 1, 17, 17, NULL, NULL, '2020-07-21 07:47:44', '2020-07-27 20:13:26');
INSERT INTO `ta_penguji` VALUES (65, 48, 2, 7, 7, NULL, NULL, '2020-07-21 07:47:44', '2020-07-27 20:13:26');
INSERT INTO `ta_penguji` VALUES (66, 63, 1, 4, 4, NULL, NULL, '2020-07-21 14:18:46', '2020-07-27 20:12:19');
INSERT INTO `ta_penguji` VALUES (67, 63, 2, 11, 11, NULL, NULL, '2020-07-21 14:18:46', '2020-07-27 20:12:20');
INSERT INTO `ta_penguji` VALUES (68, 44, 1, 9, 9, NULL, NULL, '2020-07-21 15:44:40', '2020-08-04 18:19:57');
INSERT INTO `ta_penguji` VALUES (69, 44, 2, 21, 21, NULL, NULL, '2020-07-21 15:44:40', '2020-08-04 18:19:57');
INSERT INTO `ta_penguji` VALUES (70, 53, 1, 2, 2, NULL, NULL, '2020-07-21 19:36:40', '2020-08-04 18:19:03');
INSERT INTO `ta_penguji` VALUES (71, 53, 2, 18, 18, NULL, NULL, '2020-07-21 19:36:40', '2020-08-04 18:19:03');
INSERT INTO `ta_penguji` VALUES (72, 41, 1, 6, 6, NULL, NULL, '2020-07-24 23:51:48', '2020-08-04 18:18:22');
INSERT INTO `ta_penguji` VALUES (73, 41, 2, 7, 7, NULL, NULL, '2020-07-24 23:51:48', '2020-08-04 18:18:22');
INSERT INTO `ta_penguji` VALUES (74, 46, 1, 5, 5, NULL, NULL, '2020-07-24 23:53:47', '2020-08-04 18:18:03');
INSERT INTO `ta_penguji` VALUES (75, 46, 2, 17, 17, NULL, NULL, '2020-07-24 23:53:47', '2020-08-04 18:18:03');
INSERT INTO `ta_penguji` VALUES (76, 39, 1, 21, 21, NULL, NULL, '2020-07-28 12:52:03', '2020-08-04 18:15:10');
INSERT INTO `ta_penguji` VALUES (77, 39, 2, 5, 5, NULL, NULL, '2020-07-28 12:52:03', '2020-08-04 18:15:10');

-- ----------------------------
-- Table structure for ta_seminar
-- ----------------------------
DROP TABLE IF EXISTS `ta_seminar`;
CREATE TABLE `ta_seminar`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ta_id` int(15) NULL DEFAULT NULL,
  `tanggal` date NULL DEFAULT NULL,
  `tempat` int(15) NULL DEFAULT NULL,
  `jam_mulai` time(0) NULL DEFAULT NULL,
  `jam_selesai` time(0) NULL DEFAULT NULL,
  `status_seminar` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `cetak_semhas` int(11) NULL DEFAULT NULL,
  `pernyataan` tinyint(6) NULL DEFAULT 2,
  `nilai_angka` double(15, 2) NULL DEFAULT NULL,
  `nilai_huruf` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `nilai_skala` double(6, 2) NULL DEFAULT NULL,
  `draft_semhas` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `seminar_ta`(`ta_id`) USING BTREE,
  INDEX `seminar_tempat`(`tempat`) USING BTREE,
  CONSTRAINT `ta_seminar_ibfk_1` FOREIGN KEY (`ta_id`) REFERENCES `ta` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `ta_seminar_ibfk_2` FOREIGN KEY (`tempat`) REFERENCES `ref_ruang` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 37 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ta_seminar
-- ----------------------------
INSERT INTO `ta_seminar` VALUES (12, 49, '2020-06-18', 6, '13:00:00', '15:00:00', 'SETUJU', 0, 1, 85.75, 'A', 4.00, 'https://drive.google.com/file/d/1Fua-butPtBk9hSsv5PreU40HIccR6VFc/view?usp=sharing', '2020-06-10 15:33:13', '2020-06-18 18:58:41');
INSERT INTO `ta_seminar` VALUES (13, 42, '2020-06-18', 6, '08:00:00', '10:00:00', 'SETUJU', 0, 1, 88.25, 'A', 4.00, 'https://drive.google.com/file/d/1KU84v-OONCKFSJ6expaeAOYGAlvAxOCn/view?usp=sharing', '2020-06-11 07:05:35', '2020-06-25 08:19:36');
INSERT INTO `ta_seminar` VALUES (16, 51, '2020-06-25', 6, '08:00:00', '10:00:00', 'SETUJU', 0, 1, 88.25, 'A', 4.00, 'https://drive.google.com/file/d/1W-XNvwSXoLHAYzlKfCOl681C4hMUw0u2/view?usp=sharing', '2020-06-22 15:06:47', '2020-06-25 09:30:40');
INSERT INTO `ta_seminar` VALUES (18, 37, '2020-06-30', 9, '10:00:00', '12:00:00', 'SETUJU', 0, 1, 85.50, 'A', 4.00, 'https://drive.google.com/file/d/1e0QhHCfW4CvKsnphP57uGmTNk76TbTHR/view?usp=sharing', '2020-06-28 14:32:15', '2020-06-30 11:18:55');
INSERT INTO `ta_seminar` VALUES (19, 47, '2020-07-13', 9, '08:00:00', '10:00:00', 'SETUJU', 0, 1, 85.75, 'A', 4.00, 'https://drive.google.com/drive/folders/16wk1rP-loJOAFLto2EnQJ8HpULFelI6V?usp=sharing', '2020-07-09 15:11:52', '2020-07-13 17:01:54');
INSERT INTO `ta_seminar` VALUES (20, 40, '2020-07-15', 9, '16:00:00', '18:00:00', 'SETUJU', 0, 1, 85.50, 'A', 4.00, 'https://tinyurl.com/skripsivernanda', '2020-07-11 00:51:32', '2020-07-16 13:02:10');
INSERT INTO `ta_seminar` VALUES (21, 56, '2020-07-15', 9, '14:00:00', '16:00:00', 'SETUJU', 0, 1, 86.50, 'A', 4.00, 'https://bit.ly/Draft_TA_Adip_Safiudin_I0716001', '2020-07-11 06:07:11', '2020-07-15 15:03:00');
INSERT INTO `ta_seminar` VALUES (22, 57, '2020-07-15', 9, '12:00:00', '14:00:00', 'SETUJU', 0, 2, NULL, NULL, NULL, 'https://drive.google.com/file/d/18c9U4eQUTOdBFeNyuT5N9VT88DB2d0LH/view?usp=sharing', '2020-07-11 18:52:25', '2020-07-13 18:25:35');
INSERT INTO `ta_seminar` VALUES (23, 62, '2020-07-16', 9, '10:00:00', '12:00:00', 'SETUJU', 0, 1, 83.25, 'A-', 3.70, 'https://drive.google.com/file/d/1pJl2zjWEMcNrAliYFG9uuEuCy8lXw8xy/view?usp=sharing', '2020-07-13 13:00:39', '2020-07-16 11:38:33');
INSERT INTO `ta_seminar` VALUES (24, 33, '2020-07-16', 9, '13:00:00', '15:00:00', 'SETUJU', 0, 1, 85.50, 'A', 4.00, 'https://drive.google.com/file/d/10ABUjq5ZINa_i2lWmJWrhuQI9LdFtKQG/view?usp=sharing', '2020-07-13 19:20:04', '2020-07-16 14:23:24');
INSERT INTO `ta_seminar` VALUES (25, 34, '2020-07-20', 9, '08:00:00', '10:00:00', 'SETUJU', 0, 1, 86.75, 'A', 4.00, 'https://drive.google.com/file/d/1xMwNJCTE0WqFWDKPPzwAkiwrVP_bjFov/view?usp=sharing', '2020-07-16 12:29:22', '2020-07-20 09:10:11');
INSERT INTO `ta_seminar` VALUES (26, 64, '2020-07-20', 9, '10:00:00', '12:00:00', 'SETUJU', 0, 1, 84.75, 'A-', 3.70, 'https://drive.google.com/file/d/1x5X-6qp8ZZVA8FeTvZ9OtWgdA__uMHjd/view?usp=sharing', '2020-07-17 12:44:43', '2020-07-20 11:16:02');
INSERT INTO `ta_seminar` VALUES (27, 52, '2020-07-23', 9, '08:00:00', '10:00:00', 'SETUJU', 0, 1, 82.25, 'A-', 3.70, 'https://drive.google.com/file/d/18YvfDD9SBqHaY822SPokygmtzuFzAHtR/view?usp=sharing', '2020-07-18 15:22:05', '2020-07-23 09:39:26');
INSERT INTO `ta_seminar` VALUES (28, 36, '2020-07-23', 9, '10:00:00', '12:00:00', 'SETUJU', 0, 1, 86.50, 'A', 4.00, 'https://drive.google.com/file/d/19LGYbtKX4cyKcwoN52n_Fyi8Q6M8-X_d/view?usp=drivesdk', '2020-07-20 12:54:40', '2020-07-23 11:13:16');
INSERT INTO `ta_seminar` VALUES (29, 35, '2020-07-20', 3, '10:00:00', '12:00:00', 'SETUJU', 0, 2, 80.00, 'A-', 3.70, NULL, '2020-07-20 20:56:08', '2020-07-20 20:56:12');
INSERT INTO `ta_seminar` VALUES (30, 48, '2020-07-24', 9, '08:00:00', '10:00:00', 'SETUJU', 0, 1, 85.50, 'A', 4.00, 'https://drive.google.com/file/d/1nFpmoi9IACbzXVvZT5sYGs9Txt5SD5tJ/view?usp=sharing', '2020-07-21 07:47:44', '2020-07-24 09:14:54');
INSERT INTO `ta_seminar` VALUES (31, 63, '2020-07-24', 9, '13:00:00', '15:00:00', 'SETUJU', 0, 1, 86.75, 'A', 4.00, 'https://drive.google.com/file/d/1vz6vh89LYmutjIbxEUBa2qcptYyKZgo-/view?usp=sharing', '2020-07-21 14:18:46', '2020-07-24 14:34:54');
INSERT INTO `ta_seminar` VALUES (32, 44, '2020-07-24', 9, '15:00:00', '17:00:00', 'SETUJU', 0, 1, 82.00, 'A-', 3.70, 'https://drive.google.com/file/d/1WuYKjHXDBwXmUTvuL5eGEPAzRRLEReqb/view?usp=sharing', '2020-07-21 15:44:40', '2020-07-24 16:10:32');
INSERT INTO `ta_seminar` VALUES (33, 53, '2020-07-24', 9, '10:00:00', '12:00:00', 'SETUJU', 0, 2, NULL, NULL, NULL, 'https://drive.google.com/file/d/1eynOZM5BqFxb8-c3iin-7scIX26YE1wk/view?usp=sharing', '2020-07-21 19:36:40', '2020-07-21 20:47:36');
INSERT INTO `ta_seminar` VALUES (34, 41, '2020-07-27', 9, '16:00:00', '18:00:00', 'SETUJU', 0, 1, 81.50, 'A-', 3.70, 'https://drive.google.com/drive/folders/1aPzArM_Kr9ljlPPvWRmGDMx_n1Zo5_py?usp=sharing', '2020-07-24 23:51:47', '2020-07-27 18:56:40');
INSERT INTO `ta_seminar` VALUES (35, 46, '2020-07-27', 9, '19:00:00', '21:00:00', 'SETUJU', 0, 1, 84.00, 'A-', 3.70, 'https://drive.google.com/drive/folders/14mdoiPvjL6cClViW717_b72W-HdXImEc?usp=sharing', '2020-07-24 23:53:47', '2020-07-27 20:08:53');
INSERT INTO `ta_seminar` VALUES (36, 39, '2020-08-03', 9, '16:00:00', '18:00:00', 'SETUJU', 0, 2, NULL, NULL, NULL, 'https://drive.google.com/file/d/1LxIaQKby-v79niaHCJ_ks_4QNR2tSy-G/view?usp=sharing', '2020-07-28 12:52:03', '2020-07-30 17:26:03');

-- ----------------------------
-- Table structure for ta_tawaran_topik
-- ----------------------------
DROP TABLE IF EXISTS `ta_tawaran_topik`;
CREATE TABLE `ta_tawaran_topik`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `dosen_id` int(15) NULL DEFAULT NULL,
  `jenis_topik` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `nama_proyek` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `judul_topik` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL,
  `penjelasan` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `hardware` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `software` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 23 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of ta_tawaran_topik
-- ----------------------------
INSERT INTO `ta_tawaran_topik` VALUES (6, 9, 'Topik Tugas Akhir', 'Visible Light Communication', 'Desain Signal Conditioning untuk VLC Receiver', 'Membuat hardware untuk signal conditioning receiver VLC', 'FPGA, LED, opamp', 'Modelsim, Circuit design (Multisim)', '2020-01-03 15:03:08', '2020-01-03 15:03:08');
INSERT INTO `ta_tawaran_topik` VALUES (7, 9, 'Topik Tugas Akhir', 'Visible Light Communication', 'Pengembangan BER Tester untuk komunikasi VLC', 'Membuat hardware untuk pengujian BER pada komunikasi VLC', 'FPGA, LED, PC', 'Modelsim, Quartus', '2020-01-03 15:04:08', '2020-01-03 15:04:08');
INSERT INTO `ta_tawaran_topik` VALUES (8, 3, 'Topik Tugas Akhir', 'Plasma Teknologi', 'Sistem Plasma Arc Discharge untuk pembuatan Nanopartikel', 'Pembuatan sistem monitoring Aurs dan Tegangan Plasma', 'Arduino dan portable DAQ sistem INTRUSTAR', 'Software analisis Origin', '2020-01-09 13:13:13', '2020-01-09 13:13:13');
INSERT INTO `ta_tawaran_topik` VALUES (9, 3, 'Topik Tugas Akhir', 'Plasma Teknologi', '	Doping Semikonduktor Menggunakan Plasma bertegangan Tinggi', 'Pembuatan sistem doping semikonduktor dan monitoringnya', 'Arduino dan portable DAQ INTRUSTAR', 'Software analisis Origin', '2020-01-09 13:15:04', '2020-01-09 13:15:04');
INSERT INTO `ta_tawaran_topik` VALUES (10, 3, 'Topik Tugas Akhir', 'Scanning Mokroskop', 'Sistem Tungsten Innert Gas untuk aplikasi Scanning Microscopy', 'Pembuatan Sistem Scanning Microscopy berbasis TIG dengan monitoring Arus yang menghasilkan gambar 3D', 'Arduino dan INTRUSTAR', 'Software analisis ORIGIN', '2020-01-09 13:17:38', '2020-01-09 13:17:38');
INSERT INTO `ta_tawaran_topik` VALUES (11, 3, 'Topik Tugas Akhir', 'Transistor berbasis Elektron Tunggal', 'Simulasi 4 Dot SET (Single Elektron Transistor) untuk aplikasi efek memory', 'Simulasi Transistor elektron Tunggal menggunakan simulator SIMON 2.0 untuk mengamati efek memori untuk Quntum Computer.', NULL, 'SIMON 2.0', '2020-01-09 13:20:11', '2020-01-09 13:20:11');
INSERT INTO `ta_tawaran_topik` VALUES (12, 11, 'Topik Tugas Akhir', 'Intelligent Surveillance System (Iss)', 'Foreground-background segmentation on surveillance camera', 'TA ini fokus dalam pengolahan gambar/video CCTV', '	CCTV, webcam, dll', '	MATLAB, Python', '2020-01-14 09:37:59', '2020-01-14 09:37:59');
INSERT INTO `ta_tawaran_topik` VALUES (13, 17, 'Topik Tugas Akhir', 'IoT untuk Smart Buildings', 'Buildings Energy Management System based on LoRa Modulation', 'LoRa merupakan modulasi IoT dengan kehandalan sinyal lebih stabil di daerah-daerah tertutup, berbasis frekuensi, low power dan handal. LoRa dapat dijadikan alternatif komunikasi IoT dalam manajemen energi di gedung, studi kasus Fakultas Teknik. Monotiring energi dapa bermanfaat untuk efesiensi energi.', 'Arduino/Raspi, Sensor Arus, Sensor Tegangan, LoRa, Lora Gateway', 'Arduino IDE, Python, PowerBi Dashboard, database, web programming', '2020-01-15 08:50:40', '2020-01-15 08:50:40');
INSERT INTO `ta_tawaran_topik` VALUES (14, 17, 'Topik Tugas Akhir', 'IoT Kesehatan', 'Sistem Deteksi Kelelahan Karyawan di Area Kerja Beresiko Tinggi', NULL, 'STM32, Heart Beat Sensor, ECG/EEG Sensor', 'Microcontrolling Programming, Web/Apps Programing', '2020-01-15 08:53:46', '2020-01-15 08:53:46');
INSERT INTO `ta_tawaran_topik` VALUES (16, 5, 'Topik Tugas Akhir', 'Smart Mobile Robot', 'ADAS(Advanced Driver Assisted System)', 'Merancang sistem ADAS untuk diaplikasikan pada mobil robot', 'mobil robot, ardunio', 'MATLAB', '2020-06-30 11:29:42', '2020-06-30 12:02:59');
INSERT INTO `ta_tawaran_topik` VALUES (17, 5, 'Topik Tugas Akhir', 'Smart Mobile Robot', 'Energi management sistem', 'Merancang energi management sistem pada mobil robot', 'baterai, arduino', 'proteus', '2020-06-30 11:55:56', '2020-06-30 12:02:51');
INSERT INTO `ta_tawaran_topik` VALUES (18, 5, 'Topik Tugas Akhir', 'Kontrol Sistem Energi', 'Aplikasi sistem kandali pada converter', 'Sistem kendali converter pada aplikasi panel surya', 'converter, PV', 'MATLAB, Proteus', '2020-06-30 11:59:10', '2020-06-30 11:59:10');
INSERT INTO `ta_tawaran_topik` VALUES (19, 17, 'Topik Tugas Akhir', 'IoT untuk Smart Energi', 'Desain dan Pembuatan Mobile Apps untuk Monitoring dan Controlling Energi', 'Membuat aplikasi mobile untuk pemantauan dan pengendalian energi listrik', '-', 'MIT App Inventor atau yang lain', '2020-07-13 08:52:20', '2020-07-13 08:52:20');
INSERT INTO `ta_tawaran_topik` VALUES (20, 18, 'Topik Tugas Akhir', 'Autonomous Mobile Robot (AMR)', 'Autonomous Indoor-Mapping Robot', 'pemanfaatan robot sederhana untuk pemetaan dalam ruangan secara otonom.', 'mobile robot, sensor ultrasonic atau yang sejenis, Arduino', 'Matlab, proteus', '2020-07-14 22:55:24', '2020-07-14 22:55:24');
INSERT INTO `ta_tawaran_topik` VALUES (21, 18, 'Topik Tugas Akhir', 'Autonomous Mobile Robot (AMR)', 'Human/object Following Robot', 'membuat robot asisten pribadi yang dapat mengikuti manusia.', 'robot beroda, sensor kamera, arduino / raspberry', 'Arduino IDE, Matlab', '2020-07-14 23:11:12', '2020-07-14 23:11:12');
INSERT INTO `ta_tawaran_topik` VALUES (22, 18, 'Topik Tugas Akhir', 'Autonomous Car', 'HILS (hardware in the loops Simulations) pada ADAS untuk mengatur kecepatan laju kendaraan', 'simulasi hardware aplikasi ADAS pada pengaturan kecepatan laju kendaraan pada kondisi jalanan Indonesia.', 'motor, arduino/raspi, sensor-sensor', 'Webots/V-Rep, Phyton', '2020-07-14 23:27:15', '2020-07-14 23:28:41');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nim` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp(0) NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `isLogin` int(11) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `users_email_unique`(`email`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 223 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'sutrisno', '198705062019031009', 'sutrisno@staff.uns.ac.id', NULL, '$2y$10$jiSV0kWWajgEtHHNVPw0IO7GFM2jAPM2nlbCp2Pbo9wLjFMjcUReK', NULL, 1, '2020-02-27 03:55:23', '2020-07-05 19:15:20');
INSERT INTO `users` VALUES (3, 'hamka', '198812292019031011', 'hamka@staff.uns.ac.id', NULL, '$2y$10$ir/nVF7nPD3JZTcQhggv3ehHuqE2zLViLuYp.7I0D494ligu.eKWG', NULL, 1, '2020-02-27 07:52:29', '2020-06-10 16:45:27');
INSERT INTO `users` VALUES (11, 'meiyanto', '197705132009121004', 'mekosulistyo@staff.uns.ac.id', NULL, '$2y$10$sPs/pjMACnGnhd3E3d56k.pnY6deBCmMBqm98kOOAp6Y5fkZX5dGu', NULL, 1, '2020-02-28 13:50:52', '2020-06-17 22:01:12');
INSERT INTO `users` VALUES (12, 'hari', '199104132018031001', 'hari.maghfiroh@staff.uns.ac.id', NULL, '$2y$10$8P5iL97ne6h9K4WtlnPwx.J/X1xzBTF9LlgYaixCi82xs/T76nBkS', NULL, 1, '2020-02-28 23:06:47', '2020-06-09 20:54:00');
INSERT INTO `users` VALUES (18, 'jaka', '196710191999031001', 'jakasulistyabudi@staff.uns.ac.id', NULL, '$2y$10$hZsAwc.ZeiRmWox5apiMjuyTM4ERYURBmPx0fNol.tAyHu6qXOpvy', NULL, 1, '2020-03-06 14:59:53', '2020-03-06 14:59:53');
INSERT INTO `users` VALUES (19, 'chico', '198804162015041002', 'chico@staff.uns.ac.id', NULL, '$2y$10$z1xWGaZUJNLOw91ojTdunuMPpvRfMrrTipprJ2kaFIfyqzJFXtL5K', NULL, 1, '2020-03-09 11:53:38', '2020-07-20 11:20:54');
INSERT INTO `users` VALUES (20, 'anwar', '1983032420130201', 'miftahwar@staff.uns.ac.id', NULL, '$2y$10$QEY12kfxAIKDBywHLiFZbehnuFGmw1JvD8LkSvWT6PZwFE4koWBHC', NULL, 1, '2020-03-09 11:54:12', '2020-05-29 15:19:58');
INSERT INTO `users` VALUES (21, 'Feri', '196801161999031001', 'feri.adriyanto@staff.uns.ac.id', NULL, '$2y$10$NAP3a3DXCfZpGn4ob1KxSuzYW0dM6K9Vm.8EHeAUVONSfKBiQrZxa', NULL, 1, '2020-03-09 11:54:39', '2020-06-25 07:53:58');
INSERT INTO `users` VALUES (22, 'irwan', '197004041996031002', 'irwaniftadi@staff.uns.ac.id', NULL, '$2y$10$lXhERZTiaKuyzxQ.7QeXPus0/YJ9SB13I/ZMR/Lf7EpkRurO7Dy4S', NULL, 1, '2020-03-09 11:57:34', '2020-07-15 18:43:06');
INSERT INTO `users` VALUES (24, 'nizam', '197007201999031001', 'muhammad.nizam@staff.uns.ac.id', NULL, '$2y$10$7vnODO2McsocM86MNlfNG.ARtQWd/Jq2NP26VWqy9Kp/pPINhUAfe', NULL, 1, '2020-03-09 12:01:50', '2020-06-18 10:11:48');
INSERT INTO `users` VALUES (25, 'subuh', '198106092003121002', 'subuhpramono@staff.uns.ac.id', NULL, '$2y$10$NHgC8htaHJf8gtRPzX998eaGKdBrCMelDyhOD2/hlzXSCjS8OdCA.', NULL, 1, '2020-03-09 12:02:18', '2020-06-17 22:02:16');
INSERT INTO `users` VALUES (26, 'ramelan', '199203152019031017', 'agusramelan@staff.uns.ac.id', NULL, '$2y$10$fLkAskUIvC7tUc8UiWPXaOjZcWxNVhsHMEoJXLab64/kaVUGVi/nC', NULL, 1, '2020-03-09 12:03:03', '2020-06-18 10:12:35');
INSERT INTO `users` VALUES (27, 'joko', '198904242019031013', 'jssaputro89@staff.uns.ac.id', NULL, '$2y$10$j8fDcFKev.ZEAI7PkuAkU.a4iwJTPDrts4ApgbJ3L0qFMUYhXahbG', NULL, 1, '2020-03-09 12:03:34', '2020-06-18 13:53:18');
INSERT INTO `users` VALUES (28, 'augus', '1951100120161001', 'augustinus_s@staff.uns.ac.id', NULL, '$2y$10$hUz21g4lFmK3Iv8/ilW.seg5TIijfN2q/kwmyVPDCwQsbK6/s.OFC', NULL, 1, '2020-03-09 12:04:03', '2020-05-29 15:15:13');
INSERT INTO `users` VALUES (30, 'Adip', 'I0716001', 'adip240499@student.uns.ac.id', NULL, '$2y$10$c0XONE1HL90RKypdYLuvF.zUsjTmIuSD7b5SMim3huPkwcZM5U9l.', NULL, 1, '2020-04-08 10:33:21', '2020-04-22 10:24:53');
INSERT INTO `users` VALUES (31, 'Adrian', 'I0716002', 'adrianekananda@student.uns.ac.id', NULL, '$2y$10$R4GADlzI1zTrrI8lKwTtLOlr9WRDfpSJdu7KY3Z.srxgdqzCeKy.6', NULL, 1, '2020-04-08 10:33:21', '2020-07-13 19:58:40');
INSERT INTO `users` VALUES (32, 'Afif', 'I0716003', 'afifmikoyuhend@student.uns.ac.id', NULL, '$2y$10$BlcyAeofgLaDM5PU2wjY5umB2Bk4Te2QqkU7WYd6SN1MRbDoLbjiu', NULL, NULL, '2020-04-08 10:33:21', '2020-04-08 10:33:21');
INSERT INTO `users` VALUES (33, 'Rauyan', 'I0716004', 'airauyani@student.uns.ac.id', NULL, '$2y$10$EBVDCxbhUs2dSPFWzIPRXulo7yw843Tphf0QxKpjnWIC554PvTDfi', NULL, 1, '2020-04-08 10:33:21', '2020-07-13 15:32:08');
INSERT INTO `users` VALUES (34, 'Annisa', 'I0716006', 'hanifann1sa_6@student.uns.ac.id', NULL, '$2y$10$6slGMWpU6szKF4/bUMjiZuy2pHLyEqHTcaQMhLaXvaPvqqmIn3NP6', NULL, 1, '2020-04-08 10:33:21', '2020-06-10 14:49:00');
INSERT INTO `users` VALUES (35, 'Azis', 'I0716009', 'azisubaidilah@student.uns.ac.id', NULL, '$2y$10$fiOlWVW7OnPjs6T6pOzwK.ScIqeB/xCYDtH1FRTQKb8HiqUsL9JI.', NULL, 1, '2020-04-08 10:33:21', '2020-07-19 19:53:22');
INSERT INTO `users` VALUES (36, 'Bintang Sujatmiko', 'I0716011', 'bintang.sujatmiko@student.uns.ac.id', NULL, '$2y$10$kQYA.gCWHo1ylAEcsj0./ukYn2vEsJ/GywJbgLSQy9F/vTHGbhkDC', NULL, 1, '2020-04-08 10:33:21', '2020-07-13 21:37:42');
INSERT INTO `users` VALUES (37, 'Daniel', 'I0716012', 'aquinodothebest@student.uns.ac.id', NULL, '$2y$10$eh2suLX.n3QxMYc0H7zcduEON6NMMYXMiabOMkI.7wTSXhhnvowhW', NULL, 1, '2020-04-08 10:33:21', '2020-06-10 15:20:34');
INSERT INTO `users` VALUES (38, 'Fuad', 'I0716014', 'fuadnurkuncoro@student.uns.ac.id', NULL, '$2y$10$.H8nR.NXSFCnr1Gdl/iXFuQjFiuzFytibpJhanRNcHNNfP28qAT.6', NULL, 1, '2020-04-08 10:33:21', '2020-06-10 15:26:59');
INSERT INTO `users` VALUES (39, 'Ghufron', 'I0716015', 'ghufronhusnan99@student.uns.ac.id', NULL, '$2y$10$VBZ2LciVQY0Y5dFPu2c.7uss5EKP6xjpoIDFx4IjvICc1RFboyfIC', NULL, 1, '2020-04-08 10:33:21', '2020-07-20 20:16:33');
INSERT INTO `users` VALUES (40, 'Henry', 'I0716016', 'henryprobo140198@student.uns.ac.id', NULL, '$2y$10$K2GVFcOrQ3wgJqqTm0IxrOvLWykPoVT80Jk5u51RpS3d2x.XQS4Fq', NULL, 1, '2020-04-08 10:33:21', '2020-07-10 11:41:17');
INSERT INTO `users` VALUES (41, 'Yoga', 'I0716017', 'iwayyoga@student.uns.ac.id', NULL, '$2y$10$mceQeYUQnZCP22sZVUQq/urdKxzQt0K36lLPjw.TPU8Mg9c0wRNim', NULL, 1, '2020-04-08 10:33:21', '2020-07-14 12:00:57');
INSERT INTO `users` VALUES (42, 'Kevin', 'I0716018', 'kscdh6@student.uns.ac.id', NULL, '$2y$10$mlx0o7LQdXvP6T8cnoLBX.x7ePBGCnwzvVzuUmR9qzR5jOJzvWMVe', NULL, 1, '2020-04-08 10:33:21', '2020-07-11 18:38:35');
INSERT INTO `users` VALUES (43, 'Krisna', 'I0716019', 'krisnahakim97@student.uns.ac.id', NULL, '$2y$10$U7Ngjz7lKrCI5EVn6ylRM.naLFHmP55ICJqL7CEYYI2pcIE4dhrOK', NULL, NULL, '2020-04-08 10:33:22', '2020-04-08 10:33:22');
INSERT INTO `users` VALUES (44, 'Miftahuddin', 'I0716020', 'miftahuddinirfani@student.uns.ac.id', NULL, '$2y$10$l7dhJplcne4TPoRYhc8lYeOv2X/m3484/f938Goo4p.X42I4qIzU2', NULL, 1, '2020-04-08 10:33:22', '2020-07-24 23:51:43');
INSERT INTO `users` VALUES (45, 'Mohamad', 'I0716021', 'nismanfalich18@student.uns.ac.id', NULL, '$2y$10$QZppgxRw82EL9gQEiRtuNeNVNTrcKFA6Yr4QiB1flDaig9dpLQ6zq', NULL, 1, '2020-04-08 10:33:22', '2020-07-17 18:53:38');
INSERT INTO `users` VALUES (46, 'Muhammad', 'I0716023', 'fakhri.erriyanto@student.uns.ac.id', NULL, '$2y$10$mZ4/Vc45Mzh4Lrq1bHcVOOwR5xGP/89gQncBGU7Ex4Hu/vmuJUM3W', NULL, NULL, '2020-04-08 10:33:22', '2020-04-08 10:33:22');
INSERT INTO `users` VALUES (47, 'Musyaffa\'', 'I0716026', 'mus_ahmad@student.uns.ac.id', NULL, '$2y$10$wraCXvSEeCKHyDHDuDG.suQfHZhVxCMw2ZVAMHiiAd.Crzuhv.7s.', NULL, 1, '2020-04-08 10:33:22', '2020-07-18 10:20:13');
INSERT INTO `users` VALUES (48, 'okisetyaone', 'I0716027', 'oki.setiawan@student.uns.ac.id', NULL, '$2y$10$s3vAPvyMklQ3ZkUCHhza2u4A2Zstg3fGAaefVhD9mc0Xb4Msyb1Zu', NULL, 1, '2020-04-08 10:33:22', '2020-07-20 18:41:24');
INSERT INTO `users` VALUES (49, 'Rilo', 'I0716028', 'rilopaw@student.uns.ac.id', NULL, '$2y$10$t.RJuCYo9aeS13JjLEGvq.CR9flelAH4uUe1zAVh.HMwEsBWfwyLW', NULL, 1, '2020-04-08 10:33:22', '2020-06-22 15:24:48');
INSERT INTO `users` VALUES (50, 'Royani', 'I0716029', 'royaniaulia10@student.uns.ac.id', NULL, '$2y$10$Z3PA4X7nVCpkSeEgCFFM2OGiKl8LVZoF0PhA7SnOKSTIpMJI9p6dO', NULL, NULL, '2020-04-08 10:33:22', '2020-04-08 10:33:22');
INSERT INTO `users` VALUES (51, 'Salman', 'I0716030', 'alfarisislmn@student.uns.ac.id', NULL, '$2y$10$rtHf7ITfA38lXqBEDSegt.MnoZuu.7KcXCeYlbqimfphIKxmUNtyS', NULL, 1, '2020-04-08 10:33:22', '2020-06-20 02:17:51');
INSERT INTO `users` VALUES (52, 'Vernanda', 'I0716032', 'vernandaszh@student.uns.ac.id', NULL, '$2y$10$ebKp/ha8ijy/C4aRtS.yqeGuwih9rDPKGlWm1aXT/fSK/yUeK1eJu', NULL, 1, '2020-04-08 10:33:22', '2020-06-22 19:28:23');
INSERT INTO `users` VALUES (53, 'Wiwik', 'I0716033', 'wiwiknurwinda@student.uns.ac.id', NULL, '$2y$10$sOnK6ImAiSQFmCyK31Gj9.Izh/L1Axb.1qG1/J5fyuAAQvNX5I/tK', NULL, 1, '2020-04-08 10:33:22', '2020-07-24 11:24:54');
INSERT INTO `users` VALUES (54, 'Yudhi', 'I0716034', 'yudhie123@student.uns.ac.id', NULL, '$2y$10$7PaADss6bV9Zl6H9lLXzc.p0ap5hYkCCcBaA/T/9MBQv0lSnxd8ka', NULL, 1, '2020-04-08 10:33:22', '2020-04-19 12:10:05');
INSERT INTO `users` VALUES (55, 'Widodo', '1987072320150401', 'bagaswidodo@staff.uns.ac.id', NULL, '$2y$10$tc5.duIt8s5s2TYt8zfI6uvWAV9vEb4lY5JhjNBVI7cck1MmmfbfG', NULL, 1, '2020-04-08 11:12:35', '2020-07-15 12:24:41');
INSERT INTO `users` VALUES (58, 'rioo', 'I0714029', 'rio@gmail.com', NULL, '$2y$10$Npx9XU1hrcCs1SnB7jWYT.NQaiYODK.45zY9izWXgzKh8rCRpyR1a', NULL, 1, '2020-06-16 21:54:03', '2020-06-16 21:55:34');
INSERT INTO `users` VALUES (59, 'fasda', 'I0714013', 'fasda@gmail.com', NULL, '$2y$10$Mp.jFYdk5x972secoTByfemStv5nvDNf9b4OJrmJpeqB68yNZaqzW', NULL, 1, '2020-06-16 21:54:52', '2020-06-18 07:13:24');
INSERT INTO `users` VALUES (60, 'edi nugroho', 'I0714011', 'edi@gmail.com', NULL, '$2y$10$K2kJ327YyiEQpXIhpXMPr.tg91NBzlq3T8R5HTKesLkvw0pKvX03a', NULL, 1, '2020-06-18 07:05:54', '2020-06-18 10:54:53');
INSERT INTO `users` VALUES (61, 'aditya nur', 'I0715002', 'aditya_nur@student.uns.ac.id', NULL, '$2y$10$SP6Jy4UQDvoIopoXvaT4ve7qYLG24RfqxgGnFuF4fKZXrQvHefQqi', NULL, 1, '2020-06-28 14:12:03', '2020-06-28 14:17:41');
INSERT INTO `users` VALUES (62, 'Aditya', 'I0717001', 'adit.ap@student.uns.ac.id', NULL, '$2y$10$kwR/jQMbnYvfdFC4xgWfM.cDhEA6lVmja/uzsLn2N6v4ztQvZPvAG', NULL, NULL, '2020-07-02 12:39:10', '2020-07-02 12:39:10');
INSERT INTO `users` VALUES (63, 'Agung', 'I0717002', 'diutamaa@student.uns.ac.id', NULL, '$2y$10$OPXCY/hakuch.BqIloCu/u/fQCcCrPANxHyBG5PqDT8wzmZMORmDq', NULL, 1, '2020-07-02 12:39:10', '2020-07-10 12:26:25');
INSERT INTO `users` VALUES (64, 'Aimmatul', 'I0717003', 'aimmatulazra@student.uns.ac.id', NULL, '$2y$10$G77HwaYR6w30SfHtiUAefOVqQf00lHfYJBo9ndEA7Wde0bY0XEdgu', NULL, NULL, '2020-07-02 12:39:10', '2020-07-02 12:39:10');
INSERT INTO `users` VALUES (65, 'Alvin', 'I0717004', 'alvinichwan01@student.uns.ac.id', NULL, '$2y$10$a7/BIIuoQZaqcmxT8i2Id.PBGcdUhT/JiHK3iVTuId.DQq4amAWTq', NULL, 1, '2020-07-02 12:39:10', '2020-07-26 23:16:14');
INSERT INTO `users` VALUES (66, 'Arif Wibowo', 'I0717005', 'arifwibowo14@student.uns.ac.id', NULL, '$2y$10$u7DgcDlLhQ6duLYCGdEE4evyiVt60hZFOcJcsx9pruqlaO0BUIY4G', NULL, 1, '2020-07-02 12:39:10', '2020-07-14 11:48:27');
INSERT INTO `users` VALUES (67, 'Athaya', 'I0717006', 'athayacp@student.uns.ac.id', NULL, '$2y$10$IhvgMjIeo/DTTSB6TybJkuAbmaizF6ehtq03iZ5/40PgF7P6cbPKK', NULL, NULL, '2020-07-02 12:39:10', '2020-07-02 12:39:10');
INSERT INTO `users` VALUES (68, 'Attar', 'I0717007', 'attarrasyid15@student.uns.ac.id', NULL, '$2y$10$wJJ2smWS8GLsKIzmkaiz6e2PRC9.3SppiT76zuCJt6ChSp9D.9uYq', NULL, 1, '2020-07-02 12:39:10', '2020-07-27 01:12:28');
INSERT INTO `users` VALUES (69, 'Aulia', 'I0717008', 'auliavici12345@student.uns.ac.id', NULL, '$2y$10$KEEg7wdYN0NTu0nEfXPCreh/3u62EdwFwxWVo53HXUAB7mTnPzqTm', NULL, 1, '2020-07-02 12:39:11', '2020-07-29 19:49:29');
INSERT INTO `users` VALUES (70, 'Bakasrian', 'I0717009', 'b.fericoari@student.uns.ac.id', NULL, '$2y$10$Iv6gZzijRv0MP0f.bjef2.pKKer6lVHohqEdtwlcFyLytL2GhpIta', NULL, NULL, '2020-07-02 12:39:11', '2020-07-02 12:39:11');
INSERT INTO `users` VALUES (71, 'Banu', 'I0717010', 'banu.maheswara@student.uns.ac.id', NULL, '$2y$10$mVuvkGIvjv1bPTok3eh/6eNV3q3knh42fIuiWLaTmGFYHwj/Vb5ny', NULL, 1, '2020-07-02 12:39:11', '2020-07-30 13:19:07');
INSERT INTO `users` VALUES (72, 'Bayhaqi', 'I0717011', 'bayhaqi24@student.uns.ac.id', NULL, '$2y$10$b4w0g/JuZU..RfBtZPhzxeHeKYOWODvrWUBRuynLod8DJjzeCz.se', NULL, NULL, '2020-07-02 12:39:11', '2020-07-02 12:39:11');
INSERT INTO `users` VALUES (73, 'Berlianne', 'I0717012', 'berlianne5699@student.uns.ac.id', NULL, '$2y$10$BFIf.nYZw.sZd7KIZLRq3edJFuGDGAv8SjRtdzWALf/lHAhfbMKce', NULL, 1, '2020-07-02 12:39:11', '2020-07-28 12:58:36');
INSERT INTO `users` VALUES (74, 'Bima', 'I0717013', 'bimadamar@student.uns.ac.id', NULL, '$2y$10$601TJJTMegAKt2rrw6ed5O5NPxHnYlyJyf.xb4aM9wfsBSAOQvoFS', NULL, 1, '2020-07-02 12:39:11', '2020-07-04 16:45:19');
INSERT INTO `users` VALUES (75, 'Bintar', 'I0717014', 'bintarysadewo@student.uns.ac.id', NULL, '$2y$10$1DzjJ5DdS9mbNrNAn11tHuxtz1JUeG/uNpP.ouLcCHOXHK6sNJKKG', NULL, NULL, '2020-07-02 12:39:11', '2020-07-02 12:39:11');
INSERT INTO `users` VALUES (76, 'Fahmi', 'I0717015', 'fahmiismail90@student.uns.ac.id', NULL, '$2y$10$skRvgZM4W67NdfvjHoMjIe9M4CqBxC2XMaZTeZqEOzQn9WwIT1hci', NULL, 1, '2020-07-02 12:39:11', '2020-07-14 17:15:30');
INSERT INTO `users` VALUES (77, 'Faishal', 'I0717016', 'faishal_hanif@student.uns.ac.id', NULL, '$2y$10$DEjM30QvFDr7AL/qVdFOyuPhefA/XOY17si2NKcW75GxyJm7wRcV6', NULL, 1, '2020-07-02 12:39:11', '2020-07-10 16:58:06');
INSERT INTO `users` VALUES (78, 'Gilang', 'I0717017', 'satriagilang80@student.uns.ac.id', NULL, '$2y$10$PDd5kcCxlBwCHVAqvlg4weZFHi.gOlVS60fD1ZbjaIDr/q/looGaa', NULL, 1, '2020-07-02 12:39:11', '2020-07-29 19:15:05');
INSERT INTO `users` VALUES (79, 'Hanifah', 'I0717018', 'hanyfahyulia@student.uns.ac.id', NULL, '$2y$10$kz/CSbew6zp0c1sffO/k2O4oxQBrTvaQltPDaiUm53nNbIAvaVIdG', NULL, 1, '2020-07-02 12:39:11', '2020-07-16 12:11:16');
INSERT INTO `users` VALUES (80, 'Hisbullah', 'I0717021', 'hisbullaha@student.uns.ac.id', NULL, '$2y$10$sTbqLyP.vbUG3U1jDjkdG.P6DvSXdbpgze1pTU8/x.CD/nl8IA3NK', NULL, 1, '2020-07-02 12:39:11', '2020-07-06 14:28:20');
INSERT INTO `users` VALUES (81, 'Ivan', 'I0717022', 'ivanrseptian@student.uns.ac.id', NULL, '$2y$10$q14fK9.FceodlXOHBIIqnOGGhej2zYl0krqgW6dP.lCQuWic9RKVi', NULL, 1, '2020-07-02 12:39:11', '2020-08-03 08:54:03');
INSERT INTO `users` VALUES (82, 'Kevin', 'I0717023', 'kevindwiyanto8@student.uns.ac.id', NULL, '$2y$10$oROm35nrl/qXIfvvv74hbu0iyiuSalEcEBUH08z21E2fYCvi3PkBC', NULL, 1, '2020-07-02 12:39:11', '2020-07-28 10:21:03');
INSERT INTO `users` VALUES (83, 'miqbalzidny', 'I0717024', 'm.iqbal.zidny@student.uns.ac.id', NULL, '$2y$10$CtiI6Y5iX1r3S2YbVsLPT./v37cVcIzKI/NEHEFVRXrAC4Wvxon6O', NULL, 1, '2020-07-02 12:39:11', '2020-07-14 14:16:47');
INSERT INTO `users` VALUES (84, 'Maulana', 'I0717025', 'maulanayusuf15@student.uns.ac.id', NULL, '$2y$10$wguuOcLVzp2ID09NtfCiu.DHvsvPEB7mNT00W4BHAsZuh6kuUaXG6', NULL, 1, '2020-07-02 12:39:11', '2020-07-10 11:54:44');
INSERT INTO `users` VALUES (85, 'Raihan', 'I0717026', 'raihan_hafiz@student.uns.ac.id', NULL, '$2y$10$Tbk0hdgCNZcOpzol/TVy/OezLeDGXk8uBFpoN85kLrfH5e5YWUwMi', NULL, 1, '2020-07-02 12:39:11', '2020-07-16 10:58:53');
INSERT INTO `users` VALUES (86, 'Hamid', 'I0717027', 'muhammad.al_hamid@student.uns.ac.id', NULL, '$2y$10$RMOWAYf1Q9Ec5D0mDpj1Kum0lPp1Qm4ggLHfMfaf8.9hhReQILQcS', NULL, NULL, '2020-07-02 12:39:11', '2020-07-02 12:39:11');
INSERT INTO `users` VALUES (87, 'Ikyu', 'I0717028', 'ikyu@student.uns.ac.id', NULL, '$2y$10$TDj5rjMm7cD8iNWvKPT/L.G6ulYhREQsvFrQ4hVPcrRD2YSzFAKUG', NULL, 1, '2020-07-02 12:39:11', '2020-07-26 19:47:38');
INSERT INTO `users` VALUES (88, 'Renaldy', 'I0717029', 'mrenaldy0101@student.uns.ac.id', NULL, '$2y$10$i0W8gdPmqZG7fc6F/MrR5u3L3Xrnu5Se2sd4bRSMNafzBkKbSWfpi', NULL, 1, '2020-07-02 12:39:11', '2020-07-10 11:41:57');
INSERT INTO `users` VALUES (89, 'Rifai', 'I0717030', 'muhammadrifai@student.uns.ac.id', NULL, '$2y$10$2uehk44lxMxp6vxm2mWgk.84pOcaZMQkKHVXRJvC9NXRVufZ916ha', NULL, 1, '2020-07-02 12:39:12', '2020-07-17 12:54:42');
INSERT INTO `users` VALUES (90, 'Rifyal', 'I0717031', 'rifyalabubakar@student.uns.ac.id', NULL, '$2y$10$XnSegFTFGVdLy/Krit3XHubZpu39nqXYhqfQ4J/Fl07YQ34T..qzW', NULL, 1, '2020-07-02 12:39:12', '2020-08-03 21:46:56');
INSERT INTO `users` VALUES (91, 'Rizqi', 'I0717032', 'rizqisubeno@student.uns.ac.id', NULL, '$2y$10$t8l4pe2T8VS24fmqyqqOyOT6rDS9YfmMpIz3/b9FxQtGBbHDzipra', NULL, 1, '2020-07-02 12:39:12', '2020-07-13 09:56:07');
INSERT INTO `users` VALUES (92, 'Wakhid', 'I0717033', 'wakhidmuhammad@student.uns.ac.id', NULL, '$2y$10$rL1ihdXIW3SbY07o.Odyx.aTdiFmBGn9PAFHiAbbnY3Ru/OghaPIS', NULL, 1, '2020-07-02 12:39:12', '2020-07-16 13:46:38');
INSERT INTO `users` VALUES (93, 'Nanda', 'I0717035', 'nandahafidz24@student.uns.ac.id', NULL, '$2y$10$NLESKxspSjKgK9Bn3rKH2OaKRiSGs/jmrl/exRFVTXkR3Hv5zlj8e', NULL, 1, '2020-07-02 12:39:12', '2020-07-10 11:37:05');
INSERT INTO `users` VALUES (94, 'Rafiq', 'I0717036', 'rasatria@student.uns.ac.id', NULL, '$2y$10$Jkd.1mYnQu7koND2gAgNmeLuuZC7iSC3xuSVNVYh7N9/9gQaQtpmy', NULL, NULL, '2020-07-02 12:39:12', '2020-07-02 12:39:12');
INSERT INTO `users` VALUES (95, 'Rifqi', 'I0717037', 'paradies7@student.uns.ac.id', NULL, '$2y$10$gPxQDG7J2pxwwLm/YKJhKOZVZVHuRBDhfXWKUK54lW0f6SWSmZzmW', NULL, 1, '2020-07-02 12:39:12', '2020-07-14 16:52:21');
INSERT INTO `users` VALUES (96, 'Riski', 'I0717038', 'riskirama@student.uns.ac.id', NULL, '$2y$10$1go/nFrqK4aeQ2wbHhxScujTGj7aj47gYdQuNRhkdFkNjj5StbNMq', NULL, NULL, '2020-07-02 12:39:12', '2020-07-02 12:39:12');
INSERT INTO `users` VALUES (97, 'Sony', 'I0717039', 'sonyadyatama@student.uns.ac.id', NULL, '$2y$10$8yD6Uz5wBwuIkBMMkAOZ5OkxZ9UdCozLTK9bGio3QrnpaXPTjTkCK', NULL, 1, '2020-07-02 12:39:12', '2020-07-26 20:55:39');
INSERT INTO `users` VALUES (98, 'Weldino', 'I0717041', 'weldinopanjikurniadi@student.uns.ac.id', NULL, '$2y$10$mJqyUr0tQVWjuJYEyz1EfeX5Ys4UKWG4gw97Af4ArZj1h6kypwyX2', NULL, 1, '2020-07-02 12:39:12', '2020-07-26 19:44:49');
INSERT INTO `users` VALUES (99, 'Abraham', 'I0718001', 'abrahambabtistio@student.uns.ac.id', NULL, '$2y$10$gs6W/6JEOnw3ZeCriLaFHe0FSOPM.LVgX2b4ieFmDKAaerpAshdgG', NULL, NULL, '2020-07-02 12:39:12', '2020-07-02 12:39:12');
INSERT INTO `users` VALUES (100, 'Ahmad', 'I0718002', 'ahmadazzam2000@student.uns.ac.id', NULL, '$2y$10$STUBioZbql/9I8kqGx75cuwBYO3K../ZDjF/qo3S370ZYsm0P/LKW', NULL, NULL, '2020-07-02 12:39:12', '2020-07-02 12:39:12');
INSERT INTO `users` VALUES (101, 'Alvian', 'I0718003', 'alvianaji18@student.uns.ac.id', NULL, '$2y$10$ud9E5my96U4.nvDaMG0BQ.igFjjMtGLc3t8YgvS.4xgZ4Xs2kpYdW', NULL, NULL, '2020-07-02 12:39:12', '2020-07-02 12:39:12');
INSERT INTO `users` VALUES (102, 'Andhika', 'I0718004', 'andhikarizkitap@student.uns.ac.id', NULL, '$2y$10$iRRrazCDljlaJmebK/bNtOsXGFnVaNNp.Mkkn1lGuol1pYJh2A0yS', NULL, NULL, '2020-07-02 12:39:12', '2020-07-02 12:39:12');
INSERT INTO `users` VALUES (103, 'Annisa', 'I0718005', 'annisalarasatif@student.uns.ac.id', NULL, '$2y$10$Bd.YZdgm3MycYKesnXq9mOAxbB.Cdq9cZJKrT4BGPURVV6aCd9/UG', NULL, NULL, '2020-07-02 12:39:12', '2020-07-02 12:39:12');
INSERT INTO `users` VALUES (104, 'Catya', 'I0718006', 'catyaafif@student.uns.ac.id', NULL, '$2y$10$fB0CFWvdYxzyfeCFljBRMuHhzh/NIrvO2ddadoJqegF1iqKoIc1g6', NULL, NULL, '2020-07-02 12:39:12', '2020-07-02 12:39:12');
INSERT INTO `users` VALUES (105, 'Desi', 'I0718007', 'desi2108@student.uns.ac.id', NULL, '$2y$10$bQXudftUS5UBBSVY7wezlOrZNWTHb6Qh./VZ4aqXaQA7CWtmfzVfy', NULL, NULL, '2020-07-02 12:39:12', '2020-07-02 12:39:12');
INSERT INTO `users` VALUES (106, 'Eri', 'I0718008', 'awaneryx7@student.uns.ac.id', NULL, '$2y$10$HO6X9YOFXBL8JBVskcLk2OBvLn08cwK0m.GMpUJOEeTmmcMr/2Fkm', NULL, NULL, '2020-07-02 12:39:12', '2020-07-02 12:39:12');
INSERT INTO `users` VALUES (107, 'Fandi', 'I0718009', 'fandiadinata@student.uns.ac.id', NULL, '$2y$10$0goFvReYbMV.lFxUwPVBAOVlYobdl/o0Ugu2EfXAwm6XomDh0FkV6', NULL, NULL, '2020-07-02 12:39:12', '2020-07-02 12:39:12');
INSERT INTO `users` VALUES (108, 'Firmansyah', 'I0718010', 'abadafirmansyah@student.uns.ac.id', NULL, '$2y$10$.l4mRJ1BCLp47llCG5MqGOOQ0wmgJRfWb1OY84PkyZFx4WZMzX8p.', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (109, 'Ghozy', 'I0718011', 'ghozyaa@student.uns.ac.id', NULL, '$2y$10$6vFbbnYKo7QNtF9GhXjPbOgqOYQff3f8hzwCpxMiHRf110wZHkTwS', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (110, 'Gibran', 'I0718012', 'gibran.dzulfikar@student.uns.ac.id', NULL, '$2y$10$MbRxdsNJlQayyjM3fWpSl.SOj60c5XvCJCmyqCIk6gmBvFksTMpcO', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (111, 'Hanandya', 'I0718013', 'hanandyaf@student.uns.ac.id', NULL, '$2y$10$e1XmhmqKm9qbZDiotgMhg.y3XmFa8TSHYG33nLvRkcXYHqmZDL8ze', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (112, 'Hanif', 'I0718014', 'hanifardiyoansyah@student.uns.ac.id', NULL, '$2y$10$dY6Kntrfql/KhpJD5ecVAO5c/RR9dIy..nMa/iN.mbpkAdP.nfzOu', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (113, 'Ilham', 'I0718015', 'ilham.gil1998@student.uns.ac.id', NULL, '$2y$10$Q/NSPQkWXZTdVoOCA2DYYO2Z7Pxx9vEYvY228CO71uMA2j72mYXfm', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (114, 'Imam', 'I0718016', 'imam123@student.uns.ac.id', NULL, '$2y$10$5/r1cgg2Q2AC2aK2rzyote/xw1BSpxk/eZmyj8LGC4jQ2DWygDoKO', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (115, 'Khilalul', 'I0718017', 'khilalulhanif02@student.uns.ac.id', NULL, '$2y$10$evkefvNR/fvNCdBt/5wGguG6/srbpP7k5sJD/fsfgqOnEa1JRWpQ2', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (116, 'Arifin', 'I0718018', 'futukhsan5@student.uns.ac.id', NULL, '$2y$10$VnzLXow2gFWhQs8GwZ13P.1HRilQ1zin.zge0A96ZV3h23peqm7Fi', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (117, 'Adith', 'I0718019', 'cigeron.22@student.uns.ac.id', NULL, '$2y$10$3LaeJ3Y.cltpEIRaMJBc2OF20kBl7fZmedEVsbUqHLe8YlWruNvV.', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (118, 'Ravi', 'I0718020', 'ravirachman_8@student.uns.ac.id', NULL, '$2y$10$y1LeBs8nFyCOqIj/pj1fcecEi.DMMYfmVaMNFGqqOZspHz0ewuRAq', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (119, 'Miftahus', 'I0718021', 'miftahus.surur02@student.uns.ac.id', NULL, '$2y$10$sgyRqN5qG8d94HGTrA7NsOzTrR5B.CtAtlCP0LagC9PtB7LfRn9Yi', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (120, 'Didin', 'I0718022', 'd.kamaludin17@student.uns.ac.id', NULL, '$2y$10$lSpbeOshPWk3BqaWYRJLl.lvOMHMJc0zizkRMvKDAEe.0/zmPxiUa', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (121, 'Ghozy', 'I0718023', 'muhammadghozy@student.uns.ac.id', NULL, '$2y$10$FN4Dj6qmPy3XX7mUCJ4IoumLuCZ/5OSFVK7gcUdi6/F0vwxCobsO6', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (122, 'Ibnu', 'I0718024', 'ibnusinaabbas7@student.uns.ac.id', NULL, '$2y$10$G16I6eOCTkVoHJEunwdNJe5D/r2uKXwi/E0NXISyruE9gnaPOwLEa', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (123, 'Nada', 'I0718025', 'nadaazizah@student.uns.ac.id', NULL, '$2y$10$Lg7RZgDjn7UaHQ13pWaszeAnabXMxQz.piULX6ZaI.qHKG17xL5Ym', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (124, 'Nur', 'I0718027', 'gempur554@student.uns.ac.id', NULL, '$2y$10$2rkchFL.a1gP6Y/K7zfup.e0k6lZDPheRPnW1Hbf2N2NCXiR0GcIq', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (125, 'Oga', 'I0718028', 'oga_sl@student.uns.ac.id', NULL, '$2y$10$nhX4EsuRIZMFbdXS8T8I8um6hLcWKE2SnmhD2Z6MiAY7dAM78TqBq', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (126, 'Raihan', 'I0718029', 'raihanrafif@student.uns.ac.id', NULL, '$2y$10$fYWv55FwV4ijYF6hinjYgOM74krWzzx8rW2bM0StT9H5OztVzV4Jm', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (127, 'Ramadhan', 'I0718030', 'ramadhan_4100@student.uns.ac.id', NULL, '$2y$10$f/FpwOETgEoXATI4AY1G7.jV8g2mmaH8E5Nn.iYj3vY/AlBMB1.vC', NULL, NULL, '2020-07-02 12:39:13', '2020-07-02 12:39:13');
INSERT INTO `users` VALUES (128, 'Rizal', 'I0718031', 'rizalmujaddidirsyad@student.uns.ac.id', NULL, '$2y$10$IydkZtO686bzLvwAaSdEE.bKODLFOrckP8DnE50L5Ip5G3vf2o/4G', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (129, 'Rois', 'I0718032', 'rois.hasan16@student.uns.ac.id', NULL, '$2y$10$91MbumZ01wJhsr6/ada1v.vwlWvtKwDLrDsUcWHG907mlRxsdaOkO', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (130, 'Roni', 'I0718033', 'ronitampubolon15@student.uns.ac.id', NULL, '$2y$10$j3ItqmGie4trnH5WSsvq6ehk8N4StKSnUqILx8gUGONT5UpkyKXru', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (131, 'Slash', 'I0718034', 'slasharthur000@student.uns.ac.id', NULL, '$2y$10$8BZy2pufmEbxeIVjlBz0LuSEuaRRu5rElLwwXnenf9cDwU54KRF.K', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (132, 'Syaifullah', 'I0718035', 'ifan.sfl7@student.uns.ac.id', NULL, '$2y$10$nJSmyANlEsTm80ve96uEcO7LBWqeUtZbj4kpTwXabTfr.qeQVg.Rm', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (133, 'Syauqy', 'I0718036', 'syauqymaulanar@student.uns.ac.id', NULL, '$2y$10$R80ncr0SJ3weDZJiWYxHDOOsaAsNsiKX0WAp/IJLZTJ6POZVzXVcS', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (134, 'Taufik', 'I0718037', 'taufikwidyastama@student.uns.ac.id', NULL, '$2y$10$B68eSa3Z0pvHRrXW1fwUZu8l9DWWiLpsKN7VGRaV4F.xx8JGOecdu', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (135, 'Izzuddin', 'I0719001', 'ulwan_1453@student.uns.ac.id', NULL, '$2y$10$NH4UaHeIczRcSX6D7itCteeF36R.4bU7ll53HQKu5V5CCLJG8O3yu', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (136, 'Abdul', 'I0719002', 'abdullatifpriyadi@student.uns.ac.id', NULL, '$2y$10$BROV.KshgcLd0BMv4Ct.ROHpbRlQsoK8Oeg.JFZ6otpsBrLz0fI1u', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (137, 'Abdul', 'I0719003', 'abdulqodirj23@student.uns.ac.id', NULL, '$2y$10$z9yjz8RGhS53zvjh6X8xhuOhyNagNQSsY4qGydOy3N0CkS.2X3fcq', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (138, 'Adriel', 'I0719004', 'adrielnugroho@student.uns.ac.id', NULL, '$2y$10$H9a8BSilKUSV4Ph3O5iSgODte9oOgvL.rN16bTdVkizC/Fzqy8zGm', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (139, 'Ahmad', 'I0719005', 'ahmadhanifsalladin@student.uns.ac.id', NULL, '$2y$10$7iYL77ikCmgXJse42Uri5udxxta2uK9PGcggWPNlklvmJkVVSEn5m', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (140, 'Aji', 'I0719006', 'ajighanang@student.uns.ac.id', NULL, '$2y$10$OdTtZQBqmJtRtZsHyuUTKOMT5gx.tp6Yn3US2zTJ1WFCjKt7bcm.O', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (141, 'Akbar', 'I0719007', 'akbarharmawan70@student.uns.ac.id', NULL, '$2y$10$xSbffU3j346c7Pu4n9zc7Oir2tIcwLArb67tRyhhfc3u0EDiEn5ta', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (142, 'Aldin', 'I0719008', 'aldin_wildan@student.uns.ac.id', NULL, '$2y$10$C/pUpBmpX7Kkj.HYzPz6NOLPnUTaZoRtENMcmDrL88oWSLdZ/2yZG', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (143, 'Alexander', 'I0719009', 'alexander22fls@student.uns.ac.id', NULL, '$2y$10$w1YzzVZrMnWPuqiKAqmiGuJ/i8XiOmIu38yn1XizgiFRcgtoRxJsq', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (144, 'Ali', 'I0719010', 'aliekatma@student.uns.ac.id', NULL, '$2y$10$fZKeEo6toyX3LxFd77/6K.EaFuPI7GM.m.Jr3o6RTMBQTgGqavC.e', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (145, 'Alloyus', 'I0719011', 'hansabram12@student.uns.ac.id', NULL, '$2y$10$CFVOeEkjwQVuzaNSC4MzfuSpBIeauA7NiJJ.hAPab2Qm.Nqh0.ohS', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (146, 'Anas', 'I0719012', 'anasmalikm@student.uns.ac.id', NULL, '$2y$10$KFt7JFSUB5aUI7RE57xQquHY/LSIOgmsByy4UZS1jzvFF8JvQ6Gv2', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (147, 'Andika', 'I0719013', 'andikasukma7@student.uns.ac.id', NULL, '$2y$10$VALEWPsGmQD/m/uYIDq0CeRDl/KCxFkDyzWMbHHqWEFW57oVnh4N6', NULL, NULL, '2020-07-02 12:39:14', '2020-07-02 12:39:14');
INSERT INTO `users` VALUES (148, 'Arif', 'I0719014', 'ariftok29072000@student.uns.ac.id', NULL, '$2y$10$7Ir23o4OJv2uUAwcnCk4Xus2NXIt2etMF6ABxTm.PhGRU.onWqaH2', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (149, 'As\'ad', 'I0719015', 'as_adsyahrul.32@student.uns.ac.id', NULL, '$2y$10$Hq.IUsmAhdjm0vQ9Az/fAOWWu.a.hwFWyv6DqDZveSducb2B86iBG', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (150, 'Attala', 'I0719016', 'attala.surya@student.uns.ac.id', NULL, '$2y$10$uZU6KrmZiyl5aWKNXwmrhepPYZRLGSoWMqFwrtxm3c1tNeAnWBAtm', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (151, 'Azis', 'I0719017', 'aziz.surya.3012@student.uns.ac.id', NULL, '$2y$10$WgsjJs4rbf/Ekjb/S17wHedD31TJTLOAnYOFi0zYwV5mu.DN/f/Ri', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (152, 'Aminuddin', 'I0719019', 'daffa.am99@student.uns.ac.id', NULL, '$2y$10$qQiJx/Ta9njLxzWBibhsqOLLLkOdSaxbC.WvYZVpPG7jV7F1MSGIC', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (153, 'Adi', 'I0719020', 'damarisadiwaskitho2002@student.uns.ac.id', NULL, '$2y$10$nj/FvbgD1W/gKjGslJFuwOnezKDySV5K2c3cRD53sJ.OSZHTSN6ri', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (154, 'Kartika', 'I0719021', 'dikavia0910@student.uns.ac.id', NULL, '$2y$10$.qJSeilfw25kHni7i/zZ2um3cMNyJhudpcXq1u8pHCjJGiD6nscPq', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (155, 'Mifika', 'I0719022', 'dinamifikas@student.uns.ac.id', NULL, '$2y$10$rZUM5YzJTRZrKU7F3jEfy.GCtdhU/bzoCxPWdPiCtKP9UmwdWke.S', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (156, 'Izzul', 'I0719023', 'faiqizzul@student.uns.ac.id', NULL, '$2y$10$JH.Tnt4DAqOHVRaUnc6nsuLWquhSQzQBzhNyZlCe5r6H1GOEh0nJO', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (157, 'Annisa', 'I0719024', 'fatimaharaniannisa@student.uns.ac.id', NULL, '$2y$10$gPvFGynvYMb.J4SE0B.N2.y/yqIDNbSsNM/q.197kymJI3ivREGjC', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (158, 'Rahman', 'I0719025', 'javierfazlur@student.uns.ac.id', NULL, '$2y$10$jHqEP/gQtuqoJy6WLYVJJeGpX3qf7hYnSiGTnXhLdyP9CUCKPgooe', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (159, 'Haiqal', 'I0719026', 'fiqihaiqal@student.uns.ac.id', NULL, '$2y$10$USRYpM1IQ9XZxKKNXoWRpOUfNKfnmUDZACqQdP38/JSNsFwiTvUri', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (160, 'Romadhon', 'I0719027', 'fitrohromadhon@student.uns.ac.id', NULL, '$2y$10$u7VH.t5H9AX2jUDBdAdX6.6b.gOzElzy5at7o.fK4o/OLozh0r4Jm', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (161, 'Fajar', 'I0719028', 'ganesyafajar@student.uns.ac.id', NULL, '$2y$10$v3a0tAZM84r7E2ddE86.QetCg9CIt81x9KD94d8taIl3gdyF8l9Om', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (162, 'Rahmad', 'I0719029', 'geovani.ri2001@student.uns.ac.id', NULL, '$2y$10$bVomwOuFwxXHrbBs.E7x5OR6b2SiUB79rb4HNLt.BDpgKBn4gFWl.', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (163, 'Lukman', 'I0719030', 'gustavadhi@student.uns.ac.id', NULL, '$2y$10$TjbhAgsxfKh6xK4C3IQvEe88TZ6BGgIb9IxiFDn6bSc3PBTN2b6FC', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (164, 'Wisti', 'I0719031', 'hanifwistijulitama@student.uns.ac.id', NULL, '$2y$10$URiZAe02Ns.kJjn4FJ5/yOMdsan7SZ7YcOC5As8G1zesmCivSrmyy', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (165, 'Yusuf', 'I0719032', 'hayyanyusuf@student.uns.ac.id', NULL, '$2y$10$Ma0QehGI1069l5EysceuB.bSJt1qyg9njJxpQo0U1k03kqksV4.zi', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (166, 'Hafidzsyah', 'I0719033', 'hilwan1412@student.uns.ac.id', NULL, '$2y$10$86A9UiRzHNbS31fNrd7b4OudaBzLaD/GQccxOFj22KE2Cj7QSNmCa', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (167, 'Qoyim', 'I0719034', 'ibnu.qoyim86@student.uns.ac.id', NULL, '$2y$10$qUynoJ/UXUhgU/UuTu1iEeLchh9wdbiE/lxQVBfKq7BVb7NCNW84q', NULL, NULL, '2020-07-02 12:39:15', '2020-07-02 12:39:15');
INSERT INTO `users` VALUES (168, 'Chrismastyanto', 'I0719035', 'immanuelchrismastya@student.uns.ac.id', NULL, '$2y$10$P2CFoZ0hbriCZ80aEdn9b.Enxxx1tSaIV.yA58WydEdp.aNSMAFmK', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (169, 'Salsabila', 'I0719036', 'jihansalsabila556@student.uns.ac.id', NULL, '$2y$10$5D9uCcM/WT.RmaU7ZKzlZOjn4JV1CUM4Ua5PA9tbPxtNgLY76sGEa', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (170, 'Pandu', 'I0719037', 'kresnapandu13@student.uns.ac.id', NULL, '$2y$10$xUOgskZqPzm0GP7y9yyy9.vZRddQtqET7wFsU5K3U0HvoUikCK27y', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (171, 'Hadi', 'I0719038', 'luqmanhadi07@student.uns.ac.id', NULL, '$2y$10$cFWOqojhCx.P3g5PENzlQuaiXCoT6BRMyTEGgkqpasFnci6j.Ljry', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (172, 'Nur', 'I0719039', 'mahaputranur.23@student.uns.ac.id', NULL, '$2y$10$nKYobDy4GGP9Y66kInptfut9TocPyrk6GmjfevSc7/EA7GOQ5.ij2', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (173, 'Reindhard', 'I0719040', 'mark766hi@student.uns.ac.id', NULL, '$2y$10$waSWWmdDHWTK6emoDGdC5Opa7QoXZOJHDJr2FPYQsFP9b8dSRbOV2', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (174, 'Afif', 'I0719041', 'maaf2889@student.uns.ac.id', NULL, '$2y$10$a9qnXq/UhWHhvXZb6KXFDunBm3Fe0wby6SWJnAPy1FxPvEhh4egj2', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (175, 'Ismail', 'I0719043', 'muchsin_ismail@student.uns.ac.id', NULL, '$2y$10$8unmasQ2i2/7A51RZXVNcO84uG5r3DzBaKpyoisHYeAd0NfEwp9Z2', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (176, 'Ardhana', 'I0719044', 'syahputra.ardhana@student.uns.ac.id', NULL, '$2y$10$eEoWsJqbx/PO5t25BnZRy.JvJxfuviFUpHm1ysPruGplM5b6cbmfq', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (177, 'Ariz', 'I0719045', 'fakhruddin.ariz@student.uns.ac.id', NULL, '$2y$10$geCDyF0FqKMsrP7QNCF7tO8Pk4ysghM.C3bygVTmlBWMdYWX5ALxa', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (178, 'Dhafier', 'I0719046', 'dhafier@student.uns.ac.id', NULL, '$2y$10$1Iz/iM.HfrvvnjlEzfrEpuMlQ23jd5CqtqfcAtPnJgowud0Fz6JZy', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (179, 'Fikri', 'I0719047', 'muhfikria@student.uns.ac.id', NULL, '$2y$10$z1hWZ8QQMF6oYb69XX/ZGeAfgbi77H.LKc4HTk3Qz34br1Of7ZC..', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (180, 'Haris', 'I0719048', 'harishumaidi@student.uns.ac.id', NULL, '$2y$10$2JNPLHPSs7oV/5KKc5FjpuMrq6Sn.8FbJ2z902kmaEMGVu/jPeds.', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (181, 'Hasya', 'I0719049', 'muhammad_hasya123@student.uns.ac.id', NULL, '$2y$10$zemFD1wp10Rm/JaGnUfZbO7Qrjbl6ahwML6cjglTxGLl2niIdXn7C', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (182, 'Raflie', 'I0719050', 'rafliepangestuuu@student.uns.ac.id', NULL, '$2y$10$05ggneCtjZdtld6Ow.PJcOwrABMyVFszXJbnnRcETMx15nCW/R/gC', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (183, 'Rifqi', 'I0719051', 'rifki.rk69@student.uns.ac.id', NULL, '$2y$10$5uD.W3vDeSJ412oC6OwXZu/rQG1Crrv5zDqtoHEYQXjndcDOAjNkS', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (184, 'Shafiy', 'I0719052', 'wibishafy@student.uns.ac.id', NULL, '$2y$10$UYij/ZCzIyspzMjysjtBIeCOWiM/solWenXasK4XJFqFR2UGaRjcW', NULL, NULL, '2020-07-02 12:39:16', '2020-07-02 12:39:16');
INSERT INTO `users` VALUES (185, 'Wildan', 'I0719053', 'alfa.tih@student.uns.ac.id', NULL, '$2y$10$e6af0TuHbP6PFPQH2DqCp.z5NugjveTBtKV10giaJ0oVpoDA08WPC', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (186, 'Dwi', 'I0719055', 'mukhlisdwin@student.uns.ac.id', NULL, '$2y$10$dyGbEP5udpViqAJrbnHtn.BUkhn3xkJoVlxTXcTFL2bCHybds7C/q', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (187, 'Puteri', 'I0719056', 'nadyaputerinurutomo.puput23@student.uns.ac.id', NULL, '$2y$10$weEUump9WCJ1Clyt3Zsp9e/g2ZKtdxzQ2YGIcP7GG1UqgLZ6M3gF6', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (188, 'Dhani', 'I0719058', 'oemardhanier@student.uns.ac.id', NULL, '$2y$10$YsZpG9EPSotL8jqZ84PwF.jnvI.tz2JmxO7zL.G9a/H29ds1BD/bK', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (189, 'Tigris', 'I0719059', 'tigrispero@student.uns.ac.id', NULL, '$2y$10$9oP27dTgt7cPoy0c.dQTPuT9/o.rRw1uddts61ZRmW/U7cHI01mlq', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (190, 'Wiratama', 'I0719060', 'pramudyaat@student.uns.ac.id', NULL, '$2y$10$4XivoWIddetnjdSO6kwUx.aaRxiq7ZJe1OMPopm7nmkO/qi5sFk8W', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (191, 'Maulana', 'I0719061', 'putramy18@student.uns.ac.id', NULL, '$2y$10$Eorlu7j3obPVRqep85iTDu08cRL3LXlkrMW8ruWz9EKY0S7FbcdHC', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (192, 'Panhardyansyah', 'I0719062', 'rafipanhard001@student.uns.ac.id', NULL, '$2y$10$tGbN692oLTJG/wKbXiuQ7OjRla5i1XrGYZiSldmNk65GnK1n0AUy6', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (193, 'Basu', 'I0719064', 'refansyah_dewa@student.uns.ac.id', NULL, '$2y$10$h7DShynWU0cYWWMPwR3Vue.z2o6Kf2omUJLFd2c45UJvz4NNZN26m', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (194, 'Aston', 'I0719065', 'ric.aston777@student.uns.ac.id', NULL, '$2y$10$3J06oxjMaP4ZBsnWhJy/g.HAeEwd0PtbKJpt6svXXGPykkcFKuUz.', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (195, 'Nurbiksa', 'I0719066', 'royyannurbiksa7@student.uns.ac.id', NULL, '$2y$10$0sAmsOGc6uVEjmQ4LjMp9OUg7zmyV1twpSllXuPb8LHAZlnmqmIPG', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (196, 'Ananda', 'I0719067', 'salsabilaanandaa@student.uns.ac.id', NULL, '$2y$10$TmqsLLi3qIIN9JRhKtGW4OafoIjP4W0N3CaVeFceYE28xIJDnDr4G', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (197, 'Lemuel', 'I0719068', 'serafim_lemuel@student.uns.ac.id', NULL, '$2y$10$CFnLT9b8LoyT6dvObVGDMOXQ4gspU4kKo.e5wBMfJ8HDKT1DUR6WC', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (198, 'Widyaningrum', 'I0719069', 'stefaniwidyaningrum@student.uns.ac.id', NULL, '$2y$10$g2hKkMNNfKb6ti9ktu7yLOWW/p0t8j2DRL01GwRTLcG3ugzV3TGta', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (199, 'Marcellindo', 'I0719070', 'stefanus.marcellindo@student.uns.ac.id', NULL, '$2y$10$Y94Qr6VC3cfBrAUowDPmO.VnwZ7Q/ZsXkL1IssM3cLN454/hruzsa', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (200, 'Sahdha', 'I0719071', 'talib_sahdha@student.uns.ac.id', NULL, '$2y$10$9Lr2fZW96OMv6V5uA2BMUORnSc5FCF0i/A/zNBk5Ot40tAgOZREhK', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (201, 'Aji', 'I0719072', 'wahonoaji92@student.uns.ac.id', NULL, '$2y$10$eE0wK8NU4xZYqh7kY3q7sef2DQL721GFeY.SMaXk5lyf4tOLsbW/e', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (202, 'Kusumojati', 'I0719073', 'umajawa26@student.uns.ac.id', NULL, '$2y$10$TeXCjxivticsUbRATeUoTOpg45Jp4WXwoN34G.zDcMmwqKDRZeUf6', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (203, 'Titovandaru', 'I0719074', 'wisangtitovanda@student.uns.ac.id', NULL, '$2y$10$yWQfO8fjCQ./2mKsbkAXmuwSWj7TTMsM1UuVi6fqGRkOdyj2cEndO', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (204, 'Alvin', 'I0719075', 'zaidanalvin@student.uns.ac.id', NULL, '$2y$10$r8A.lADfIoP6iXfFbAGFfuhpS.uph9QjdxH3MSqem3vK9kngdCKZu', NULL, NULL, '2020-07-02 12:39:17', '2020-07-02 12:39:17');
INSERT INTO `users` VALUES (205, 'Juan', 'I0719076', 'zulfikarpramasta@student.uns.ac.id', NULL, '$2y$10$tFeBwP0IQAGnUG/DJt3MquQV9A3UUTA/7w6MrsQ6C1SQuYOqkoWyi', NULL, NULL, '2020-07-02 12:39:18', '2020-07-02 12:39:18');
INSERT INTO `users` VALUES (206, 'Danish', 'I0719077', 'teukudanish@student.uns.ac.id', NULL, '$2y$10$e9gH.xPBhWfNcVg7wnDz4.EOTFQhOXylsHcdPx9Ez.NqlVP.DKNxq', NULL, NULL, '2020-07-02 12:39:18', '2020-07-02 12:39:18');
INSERT INTO `users` VALUES (207, 'boni', 'I0714009', 'boni@gmail.com', NULL, '$2y$10$wUmhZKv3pU/ar02YyX7g7.heHBKdWULC2HzvKVIUi1O15rffLQpv2', NULL, 1, '2020-07-04 22:45:28', '2020-07-08 08:00:47');
INSERT INTO `users` VALUES (208, 'iqbal', 'I0714022', 'iqbal@gmail.com', NULL, '$2y$10$NJ..V5fo7xLrXArXw1WubelBlatzXZFsL6NljC.bKd.rAk.0gTDWC', NULL, NULL, '2020-07-04 22:48:03', '2020-07-04 22:48:03');
INSERT INTO `users` VALUES (209, 'reynaldi', 'I0714026', 'reynaldi@gmail.com', NULL, '$2y$10$XzWXPmBB8W0pQ54lQ5lRb.qFQrEadT.IcpJ7YP9ROIxSTYcuEwkcO', NULL, 1, '2020-07-04 22:48:51', '2020-07-04 22:58:27');
INSERT INTO `users` VALUES (210, 'khoiri', 'I0719018', 'khoiri@gmail.com', NULL, '$2y$10$EpTYbiV8SjcC9UxtzmsJbeZc.HUDINruQjabIp2Uu.20.JT99c1MS', NULL, NULL, '2020-07-04 22:49:22', '2020-07-04 22:49:22');
INSERT INTO `users` VALUES (211, 'Ajii', 'I0719042', 'aji@gmail.com', NULL, '$2y$10$nByFsi33zazpCR1eWgLDu.53RUfX4AtOGAak7gd9tXS8/UZfuGS/.', NULL, NULL, '2020-07-04 22:50:24', '2020-07-04 22:50:24');
INSERT INTO `users` VALUES (212, 'Dosen1', '100000000000001', 'dosen1@gmail.com', NULL, '$2y$10$oetbhB8ALVCm3rG5JLzOHeS.wn4jDhrpGXZD1FxDLYq5RSSILEHMm', NULL, 1, '2020-07-04 22:51:57', '2020-07-04 22:54:13');
INSERT INTO `users` VALUES (213, 'wahid', 'I0715027', 'haizim@student.uns.ac.id', NULL, '$2y$10$.Woiq4tJJ9pUtDPZuQc7muMRqB1jmT.oqcVVh1okkBtJCg9dSeNYy', NULL, 1, '2020-07-11 09:20:50', '2020-07-11 09:26:18');
INSERT INTO `users` VALUES (214, 'Yann', 'I0715037', 'perdanayan32@student.uns.ac.id', NULL, '$2y$10$wQ5HoGa8gxGIp4tozgoFeuXeKaXZmY/nGZGogqElqPs9EcVA/iMjO', NULL, 1, '2020-07-13 18:43:45', '2020-07-13 18:51:55');
INSERT INTO `users` VALUES (215, 'Liaa', 'I0715020', 'lianwtl@student.uns.ac.id', NULL, '$2y$10$l8SpmXhIXMNtNB6xpcnnkObHGliN2a/vEd5Zl4xXCBQVtNtWQCE7G', NULL, 1, '2020-07-15 14:46:19', '2020-07-15 14:57:36');
INSERT INTO `users` VALUES (216, 'ramanda', 'I0715030', 'ramandaf@student.uns.ac.id', NULL, '$2y$10$P3LjYTz3GsKOjMHNh0hcc.tr7wQQGJQSdJurmzO67sJzz5ncy0mrS', NULL, 1, '2020-07-20 10:32:25', '2020-07-20 10:36:07');
INSERT INTO `users` VALUES (217, 'Latif', 'I0715018', 'latifnurfauzi@student.uns.ac.id', NULL, '$2y$10$c.9wHaWBT4xBEi.boN.F3eGYNDmlcRBGQPw0QnEDEbLRvhrIBGGSq', NULL, 1, '2020-07-20 17:16:42', '2020-07-20 17:19:54');
INSERT INTO `users` VALUES (218, 'Artur', 'I0715007', 'arthur.titus@student.uns.ac.id', NULL, '$2y$10$0.ksi1IyDE2b.EMRKRBnpOLq6GB8vdPJL5B3FbE976M2DKKCyaEgu', NULL, 1, '2020-07-21 18:30:20', '2020-07-27 10:34:20');
INSERT INTO `users` VALUES (220, 'faisal.rahutomo', '197711162005011008', 'dr.eng.faisal.r@gmail.com', NULL, '$2y$10$SV8V5mRL5W6AJg/UZnB1OeXPhKIxvfsjwdiNgW77Sk1j9asKLzzRe', NULL, 1, '2020-07-21 20:42:19', '2020-07-22 10:36:16');
INSERT INTO `users` VALUES (221, 'nanang.wiyono@staff.uns.ac.id', '197605302002121002', 'nanang.wiyono@staff.uns.ac.id', NULL, '$2y$10$l0FFR9UbbU9NPymnWeMD5ezabN8BFVB53fSUrgQZF4JSvmL0DZBMu', NULL, 1, '2020-07-28 12:42:30', '2020-08-03 16:59:53');
INSERT INTO `users` VALUES (222, 'cesar@student.uns.ac.id', 'I0715008', 'cesar@student.uns.ac.id', NULL, '$2y$10$WniTyvKKwtumiaQeP1nhSuRB8h0RORXrwmoBUwpg9h5AsNcmZ2QNu', NULL, 1, '2020-07-28 12:44:53', '2020-07-28 12:46:11');

SET FOREIGN_KEY_CHECKS = 1;
